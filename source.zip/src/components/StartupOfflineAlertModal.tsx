import React, { useEffect, useState } from 'react';
import { X, WifiOff, CheckCircle2, Loader2 } from 'lucide-react';
import { Button } from './ui/Button.tsx';

export const OFFLINE_ALERT_RETRY_MESSAGE = 'Internet abhi off hai';

export interface OfflineDialogControllerDeps {
  refreshStatus: () => Promise<{ connected: boolean }>;
  isDialogOpen: () => boolean;
  onDismissDialog: () => void;
  onSetOnline: (connected: boolean) => void;
  onDrainQueue: () => Promise<any>;
  debounceMs?: number;
}

export interface OfflineDialogController {
  reset: () => void;
  handleUseOnline: () => Promise<boolean>;
  handleUseOffline: () => void;
  handleManualDismiss: () => void;
  handleNetworkChange: (connected: boolean) => void;
  cleanup: () => void;
}

/**
 * Coordinates "Use Online" verification and debounced automatic dismissal
 * when verified internet connectivity returns. Reuses the app's existing
 * refresh/reachability probe and queue drain functions without polling.
 */
export function createOfflineDialogController(
  deps: OfflineDialogControllerDeps
): OfflineDialogController {
  const debounceMs = deps.debounceMs ?? 250;
  let onlineTransitionCompleted = false;
  let autoDismissTimer: ReturnType<typeof setTimeout> | null = null;
  let inFlightUseOnline: Promise<boolean> | null = null;

  const clearAutoDismissTimer = () => {
    if (autoDismissTimer !== null) {
      clearTimeout(autoDismissTimer);
      autoDismissTimer = null;
    }
  };

  const completeOnlineTransition = () => {
    if (onlineTransitionCompleted) {
      return;
    }
    onlineTransitionCompleted = true;
    clearAutoDismissTimer();
    deps.onSetOnline(true);
    deps.onDismissDialog();
    Promise.resolve(deps.onDrainQueue()).catch(() => {});
  };

  return {
    reset() {
      onlineTransitionCompleted = false;
      clearAutoDismissTimer();
    },

    async handleUseOnline(): Promise<boolean> {
      if (inFlightUseOnline) {
        return inFlightUseOnline;
      }

      inFlightUseOnline = (async () => {
        try {
          const status = await deps.refreshStatus();
          if (status.connected) {
            completeOnlineTransition();
            return true;
          }
          deps.onSetOnline(false);
          return false;
        } catch {
          deps.onSetOnline(false);
          return false;
        } finally {
          inFlightUseOnline = null;
        }
      })();

      return inFlightUseOnline;
    },

    handleUseOffline() {
      clearAutoDismissTimer();
      deps.onDismissDialog();
    },

    handleManualDismiss() {
      clearAutoDismissTimer();
      deps.onDismissDialog();
    },

    handleNetworkChange(connected: boolean) {
      if (!connected) {
        clearAutoDismissTimer();
        deps.onSetOnline(false);
        return;
      }

      if (!deps.isDialogOpen() || onlineTransitionCompleted) {
        return;
      }

      clearAutoDismissTimer();
      autoDismissTimer = setTimeout(async () => {
        autoDismissTimer = null;
        if (!deps.isDialogOpen() || onlineTransitionCompleted) {
          return;
        }
        try {
          const confirmed = await deps.refreshStatus();
          if (confirmed.connected && deps.isDialogOpen() && !onlineTransitionCompleted) {
            completeOnlineTransition();
          }
        } catch {
          // Reachability failed — keep dialog open
        }
      }, debounceMs);
    },

    cleanup() {
      clearAutoDismissTimer();
    }
  };
}

interface StartupOfflineAlertModalProps {
  isOpen: boolean;
  isOnline?: boolean;
  onClose: () => void;
  onUseOffline: () => void;
  onUseOnline?: () => boolean | void | Promise<boolean | void>;
}

export const StartupOfflineAlertModal: React.FC<StartupOfflineAlertModalProps> = ({
  isOpen,
  isOnline = false,
  onClose,
  onUseOffline,
  onUseOnline
}) => {
  const [offlineMessage, setOfflineMessage] = useState<string | null>(null);
  const [isCheckingOnline, setIsCheckingOnline] = useState<boolean>(false);

  useEffect(() => {
    if (!isOpen || isOnline) {
      setOfflineMessage(null);
      setIsCheckingOnline(false);
    }
  }, [isOpen, isOnline]);

  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleUseOnlineClick = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!onUseOnline) {
      onClose();
      return;
    }

    setIsCheckingOnline(true);
    try {
      const result = await onUseOnline();
      if (result === false) {
        setOfflineMessage(OFFLINE_ALERT_RETRY_MESSAGE);
      } else {
        setOfflineMessage(null);
      }
    } catch {
      setOfflineMessage(OFFLINE_ALERT_RETRY_MESSAGE);
    } finally {
      setIsCheckingOnline(false);
    }
  };

  const handleUseOfflineClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setOfflineMessage(null);
    onUseOffline();
  };

  const handleCloseClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setOfflineMessage(null);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 overflow-y-auto">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs transition-opacity duration-200"
        onClick={handleCloseClick}
      />

      {/* Dialog container */}
      <div
        role="dialog"
        aria-modal="true"
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl border border-slate-200/80 z-10 overflow-hidden text-left animate-in fade-in zoom-in-95 duration-200"
      >
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-amber-500/10 via-slate-50 to-transparent">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-700 flex items-center justify-center font-bold">
              <WifiOff className="w-5 h-5 text-amber-600" />
            </div>
            <div>
              <h3 className="font-extrabold text-base text-slate-900 tracking-tight">
                No Internet Connection
              </h3>
              <p className="text-[11px] text-slate-500">
                Offline Mode Available
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={handleCloseClick}
            className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center transition-colors cursor-pointer"
            aria-label="Close offline alert"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4">
          <p className="text-sm text-slate-600 leading-relaxed">
            You are currently offline. You can continue using SPLITO to record expenses and manage your spaces. All entries are saved locally and will automatically synchronize when connectivity is restored.
          </p>

          {/* Action Buttons */}
          <div className="space-y-2 pt-2">
            <Button
              type="button"
              variant="primary"
              size="lg"
              onClick={handleUseOfflineClick}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-2xl flex items-center justify-center gap-2 shadow-md shadow-blue-600/20 cursor-pointer"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Use Offline</span>
            </Button>

            <Button
              type="button"
              variant="secondary"
              size="lg"
              disabled={isCheckingOnline}
              onClick={handleUseOnlineClick}
              className="w-full font-semibold text-slate-700 border border-slate-200 rounded-2xl cursor-pointer flex items-center justify-center gap-2"
            >
              {isCheckingOnline && <Loader2 className="w-4 h-4 animate-spin text-slate-500" />}
              <span>Use Online</span>
            </Button>

            {offlineMessage && (
              <p
                role="status"
                aria-live="polite"
                className="text-xs font-medium text-amber-700 text-center pt-1"
              >
                {offlineMessage}
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
