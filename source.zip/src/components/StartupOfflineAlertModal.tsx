import React, { useEffect } from 'react';
import { X, WifiOff, CheckCircle2 } from 'lucide-react';
import { Button } from './ui/Button.tsx';

interface StartupOfflineAlertModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUseOffline: () => void;
  onUseOnline?: () => void;
}

export const StartupOfflineAlertModal: React.FC<StartupOfflineAlertModalProps> = ({
  isOpen,
  onClose,
  onUseOffline,
  onUseOnline
}) => {
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleUseOnlineClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onUseOnline) {
      onUseOnline();
    } else {
      onClose();
    }
  };

  const handleUseOfflineClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onUseOffline();
  };

  const handleCloseClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 overflow-y-auto">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs transition-opacity duration-200"
        onClick={handleCloseClick}
      />

      {/* Dialog container */}
      <div
        role="dialog"
        aria-modal="true"
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl border border-slate-200/80 z-10 overflow-hidden text-left animate-in fade-in zoom-in-95 duration-200"
      >
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-amber-500/10 via-slate-50 to-transparent">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-700 flex items-center justify-center font-bold">
              <WifiOff className="w-5 h-5 text-amber-600" />
            </div>
            <div>
              <h3 className="font-extrabold text-base text-slate-900 tracking-tight">
                No Internet Connection
              </h3>
              <p className="text-[11px] text-slate-500">
                Offline Mode Available
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={handleCloseClick}
            className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center transition-colors cursor-pointer"
            aria-label="Close offline alert"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4">
          <p className="text-sm text-slate-600 leading-relaxed">
            You are currently offline. You can continue using SPLITO to record expenses and manage your spaces. All entries are saved locally and will automatically synchronize when connectivity is restored.
          </p>

          {/* Action Buttons */}
          <div className="space-y-2 pt-2">
            <Button
              type="button"
              variant="primary"
              size="lg"
              onClick={handleUseOfflineClick}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-2xl flex items-center justify-center gap-2 shadow-md shadow-blue-600/20 cursor-pointer"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Use Offline</span>
            </Button>

            <Button
              type="button"
              variant="secondary"
              size="lg"
              onClick={handleUseOnlineClick}
              className="w-full font-semibold text-slate-700 border border-slate-200 rounded-2xl cursor-pointer"
            >
              <span>Use Online</span>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};
