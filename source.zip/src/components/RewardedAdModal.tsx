import React, { useState, useEffect } from 'react';
import { Modal } from './ui/Modal.tsx';
import { Button } from './ui/Button.tsx';
import { Play, Sparkles, CheckCircle, ShieldCheck, Clock } from 'lucide-react';

interface RewardedAdModalProps {
  isOpen: boolean;
  onClose: () => void;
  exportType?: 'pdf' | 'csv';
  completedAds?: number;
  totalAdsRequired?: number;
  onAdCompleted?: (newCount: number) => void;
  onRewardGranted: () => void;
  onOpenUpgradeModal: () => void;
}

export const RewardedAdModal: React.FC<RewardedAdModalProps> = ({
  isOpen,
  onClose,
  exportType = 'pdf',
  completedAds = 0,
  totalAdsRequired = 3,
  onAdCompleted,
  onRewardGranted,
  onOpenUpgradeModal
}) => {
  const [isPlayingAd, setIsPlayingAd] = useState<boolean>(false);
  const [secondsRemaining, setSecondsRemaining] = useState<number>(5);

  const adsRequired = totalAdsRequired || 3;
  const currentAdNumber = Math.min(completedAds + 1, adsRequired);
  const counterLabel = `Ad ${currentAdNumber} of ${adsRequired}`;
  const exportLabel = exportType === 'csv' ? 'CSV' : 'PDF';

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isPlayingAd && secondsRemaining > 0) {
      timer = setTimeout(() => {
        setSecondsRemaining((prev) => prev - 1);
      }, 1000);
    } else if (isPlayingAd && secondsRemaining === 0) {
      setIsPlayingAd(false);
      setSecondsRemaining(5);
      const nextCount = completedAds + 1;
      if (onAdCompleted) {
        onAdCompleted(nextCount);
      }
      if (nextCount >= adsRequired) {
        onRewardGranted();
      }
    }
    return () => clearTimeout(timer);
  }, [isPlayingAd, secondsRemaining, completedAds, adsRequired, onAdCompleted, onRewardGranted]);

  const handleStartAd = () => {
    setIsPlayingAd(true);
    setSecondsRemaining(5);
  };

  const handleDismissAd = () => {
    if (isPlayingAd) {
      // Unfinished ad does NOT count (RW-03)
      setIsPlayingAd(false);
      setSecondsRemaining(5);
    }
    onClose();
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={isPlayingAd ? handleDismissAd : onClose}
      title={`Export ${exportType === 'csv' ? 'CSV Ledger' : 'Financial Statement'}`}
      subtitle={`Free plan includes optional sponsored export (${completedAds}/${adsRequired} completed)`}
      maxWidth="md"
    >
      <div className="space-y-4 text-left">
        {!isPlayingAd ? (
          <>
            {/* 3-Ad Progress Counter Banner (RW-02) */}
            <div className="p-3 bg-blue-50/70 border border-blue-200/80 rounded-2xl space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-blue-800 bg-white border border-blue-200 px-2.5 py-0.5 rounded-full shadow-2xs">
                    {counterLabel}
                  </span>
                  <span className="text-xs font-medium text-slate-700">
                    {completedAds === 0 && 'Complete 3 short test ads to unlock export'}
                    {completedAds === 1 && '1 of 3 completed • 2 more to unlock'}
                    {completedAds === 2 && '2 of 3 completed • 1 last ad to unlock!'}
                  </span>
                </div>
                <span className="text-[11px] font-mono font-bold text-blue-700 bg-white border border-blue-200 px-2 py-0.5 rounded-lg">
                  {completedAds}/{adsRequired}
                </span>
              </div>

              {/* 3 Step Pills */}
              <div className="grid grid-cols-3 gap-2 pt-0.5">
                {[1, 2, 3].map((step) => {
                  const isDone = completedAds >= step;
                  const isCurrent = completedAds + 1 === step;
                  return (
                    <div
                      key={step}
                      className={`py-1.5 px-2 rounded-xl border text-center transition-all ${
                        isDone
                          ? 'bg-emerald-50 border-emerald-300 text-emerald-800 font-bold'
                          : isCurrent
                          ? 'bg-blue-600 border-blue-700 text-white font-bold shadow-xs'
                          : 'bg-white/80 border-slate-200 text-slate-400 font-medium'
                      }`}
                    >
                      <span className="block text-[9px] uppercase tracking-wider">
                        {isDone ? '✓ Done' : isCurrent ? 'Next' : 'Pending'}
                      </span>
                      <span className="text-[11px]">Ad {step} of 3</span>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="p-4 bg-slate-50 border border-slate-200/80 rounded-2xl text-slate-700 text-xs space-y-2">
              <div className="flex items-center gap-2 text-slate-900 font-bold text-sm">
                <ShieldCheck className="w-4.5 h-4.5 text-blue-600" />
                <span>Zero Financial Data Shared</span>
              </div>
              <p className="leading-relaxed text-slate-600">
                SPLITO Free allows complete export of audit statements. To keep the service free, complete 3 quick 5-second test sponsor messages ({counterLabel}), or upgrade to SPLITO Pro for instant ad-free exports anytime. Only completed ads count.
              </p>
            </div>

            <div className="space-y-2.5 pt-1">
              <Button
                variant="primary"
                fullWidth
                size="lg"
                icon={<Play className="w-4 h-4 fill-current" />}
                onClick={handleStartAd}
              >
                Watch {counterLabel} (5s) to Unlock {exportLabel} (Free)
              </Button>

              <div className="relative py-2 text-center">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-slate-200" />
                </div>
                <span className="relative bg-white px-3 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                  Or Go Ad-Free
                </span>
              </div>

              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenUpgradeModal();
                }}
                className="w-full p-3.5 bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-700 hover:to-amber-800 text-white rounded-xl font-bold text-xs flex items-center justify-between shadow-md cursor-pointer transition-all"
              >
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-amber-300" />
                  <span>SPLITO Pro (Coming Soon)</span>
                </div>
                <span className="text-[10px] bg-white/20 border border-white/30 px-2 py-0.5 rounded-full uppercase tracking-wider font-extrabold">
                  Coming Soon
                </span>
              </button>
            </div>
          </>
        ) : (
          /* Simulated Test Ad Player */
          <div className="py-6 px-4 bg-slate-900 text-white rounded-2xl text-center space-y-4 border border-slate-800">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-800 text-slate-300 text-[10px] font-mono border border-slate-700">
              <Clock className="w-3 h-3 text-blue-400" />
              <span>AdMob Test Unit • {counterLabel} • Reward in {secondsRemaining}s</span>
            </div>

            <div className="py-6">
              <h4 className="text-lg font-bold text-slate-100">Sponsored Ad Preview ({counterLabel})</h4>
              <p className="text-xs text-slate-400 mt-1 max-w-xs mx-auto">
                No personal data, amounts, or space balances are sent to advertisers. Watch full 5 seconds to count.
              </p>
            </div>

            <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
              <div
                className="bg-blue-500 h-full transition-all duration-1000 ease-linear"
                style={{ width: `${((5 - secondsRemaining) / 5) * 100}%` }}
              />
            </div>
          </div>
        )}
      </div>
    </Modal>
  );
};
