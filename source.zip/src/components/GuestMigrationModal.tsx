import React, { useState } from 'react';
import { Space, Transaction } from '../types/finance.ts';
import { X, CloudUpload, CheckCircle2, AlertCircle, ArrowRight, ShieldCheck, RefreshCw } from 'lucide-react';
import { Button } from './ui/Button.tsx';

interface GuestMigrationModalProps {
  isOpen: boolean;
  guestSpaces: Space[];
  onClose: () => void;
  onMigrate: () => Promise<{ success: boolean; migratedSpaces: number; migratedTx: number; error?: string }>;
  onNotNow: () => void;
}

export const GuestMigrationModal: React.FC<GuestMigrationModalProps> = ({
  isOpen,
  guestSpaces,
  onClose,
  onMigrate,
  onNotNow
}) => {
  const [isMigrating, setIsMigrating] = useState(false);
  const [resultMessage, setResultMessage] = useState<string | null>(null);
  const [isError, setIsError] = useState(false);

  if (!isOpen || guestSpaces.length === 0) return null;

  const handleStartMigration = async () => {
    setIsMigrating(true);
    setResultMessage(null);
    setIsError(false);

    try {
      const res = await onMigrate();
      if (res.success) {
        setResultMessage(`Successfully transferred ${res.migratedSpaces} space(s) and ${res.migratedTx} transaction(s) to your cloud account!`);
        setTimeout(() => {
          onClose();
        }, 1500);
      } else {
        setIsError(true);
        setResultMessage(res.error || 'Migration could not complete all items. Local copies preserved.');
      }
    } catch (err: any) {
      setIsError(true);
      setResultMessage(err instanceof Error ? err.message : String(err));
    } finally {
      setIsMigrating(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-y-auto">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs transition-opacity duration-200"
        onClick={isMigrating ? undefined : onClose}
      />

      {/* Modal Dialog */}
      <div
        role="dialog"
        aria-modal="true"
        className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl border border-slate-200/80 z-10 overflow-hidden text-left animate-in fade-in zoom-in-95 duration-200"
      >
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-blue-500/10 via-emerald-500/5 to-transparent">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-blue-600 text-white flex items-center justify-center font-bold shadow-md shadow-blue-600/20">
              <CloudUpload className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-base text-slate-900 tracking-tight">
                Transfer Guest Data
              </h3>
              <p className="text-[11px] text-slate-500">
                Sync local ledger to your Google Account
              </p>
            </div>
          </div>

          {!isMigrating && (
            <button
              type="button"
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center transition-colors cursor-pointer"
              aria-label="Close"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Content */}
        <div className="p-5 space-y-4">
          <p className="text-sm text-slate-600 leading-relaxed">
            We noticed you have <strong>{guestSpaces.length} local space(s)</strong> created during your guest session. Would you like to transfer them into your signed-in account so they are backed up and synced across your devices?
          </p>

          <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
            <span className="text-xs font-bold text-slate-700 block uppercase tracking-wider">
              Spaces to transfer:
            </span>
            <div className="space-y-1 max-h-32 overflow-y-auto">
              {guestSpaces.map((sp) => (
                <div key={sp.id} className="flex items-center justify-between text-xs text-slate-800 font-semibold py-1">
                  <span className="truncate">{sp.name}</span>
                  <span className="text-[10px] text-slate-500 bg-white px-2 py-0.5 rounded-full border border-slate-200">
                    {sp.mode}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {resultMessage && (
            <div
              className={`p-3 rounded-2xl text-xs flex items-center gap-2 ${
                isError ? 'bg-rose-50 border border-rose-200 text-rose-800' : 'bg-emerald-50 border border-emerald-200 text-emerald-800 font-semibold'
              }`}
            >
              {isError ? <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" /> : <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />}
              <span>{resultMessage}</span>
            </div>
          )}

          {/* Action Buttons */}
          <div className="space-y-2 pt-2">
            <Button
              type="button"
              variant="primary"
              size="lg"
              disabled={isMigrating}
              onClick={handleStartMigration}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-2xl flex items-center justify-center gap-2 shadow-md shadow-blue-600/20 cursor-pointer"
            >
              {isMigrating ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Transferring Data...</span>
                </>
              ) : (
                <>
                  <ShieldCheck className="w-4 h-4" />
                  <span>Migrate Guest Data</span>
                </>
              )}
            </Button>

            {!isMigrating && (
              <Button
                type="button"
                variant="ghost"
                onClick={onNotNow}
                className="w-full font-semibold text-slate-600 hover:bg-slate-100 rounded-2xl cursor-pointer"
              >
                <span>Not Now</span>
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
