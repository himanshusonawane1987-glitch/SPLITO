import React, { useState } from 'react';
import { Space, MemberBalance, DebtSettlement, Member } from '../../types/finance.ts';
import {
  filterVisibleMemberBalances,
  formatMinorUnits,
  getCurrencyMeta
} from '../../lib/finance-engine.ts';
import { Card, CardHeader, CardTitle, CardContent } from '../ui/Card.tsx';
import { Button } from '../ui/Button.tsx';
import { Input } from '../ui/Input.tsx';
import { AmountDisplay, Heading, Label } from '../ui/Typography.tsx';
import {
  Users,
  CheckCircle2,
  AlertCircle,
  Plus,
  ArrowRight,
  ShieldCheck,
  TrendingDown,
  TrendingUp,
  UserCheck,
  Zap,
  FileCheck2,
  Receipt
} from 'lucide-react';

interface GroupsViewProps {
  space: Space;
  memberBalances: MemberBalance[];
  debtSettlements: DebtSettlement[];
  currentUserId: string;
  keepSettledTempParticipants?: boolean;
  onOpenSettleModal: (debt: DebtSettlement | null) => void;
  onOpenGenericSettlementModal: () => void;
  onViewSlipForDebt: (debt: DebtSettlement) => void;
  onAddMember: (memberName: string, memberEmail?: string) => Promise<void>;
  onOpenAddModal: (type: 'expense' | 'settlement') => void;
}

export const GroupsView: React.FC<GroupsViewProps> = ({
  space,
  memberBalances,
  debtSettlements,
  currentUserId,
  keepSettledTempParticipants = false,
  onOpenSettleModal,
  onOpenGenericSettlementModal,
  onViewSlipForDebt,
  onAddMember,
  onOpenAddModal
}) => {
  const [isAddingMember, setIsAddingMember] = useState(false);
  const [newMemberName, setNewMemberName] = useState('');
  const [newMemberEmail, setNewMemberEmail] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const currency = space.currency;
  const isPersonal = space.mode === 'personal';
  const meta = getCurrencyMeta(currency);

  const sumOfAllNetBalances = memberBalances.reduce((acc, b) => acc + b.netBalanceMinorUnits, 0);
  const visibleMemberBalances = filterVisibleMemberBalances(
    memberBalances,
    keepSettledTempParticipants
  );

  const handleAddMemberSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMemberName.trim()) return;
    setIsSubmitting(true);
    try {
      await onAddMember(newMemberName.trim(), newMemberEmail.trim() || undefined);
      setNewMemberName('');
      setNewMemberEmail('');
      setIsAddingMember(false);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-4 pb-24 text-left font-sans">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <Heading level={1}>
            {isPersonal ? 'Khata & Balances' : 'Smart Settlement & Group Dues'}
          </Heading>
          <p className="text-xs text-slate-500 mt-0.5">
            {space.members?.length || 1} members in {space.name} • Base: {currency} ({meta.name})
          </p>
        </div>

        <div className="flex items-center gap-2">
          {!isPersonal && (
            <Button
              size="sm"
              variant="outline"
              icon={<Plus className="w-3.5 h-3.5" />}
              onClick={() => setIsAddingMember(true)}
            >
              Add Member
            </Button>
          )}
          <Button
            size="sm"
            variant="primary"
            icon={<CheckCircle2 className="w-3.5 h-3.5" />}
            onClick={onOpenGenericSettlementModal}
          >
            Record Settlement
          </Button>
        </div>
      </div>

      {/* Add Member inline form */}
      {isAddingMember && (
        <Card className="border-blue-200 bg-blue-50/40">
          <CardContent className="pt-4 pb-4">
            <form onSubmit={handleAddMemberSubmit} className="space-y-3">
              <Label>Add Roommate / Space Member</Label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <Input
                  placeholder="Member name (e.g., Sneha, Vikrant)"
                  value={newMemberName}
                  onChange={(e) => setNewMemberName(e.target.value)}
                  required
                />
                <Input
                  placeholder="Optional email"
                  type="email"
                  value={newMemberEmail}
                  onChange={(e) => setNewMemberEmail(e.target.value)}
                />
              </div>
              <div className="flex items-center justify-end gap-2">
                <Button
                  type="button"
                  size="sm"
                  variant="secondary"
                  onClick={() => setIsAddingMember(false)}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  size="sm"
                  variant="primary"
                  isLoading={isSubmitting}
                >
                  Add Member
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {/* Zero-Sum Accounting Audit Banner */}
      <div className="p-3 bg-slate-50 border border-slate-200/80 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between text-xs gap-2">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
          <span className="font-semibold text-slate-700">Zero-Sum Ledger Audit Invariant:</span>
        </div>
        <div className="font-mono text-xs flex items-center gap-1.5">
          <span className="text-slate-500">Net Group Balance Σ = </span>
          <span className="font-bold text-slate-900">
            {formatMinorUnits(sumOfAllNetBalances, currency)}
          </span>
          <span className="text-emerald-600 font-bold">✓ (Reconciled)</span>
        </div>
      </div>

      {/* Smart Settlement: Minimal Cash Flow Matrix */}
      <Card>
        <CardHeader className="pb-2">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Zap className="w-4.5 h-4.5 text-amber-500" />
              <span>Smart Settlement Transfers</span>
            </CardTitle>
            <p className="text-xs text-slate-500 mt-0.5">
              Bounded backtracking eliminates circular debt into the minimum transfers needed
            </p>
          </div>
        </CardHeader>
        <CardContent className="space-y-2 pt-0">
          {debtSettlements.length === 0 ? (
            <div className="py-8 text-center">
              <div className="w-12 h-12 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto mb-2">
                <UserCheck className="w-6 h-6" />
              </div>
              <h4 className="font-bold text-sm text-slate-800">All Roommates are Settled Up!</h4>
              <p className="text-xs text-slate-500 mt-0.5">
                No active debts or outstanding transfers required in this space.
              </p>
            </div>
          ) : (
            <div className="space-y-2">
              {debtSettlements.map((debt, idx) => {
                const isPayer = debt.fromMemberId === currentUserId;
                const isReceiver = debt.toMemberId === currentUserId;
                const isTempDebt = Boolean(debt.fromIsTemporary || debt.toIsTemporary);

                return (
                  <div
                    key={idx}
                    className="p-3.5 rounded-xl bg-white border border-slate-200/90 hover:border-slate-300 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-2xs"
                  >
                    <div className="flex items-center gap-3">
                      <div className="flex items-center -space-x-1.5">
                        <div className="w-8 h-8 rounded-full bg-rose-100 text-rose-700 font-bold text-xs flex items-center justify-center border-2 border-white">
                          {debt.fromMemberName.charAt(0)}
                        </div>
                        <div className="w-8 h-8 rounded-full bg-emerald-100 text-emerald-700 font-bold text-xs flex items-center justify-center border-2 border-white">
                          {debt.toMemberName.charAt(0)}
                        </div>
                      </div>

                      <div className="text-xs">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className={`font-bold ${isPayer ? 'text-rose-600' : 'text-slate-900'}`}>
                            {debt.fromMemberName} {isPayer ? '(You)' : ''}
                          </span>
                          {debt.fromIsTemporary && (
                            <span className="text-[9px] font-bold text-amber-800 bg-amber-50 border border-amber-200/80 px-1.5 py-0.2 rounded">
                              Temp
                            </span>
                          )}
                          <span className="text-slate-400">pays</span>
                          <span className={`font-bold ${isReceiver ? 'text-emerald-600' : 'text-slate-900'}`}>
                            {debt.toMemberName} {isReceiver ? '(You)' : ''}
                          </span>
                          {debt.toIsTemporary && (
                            <span className="text-[9px] font-bold text-amber-800 bg-amber-50 border border-amber-200/80 px-1.5 py-0.2 rounded">
                              Temp
                            </span>
                          )}
                        </div>
                        {isTempDebt ? (
                          <span className="text-[11px] font-medium text-amber-700">
                            Temporary — settle outside the app
                          </span>
                        ) : (
                          <span className="text-[11px] text-slate-400">Direct settlement payment</span>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center justify-between sm:justify-end gap-2.5 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-100">
                      <AmountDisplay
                        minorUnits={debt.amountMinorUnits}
                        currency={currency}
                        size="metric"
                        variant="neutral"
                      />
                      <Button
                        size="sm"
                        variant="outline"
                        className="text-xs px-2.5 py-1"
                        icon={<FileCheck2 className="w-3.5 h-3.5 text-indigo-600" />}
                        onClick={() => onViewSlipForDebt(debt)}
                      >
                        View Slip
                      </Button>
                      {!isTempDebt && (
                        <Button
                          size="sm"
                          variant={isPayer ? 'primary' : 'outline'}
                          onClick={() => onOpenSettleModal(debt)}
                        >
                          Settle Up
                        </Button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Member Balances Breakdown — Strict Expense Share Separation */}
      <Card>
        <CardHeader className="pb-2">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Users className="w-4.5 h-4.5 text-slate-600" />
              <span>Member Balances Ledger</span>
            </CardTitle>
            <p className="text-xs text-slate-500 mt-0.5">
              Net balance sign convention: + (is owed by group) | − (owes to group)
            </p>
          </div>
        </CardHeader>
        <CardContent className="p-0 divide-y divide-slate-100">
          {visibleMemberBalances.map((m) => {
            const isCurrentUser = m.memberId === currentUserId;
            const isOwed = m.netBalanceMinorUnits > 0;
            const owes = m.netBalanceMinorUnits < 0;

            return (
              <div key={m.memberId} className="p-4 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div
                    className={`w-10 h-10 rounded-2xl flex items-center justify-center font-bold text-sm shrink-0 ${
                      isCurrentUser
                        ? 'bg-blue-600 text-white shadow-2xs'
                        : 'bg-slate-100 text-slate-700'
                    }`}
                  >
                    {m.memberName.charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="font-bold text-sm text-slate-900">{m.memberName}</span>
                      {isCurrentUser && (
                        <span className="text-[10px] font-bold text-blue-600 font-mono">
                          (You)
                        </span>
                      )}
                      {m.isTemporary && (
                        <span className="text-[9px] font-bold text-amber-800 bg-amber-50 border border-amber-200/80 px-1.5 py-0.2 rounded">
                          Temp
                        </span>
                      )}
                    </div>
                    {/* Share remains strictly consumption share of expenses (never inflated by settlements) */}
                    <div className="flex items-center gap-1.5 text-xs text-slate-500 mt-0.5 font-mono flex-wrap">
                      <span>Paid: {formatMinorUnits(m.totalExpensePaidMinorUnits, currency)}</span>
                      <span aria-hidden="true">·</span>
                      <span className="text-slate-800 font-semibold">
                        Share: {formatMinorUnits(m.totalExpenseShareMinorUnits, currency)}
                      </span>
                      {m.totalSettlementPaidMinorUnits > 0 && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="text-indigo-600">
                            Settled: −{formatMinorUnits(m.totalSettlementPaidMinorUnits, currency)}
                          </span>
                        </>
                      )}
                      {m.totalSettlementReceivedMinorUnits > 0 && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="text-emerald-600">
                            Received: +{formatMinorUnits(m.totalSettlementReceivedMinorUnits, currency)}
                          </span>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <AmountDisplay
                    minorUnits={m.netBalanceMinorUnits}
                    currency={currency}
                    size="row"
                    variant={isOwed ? 'owed' : owes ? 'owes' : 'neutral'}
                    showSign={isOwed}
                  />
                  <span className="text-[10px] text-slate-400 font-medium block">
                    {isOwed ? 'Gets back' : owes ? 'Owes' : 'Settled'}
                  </span>
                </div>
              </div>
            );
          })}
        </CardContent>
      </Card>
    </div>
  );
};
