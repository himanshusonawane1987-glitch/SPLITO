import React, { useState, useEffect } from 'react';
import { Space, UserProfile } from '../../types/finance.ts';
import { UserSubscription, SubscriptionEntitlement } from '../../types/subscription.ts';
import { LegalDocKey } from '../../lib/legal-content.ts';
import { Card, CardHeader, CardTitle, CardContent } from '../ui/Card.tsx';
import { Button } from '../ui/Button.tsx';
import { CurrencyInput, Input } from '../ui/Input.tsx';
import {
  User,
  ShieldCheck,
  Wallet,
  Settings,
  LogIn,
  LogOut,
  CheckCircle,
  AlertTriangle,
  Archive,
  RefreshCw,
  HardDrive,
  Sparkles,
  FileText,
  Trash2,
  Sliders,
  RotateCcw,
  Clock,
  ChevronRight,
  ShieldAlert,
  Database,
  Bell,
  Camera
} from 'lucide-react';

import { SyncStatus } from '../Header.tsx';
import { LogoutConfirmModal } from '../LogoutConfirmModal.tsx';
import {
  areExpenseRemindersEnabled,
  setExpenseRemindersEnabled,
  scheduleDailyTrollNotifications,
  getNotificationPermissionStatus,
  getNotificationDeniedGuidance,
  NotificationPermissionState
} from '../../lib/reminder-service.ts';
import { Transaction } from '../../types/finance.ts';

interface ProfileViewProps {
  space: Space;
  userProfile: UserProfile | null;
  currentUserEmail?: string | null;
  currentUserDisplayName?: string | null;
  profilePhotoUrl?: string | null;
  onUpdateProfilePhoto?: (photoUrl: string | null) => void;
  isAuthenticated: boolean;
  syncStatus?: SyncStatus;
  subscription?: UserSubscription;
  entitlement?: SubscriptionEntitlement;
  onLogin: () => void;
  onLogout: () => void;
  onUpdateSpaceDetails: (updates: Partial<Space>) => Promise<void>;
  onOpenSpaceSwitcher: () => void;
  onOpenSubscriptionModal?: () => void;
  onOpenLegalModal?: (docKey?: LegalDocKey) => void;
  onOpenConsentModal?: () => void;
  onOpenDeleteDataModal?: () => void;
  onOpenAccountDeletionModal?: () => void;
  spaces?: Space[];
  transactions?: Transaction[];
  onToggleReminders?: (enabled: boolean) => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  space,
  userProfile,
  currentUserEmail,
  currentUserDisplayName,
  profilePhotoUrl,
  onUpdateProfilePhoto,
  isAuthenticated,
  syncStatus = 'local-only',
  subscription,
  entitlement,
  onLogin,
  onLogout,
  onUpdateSpaceDetails,
  onOpenSpaceSwitcher,
  onOpenSubscriptionModal,
  onOpenLegalModal,
  onOpenConsentModal,
  onOpenDeleteDataModal,
  onOpenAccountDeletionModal,
  spaces,
  transactions,
  onToggleReminders
}) => {
  const [editingBalance, setEditingBalance] = useState<number>(space.startingBalance || 0);
  const [spaceName, setSpaceName] = useState<string>(space.name || '');
  const [isArchived, setIsArchived] = useState<boolean>(space.isArchived || false);
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [remindersEnabled, setRemindersEnabled] = useState<boolean>(() => areExpenseRemindersEnabled());
  const [permissionStatus, setPermissionStatus] = useState<NotificationPermissionState>('granted');
  const [reminderStatusMsg, setReminderStatusMsg] = useState<string | null>(null);
  const [reminderErrorMsg, setReminderErrorMsg] = useState<string | null>(null);
  const [isLogoutModalOpen, setIsLogoutModalOpen] = useState(false);
  const fileInputRef = React.useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    let mounted = true;
    const syncPermission = async () => {
      const status = await getNotificationPermissionStatus();
      if (!mounted) return;
      setPermissionStatus(status);
      if (status === 'granted' && areExpenseRemindersEnabled()) {
        await scheduleDailyTrollNotifications({ fromUserAction: false });
      }
    };
    syncPermission();

    const handleReturnFocus = () => {
      syncPermission();
    };
    if (typeof window !== 'undefined') {
      window.addEventListener('focus', handleReturnFocus);
    }
    return () => {
      mounted = false;
      if (typeof window !== 'undefined') {
        window.removeEventListener('focus', handleReturnFocus);
      }
    };
  }, []);

  const resolvedDisplayName = isAuthenticated
    ? (currentUserDisplayName || userProfile?.displayName || (currentUserEmail ? currentUserEmail.split('@')[0] : 'User'))
    : 'Guest User';

  const initialLetter = isAuthenticated ? resolvedDisplayName.charAt(0).toUpperCase() : 'G';

  const handlePhotoSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (loadEvent) => {
      const src = loadEvent.target?.result as string;
      if (!src) return;

      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const maxSize = 256;
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > maxSize) {
            height = Math.round((height * maxSize) / width);
            width = maxSize;
          }
        } else {
          if (height > maxSize) {
            width = Math.round((width * maxSize) / height);
            height = maxSize;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
          if (onUpdateProfilePhoto) {
            onUpdateProfilePhoto(dataUrl);
          }
        }
      };
      img.src = src;
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleToggleReminders = async () => {
    const nextVal = !remindersEnabled;
    setRemindersEnabled(nextVal);
    setReminderStatusMsg(null);
    setReminderErrorMsg(null);
    await setExpenseRemindersEnabled(nextVal);

    if (nextVal) {
      const res = await scheduleDailyTrollNotifications({
        force: true,
        fromUserAction: true
      });
      setPermissionStatus(res.permissionStatus);

      if (res.permissionStatus === 'denied') {
        setReminderErrorMsg(getNotificationDeniedGuidance('denied'));
      } else if (res.scheduledCount > 0) {
        setReminderStatusMsg('10 daily funny reminders scheduled across 24 hours');
        setTimeout(() => setReminderStatusMsg(null), 3500);
      } else {
        setReminderErrorMsg(res.error || 'Unable to schedule notifications on this device.');
      }
    } else {
      setReminderStatusMsg('Expense reminders disabled');
      setTimeout(() => setReminderStatusMsg(null), 3000);
    }

    if (onToggleReminders) {
      onToggleReminders(nextVal);
    }
  };

  const handleRecheckNotificationPermission = async () => {
    setReminderStatusMsg(null);
    setReminderErrorMsg(null);
    const res = await scheduleDailyTrollNotifications({
      force: true,
      fromUserAction: true
    });
    setPermissionStatus(res.permissionStatus);
    if (res.permissionStatus === 'granted' && res.scheduledCount > 0) {
      setRemindersEnabled(true);
      setReminderStatusMsg('10 daily funny reminders scheduled across 24 hours');
      setTimeout(() => setReminderStatusMsg(null), 3500);
    } else if (res.permissionStatus === 'denied') {
      setReminderErrorMsg(getNotificationDeniedGuidance('denied'));
    }
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setSaveSuccess(false);
    try {
      await onUpdateSpaceDetails({
        name: spaceName.trim() || space.name,
        currency: 'INR',
        startingBalance: editingBalance,
        isArchived
      });
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    } finally {
      setIsSaving(false);
    }
  };

  const handleToggleArchive = async () => {
    const nextState = !isArchived;
    setIsArchived(nextState);
    await onUpdateSpaceDetails({ isArchived: nextState });
  };

  const isPro = entitlement?.isPro || false;

  return (
    <div className="space-y-4 pb-24 text-left">
      {/* Title */}
      <div>
        <h2 className="text-xl font-extrabold text-slate-900 tracking-tight">Settings & Preferences</h2>
        <p className="text-xs text-slate-500">
          Account details, subscription plan, legal agreements, and space settings
        </p>
      </div>

      {/* Account & Profile Card (PF-02, PF-04, PF-05, PF-06) */}
      <Card className="bg-white">
        <CardContent className="p-5 sm:p-6 text-center sm:text-left">
          <div className="flex flex-col sm:flex-row items-center sm:items-start justify-between gap-5">
            <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4">
              {/* Profile Photo (DP) / Avatar Circle */}
              <div className="relative group shrink-0">
                <div className="w-20 h-20 rounded-full bg-blue-50 text-blue-700 flex items-center justify-center font-black text-2xl border-2 border-blue-200 overflow-hidden shadow-xs">
                  {profilePhotoUrl ? (
                    <img
                      src={profilePhotoUrl}
                      alt={resolvedDisplayName}
                      className="w-full h-full rounded-full object-cover"
                    />
                  ) : (
                    initialLetter
                  )}
                </div>
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  title="Change profile photo"
                  className="absolute bottom-0 right-0 p-1.5 bg-blue-600 text-white rounded-full hover:bg-blue-700 transition-colors shadow-xs cursor-pointer border-2 border-white"
                  aria-label="Change profile photo"
                >
                  <Camera className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Profile Details */}
              <div className="space-y-1 text-center sm:text-left">
                <div className="flex flex-col sm:flex-row sm:items-center gap-2">
                  <h3 className="font-extrabold text-lg text-slate-900 tracking-tight">
                    {resolvedDisplayName}
                  </h3>
                  {isAuthenticated ? (
                    syncStatus === 'CLOUD_CONFIRMED' ? (
                      <span className="inline-flex items-center gap-1 text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200/60 px-2 py-0.5 rounded-full mx-auto sm:mx-0">
                        <ShieldCheck className="w-3 h-3 text-emerald-600" /> Cloud confirmed
                      </span>
                    ) : syncStatus === 'WRITE_PENDING' ? (
                      <span className="inline-flex items-center gap-1 text-[10px] font-bold bg-blue-50 text-blue-700 border border-blue-200/60 px-2 py-0.5 rounded-full animate-pulse mx-auto sm:mx-0">
                        <RefreshCw className="w-3 h-3 text-blue-600 animate-spin" /> Saving...
                      </span>
                    ) : syncStatus === 'SYNCING' ? (
                      <span className="inline-flex items-center gap-1 text-[10px] font-bold bg-blue-50 text-blue-700 border border-blue-200/60 px-2 py-0.5 rounded-full animate-pulse mx-auto sm:mx-0">
                        <RefreshCw className="w-3 h-3 text-blue-600 animate-spin" /> Syncing...
                      </span>
                    ) : syncStatus === 'SYNC_FAILED' ? (
                      <span className="inline-flex items-center gap-1 text-[10px] font-bold bg-rose-50 text-rose-700 border border-rose-200/60 px-2 py-0.5 rounded-full mx-auto sm:mx-0">
                        <AlertTriangle className="w-3 h-3 text-rose-600" /> Sync failed
                      </span>
                    ) : syncStatus === 'CONFLICT' ? (
                      <span className="inline-flex items-center gap-1 text-[10px] font-bold bg-amber-50 text-amber-700 border border-amber-200/60 px-2 py-0.5 rounded-full mx-auto sm:mx-0">
                        <AlertTriangle className="w-3 h-3 text-amber-600" /> Conflict
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-[10px] font-bold bg-slate-100 text-slate-700 border border-slate-200 px-2 py-0.5 rounded-full mx-auto sm:mx-0">
                        <HardDrive className="w-3 h-3 text-slate-600" /> Local only
                      </span>
                    )
                  ) : (
                    <span className="inline-flex items-center gap-1 text-[10px] font-bold bg-slate-100 text-slate-600 border border-slate-200 px-2 py-0.5 rounded-full mx-auto sm:mx-0">
                      <HardDrive className="w-3 h-3 text-slate-500" /> Guest Local
                    </span>
                  )}
                </div>

                {/* Email (Google users) or Guest subtitle (PF-05) */}
                <p className="text-xs text-slate-500">
                  {isAuthenticated
                    ? currentUserEmail || 'Google Account'
                    : 'Guest account — sign in with Google to sync'}
                </p>

                {/* Change photo controls */}
                <div className="flex items-center justify-center sm:justify-start gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="text-xs font-semibold text-blue-600 hover:text-blue-700 flex items-center gap-1 cursor-pointer transition-colors"
                  >
                    <Camera className="w-3.5 h-3.5" />
                    <span>Change profile photo</span>
                  </button>
                  {profilePhotoUrl && (
                    <>
                      <span className="text-slate-300">•</span>
                      <button
                        type="button"
                        onClick={() => onUpdateProfilePhoto && onUpdateProfilePhoto(null)}
                        className="text-xs text-slate-400 hover:text-rose-600 cursor-pointer transition-colors"
                      >
                        Remove
                      </button>
                    </>
                  )}
                </div>
                {/* Hidden File Picker */}
                <input
                  type="file"
                  ref={fileInputRef}
                  accept="image/*"
                  onChange={handlePhotoSelect}
                  className="hidden"
                />
              </div>
            </div>

            {/* Logout / Login actions (PF-03) */}
            <div className="pt-2 sm:pt-0 shrink-0">
              {isAuthenticated ? (
                <Button
                  size="sm"
                  variant="outline"
                  icon={<LogOut className="w-3.5 h-3.5" />}
                  onClick={() => setIsLogoutModalOpen(true)}
                >
                  Sign Out
                </Button>
              ) : (
                <div className="flex flex-col sm:flex-row gap-2">
                  <Button
                    size="sm"
                    variant="primary"
                    icon={<LogIn className="w-3.5 h-3.5" />}
                    onClick={onLogin}
                  >
                    Sign In with Google
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => setIsLogoutModalOpen(true)}
                    className="text-slate-500 hover:text-rose-600"
                  >
                    Exit Guest Session
                  </Button>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* SPLITO Subscription Card */}
      <Card className="border-amber-200/80 bg-gradient-to-br from-white to-amber-50/20 overflow-hidden relative">
        <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/5 rounded-full blur-xl pointer-events-none" />
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between w-full">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4.5 h-4.5 text-amber-500" />
              <CardTitle>SPLITO Subscription</CardTitle>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-extrabold uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-800 border border-amber-300 shadow-2xs">
                COMING SOON
              </span>
              <span className="text-[10px] font-semibold text-slate-500 bg-slate-100 border border-slate-200 px-2 py-0.5 rounded-full">
                Free Plan Active
              </span>
            </div>
          </div>
        </CardHeader>
        <CardContent className="pt-2 space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3.5 bg-white rounded-2xl border border-slate-200/80 shadow-2xs">
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-sm text-slate-900 block">
                  SPLITO Pro
                </span>
                <span className="text-[9px] font-bold bg-amber-100 text-amber-800 border border-amber-300 px-1.5 py-0.2 rounded-md">
                  COMING SOON
                </span>
              </div>
              <p className="text-xs text-amber-900 font-medium mt-1">
                Premium features are on their way. Subscription will be available soon.
              </p>
              <p className="text-[11px] text-slate-500 mt-0.5">
                SPLITO Free plan active: All spaces, expenses, Smart Settlement, and core ledger features remain 100% free.
              </p>
            </div>

            <Button
              size="sm"
              variant="outline"
              onClick={onOpenSubscriptionModal}
              icon={<Sparkles className="w-3.5 h-3.5 text-amber-500" />}
              className="border-amber-300 text-amber-900 bg-amber-50/60 hover:bg-amber-100 font-bold shrink-0"
            >
              Coming Soon
            </Button>
          </div>

          <div className="flex items-center gap-2 text-[11px] text-slate-600 px-1">
            <Clock className="w-3.5 h-3.5 text-blue-600 shrink-0" />
            <span>
              Upcoming Pro pricing: <strong>₹59/month</strong> or <strong>₹599/year</strong> • Includes <strong>1-month free trial</strong> (Purchases launching soon)
            </span>
          </div>
        </CardContent>
      </Card>

      {/* Space Configuration */}
      <Card>
        <CardHeader className="pb-2">
          <div className="flex items-center gap-2">
            <Wallet className="w-4.5 h-4.5 text-blue-600" />
            <CardTitle>Space Configuration</CardTitle>
          </div>
          <Button size="sm" variant="ghost" onClick={onOpenSpaceSwitcher}>
            Switch Space
          </Button>
        </CardHeader>
        <CardContent className="pt-2">
          <form onSubmit={handleSaveSettings} className="space-y-4">
            <Input
              label="Space / Diary Name"
              value={spaceName}
              onChange={(e) => setSpaceName(e.target.value)}
              required
            />

            <div>
              <CurrencyInput
                label="Starting Cash Balance"
                paise={editingBalance}
                onChangePaise={setEditingBalance}
                currency="INR"
                hint="Starting cash balance in INR (₹)"
              />
            </div>

            {/* Space Archiving */}
            <div className="p-3.5 bg-slate-50 border border-slate-200/80 rounded-xl flex items-center justify-between">
              <div>
                <span className="font-bold text-xs text-slate-900 block">Archive Financial Space</span>
                <span className="text-[11px] text-slate-500">
                  Archived spaces become read-only while preserving complete audit history
                </span>
              </div>
              <button
                type="button"
                onClick={handleToggleArchive}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-colors ${
                  isArchived
                    ? 'bg-amber-100 text-amber-800 border border-amber-300'
                    : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                {isArchived ? 'Archived (Read-Only)' : 'Archive Space'}
              </button>
            </div>

            {saveSuccess && (
              <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-700 rounded-xl text-xs font-medium flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Space settings saved successfully!</span>
              </div>
            )}

            <Button type="submit" variant="primary" isLoading={isSaving} size="md">
              Save Space Changes
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* Notifications & Reminders */}
      <Card>
        <CardHeader className="pb-2">
          <div className="flex items-center gap-2">
            <Bell className="w-4.5 h-4.5 text-blue-600" />
            <CardTitle>Notifications & Reminders</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="pt-2 space-y-3">
          <div className="p-3.5 bg-slate-50 border border-slate-200/80 rounded-xl flex items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-xs text-slate-900 block">Expense reminders</span>
                <span
                  className={`text-[9px] font-bold px-1.5 py-0.5 rounded-md ${
                    remindersEnabled && permissionStatus === 'denied'
                      ? 'bg-amber-100 text-amber-800 border border-amber-300'
                      : remindersEnabled && permissionStatus === 'granted'
                        ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                        : 'bg-slate-200 text-slate-600'
                  }`}
                >
                  {remindersEnabled && permissionStatus === 'denied'
                    ? 'Permission Denied'
                    : remindersEnabled
                      ? 'Active'
                      : 'Off'}
                </span>
              </div>
              <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                10 random funny Hinglish reminders across all 24 hours (day &amp; night) so you never forget to log expenses — never repeats twice in a row.
              </p>
              {reminderStatusMsg && (
                <p className="text-[10px] font-semibold text-blue-600 mt-1 flex items-center gap-1">
                  <CheckCircle className="w-3 h-3 text-blue-600 shrink-0" />
                  {reminderStatusMsg}
                </p>
              )}
              {reminderErrorMsg && permissionStatus !== 'denied' && (
                <p className="text-[10px] font-semibold text-amber-700 mt-1 flex items-center gap-1">
                  <AlertTriangle className="w-3 h-3 text-amber-600 shrink-0" />
                  {reminderErrorMsg}
                </p>
              )}
            </div>
            <button
              type="button"
              role="switch"
              aria-checked={remindersEnabled && permissionStatus !== 'denied'}
              onClick={handleToggleReminders}
              className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-hidden ${
                remindersEnabled && permissionStatus !== 'denied' ? 'bg-blue-600' : 'bg-slate-300'
              }`}
            >
              <span
                className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-md ring-0 transition duration-200 ease-in-out ${
                  remindersEnabled && permissionStatus !== 'denied' ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {permissionStatus === 'denied' && (
            <div className="p-3 bg-amber-50 border border-amber-200 text-amber-900 rounded-xl text-[11px] leading-relaxed flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
              <div className="flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <span>{getNotificationDeniedGuidance('denied')}</span>
              </div>
              <Button
                type="button"
                size="sm"
                variant="outline"
                onClick={handleRecheckNotificationPermission}
                className="border-amber-300 text-amber-900 bg-white hover:bg-amber-100 shrink-0 text-[11px]"
              >
                Check Permission
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Legal Documents & Transparency Library */}
      <Card>
        <CardHeader className="pb-2">
          <div className="flex items-center gap-2">
            <FileText className="w-4.5 h-4.5 text-blue-600" />
            <CardTitle>Legal, Terms & Consumer Disclosures</CardTitle>
          </div>
          <span className="text-[10px] font-bold text-amber-800 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded-md">
            DRAFT
          </span>
        </CardHeader>
        <CardContent className="pt-2 space-y-3">
          <p className="text-xs text-slate-600 leading-relaxed">
            SPLITO is an expense ledger, not a bank or wallet. We never collect or store banking passwords, UPI PINs, or OTPs. Review our complete regulatory documents and user agreements in English or Hindi below:
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
            {[
              { key: 'user_agreement' as LegalDocKey, label: '1. User Agreement' },
              { key: 'terms_conditions' as LegalDocKey, label: '2. Terms and Conditions' },
              { key: 'privacy_policy' as LegalDocKey, label: '3. Privacy Policy' },
              { key: 'subscription_terms' as LegalDocKey, label: '4. Subscription Terms' },
              { key: 'cancellation_refund' as LegalDocKey, label: '5. Cancellation & Refunds' },
              { key: 'data_permissions' as LegalDocKey, label: '6. Data Collection & Permissions' },
              { key: 'account_deletion' as LegalDocKey, label: '7. Account Deletion Policy' }
            ].map((doc) => (
              <button
                key={doc.key}
                type="button"
                onClick={() => onOpenLegalModal && onOpenLegalModal(doc.key)}
                className="p-3 bg-slate-50 hover:bg-slate-100 border border-slate-200/80 rounded-xl text-slate-800 font-semibold flex items-center justify-between cursor-pointer transition-colors text-left"
              >
                <span>{doc.label}</span>
                <ChevronRight className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              </button>
            ))}
          </div>

          <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2">
            <Button
              size="sm"
              variant="outline"
              icon={<Sliders className="w-3.5 h-3.5 text-blue-600" />}
              onClick={onOpenConsentModal}
            >
              Privacy & Consent Preferences
            </Button>
            <span className="text-[11px] text-slate-500">
              v1.5 • SPLITO
            </span>
          </div>
        </CardContent>
      </Card>

      {/* Personal Data & Entries Management */}
      <Card>
        <CardHeader className="pb-2">
          <div className="flex items-center gap-2">
            <Database className="w-4.5 h-4.5 text-blue-600" />
            <CardTitle>Personal Data & Entries</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="pt-2 space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3.5 bg-slate-50 rounded-2xl border border-slate-200/80">
            <div>
              <span className="font-bold text-xs text-slate-900 block">Delete My Entries & Data</span>
              <p className="text-[11px] text-slate-500 mt-0.5 leading-relaxed">
                Delete your SPLITO spaces, entries and associated personal data while keeping your account and login active.
              </p>
            </div>
            <Button
              size="sm"
              variant="outline"
              icon={<Trash2 className="w-3.5 h-3.5 text-slate-600" />}
              onClick={onOpenDeleteDataModal}
              className="border-slate-300 text-slate-700 hover:bg-slate-100 hover:text-slate-900 shrink-0 font-medium"
            >
              Delete My Data
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Advanced Account Actions: Understated secondary location */}
      <div className="pt-4 pb-2 border-t border-slate-200/80">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 px-1">
          <div>
            <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Advanced Account Actions
            </h4>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Permanently close your SPLITO account and remove eligible account data.
            </p>
          </div>
          <Button
            size="sm"
            variant="ghost"
            onClick={onOpenAccountDeletionModal}
            className="text-xs text-slate-400 hover:text-rose-600 hover:bg-rose-50/50 transition-colors cursor-pointer self-start sm:self-auto"
          >
            Delete Account
          </Button>
        </div>
      </div>

      {/* Logout Confirmation Dialog (PF-03) */}
      <LogoutConfirmModal
        isOpen={isLogoutModalOpen}
        onClose={() => setIsLogoutModalOpen(false)}
        onConfirmLogout={() => {
          setIsLogoutModalOpen(false);
          onLogout();
        }}
      />
    </div>
  );
};
