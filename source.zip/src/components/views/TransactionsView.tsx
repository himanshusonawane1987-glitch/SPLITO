import React, { useState, useMemo } from 'react';
import { Space, Transaction, TransactionType, MemberBalance, ActualBalanceBreakdown } from '../../types/finance.ts';
import { formatMinorUnits } from '../../lib/finance-engine.ts';
import { exportCsvStatement } from '../../lib/export-service.ts';
import { Card, CardHeader, CardTitle, CardContent } from '../ui/Card.tsx';
import { Button } from '../ui/Button.tsx';
import { Input } from '../ui/Input.tsx';
import {
  Search,
  Download,
  Filter,
  ArrowDownLeft,
  ArrowUpRight,
  ArrowLeftRight,
  CheckCircle2,
  Trash2,
  Edit2,
  Calendar,
  RotateCcw,
  Printer,
  Receipt,
  Camera,
  Wallet
} from 'lucide-react';

import { ReversalConfirmModal } from '../ReversalConfirmModal.tsx';
import { AmountDisplay, Heading } from '../ui/Typography.tsx';
import { AdBanner } from '../ui/AdBanner.tsx';

interface TransactionsViewProps {
  space: Space;
  transactions: Transaction[];
  currentUserId: string;
  isPro?: boolean;
  onOpenUpgradeModal?: () => void;
  onTriggerRewardedAd?: (type: 'pdf' | 'csv') => void;
  onEditTransaction: (tx: Transaction) => void;
  onReverseTransaction: (tx: Transaction, reason?: string) => Promise<void>;
  onDeleteTransaction: (txId: string) => Promise<void>;
  onOpenAddModal: (type: TransactionType) => void;
  onOpenReceiptCapture: () => void;
  onOpenPdfExport: () => void;
  onPayAgain?: (tx: Transaction) => void;
}

export const TransactionsView: React.FC<TransactionsViewProps> = ({
  space,
  transactions,
  currentUserId,
  isPro = false,
  onOpenUpgradeModal,
  onTriggerRewardedAd,
  onEditTransaction,
  onReverseTransaction,
  onDeleteTransaction,
  onOpenAddModal,
  onOpenReceiptCapture,
  onOpenPdfExport,
  onPayAgain
}) => {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [reversalTargetTx, setReversalTargetTx] = useState<Transaction | null>(null);

  const currency = space.currency;
  const isPersonal = space.mode === 'personal';

  const categories = useMemo(() => {
    const set = new Set<string>();
    transactions.forEach((tx) => {
      if (tx.category) set.add(tx.category);
    });
    return Array.from(set);
  }, [transactions]);

  const filteredTransactions = useMemo(() => {
    return transactions.filter((tx) => {
      if (selectedType !== 'all' && tx.type !== selectedType) return false;
      if (selectedCategory !== 'all' && tx.category !== selectedCategory) return false;
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchesTitle = tx.title.toLowerCase().includes(query);
        const matchesNotes = tx.notes ? tx.notes.toLowerCase().includes(query) : false;
        const matchesCat = tx.category.toLowerCase().includes(query);
        if (!matchesTitle && !matchesNotes && !matchesCat) return false;
      }
      return true;
    });
  }, [transactions, selectedType, selectedCategory, searchQuery]);

  const filteredStats = useMemo(() => {
    let income = 0;
    let expense = 0;
    for (const tx of filteredTransactions) {
      if (!tx.isReversed && (!tx.paymentStatus || tx.paymentStatus === 'paid')) {
        if (tx.type === 'income') income += tx.amount;
        if (tx.type === 'expense') expense += tx.amount;
      }
    }
    return { income, expense, count: filteredTransactions.length };
  }, [filteredTransactions]);

  const groupedByDate = useMemo(() => {
    const groups: Record<string, Transaction[]> = {};
    for (const tx of filteredTransactions) {
      const dateKey = tx.date;
      if (!groups[dateKey]) groups[dateKey] = [];
      groups[dateKey].push(tx);
    }
    return groups;
  }, [filteredTransactions]);

  const handleOpenReverseModal = (tx: Transaction) => {
    setReversalTargetTx(tx);
  };

  const handleConfirmReversal = async (tx: Transaction, reason: string) => {
    await onReverseTransaction(tx, reason);
    setReversalTargetTx(null);
  };

  const [isExportingCsv, setIsExportingCsv] = useState(false);

  const exportToCSV = async () => {
    if (transactions.length === 0 || isExportingCsv) return;
    if (!isPro && onTriggerRewardedAd) {
      onTriggerRewardedAd('csv');
      return;
    }
    setIsExportingCsv(true);
    try {
      await exportCsvStatement(space, transactions);
    } finally {
      setIsExportingCsv(false);
    }
  };

  return (
    <div className="space-y-4 pb-24 text-left">
      {/* Top Header Card */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900 tracking-tight">Ledger & Diary</h2>
          <p className="text-xs text-slate-500">
            {transactions.length} total entries recorded in {space.name} • Immutable history
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <Button
            size="sm"
            variant="outline"
            icon={<Printer className="w-3.5 h-3.5" />}
            onClick={onOpenPdfExport}
          >
            PDF Statement
          </Button>
          <Button
            size="sm"
            variant="outline"
            icon={<Download className="w-3.5 h-3.5" />}
            onClick={exportToCSV}
            disabled={transactions.length === 0}
          >
            CSV
          </Button>
          <Button
            size="sm"
            variant="secondary"
            icon={<Camera className="w-3.5 h-3.5" />}
            onClick={onOpenReceiptCapture}
          >
            <span>Scan</span>
            <span className="ml-1 text-[8px] font-bold bg-amber-100 text-amber-800 border border-amber-300 px-1 py-0.2 rounded">
              SOON
            </span>
          </Button>
          <Button
            size="sm"
            variant="primary"
            onClick={() => onOpenAddModal('expense')}
          >
            + Add Entry
          </Button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <Card className="bg-white">
        <CardContent className="pt-4 pb-4 space-y-3">
          <Input
            leftIcon={<Search className="w-4 h-4" />}
            placeholder="Search merchant, notes, categories, payment method..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />

          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center gap-1 bg-slate-100 p-0.5 rounded-xl text-xs font-semibold">
              {['all', 'expense', 'income', 'transfer', 'settlement'].map((t) => (
                <button
                  key={t}
                  onClick={() => setSelectedType(t)}
                  className={`px-2.5 py-1 rounded-lg capitalize cursor-pointer transition-colors ${
                    selectedType === t
                      ? 'bg-white text-slate-900 shadow-2xs font-bold'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>

            {categories.length > 0 && (
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="bg-white border border-slate-200 text-slate-700 text-xs font-semibold rounded-xl px-2.5 py-1.5 focus:outline-none focus:border-blue-600 cursor-pointer shadow-2xs"
              >
                <option value="all">All Categories ({categories.length})</option>
                {categories.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Filter Summary Row */}
      <div className="flex items-center justify-between px-2 text-xs text-slate-500">
        <span>Showing {filteredStats.count} entries</span>
        <div className="flex items-center gap-3 font-mono text-xs">
          <span className="text-emerald-600 font-bold">
            +{formatMinorUnits(filteredStats.income, currency)}
          </span>
          <span className="text-rose-600 font-bold">
            −{formatMinorUnits(filteredStats.expense, currency)}
          </span>
        </div>
      </div>

      {/* Grouped Ledger Entries */}
      {Object.keys(groupedByDate).length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <p className="text-sm font-bold text-slate-700">No entries match your search</p>
            <p className="text-xs text-slate-400 mt-1">Try clearing filters or search keywords</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {Object.entries(groupedByDate).map(([dateStr, items]) => (
            <div key={dateStr} className="space-y-1.5">
              <div className="flex items-center gap-2 px-1">
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                <span className="text-xs font-bold text-slate-600 tracking-tight uppercase">
                  {dateStr}
                </span>
                <span className="h-px bg-slate-200 flex-1 ml-2" />
              </div>

              <Card>
                <CardContent className="p-0 divide-y divide-slate-100">
                  {items.map((tx) => {
                    const isIncome = tx.type === 'income';
                    const isExpense = tx.type === 'expense';
                    // Reversal accounting display:
                    // An expense reversal credits back money (+₹ in green)
                    // An income reversal debits the ledger (−₹ in red)
                    const isCredit = tx.isReversal ? isExpense : isIncome;
                    const isDebit = tx.isReversal ? isIncome : isExpense;
                    const payer = space.members?.find((m) => m.id === tx.payerId);
                    const receiver = tx.paidToId ? space.members?.find((m) => m.id === tx.paidToId) : null;

                    return (
                      <div
                        key={tx.id}
                        className={`p-3.5 flex items-center justify-between gap-3 hover:bg-slate-50 transition-colors ${
                          tx.isReversed ? 'opacity-50 bg-slate-50/50' : ''
                        }`}
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <div
                            className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                              isCredit
                                ? 'bg-emerald-50 text-emerald-600'
                                : isDebit
                                ? 'bg-rose-50 text-rose-600'
                                : 'bg-slate-100 text-slate-700'
                            }`}
                          >
                            {isCredit ? (
                              <ArrowDownLeft className="w-5 h-5" />
                            ) : isDebit ? (
                              <ArrowUpRight className="w-5 h-5" />
                            ) : (
                              <ArrowLeftRight className="w-5 h-5" />
                            )}
                          </div>
                          <div className="min-w-0 text-left">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span
                                className={`font-bold text-sm text-slate-900 truncate ${
                                  tx.isReversed ? 'line-through text-slate-400' : ''
                                }`}
                              >
                                {tx.title}
                              </span>
                              {tx.isReversal && (
                                <span className="text-[10px] text-emerald-700 bg-emerald-50 border border-emerald-200/60 px-1.5 py-0.2 rounded font-medium">
                                  Reversal
                                </span>
                              )}
                              {tx.isReversed && (
                                <span className="text-[10px] text-rose-600 bg-rose-50 px-1.5 py-0.2 rounded font-medium">
                                  Reversed
                                </span>
                              )}
                              {/* Payment Status Badges (PART 13: Paid green, Pending amber, Failed red) */}
                              {tx.paymentStatus === 'pending' && (
                                <span className="text-[10px] text-amber-700 bg-amber-50 border border-amber-200/80 px-1.5 py-0.2 rounded font-bold">
                                  Pending
                                </span>
                              )}
                              {tx.paymentStatus === 'failed' && (
                                <span className="text-[10px] text-rose-700 bg-rose-50 border border-rose-200/80 px-1.5 py-0.2 rounded font-bold">
                                  Failed
                                </span>
                              )}
                              {tx.paymentStatus === 'paid' && (
                                <span className="text-[10px] text-emerald-700 bg-emerald-50 border border-emerald-200/80 px-1.5 py-0.2 rounded font-bold">
                                  Paid
                                </span>
                              )}
                            </div>

                            {/* Clean unboxed metadata with typographic separators */}
                            <div className="flex items-center gap-1.5 text-xs text-slate-500 mt-0.5 flex-wrap">
                              <span>{tx.category}</span>
                              <span aria-hidden="true">·</span>
                              <span>{tx.type}</span>
                              {tx.paymentMethod && (
                                <>
                                  <span aria-hidden="true">·</span>
                                  <span>{tx.paymentMethod}</span>
                                </>
                              )}
                              {!isPersonal && payer && (
                                <>
                                  <span aria-hidden="true">·</span>
                                  <span>By {payer.name}</span>
                                </>
                              )}
                              {receiver && (
                                <>
                                  <span aria-hidden="true">·</span>
                                  <span>To {receiver.name}</span>
                                </>
                              )}
                              {tx.notes && (
                                <>
                                  <span aria-hidden="true">·</span>
                                  <span className="italic truncate max-w-[150px]">{tx.notes}</span>
                                </>
                              )}
                            </div>

                            {/* Per-person split details (PART 13: Show actual participant amounts) */}
                            {tx.splits && tx.splits.length > 0 && (
                              <div className="flex items-center gap-1.5 text-[11px] text-slate-500 mt-1 flex-wrap">
                                <span className="font-semibold text-slate-600">Splits:</span>
                                {tx.splits.map((s) => {
                                  const member = space.members?.find((m) => m.id === s.memberId);
                                  const name = member?.name || s.memberId;
                                  return (
                                    <span key={s.memberId} className="inline-flex items-center gap-1 bg-slate-100/80 border border-slate-200/60 px-1.5 py-0.5 rounded text-[10px]">
                                      <span className="text-slate-600 font-medium">{name}:</span>
                                      <span className="font-mono font-bold text-slate-900">{formatMinorUnits(s.shareMinorUnits, currency)}</span>
                                    </span>
                                  );
                                })}
                              </div>
                            )}
                          </div>
                        </div>

                        <div className="flex items-center gap-3 shrink-0">
                          <div className="text-right">
                            <span
                              className={`font-mono font-bold text-sm block ${
                                tx.isReversed
                                  ? 'line-through text-slate-400'
                                  : isCredit
                                  ? 'text-emerald-600'
                                  : isDebit
                                  ? 'text-rose-600'
                                  : 'text-slate-900'
                              }`}
                            >
                              {isCredit ? '+' : isDebit ? '−' : ''}
                              {formatMinorUnits(tx.amount, currency)}
                            </span>
                            {tx.splits && tx.splits.length > 0 && (
                              <span className="text-[10px] text-slate-400 font-medium block">
                                {tx.splitType} split ({tx.splits.length})
                              </span>
                            )}
                          </div>

                          {/* Action controls */}
                          <div className="flex items-center gap-1">
                            {!tx.isReversed && !tx.isReversal && (
                              <>
                                {/* Pay Again button for Pending and Failed entries (PART 13) */}
                                {(tx.paymentStatus === 'pending' || tx.paymentStatus === 'failed') && onPayAgain && (
                                  <button
                                    type="button"
                                    onClick={() => onPayAgain(tx)}
                                    className="px-2 py-1 text-[11px] font-bold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-lg transition-colors flex items-center gap-1 cursor-pointer shrink-0"
                                    title="Pay Again via UPI"
                                    aria-label="Pay Again"
                                  >
                                    <Wallet className="w-3 h-3 text-emerald-600" />
                                    <span>Pay Again</span>
                                  </button>
                                )}
                                <button
                                  onClick={() => onEditTransaction(tx)}
                                  className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors cursor-pointer"
                                  title="Edit Entry"
                                >
                                  <Edit2 className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleOpenReverseModal(tx)}
                                  className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                                  title="Reverse Transaction (Immutable Reversal)"
                                  aria-label="Reverse Transaction"
                                >
                                  <RotateCcw className="w-3.5 h-3.5" />
                                </button>
                              </>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </CardContent>
              </Card>
            </div>
          ))}
        </div>
      )}

      {/* Required Change RW-05: ONE Permanent Banner in genuinely empty space below transactions */}
      <div className="pt-2">
        <AdBanner
          isPro={isPro}
          onUpgradeClick={onOpenUpgradeModal}
          placement="permanent"
          className="min-h-[68px] touch-manipulation"
        />
      </div>

      {/* Immutable Reversal Confirmation Modal */}
      <ReversalConfirmModal
        isOpen={!!reversalTargetTx}
        onClose={() => setReversalTargetTx(null)}
        transaction={reversalTargetTx}
        currency={currency}
        onConfirmReversal={handleConfirmReversal}
      />
    </div>
  );
};
