import React, { useState, useMemo } from 'react';
import { Space, Transaction } from '../../types/finance.ts';
import {
  calculateCategoryBreakdowns,
  formatMinorUnits,
  getActiveLedgerTransactions
} from '../../lib/finance-engine.ts';
import { Card, CardHeader, CardTitle, CardContent } from '../ui/Card.tsx';
import { AmountDisplay, Heading, Label } from '../ui/Typography.tsx';
import {
  PieChart,
  TrendingUp,
  TrendingDown,
  DollarSign,
  Calendar,
  ArrowUpRight,
  ArrowDownLeft,
  ShieldCheck,
  Sparkles,
  FileSpreadsheet,
  ShieldAlert,
  Clock
} from 'lucide-react';
import { Button } from '../ui/Button.tsx';
import { AdBanner } from '../ui/AdBanner.tsx';

interface InsightsViewProps {
  space: Space;
  transactions: Transaction[];
  currentUserId: string;
  isPro?: boolean;
  onOpenUpgradeModal?: () => void;
}

type TimePeriod = 'this_month' | 'last_month' | 'last_30_days' | 'all_time';

export const InsightsView: React.FC<InsightsViewProps> = ({
  space,
  transactions,
  currentUserId,
  isPro = false,
  onOpenUpgradeModal
}) => {
  const [selectedPeriod, setSelectedPeriod] = useState<TimePeriod>('this_month');
  const currency = space.currency;

  // Active ledger transactions (excluding reversals)
  const activeTx = useMemo(() => getActiveLedgerTransactions(transactions), [transactions]);

  // Filter transactions by selected time period
  const periodFilteredTx = useMemo(() => {
    const now = new Date();
    const currentYear = now.getFullYear();
    const currentMonth = now.getMonth(); // 0-indexed

    return activeTx.filter((t) => {
      const txDate = new Date(t.date);
      if (selectedPeriod === 'all_time') return true;

      if (selectedPeriod === 'this_month') {
        return txDate.getFullYear() === currentYear && txDate.getMonth() === currentMonth;
      }

      if (selectedPeriod === 'last_month') {
        const lastMonth = currentMonth === 0 ? 11 : currentMonth - 1;
        const lastMonthYear = currentMonth === 0 ? currentYear - 1 : currentYear;
        return txDate.getFullYear() === lastMonthYear && txDate.getMonth() === lastMonth;
      }

      if (selectedPeriod === 'last_30_days') {
        const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
        return txDate >= thirtyDaysAgo && txDate <= now;
      }

      return true;
    });
  }, [activeTx, selectedPeriod]);

  const expenseBreakdowns = useMemo(
    () => calculateCategoryBreakdowns(periodFilteredTx, 'expense'),
    [periodFilteredTx]
  );

  const totalExpenseUnits = useMemo(() => {
    return periodFilteredTx
      .filter((t) => t.type === 'expense')
      .reduce((acc, t) => acc + t.amount, 0);
  }, [periodFilteredTx]);

  const totalIncomeUnits = useMemo(() => {
    return periodFilteredTx
      .filter((t) => t.type === 'income')
      .reduce((acc, t) => acc + t.amount, 0);
  }, [periodFilteredTx]);

  const netSavingsUnits = totalIncomeUnits - totalExpenseUnits;
  const savingsRate =
    totalIncomeUnits > 0
      ? Math.max(0, Math.min(100, Math.round((netSavingsUnits / totalIncomeUnits) * 100)))
      : 0;

  const expenseList = periodFilteredTx.filter((t) => t.type === 'expense');
  const largestExpense = expenseList.length > 0
    ? [...expenseList].sort((a, b) => b.amount - a.amount)[0]
    : null;

  const averageExpenseUnits = expenseList.length > 0
    ? Math.round(totalExpenseUnits / expenseList.length)
    : 0;

  const barColors = [
    'bg-blue-600',
    'bg-emerald-500',
    'bg-amber-500',
    'bg-indigo-500',
    'bg-rose-500',
    'bg-cyan-500',
    'bg-purple-500',
    'bg-teal-500',
    'bg-slate-400'
  ];

  return (
    <div className="space-y-4 pb-24 text-left">
      {/* Title & Time-Period Selector */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900 tracking-tight">Monthly Expense Dashboard</h2>
          <p className="text-xs text-slate-500">
            Analytics & category breakdown for {space.name}
          </p>
        </div>

        {/* Time-Period Segmented Control */}
        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl text-xs font-semibold self-start sm:self-auto">
          {[
            { key: 'this_month', label: 'This Month' },
            { key: 'last_month', label: 'Last Month' },
            { key: 'last_30_days', label: '30 Days' },
            { key: 'all_time', label: 'All Time' }
          ].map((period) => (
            <button
              key={period.key}
              type="button"
              onClick={() => setSelectedPeriod(period.key as TimePeriod)}
              className={`px-2.5 py-1.5 rounded-lg cursor-pointer transition-colors ${
                selectedPeriod === period.key
                  ? 'bg-white text-slate-900 shadow-2xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {period.label}
            </button>
          ))}
        </div>
      </div>

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
        <Card className="bg-white">
          <CardContent className="p-4">
            <Label className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">
              Period Inflow
            </Label>
            <AmountDisplay
              minorUnits={totalIncomeUnits}
              currency={currency}
              size="md"
              variant="positive"
              showSign={true}
              className="mt-1 font-extrabold"
            />
            <span className="text-[10px] text-slate-400 block mt-0.5">
              {periodFilteredTx.filter((t) => t.type === 'income').length} deposits
            </span>
          </CardContent>
        </Card>

        <Card className="bg-white">
          <CardContent className="p-4">
            <Label className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">
              Period Outflow
            </Label>
            <AmountDisplay
              minorUnits={totalExpenseUnits}
              currency={currency}
              size="md"
              variant="negative"
              forceNegativeSign={true}
              className="mt-1 font-extrabold"
            />
            <span className="text-[10px] text-slate-400 block mt-0.5">
              {expenseList.length} expenses
            </span>
          </CardContent>
        </Card>

        <Card className="bg-white">
          <CardContent className="p-4">
            <Label className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">
              Net Savings Rate
            </Label>
            <span className="font-mono font-extrabold text-lg text-blue-600 block mt-1">
              {savingsRate}%
            </span>
            <div className="text-[10px] text-slate-400 mt-0.5 flex items-center gap-1">
              <span>Net</span>
              <AmountDisplay
                minorUnits={netSavingsUnits}
                currency={currency}
                size="sm"
                showSign={true}
                className="text-[11px]"
              />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white">
          <CardContent className="p-4">
            <Label className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">
              Avg Spend / Entry
            </Label>
            <AmountDisplay
              minorUnits={averageExpenseUnits}
              currency={currency}
              size="md"
              className="mt-1 font-extrabold text-slate-900"
            />
            <span className="text-[10px] text-slate-400 block mt-0.5">Across active items</span>
          </CardContent>
        </Card>
      </div>

      {/* Cash Flow Distribution Bar */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle>Inflow vs Outflow Ratio</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="h-3 w-full bg-slate-100 rounded-full overflow-hidden flex">
            {totalIncomeUnits + totalExpenseUnits > 0 ? (
              <>
                <div
                  style={{
                    width: `${Math.round(
                      (totalIncomeUnits / (totalIncomeUnits + totalExpenseUnits)) * 100
                    )}%`
                  }}
                  className="bg-emerald-500 h-full transition-all"
                  title="Inflow"
                />
                <div
                  style={{
                    width: `${Math.round(
                      (totalExpenseUnits / (totalIncomeUnits + totalExpenseUnits)) * 100
                    )}%`
                  }}
                  className="bg-rose-500 h-full transition-all"
                  title="Outflow"
                />
              </>
            ) : (
              <div className="w-full bg-slate-200 h-full" />
            )}
          </div>

          <div className="flex items-center justify-between text-xs text-slate-600">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
              <span>Inflow ({totalIncomeUnits + totalExpenseUnits > 0 ? Math.round((totalIncomeUnits / (totalIncomeUnits + totalExpenseUnits)) * 100) : 0}%)</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500" />
              <span>Outflow ({totalIncomeUnits + totalExpenseUnits > 0 ? Math.round((totalExpenseUnits / (totalIncomeUnits + totalExpenseUnits)) * 100) : 0}%)</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Category Wise Expense Breakdown Chart */}
      <Card>
        <CardHeader className="pb-2">
          <div>
            <CardTitle className="flex items-center gap-2">
              <PieChart className="w-4.5 h-4.5 text-blue-600" />
              <span>Expense Categories & Spending Breakdown</span>
            </CardTitle>
            <p className="text-xs text-slate-500 mt-0.5">
              Distribution of expenditures in {space.currency}
            </p>
          </div>
        </CardHeader>
        <CardContent className="space-y-3.5 pt-0">
          {expenseBreakdowns.length === 0 ? (
            <div className="py-8 text-center text-xs text-slate-500">
              No expenses recorded for this time period.
            </div>
          ) : (
            <div className="space-y-3">
              {expenseBreakdowns.map((cat, idx) => {
                const color = barColors[idx % barColors.length];

                return (
                  <div key={cat.category} className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2">
                        <span className={`w-2.5 h-2.5 rounded-full ${color}`} />
                        <span className="font-bold text-slate-800">{cat.category}</span>
                        <span className="text-[10px] text-slate-400">({cat.count} txns)</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <AmountDisplay
                          minorUnits={cat.amountMinorUnits}
                          currency={currency}
                          size="sm"
                          className="font-bold text-slate-900"
                        />
                        <span className="text-slate-400 text-[11px] w-10 text-right">
                          {cat.percentage}%
                        </span>
                      </div>
                    </div>

                    <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                      <div
                        className={`h-full ${color} rounded-full transition-all duration-300`}
                        style={{ width: `${Math.max(2, cat.percentage)}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Largest Expense Highlight */}
      {largestExpense && (
        <Card className="bg-slate-50/70 border-slate-200">
          <CardContent className="p-4 flex items-center justify-between gap-3">
            <div>
              <Label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                Highest Single Spend in Period
              </Label>
              <h4 className="font-bold text-sm text-slate-900 mt-0.5">{largestExpense.title}</h4>
              <p className="text-xs text-slate-500">
                {largestExpense.category} • {largestExpense.date} • {largestExpense.paymentMethod || 'UPI'}
              </p>
            </div>
            <AmountDisplay
              minorUnits={largestExpense.amount}
              currency={currency}
              size="md"
              variant="negative"
              forceNegativeSign={true}
              className="font-extrabold shrink-0"
            />
          </CardContent>
        </Card>
      )}

      {/* SPLITO Pro Features (Coming Soon Showcase) */}
      <Card className="border-amber-200/80 bg-gradient-to-br from-amber-50/30 via-white to-amber-50/10 overflow-hidden relative">
        <div className="absolute top-0 right-0 w-36 h-36 bg-amber-400/10 rounded-full blur-2xl pointer-events-none" />
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between w-full">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4.5 h-4.5 text-amber-500" />
              <CardTitle>SPLITO Pro Features</CardTitle>
            </div>
            <span className="text-[10px] font-extrabold uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-800 border border-amber-300">
              COMING SOON
            </span>
          </div>
          <p className="text-xs text-amber-900/90 mt-0.5">
            Premium features are on their way. Subscription will be available soon.
          </p>
        </CardHeader>
        <CardContent className="space-y-3 pt-1">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {/* 1. Advanced Reports & Insights */}
            <div className="p-3 bg-white rounded-xl border border-slate-200/90 space-y-1.5 shadow-2xs">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 font-bold text-xs text-slate-900">
                  <div className="p-1.5 bg-blue-50 text-blue-600 rounded-lg">
                    <PieChart className="w-3.5 h-3.5" />
                  </div>
                  <span>Advanced Reports & Insights</span>
                </div>
                <span className="text-[9px] font-bold bg-amber-100 text-amber-800 border border-amber-300 px-1.5 py-0.2 rounded-md">
                  COMING SOON
                </span>
              </div>
              <p className="text-[11px] text-slate-500 leading-relaxed">
                Multi-category cross comparisons, recurring expense detectors, and month-over-month trend predictions.
              </p>
            </div>

            {/* 2. Money Timeline */}
            <div className="p-3 bg-white rounded-xl border border-slate-200/90 space-y-1.5 shadow-2xs">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 font-bold text-xs text-slate-900">
                  <div className="p-1.5 bg-emerald-50 text-emerald-600 rounded-lg">
                    <TrendingUp className="w-3.5 h-3.5" />
                  </div>
                  <span>Money Timeline</span>
                </div>
                <span className="text-[9px] font-bold bg-amber-100 text-amber-800 border border-amber-300 px-1.5 py-0.2 rounded-md">
                  COMING SOON
                </span>
              </div>
              <p className="text-[11px] text-slate-500 leading-relaxed">
                Chronological interactive balance stream showing exactly how and when every Rupee moved across your spaces.
              </p>
            </div>

            {/* 3. Spending Guard */}
            <div className="p-3 bg-white rounded-xl border border-slate-200/90 space-y-1.5 shadow-2xs">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 font-bold text-xs text-slate-900">
                  <div className="p-1.5 bg-rose-50 text-rose-600 rounded-lg">
                    <ShieldAlert className="w-3.5 h-3.5" />
                  </div>
                  <span>Spending Guard</span>
                </div>
                <span className="text-[9px] font-bold bg-amber-100 text-amber-800 border border-amber-300 px-1.5 py-0.2 rounded-md">
                  COMING SOON
                </span>
              </div>
              <p className="text-[11px] text-slate-500 leading-relaxed">
                Proactive budget thresholds and velocity warnings when group or personal burn rates spike unusually.
              </p>
            </div>

            {/* 4. Advanced Statement & CSV Exports */}
            <div className="p-3 bg-white rounded-xl border border-slate-200/90 space-y-1.5 shadow-2xs">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 font-bold text-xs text-slate-900">
                  <div className="p-1.5 bg-purple-50 text-purple-600 rounded-lg">
                    <FileSpreadsheet className="w-3.5 h-3.5" />
                  </div>
                  <span>Advanced Exports</span>
                </div>
                <span className="text-[9px] font-bold bg-amber-100 text-amber-800 border border-amber-300 px-1.5 py-0.2 rounded-md">
                  COMING SOON
                </span>
              </div>
              <p className="text-[11px] text-slate-500 leading-relaxed">
                Multi-year ledger exports, formatted Excel/CSV sheets, and instant ad-free high-resolution PDF statements.
              </p>
            </div>
          </div>

          <div className="pt-2 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 border-t border-amber-200/50">
            <span className="text-[11px] text-amber-900 font-medium">
              Upcoming: ₹59/month or ₹599/year with 1-month free trial
            </span>
            <Button
              size="sm"
              variant="outline"
              onClick={onOpenUpgradeModal}
              icon={<Sparkles className="w-3.5 h-3.5 text-amber-600" />}
              className="border-amber-300 bg-white hover:bg-amber-50 text-amber-900 font-bold"
            >
              SPLITO Pro (Coming Soon)
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Non-intrusive AdBanner for free users (omitted for Pro users) */}
      <AdBanner isPro={isPro} onUpgradeClick={onOpenUpgradeModal} className="mt-2" />
    </div>
  );
};
