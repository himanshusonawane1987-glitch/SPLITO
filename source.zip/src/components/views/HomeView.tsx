import React from 'react';
import { Space, Transaction, ActualBalanceBreakdown, MemberBalance, DebtSettlement } from '../../types/finance.ts';
import { formatMinorUnits, getCurrencyMeta } from '../../lib/finance-engine.ts';
import { Card, CardHeader, CardTitle, CardContent } from '../ui/Card.tsx';
import { Button } from '../ui/Button.tsx';
import { AmountDisplay, Heading, Label } from '../ui/Typography.tsx';
import {
  ArrowDownLeft,
  ArrowUpRight,
  ArrowLeftRight,
  CheckCircle2,
  Clock,
  Plus,
  Receipt,
  Users,
  Camera,
  ShieldCheck,
  Zap,
  ChevronRight
} from 'lucide-react';
import { AdBanner } from '../ui/AdBanner.tsx';

interface HomeViewProps {
  space: Space;
  transactions: Transaction[];
  actualBalanceBreakdown: ActualBalanceBreakdown;
  memberBalances: MemberBalance[];
  debtSettlements: DebtSettlement[];
  currentUserId: string;
  isPro?: boolean;
  onOpenUpgradeModal?: () => void;
  onOpenAddModal: (type: 'expense' | 'income' | 'transfer' | 'settlement') => void;
  onOpenReceiptCapture: () => void;
  onOpenSettleModal: (debt: DebtSettlement) => void;
  onViewAllTransactions: () => void;
  onViewGroups: () => void;
  onEditTransaction: (tx: Transaction) => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  space,
  transactions,
  actualBalanceBreakdown,
  memberBalances,
  debtSettlements,
  currentUserId,
  isPro = false,
  onOpenUpgradeModal,
  onOpenAddModal,
  onOpenReceiptCapture,
  onOpenSettleModal,
  onViewAllTransactions,
  onViewGroups,
  onEditTransaction
}) => {
  const currency = space.currency;
  const isPersonal = space.mode === 'personal';
  const meta = getCurrencyMeta(currency);

  const userBalance = memberBalances.find((b) => b.memberId === currentUserId);
  const netSettlementUnits = userBalance?.netBalanceMinorUnits || 0;
  const recentTransactions = transactions.slice(0, 15);

  return (
    <div className="space-y-5 pb-24 text-left">
      {/* Primary Balance Hero Card — Deep Navy with Premium Subtle Accents */}
      <div className="bg-slate-900 text-white rounded-3xl p-5 sm:p-6 shadow-xl relative overflow-hidden border border-slate-800">
        <div className="absolute top-0 right-0 -mt-6 -mr-6 w-48 h-48 bg-blue-500/10 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 -mb-6 -ml-6 w-48 h-48 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10">
          <div className="flex items-center justify-between mb-1.5">
            <Label className="text-slate-300 font-bold uppercase tracking-wider text-[11px]">
              Actual Available Balance
            </Label>
            <span className="text-[11px] text-slate-400 font-mono">
              Base: {currency} ({meta.name})
            </span>
          </div>

          <div className="flex items-baseline gap-2 mb-1">
            <AmountDisplay
              minorUnits={actualBalanceBreakdown.actualBalance}
              currency={currency}
              size="lg"
              className="text-3xl sm:text-4xl text-white font-extrabold tracking-tight"
            />
          </div>

          {/* Official Tagline */}
          <p className="text-xs text-slate-400 font-medium tracking-tight mb-4">
            {currency === 'INR'
              ? 'Every Rupee. Accounted For.'
              : 'Every currency. Every transaction. Accounted for.'}
          </p>

          {/* Balance breakdown metrics */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-3.5 border-t border-white/10 text-xs">
            <div>
              <Label className="text-slate-400 block text-[10px] font-semibold uppercase">Starting</Label>
              <AmountDisplay
                minorUnits={actualBalanceBreakdown.startingBalance}
                currency={currency}
                size="sm"
                className="text-slate-200 font-semibold"
              />
            </div>
            <div>
              <Label className="text-slate-400 block text-[10px] font-semibold uppercase">Inflow (+)</Label>
              <AmountDisplay
                minorUnits={actualBalanceBreakdown.receivedIncome}
                currency={currency}
                size="sm"
                variant="positive"
                showSign={true}
                className="text-emerald-400 font-semibold"
              />
            </div>
            <div>
              <Label className="text-slate-400 block text-[10px] font-semibold uppercase">Outflow (−)</Label>
              <AmountDisplay
                minorUnits={actualBalanceBreakdown.paidExpenses}
                currency={currency}
                size="sm"
                variant="negative"
                forceNegativeSign={true}
                className="text-rose-400 font-semibold"
              />
            </div>
            <div>
              <Label className="text-slate-400 block text-[10px] font-semibold uppercase">Net Transfers</Label>
              <AmountDisplay
                minorUnits={actualBalanceBreakdown.incomingTransfers - actualBalanceBreakdown.outgoingTransfers}
                currency={currency}
                size="sm"
                showSign={true}
                className="text-slate-300 font-semibold"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Quick Actions Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
        <button
          onClick={() => onOpenAddModal('expense')}
          className="flex items-center gap-2.5 p-3 rounded-2xl bg-white hover:bg-slate-50 border border-slate-200/90 shadow-2xs transition-all cursor-pointer text-left group"
        >
          <div className="w-10 h-10 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
            <ArrowUpRight className="w-5 h-5 stroke-[2.5]" />
          </div>
          <div>
            <span className="text-xs font-bold text-slate-900 block">Add Expense</span>
            <span className="text-[10px] text-slate-500">{!isPersonal ? 'Split bill' : 'Diary entry'}</span>
          </div>
        </button>

        <button
          onClick={onOpenReceiptCapture}
          className="flex items-center gap-2.5 p-3 rounded-2xl bg-white hover:bg-slate-50 border border-slate-200/90 shadow-2xs transition-all cursor-pointer text-left group"
        >
          <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
            <Camera className="w-5 h-5 stroke-[2.5]" />
          </div>
          <div>
            <span className="text-xs font-bold text-slate-900 block">Scan Receipt</span>
            <span className="text-[9px] font-bold bg-amber-100 text-amber-800 border border-amber-300 px-1.5 py-0.2 rounded-md inline-block mt-0.5">
              COMING SOON
            </span>
          </div>
        </button>

        <button
          onClick={() => onOpenAddModal('income')}
          className="flex items-center gap-2.5 p-3 rounded-2xl bg-white hover:bg-slate-50 border border-slate-200/90 shadow-2xs transition-all cursor-pointer text-left group"
        >
          <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
            <ArrowDownLeft className="w-5 h-5 stroke-[2.5]" />
          </div>
          <div>
            <span className="text-xs font-bold text-slate-900 block">Add Income</span>
            <span className="text-[10px] text-slate-500">Deposit / Salary</span>
          </div>
        </button>

        {!isPersonal ? (
          <button
            onClick={() => onOpenAddModal('settlement')}
            className="flex items-center gap-2.5 p-3 rounded-2xl bg-white hover:bg-slate-50 border border-slate-200/90 shadow-2xs transition-all cursor-pointer text-left group"
          >
            <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
              <CheckCircle2 className="w-5 h-5 stroke-[2.5]" />
            </div>
            <div>
              <span className="text-xs font-bold text-slate-900 block">Settle Up</span>
              <span className="text-[10px] text-slate-500">Record payment</span>
            </div>
          </button>
        ) : (
          <button
            onClick={() => onOpenAddModal('transfer')}
            className="flex items-center gap-2.5 p-3 rounded-2xl bg-white hover:bg-slate-50 border border-slate-200/90 shadow-2xs transition-all cursor-pointer text-left group"
          >
            <div className="w-10 h-10 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
              <ArrowLeftRight className="w-5 h-5 stroke-[2.5]" />
            </div>
            <div>
              <span className="text-xs font-bold text-slate-900 block">Transfer</span>
              <span className="text-[10px] text-slate-500">Wallet / Bank</span>
            </div>
          </button>
        )}
      </div>

      {/* Screen Family (a): Group Dashboard Settlement Overview (Repositioned below balance card and action buttons) */}
      {!isPersonal ? (
        <div className="space-y-3">
          <Card className="bg-white">
            <CardHeader className="pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Users className="w-4.5 h-4.5 text-blue-600" />
                <div>
                  <CardTitle>Settlement Overview & Roommate Balances</CardTitle>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Smart Settlement with bounded backtracking • Zero-sum audited
                  </p>
                </div>
              </div>
              <Button size="sm" variant="outline" onClick={onViewGroups}>
                View Dues Matrix
              </Button>
            </CardHeader>

            <CardContent className="pt-4 space-y-4">
              {/* Member Avatars & Balance Row */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {memberBalances.map((m) => {
                  const isCurrentUser = m.memberId === currentUserId;
                  const isOwed = m.netBalanceMinorUnits > 0;
                  const owes = m.netBalanceMinorUnits < 0;

                  return (
                    <div
                      key={m.memberId}
                      className={`p-3 rounded-2xl border transition-all ${
                        isCurrentUser
                          ? 'border-blue-200 bg-blue-50/30'
                          : 'border-slate-200/80 bg-slate-50/50'
                      }`}
                    >
                      <div className="flex items-center gap-2.5 mb-2">
                        <div className="w-8 h-8 rounded-full bg-slate-200 text-slate-800 font-bold text-xs flex items-center justify-center shrink-0">
                          {m.memberName.charAt(0).toUpperCase()}
                        </div>
                        <div className="min-w-0">
                          <span className="font-bold text-xs text-slate-900 block truncate">
                            {m.memberName} {isCurrentUser ? '(You)' : ''}
                          </span>
                          <span className="text-[10px] text-slate-500">
                            Paid: {formatMinorUnits(m.totalPaidMinorUnits, currency)}
                          </span>
                        </div>
                      </div>

                      <div className="pt-1.5 border-t border-slate-100 flex items-center justify-between text-xs">
                        <Label className="text-[10px] text-slate-400 uppercase font-semibold">Net</Label>
                        <AmountDisplay
                          minorUnits={m.netBalanceMinorUnits}
                          currency={currency}
                          size="sm"
                          variant={isOwed ? 'positive' : owes ? 'negative' : 'neutral'}
                          showSign={true}
                          className="font-bold"
                        />
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Pending Settlements Preview */}
              {debtSettlements.length > 0 ? (
                <div className="space-y-2 pt-1">
                  <Label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                    Pending Smart Settlements ({debtSettlements.length} transfers needed)
                  </Label>
                  <div className="space-y-2">
                    {debtSettlements.slice(0, 3).map((debt, idx) => {
                      const isPayer = debt.fromMemberId === currentUserId;
                      const isReceiver = debt.toMemberId === currentUserId;

                      return (
                        <div
                          key={idx}
                          className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-200/80"
                        >
                          <div className="flex items-center gap-2.5">
                            <div className="w-7 h-7 rounded-full bg-slate-200 text-slate-700 font-bold text-xs flex items-center justify-center">
                              {debt.fromMemberName.charAt(0)}
                            </div>
                            <div className="text-xs">
                              <span className="font-bold text-slate-900">
                                {isPayer ? 'You' : debt.fromMemberName}
                              </span>
                              <span className="text-slate-500 mx-1.5">owes</span>
                              <span className="font-bold text-slate-900">
                                {isReceiver ? 'You' : debt.toMemberName}
                              </span>
                            </div>
                          </div>

                          <div className="flex items-center gap-2">
                            <AmountDisplay
                              minorUnits={debt.amountMinorUnits}
                              currency={currency}
                              size="sm"
                              className="text-slate-900 font-bold"
                            />
                            <Button
                              size="sm"
                              variant={isPayer ? 'primary' : 'outline'}
                              className="text-xs px-2.5 py-1"
                              onClick={() => onOpenSettleModal(debt)}
                            >
                              Settle
                            </Button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ) : (
                <div className="p-3 bg-emerald-50/70 border border-emerald-200/70 rounded-xl text-xs text-emerald-800 font-medium flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>All roommates are completely settled up! Zero outstanding debt.</span>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Required Change 4: ONE Permanent Ad Slot immediately adjacent to Settlement Overview */}
          <AdBanner
            isPro={isPro}
            onUpgradeClick={onOpenUpgradeModal}
            placement="permanent"
          />
        </div>
      ) : (
        /* Permanent Ad Slot in personal mode to maintain consistent fixed ad slot structure */
        <AdBanner
          isPro={isPro}
          onUpgradeClick={onOpenUpgradeModal}
          placement="permanent"
        />
      )}

      {/* Screen Family (a): Recent Activity / Ledger Diary with Continuous Scrolling Inline Ads */}
      <Card>
        <CardHeader className="pb-2">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-slate-400" />
            <CardTitle>Recent Diary Entries</CardTitle>
          </div>
          <Button size="sm" variant="ghost" onClick={onViewAllTransactions}>
            View Ledger
          </Button>
        </CardHeader>
        <CardContent className="pt-0">
          {recentTransactions.length === 0 ? (
            <div className="space-y-4">
              <div className="text-center py-8">
                <div className="w-12 h-12 rounded-2xl bg-slate-100 text-slate-400 flex items-center justify-center mx-auto mb-3">
                  <Receipt className="w-6 h-6" />
                </div>
                <h4 className="font-bold text-sm text-slate-700">No entries recorded yet</h4>
                <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
                  Snap a receipt or record your first room expense or personal income.
                </p>
                <div className="mt-4 flex justify-center gap-2">
                  <Button size="sm" variant="primary" onClick={() => onOpenAddModal('expense')}>
                    Add Expense
                  </Button>
                  <Button size="sm" variant="secondary" onClick={onOpenReceiptCapture}>
                    <span>Scan Receipt</span>
                    <span className="ml-1.5 text-[8px] font-bold bg-amber-100 text-amber-800 border border-amber-300 px-1 py-0.2 rounded">
                      COMING SOON
                    </span>
                  </Button>
                </div>
              </div>

              {/* Required Change 2: End-of-List Ad Slot (visible only at the scroll end of Home feed) */}
              <div className="pt-3 border-t border-slate-100">
                <AdBanner
                  isPro={isPro}
                  onUpgradeClick={onOpenUpgradeModal}
                  placement="end-of-list"
                />
              </div>
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {recentTransactions.map((tx, idx) => {
                const isIncome = tx.type === 'income';
                const isExpense = tx.type === 'expense';
                // Reversal accounting display:
                // An expense reversal credits back money (+₹ in green)
                // An income reversal debits the ledger (−₹ in red)
                const isCredit = tx.isReversal ? isExpense : isIncome;
                const isDebit = tx.isReversal ? isIncome : isExpense;
                const payer = space.members?.find((m) => m.id === tx.payerId);

                // Required Change 1: Inline Ad slot at regular intervals (after every 3rd item)
                const showInlineAd = (idx + 1) % 3 === 0;

                return (
                  <React.Fragment key={tx.id}>
                    <div
                      onClick={() => onEditTransaction(tx)}
                      className="py-3 flex items-center justify-between gap-3 hover:bg-slate-50/80 -mx-2 px-2 rounded-xl transition-colors cursor-pointer"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div
                          className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                            isCredit
                              ? 'bg-emerald-50 text-emerald-600'
                              : isDebit
                              ? 'bg-rose-50 text-rose-600'
                              : 'bg-slate-100 text-slate-700'
                          }`}
                        >
                          {isCredit ? (
                            <ArrowDownLeft className="w-4 h-4" />
                          ) : isDebit ? (
                            <ArrowUpRight className="w-4 h-4" />
                          ) : (
                            <ArrowLeftRight className="w-4 h-4" />
                          )}
                        </div>
                        <div className="min-w-0">
                          <div className="flex items-center gap-2">
                            <span
                              className={`font-bold text-sm text-slate-900 truncate ${
                                tx.isReversed ? 'line-through text-slate-400' : ''
                              }`}
                            >
                              {tx.title}
                            </span>
                            {tx.isReversal && (
                              <span className="text-[10px] text-emerald-700 bg-emerald-50 border border-emerald-200/60 px-1.5 py-0.2 rounded font-medium">
                                Reversal
                              </span>
                            )}
                          </div>

                          {/* Unboxed metadata text with typographic separators */}
                          <div className="flex items-center gap-1.5 text-xs text-slate-500 mt-0.5">
                            <span>{tx.category}</span>
                            <span aria-hidden="true">·</span>
                            <span>{tx.date}</span>
                            {!isPersonal && payer && (
                              <>
                                <span aria-hidden="true">·</span>
                                <span>By {payer.name}</span>
                              </>
                            )}
                            {tx.paymentMethod && (
                              <>
                                <span aria-hidden="true">·</span>
                                <span>{tx.paymentMethod}</span>
                              </>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="text-right shrink-0">
                        <AmountDisplay
                          minorUnits={tx.amount}
                          currency={currency}
                          size="sm"
                          variant={isCredit ? 'positive' : isDebit ? 'negative' : 'neutral'}
                          showSign={isCredit}
                          forceNegativeSign={isDebit}
                          isReversed={tx.isReversed}
                          className="font-bold block"
                        />
                        {tx.splits && tx.splits.length > 0 && (
                          <span className="text-[10px] text-slate-400 block">
                            Split with {tx.splits.length}
                          </span>
                        )}
                      </div>
                    </div>

                    {showInlineAd && (
                      <div className="py-2.5">
                        <AdBanner
                          isPro={isPro}
                          onUpgradeClick={onOpenUpgradeModal}
                          placement="inline"
                          slotIndex={Math.floor(idx / 3)}
                        />
                      </div>
                    )}
                  </React.Fragment>
                );
              })}

              {/* Required Change 2: End-of-List Ad Slot (after the last item in the list) */}
              <div className="pt-3.5 mt-2 border-t border-slate-100">
                <AdBanner
                  isPro={isPro}
                  onUpgradeClick={onOpenUpgradeModal}
                  placement="end-of-list"
                />
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};
