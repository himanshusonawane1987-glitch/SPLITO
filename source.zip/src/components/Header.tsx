import React from 'react';
import { Space, UserProfile } from '../types/finance.ts';
import { ChevronDown, Wallet, LogIn, ShieldCheck, HardDrive, RefreshCw, AlertTriangle, WifiOff } from 'lucide-react';
import { Button } from './ui/Button.tsx';

export type SyncStatus =
  | 'LOCAL_ONLY'
  | 'WRITE_PENDING'
  | 'SYNCING'
  | 'CLOUD_CONFIRMED'
  | 'SYNC_FAILED'
  | 'CONFLICT';

interface HeaderProps {
  currentSpace: Space | null;
  spaces: Space[];
  userProfile: UserProfile | null;
  currentUserEmail?: string | null;
  currentUserDisplayName?: string | null;
  profilePhotoUrl?: string | null;
  isAuthenticated: boolean;
  isOnline?: boolean;
  syncStatus?: SyncStatus;
  syncErrorMessage?: string | null;
  onOpenSpaceSwitcher: () => void;
  onOpenProfile: () => void;
  onLogin: () => void;
  onLogout: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentSpace,
  userProfile,
  currentUserEmail,
  currentUserDisplayName,
  profilePhotoUrl,
  isAuthenticated,
  isOnline = true,
  syncStatus = 'LOCAL_ONLY',
  syncErrorMessage,
  onOpenSpaceSwitcher,
  onOpenProfile,
  onLogin,
  onLogout
}) => {
  const modeLabels: Record<string, string> = {
    roommates: 'Roommates',
    personal: 'Personal',
    family: 'Family',
    trip: 'Trip'
  };

  const resolvedDisplayName = isAuthenticated
    ? (currentUserDisplayName || userProfile?.displayName || (currentUserEmail ? currentUserEmail.split('@')[0] : 'User'))
    : 'Guest User';

  const initialLetter = isAuthenticated ? resolvedDisplayName.charAt(0).toUpperCase() : 'G';

  const renderSyncBadge = () => {
    switch (syncStatus) {
      case 'CLOUD_CONFIRMED':
        return (
          <span
            className="text-[10px] font-medium text-emerald-600 flex items-center gap-1 justify-end"
            title="Authoritative Firestore write acknowledged and server read-after-write verified"
          >
            <ShieldCheck className="w-3 h-3 text-emerald-600" /> Cloud confirmed
          </span>
        );
      case 'WRITE_PENDING':
        return (
          <span
            className="text-[10px] font-medium text-blue-600 flex items-center gap-1 justify-end animate-pulse"
            title="Validating ledger data..."
          >
            <RefreshCw className="w-3 h-3 text-blue-600 animate-spin" /> Saving...
          </span>
        );
      case 'SYNCING':
        return (
          <span
            className="text-[10px] font-medium text-blue-600 flex items-center gap-1 justify-end animate-pulse"
            title="Cloud write in-flight, awaiting server round-trip confirmation..."
          >
            <RefreshCw className="w-3 h-3 text-blue-600 animate-spin" /> Syncing...
          </span>
        );
      case 'SYNC_FAILED':
        return (
          <span
            className="text-[10px] font-bold text-rose-600 flex items-center gap-1 justify-end"
            title={syncErrorMessage || 'Cloud sync operation failed. Inputs kept safe.'}
          >
            <AlertTriangle className="w-3 h-3 text-rose-600" /> Sync failed
          </span>
        );
      case 'CONFLICT':
        return (
          <span
            className="text-[10px] font-medium text-amber-600 flex items-center gap-1 justify-end"
            title="Version mismatch detected with server ledger."
          >
            <AlertTriangle className="w-3 h-3 text-amber-600" /> Conflict
          </span>
        );
      case 'LOCAL_ONLY':
      default:
        return (
          <span
            className="text-[10px] font-medium text-slate-500 flex items-center gap-1 justify-end"
            title={isAuthenticated ? 'Unverified local space or server read pending' : 'Guest session (local storage only)'}
          >
            <HardDrive className="w-3 h-3 text-slate-500" /> Local only
          </span>
        );
    }
  };

  const getPipColor = () => {
    switch (syncStatus) {
      case 'CLOUD_CONFIRMED':
        return 'bg-emerald-500';
      case 'WRITE_PENDING':
      case 'SYNCING':
        return 'bg-blue-500';
      case 'SYNC_FAILED':
        return 'bg-rose-500';
      case 'CONFLICT':
        return 'bg-amber-500';
      case 'LOCAL_ONLY':
      default:
        return 'bg-slate-400';
    }
  };

  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200/80 px-4 py-3">
      <div className="max-w-4xl mx-auto flex items-center justify-between gap-2">
        {/* Logo and Space Selector */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <div
              className={`relative w-8 h-8 rounded-xl flex items-center justify-center font-black text-sm tracking-tight shadow-xs transition-colors duration-300 ${
                isOnline
                  ? 'bg-blue-600 text-white'
                  : 'bg-slate-700 text-slate-300'
              }`}
              aria-label={isOnline ? 'SPLITO — Online' : 'SPLITO — Offline'}
              title={isOnline ? 'Internet connection active' : 'Offline mode active'}
            >
              <span>H</span>
              {/* Distinct live network status indicator on H logo */}
              {isOnline ? (
                <span className="absolute -top-0.5 -right-0.5 flex h-2 w-2">
                  <span className="animate-ping motion-reduce:hidden absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500 ring-1.5 ring-white" />
                </span>
              ) : (
                <span className="absolute -top-0.5 -right-0.5 flex h-2 w-2">
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-500 ring-1.5 ring-white" />
                </span>
              )}
            </div>
            <span className="font-extrabold text-base tracking-tight text-slate-900 hidden xs:inline">
              HISAAB
            </span>
          </div>

          <span className="h-4 w-px bg-slate-200" />

          {/* Space Trigger */}
          <button
            onClick={onOpenSpaceSwitcher}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200/80 text-slate-800 transition-all text-xs font-semibold cursor-pointer border border-slate-200/60 max-w-[180px] sm:max-w-[260px] truncate"
          >
            <Wallet className="w-3.5 h-3.5 text-blue-600 shrink-0" />
            <span className="truncate">{currentSpace?.name || 'Select Space'}</span>
            {currentSpace && (
              <span className="text-[10px] text-slate-500 bg-white px-1.5 py-0.5 rounded-md font-medium shrink-0">
                {modeLabels[currentSpace.mode] || currentSpace.mode}
              </span>
            )}
            <ChevronDown className="w-3.5 h-3.5 text-slate-400 shrink-0" />
          </button>
        </div>

        {/* Right side: Honest Sync Status & Auth / Profile Avatar */}
        <div className="flex items-center gap-3">
          {isAuthenticated ? (
            <div className="flex items-center gap-2.5">
              <div className="flex flex-col text-right">
                <span className="text-xs font-semibold text-slate-900 truncate max-w-[120px]">
                  {resolvedDisplayName}
                </span>
                {renderSyncBadge()}
              </div>

              {/* PF-01: Avatar button opens profile, NEVER logs out directly */}
              <button
                type="button"
                onClick={onOpenProfile}
                title={`Signed in as ${resolvedDisplayName}. Tap to view profile & settings.`}
                className="relative w-8 h-8 rounded-full bg-blue-50 text-blue-700 font-bold text-xs flex items-center justify-center border border-blue-200 hover:bg-blue-100 hover:border-blue-300 transition-colors cursor-pointer overflow-hidden shrink-0"
              >
                {profilePhotoUrl ? (
                  <img src={profilePhotoUrl} alt={resolvedDisplayName} className="w-full h-full rounded-full object-cover" />
                ) : (
                  initialLetter
                )}
                {/* Mobile sync status pip */}
                <span
                  className={`absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border-2 border-white sm:hidden ${getPipColor()}`}
                />
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2.5">
              <div className="flex flex-col text-right">
                <span className="text-xs font-semibold text-slate-900 truncate max-w-[120px]">
                  Guest User
                </span>
                <span className="text-[10px] text-slate-400 font-medium flex items-center gap-1 justify-end">
                  <HardDrive className="w-2.5 h-2.5 text-slate-400" /> Guest Local
                </span>
              </div>

              {/* PF-01 & PF-05: Guest avatar opens profile */}
              <button
                type="button"
                onClick={onOpenProfile}
                title="Guest User Profile & Settings. Tap to view profile."
                className="relative w-8 h-8 rounded-full bg-slate-100 text-slate-700 font-bold text-xs flex items-center justify-center border border-slate-300 hover:bg-slate-200 transition-colors cursor-pointer overflow-hidden shrink-0"
              >
                {profilePhotoUrl ? (
                  <img src={profilePhotoUrl} alt="Guest User" className="w-full h-full rounded-full object-cover" />
                ) : (
                  'G'
                )}
              </button>

              <Button
                size="sm"
                variant="outline"
                icon={<LogIn className="w-3.5 h-3.5 text-blue-600" />}
                onClick={onLogin}
                className="text-xs font-semibold hidden sm:inline-flex"
              >
                Sign In
              </Button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
