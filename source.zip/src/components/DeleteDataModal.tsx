import React, { useState } from 'react';
import { Modal } from './ui/Modal.tsx';
import { Button } from './ui/Button.tsx';
import { AlertTriangle, Trash2, Database, ShieldCheck, CheckCircle2 } from 'lucide-react';

interface DeleteDataModalProps {
  isOpen: boolean;
  onClose: () => void;
  userEmail?: string | null;
  onConfirmDeleteData: () => Promise<void>;
}

export const DeleteDataModal: React.FC<DeleteDataModalProps> = ({
  isOpen,
  onClose,
  userEmail,
  onConfirmDeleteData
}) => {
  const [confirmationText, setConfirmationText] = useState<string>('');
  const [finalConsent, setFinalConsent] = useState<boolean>(false);
  const [isDeleting, setIsDeleting] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const isConfirmed = confirmationText.trim().toUpperCase() === 'DELETE MY DATA';
  const canProceed = isConfirmed && finalConsent && !isDeleting;

  const handleDelete = async () => {
    if (!canProceed) return;
    setIsDeleting(true);
    setErrorMessage(null);
    try {
      await onConfirmDeleteData();
      onClose();
    } catch (err: any) {
      setErrorMessage(err?.message || 'Failed to delete personal data. Please try again.');
      setIsDeleting(false);
    }
  };

  const handleModalClose = () => {
    if (isDeleting) return;
    setConfirmationText('');
    setFinalConsent(false);
    setErrorMessage(null);
    onClose();
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={handleModalClose}
      title="Delete My Entries & Data"
      subtitle="Delete your spaces and ledger records while keeping your login active"
      maxWidth="md"
    >
      <div className="space-y-4 text-left">
        {/* Warning Banner */}
        <div className="p-4 bg-amber-50 border border-amber-200/90 rounded-2xl flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div className="text-xs text-amber-950 space-y-1">
            <span className="font-bold block">
              Permanent Data Deletion Notice
            </span>
            <p className="leading-relaxed text-amber-900">
              This will permanently delete your personal spaces, transactions and associated data. Your SPLITO account and login will remain active.
            </p>
          </div>
        </div>

        {/* Detailed Explanation */}
        <div className="p-4 bg-slate-50 border border-slate-200/80 rounded-2xl space-y-2 text-xs text-slate-700">
          <span className="font-bold text-slate-900 block">
            What will and will not be removed:
          </span>
          <ul className="list-disc pl-4 space-y-1.5 text-slate-600">
            <li>
              <strong className="text-slate-800">Your Login & Account:</strong> Your Google login and account ({userEmail || 'Active User'}) will <strong>remain active</strong>. You will not be signed out.
            </li>
            <li>
              <strong className="text-slate-800">Personal Spaces & Entries:</strong> All personal spaces, transactions, receipts, and audit entries exclusively owned by you will be permanently removed.
            </li>
            <li>
              <strong className="text-slate-800">Shared Spaces (Roommates/Trips):</strong> Shared ledgers are preserved so remaining members' zero-sum balances are not corrupted. Your name will appear as "Former Member".
            </li>
            <li>
              <strong className="text-slate-800">Clean Slate:</strong> After deletion, you can immediately create a brand new space and start fresh.
            </li>
          </ul>
        </div>

        {/* Explicit Typed Confirmation */}
        <div className="space-y-2">
          <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider">
            Type <span className="text-amber-700 font-mono">DELETE MY DATA</span> to confirm:
          </label>
          <input
            type="text"
            value={confirmationText}
            onChange={(e) => {
              setConfirmationText(e.target.value);
              setErrorMessage(null);
            }}
            placeholder="DELETE MY DATA"
            className="w-full bg-white text-slate-900 font-mono text-sm px-3.5 py-3 border border-slate-300 focus:border-amber-500 focus:ring-2 focus:ring-amber-200 rounded-xl focus:outline-none transition-all"
            disabled={isDeleting}
          />
        </div>

        {/* Final Checkbox Confirmation */}
        <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-start gap-2.5">
          <input
            id="final-delete-data-consent"
            type="checkbox"
            checked={finalConsent}
            onChange={(e) => setFinalConsent(e.target.checked)}
            disabled={!isConfirmed || isDeleting}
            className="mt-0.5 w-4 h-4 text-amber-600 rounded border-slate-300 focus:ring-amber-500 cursor-pointer disabled:opacity-50"
          />
          <label
            htmlFor="final-delete-data-consent"
            className={`text-xs leading-relaxed select-none ${
              isConfirmed ? 'text-slate-800 cursor-pointer font-medium' : 'text-slate-400 cursor-not-allowed'
            }`}
          >
            I confirm that I want to erase all my personal entries and spaces. I understand this cannot be undone.
          </label>
        </div>

        {errorMessage && (
          <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl text-xs font-medium">
            {errorMessage}
          </div>
        )}

        {/* Actions */}
        <div className="pt-2 flex items-center justify-end gap-2">
          <Button
            type="button"
            variant="ghost"
            onClick={handleModalClose}
            disabled={isDeleting}
          >
            Cancel
          </Button>
          <Button
            type="button"
            variant="primary"
            size="md"
            icon={<Trash2 className="w-4 h-4" />}
            isLoading={isDeleting}
            disabled={!canProceed}
            onClick={handleDelete}
            className="bg-amber-600 hover:bg-amber-700 text-white border-amber-600"
          >
            Delete My Data
          </Button>
        </div>
      </div>
    </Modal>
  );
};
