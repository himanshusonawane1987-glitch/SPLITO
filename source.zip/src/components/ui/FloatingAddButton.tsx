import React, { useState } from 'react';
import { Plus, ArrowDownLeft, ArrowUpRight, ArrowLeftRight, CheckCircle2, Wallet } from 'lucide-react';
import { TransactionType } from '../../types/finance.ts';

interface FloatingAddButtonProps {
  onSelectAction: (type: TransactionType) => void;
  onOpenWalletPay?: () => void;
  spaceMode?: string;
  isArchived?: boolean;
}

export const FloatingAddButton: React.FC<FloatingAddButtonProps> = ({
  onSelectAction,
  onOpenWalletPay,
  spaceMode = 'roommates',
  isArchived = false
}) => {
  const [isOpen, setIsOpen] = useState(false);

  const handleSelect = (type: TransactionType) => {
    setIsOpen(false);
    if (isArchived && type !== 'settlement') {
      alert('This space is archived and in read-only audit mode. New expenses or transfers cannot be recorded.');
      return;
    }
    onSelectAction(type);
  };

  return (
    <>
      {/* Backdrop when menu is open */}
      {isOpen && (
        <div
          className="fixed inset-0 z-40 bg-slate-900/30 backdrop-blur-xs transition-opacity"
          onClick={() => setIsOpen(false)}
        />
      )}

      {/* Floating Action Menu */}
      <div className="fixed bottom-20 right-4 sm:right-8 z-40 flex flex-col items-end gap-2.5">
        {/* Wallet floating icon (PART 3) - rendered before menu in DOM order */}
        {onOpenWalletPay && (
          <button
            onClick={() => {
              if (isArchived) {
                alert('This space is archived and in read-only audit mode. New expenses or transfers cannot be added to an archived space. You can settle outstanding balances or restore the space.');
                return;
              }
              onOpenWalletPay();
            }}
            aria-label="SPLITO Wallet Pay"
            title="SPLITO Wallet Pay"
            className="flex items-center justify-center w-12 h-12 rounded-2xl bg-emerald-600 text-white shadow-xl hover:bg-emerald-700 active:scale-95 transition-all duration-200 cursor-pointer border border-emerald-500/40"
          >
            <Wallet className="w-5 h-5" />
          </button>
        )}

        {isOpen && (
          <div className="flex flex-col items-end gap-2 mb-2 animate-in fade-in slide-in-from-bottom-3 duration-150">
            {/* Record Settlement (if group or roommates or trip) */}
            {spaceMode !== 'personal' && (
              <button
                onClick={() => handleSelect('settlement')}
                className="flex items-center gap-2.5 bg-white text-slate-800 hover:text-indigo-600 px-3.5 py-2 rounded-xl shadow-md border border-slate-200/80 hover:bg-slate-50 transition-all text-xs font-semibold cursor-pointer group"
              >
                <span>Record Settlement</span>
                <span className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center group-hover:bg-indigo-100 transition-colors">
                  <CheckCircle2 className="w-4 h-4" />
                </span>
              </button>
            )}

            {/* Transfer */}
            <button
              onClick={() => handleSelect('transfer')}
              className="flex items-center gap-2.5 bg-white text-slate-800 hover:text-blue-600 px-3.5 py-2 rounded-xl shadow-md border border-slate-200/80 hover:bg-slate-50 transition-all text-xs font-semibold cursor-pointer group"
            >
              <span>Transfer / Khata</span>
              <span className="w-8 h-8 rounded-lg bg-slate-100 text-slate-600 flex items-center justify-center group-hover:bg-slate-200 transition-colors">
                <ArrowLeftRight className="w-4 h-4" />
              </span>
            </button>

            {/* Income */}
            <button
              onClick={() => handleSelect('income')}
              className="flex items-center gap-2.5 bg-white text-slate-800 hover:text-emerald-600 px-3.5 py-2 rounded-xl shadow-md border border-slate-200/80 hover:bg-slate-50 transition-all text-xs font-semibold cursor-pointer group"
            >
              <span>Add Received Money</span>
              <span className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center group-hover:bg-emerald-100 transition-colors">
                <ArrowDownLeft className="w-4 h-4" />
              </span>
            </button>

            {/* Expense */}
            <button
              onClick={() => handleSelect('expense')}
              className="flex items-center gap-2.5 bg-white text-slate-800 hover:text-rose-600 px-3.5 py-2 rounded-xl shadow-md border border-slate-200/80 hover:bg-slate-50 transition-all text-xs font-semibold cursor-pointer group"
            >
              <span>Add Expense {spaceMode !== 'personal' ? '& Split' : ''}</span>
              <span className="w-8 h-8 rounded-lg bg-rose-50 text-rose-600 flex items-center justify-center group-hover:bg-rose-100 transition-colors">
                <ArrowUpRight className="w-4 h-4" />
              </span>
            </button>
          </div>
        )}

        {/* Main Floating Trigger Button */}
        <button
          onClick={() => setIsOpen(!isOpen)}
          aria-label="Add transaction"
          className={`flex items-center justify-center w-14 h-14 rounded-2xl bg-blue-600 text-white shadow-xl hover:bg-blue-700 active:scale-95 transition-all duration-200 cursor-pointer ${
            isOpen ? 'rotate-45 bg-slate-800 hover:bg-slate-900' : ''
          }`}
        >
          <Plus className="w-6 h-6 stroke-[2.5]" />
        </button>
      </div>
    </>
  );
};
