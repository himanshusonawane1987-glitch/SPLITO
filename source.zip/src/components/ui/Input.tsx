import React from 'react';
import { getCurrencySymbol } from '../../lib/finance-engine.ts';
import { CurrencyCode } from '../../types/finance.ts';

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  hint?: string;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
}

export const Input = React.forwardRef<HTMLInputElement, InputProps>(({
  label,
  error,
  hint,
  leftIcon,
  rightIcon,
  className = '',
  id,
  ...props
}, ref) => {
  const inputId = id || (label ? label.toLowerCase().replace(/\s+/g, '-') : undefined);

  return (
    <div className="w-full text-left">
      {label && (
        <label htmlFor={inputId} className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
          {label}
        </label>
      )}
      <div className="relative flex items-center">
        {leftIcon && (
          <div className="absolute left-3.5 text-slate-400 pointer-events-none flex items-center">
            {leftIcon}
          </div>
        )}
        <input
          id={inputId}
          ref={ref}
          className={`w-full bg-white text-slate-900 placeholder:text-slate-400 border rounded-xl py-2.5 text-sm transition-all
            ${leftIcon ? 'pl-10' : 'pl-3.5'}
            ${rightIcon ? 'pr-10' : 'pr-3.5'}
            ${error ? 'border-rose-400 focus:border-rose-500 focus:ring-2 focus:ring-rose-200' : 'border-slate-200 hover:border-slate-300 focus:border-blue-600 focus:ring-2 focus:ring-blue-100'}
            focus:outline-none shadow-2xs ${className}`}
          {...props}
        />
        {rightIcon && (
          <div className="absolute right-3.5 text-slate-400 pointer-events-none flex items-center">
            {rightIcon}
          </div>
        )}
      </div>
      {error && <p className="text-xs text-rose-600 mt-1 font-medium">{error}</p>}
      {hint && !error && <p className="text-xs text-slate-500 mt-1">{hint}</p>}
    </div>
  );
});
Input.displayName = 'Input';

interface CurrencyInputProps {
  label?: string;
  paise: number;
  onChangePaise: (paise: number) => void;
  currency?: CurrencyCode;
  error?: string;
  hint?: string;
  autoFocus?: boolean;
}

export const CurrencyInput: React.FC<CurrencyInputProps> = ({
  label,
  paise,
  onChangePaise,
  currency = 'INR',
  error,
  hint,
  autoFocus
}) => {
  // We keep a display string state that converts between rupee string and integer paise
  const [displayValue, setDisplayValue] = React.useState<string>(() => {
    if (paise === 0) return '';
    return (paise / 100).toString();
  });

  React.useEffect(() => {
    // If incoming paise changed externally and does not match current parsed value
    const currentParsedPaise = Math.round((parseFloat(displayValue) || 0) * 100);
    if (paise !== currentParsedPaise) {
      setDisplayValue(paise === 0 ? '' : (paise / 100).toString());
    }
  }, [paise]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    // Allow digits and up to one decimal point
    if (val === '' || /^\d*(\.\d{0,2})?$/.test(val)) {
      setDisplayValue(val);
      const parsedFloat = parseFloat(val);
      const calculatedPaise = isNaN(parsedFloat) ? 0 : Math.round(parsedFloat * 100);
      onChangePaise(calculatedPaise);
    }
  };

  const symbol = getCurrencySymbol(currency);

  return (
    <div className="w-full text-left">
      {label && (
        <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
          {label}
        </label>
      )}
      <div className="relative flex items-center">
        <div className="absolute left-4 text-slate-700 font-bold text-lg select-none">
          {symbol}
        </div>
        <input
          type="text"
          inputMode="decimal"
          placeholder="0.00"
          value={displayValue}
          onChange={handleChange}
          autoFocus={autoFocus}
          className={`w-full bg-white text-slate-900 font-bold text-2xl pl-10 pr-4 py-3 border rounded-xl transition-all tracking-tight
            ${error ? 'border-rose-400 focus:border-rose-500 focus:ring-2 focus:ring-rose-200' : 'border-slate-200 hover:border-slate-300 focus:border-blue-600 focus:ring-3 focus:ring-blue-100'}
            focus:outline-none shadow-2xs font-mono font-tabular tabular-nums`}
        />
        <div className="absolute right-3.5 text-xs font-semibold text-slate-400 bg-slate-100 px-2 py-1 rounded-md">
          {currency}
        </div>
      </div>
      <div className="flex justify-between items-center mt-1">
        {error ? (
          <p className="text-xs text-rose-600 font-medium">{error}</p>
        ) : (
          <p className="text-xs text-slate-500">
            {hint || (paise > 0 ? `= ${paise.toLocaleString('en-IN')} paise minor units` : 'Enter amount')}
          </p>
        )}
      </div>
    </div>
  );
};
