import React from 'react';
import { TransactionType } from '../../types/finance.ts';

interface BadgeProps {
  children: React.ReactNode;
  variant?: 'income' | 'expense' | 'transfer' | 'settlement' | 'neutral' | 'primary' | 'warning';
  size?: 'sm' | 'md';
  className?: string;
  icon?: React.ReactNode;
}

export const Badge: React.FC<BadgeProps> = ({
  children,
  variant = 'neutral',
  size = 'md',
  className = '',
  icon
}) => {
  const sizeStyles = {
    sm: 'text-[11px] px-2 py-0.5 gap-1 font-medium',
    md: 'text-xs px-2.5 py-1 gap-1.5 font-semibold'
  };

  const variantStyles = {
    income: 'bg-emerald-50 text-emerald-700 border border-emerald-200/80',
    expense: 'bg-rose-50 text-rose-700 border border-rose-200/80',
    transfer: 'bg-slate-100 text-slate-700 border border-slate-200',
    settlement: 'bg-indigo-50 text-indigo-700 border border-indigo-200/80',
    primary: 'bg-blue-50 text-blue-700 border border-blue-200/80',
    neutral: 'bg-slate-50 text-slate-600 border border-slate-200/60',
    warning: 'bg-amber-50 text-amber-700 border border-amber-200/80'
  };

  return (
    <span
      className={`inline-flex items-center rounded-lg leading-tight shrink-0 transition-colors ${sizeStyles[size]} ${variantStyles[variant]} ${className}`}
    >
      {icon && <span className="shrink-0">{icon}</span>}
      {children}
    </span>
  );
};

export const TransactionTypeBadge: React.FC<{ type: TransactionType }> = ({ type }) => {
  switch (type) {
    case 'income':
      return <Badge variant="income">Income</Badge>;
    case 'expense':
      return <Badge variant="expense">Expense</Badge>;
    case 'transfer':
      return <Badge variant="transfer">Transfer</Badge>;
    case 'settlement':
      return <Badge variant="settlement">Settlement</Badge>;
    default:
      return <Badge variant="neutral">{type}</Badge>;
  }
};
