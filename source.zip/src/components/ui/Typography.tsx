import React from 'react';
import { CurrencyCode } from '../../types/finance.ts';
import { formatMinorUnits, getCurrencyMeta } from '../../lib/finance-engine.ts';
import { TEXT_STYLES } from '../../lib/typography.ts';

interface AmountDisplayProps {
  minorUnits: number;
  currency: CurrencyCode;
  size?: 'hero' | 'metric' | 'row' | 'sm' | 'lg' | 'md';
  variant?: 'income' | 'expense' | 'neutral' | 'owed' | 'owes' | 'settlement' | 'inverted' | 'positive' | 'negative';
  showSign?: boolean;
  forceNegativeSign?: boolean;
  className?: string;
  isReversed?: boolean;
}

export const AmountDisplay: React.FC<AmountDisplayProps> = ({
  minorUnits,
  currency,
  size = 'row',
  variant = 'neutral',
  showSign = false,
  forceNegativeSign = false,
  className = '',
  isReversed = false
}) => {
  const isPositive = minorUnits > 0;
  const isNegative = minorUnits < 0;

  const normalizedSize = size === 'lg' ? 'hero' : size === 'md' ? 'metric' : size;
  const normalizedVariant =
    variant === 'positive'
      ? 'income'
      : variant === 'negative'
      ? 'expense'
      : variant;

  const sizeClasses: Record<'hero' | 'metric' | 'row' | 'sm', string> = {
    hero: 'text-3xl sm:text-4xl ' + TEXT_STYLES.amountHero,
    metric: 'text-lg sm:text-xl ' + TEXT_STYLES.amountMetric,
    row: 'text-sm sm:text-base ' + TEXT_STYLES.amountRow,
    sm: 'text-xs ' + TEXT_STYLES.amountSmall
  };

  const variantClasses: Record<'neutral' | 'inverted' | 'income' | 'expense' | 'owed' | 'owes' | 'settlement', string> = {
    neutral: 'text-slate-900',
    inverted: 'text-white',
    income: 'text-emerald-600',
    expense: 'text-rose-600',
    owed: 'text-emerald-600',
    owes: 'text-rose-600',
    settlement: 'text-indigo-600'
  };

  const formatted = formatMinorUnits(Math.abs(minorUnits), currency);

  return (
    <span
      className={`inline-flex items-baseline gap-0.5 ${sizeClasses[normalizedSize]} ${
        isReversed ? 'line-through text-slate-400' : variantClasses[normalizedVariant]
      } ${className}`}
    >
      {/* Explicit sign indicator ensuring status is never conveyed by color alone */}
      {showSign && isPositive && <span className="font-bold select-none">+</span>}
      {(isNegative || normalizedVariant === 'expense' || normalizedVariant === 'owes' || forceNegativeSign) && minorUnits !== 0 && (
        <span className="font-bold select-none">−</span>
      )}
      <span>{formatted}</span>
    </span>
  );
};

export const Heading: React.FC<{
  level?: 1 | 2 | 3 | 'display';
  children: React.ReactNode;
  className?: string;
}> = ({ level = 2, children, className = '' }) => {
  if (level === 'display') {
    return <h1 className={`text-2xl sm:text-3xl text-slate-900 ${TEXT_STYLES.display} ${className}`}>{children}</h1>;
  }
  if (level === 1) {
    return <h1 className={`text-xl sm:text-2xl text-slate-900 ${TEXT_STYLES.h1} ${className}`}>{children}</h1>;
  }
  if (level === 2) {
    return <h2 className={`text-lg sm:text-xl text-slate-900 ${TEXT_STYLES.h2} ${className}`}>{children}</h2>;
  }
  return <h3 className={`text-base font-bold text-slate-900 ${TEXT_STYLES.h3} ${className}`}>{children}</h3>;
};

export const Label: React.FC<{
  children: React.ReactNode;
  className?: string;
}> = ({ children, className = '' }) => (
  <span className={`block ${TEXT_STYLES.label} ${className}`}>{children}</span>
);
