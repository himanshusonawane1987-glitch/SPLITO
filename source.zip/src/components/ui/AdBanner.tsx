import React from 'react';
import { shouldShowAds, ADMOB_TEST_CONFIG } from '../../lib/ad-service.ts';
import { Sparkles, ShieldCheck } from 'lucide-react';

export type AdPlacement = 'inline' | 'permanent' | 'end-of-list' | 'insights' | string;

interface AdBannerProps {
  isPro?: boolean;
  onUpgradeClick?: () => void;
  className?: string;
  placement?: AdPlacement;
  slotIndex?: number;
}

export const AdBanner: React.FC<AdBannerProps> = ({
  isPro = false,
  onUpgradeClick,
  className = '',
  placement = 'inline',
  slotIndex
}) => {
  // Pro users never see any ads in any placement
  if (!shouldShowAds(isPro)) {
    return null;
  }

  const getPlacementDetails = () => {
    switch (placement) {
      case 'permanent':
        return {
          badge: 'Ad • Sponsor',
          title: `Test AdMob Permanent Banner (${ADMOB_TEST_CONFIG.isTestMode ? 'Test Unit' : 'Live'})`,
          subtitle: 'Fixed sponsor slot • Zero private financial data shared'
        };
      case 'end-of-list':
        return {
          badge: 'Ad • End of Feed',
          title: `Test AdMob End-of-List Banner (${ADMOB_TEST_CONFIG.isTestMode ? 'Test Unit' : 'Live'})`,
          subtitle: 'End of diary feed • Zero private financial data shared'
        };
      case 'inline':
        return {
          badge: 'Ad • Feed',
          title: `Test AdMob Inline Ad ${typeof slotIndex === 'number' ? `#${slotIndex + 1}` : ''} (${ADMOB_TEST_CONFIG.isTestMode ? 'Test Unit' : 'Live'})`.trim(),
          subtitle: 'Inline scroll slot • Zero private financial data shared'
        };
      default:
        return {
          badge: 'Ad',
          title: `Test AdMob Banner (${ADMOB_TEST_CONFIG.isTestMode ? 'Test Unit' : 'Live'})`,
          subtitle: 'Zero private financial data shared'
        };
    }
  };

  const details = getPlacementDetails();

  return (
    <div
      aria-label="Sponsored advertisement"
      data-ad-placement={placement}
      className={`p-3 bg-gradient-to-r from-slate-50 to-blue-50/40 border border-slate-200/80 rounded-2xl flex items-center justify-between text-left text-xs ${className}`}
    >
      <div className="flex items-center gap-2.5">
        <span className="text-[10px] font-bold text-slate-500 bg-slate-200/70 border border-slate-300/50 px-1.5 py-0.5 rounded uppercase tracking-wider">
          {details.badge}
        </span>
        <div>
          <span className="font-semibold text-slate-800 block text-xs">
            {details.title}
          </span>
          <span className="text-[11px] text-slate-500 flex items-center gap-1">
            <ShieldCheck className="w-3 h-3 text-emerald-600" />
            {details.subtitle}
          </span>
        </div>
      </div>

      {onUpgradeClick && (
        <button
          type="button"
          onClick={onUpgradeClick}
          className="px-2.5 py-1 bg-white border border-blue-200 text-blue-700 hover:bg-blue-50 rounded-lg font-bold text-[11px] cursor-pointer shadow-2xs flex items-center gap-1 transition-colors shrink-0"
        >
          <Sparkles className="w-3 h-3 text-amber-500" />
          Go Ad-Free
        </button>
      )}
    </div>
  );
};
