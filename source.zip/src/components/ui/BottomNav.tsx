import React from 'react';
import { Home, ReceiptText, Users, PieChart, User } from 'lucide-react';

export type TabKey = 'home' | 'transactions' | 'groups' | 'insights' | 'profile';

interface BottomNavProps {
  activeTab: TabKey;
  onChangeTab: (tab: TabKey) => void;
  spaceMode?: string;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  onChangeTab,
  spaceMode = 'roommates'
}) => {
  const tabs = [
    { key: 'home' as TabKey, label: 'Home', icon: Home },
    { key: 'transactions' as TabKey, label: 'Ledger', icon: ReceiptText },
    {
      key: 'groups' as TabKey,
      label: spaceMode === 'personal' ? 'Khata' : 'Split & Dues',
      icon: Users
    },
    { key: 'insights' as TabKey, label: 'Insights', icon: PieChart },
    { key: 'profile' as TabKey, label: 'Settings', icon: User }
  ];

  const activeIndex = tabs.findIndex((tab) => tab.key === activeTab);
  const safeActiveIndex = activeIndex >= 0 ? activeIndex : 0;

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200/80 px-2 py-1.5 shadow-lg select-none">
      <div className="max-w-md mx-auto grid grid-cols-5 relative items-center">
        {/* Animated Sliding Glass Circle Overlay (One unified real-glass circular element) */}
        <div
          aria-hidden="true"
          className="absolute top-0 bottom-0 pointer-events-none z-10 flex items-center justify-center transition-transform duration-300 ease-out motion-reduce:transition-none"
          style={{
            width: '20%',
            transform: `translateX(${safeActiveIndex * 100}%)`
          }}
        >
          {/* Real Optical Glass Circle (50px diameter, aspect ratio 1:1, frosted blur, glossy highlight, blue rim glow) */}
          <div className="w-[50px] h-[50px] rounded-full relative overflow-hidden backdrop-blur-md bg-gradient-to-b from-white/75 via-white/30 to-blue-500/15 border border-white/90 ring-1 ring-blue-300/40 shadow-[0_4px_16px_rgba(37,99,235,0.18),0_1px_4px_rgba(37,99,235,0.12),inset_0_1.5px_2px_rgba(255,255,255,0.95),inset_0_-1.5px_2px_rgba(37,99,235,0.14)]">
            {/* Glossy Top Specular Highlight Arc */}
            <div className="absolute inset-x-1.5 top-0.5 h-[44%] rounded-t-full bg-gradient-to-b from-white/95 via-white/50 to-transparent pointer-events-none opacity-80" />
            {/* Light Refraction Caustic Lens Effect */}
            <div className="absolute inset-0 rounded-full bg-[radial-gradient(circle_at_50%_18%,rgba(255,255,255,0.85)_0%,rgba(255,255,255,0.15)_45%,rgba(59,130,246,0.15)_100%)] pointer-events-none" />
          </div>
        </div>

        {/* Five Navigation Tabs */}
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.key;

          return (
            <button
              key={tab.key}
              onClick={() => onChangeTab(tab.key)}
              className={`relative z-20 flex flex-col items-center justify-center py-1 px-1 rounded-xl transition-all duration-150 cursor-pointer min-w-0 w-full h-[50px] ${
                isActive
                  ? 'text-blue-600 font-bold scale-105'
                  : 'text-slate-400 hover:text-slate-600 font-medium'
              }`}
            >
              <div className="relative">
                <Icon className={`w-5 h-5 transition-transform ${isActive ? 'stroke-[2.5px]' : 'stroke-2'}`} />
              </div>
              <span className={`text-[10px] mt-0.5 tracking-tight ${isActive ? 'text-blue-600 font-semibold' : 'text-slate-500'}`}>
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
