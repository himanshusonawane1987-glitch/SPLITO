import React, { useState } from 'react';
import { Modal } from '../ui/Modal.tsx';
import { Button } from '../ui/Button.tsx';
import { LEGAL_DOCUMENTS, LegalDocKey } from '../../lib/legal-content.ts';
import {
  FileText,
  Languages,
  ChevronRight,
  ExternalLink,
  ShieldCheck,
  CheckCircle2
} from 'lucide-react';

interface LegalModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialDocKey?: LegalDocKey;
}

export const LegalModal: React.FC<LegalModalProps> = ({
  isOpen,
  onClose,
  initialDocKey = 'user_agreement'
}) => {
  const [selectedDocKey, setSelectedDocKey] = useState<LegalDocKey>(initialDocKey);
  const [language, setLanguage] = useState<'en' | 'hi'>('en');

  const currentDoc = LEGAL_DOCUMENTS[selectedDocKey];
  const isEnglish = language === 'en';

  const docList = Object.values(LEGAL_DOCUMENTS);

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Legal & User Agreements"
      subtitle="Transparency, regulatory disclosures, and consumer rights"
      maxWidth="xl"
    >
      <div className="space-y-4 text-left">
        {/* Language Selection Header (LG-01: DRAFT banner removed) */}
        <div className="flex items-center justify-between gap-2.5 pb-1 border-b border-slate-100">
          <span className="text-xs font-semibold text-slate-500">
            Document Language
          </span>
          <button
            type="button"
            onClick={() => setLanguage(language === 'en' ? 'hi' : 'en')}
            className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200/80 border border-slate-200 text-slate-800 rounded-xl font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-2xs transition-colors"
          >
            <Languages className="w-3.5 h-3.5 text-blue-600" />
            <span>{isEnglish ? 'हिंदी में पढ़ें (Hindi)' : 'Read in English'}</span>
          </button>
        </div>

        {/* Document Navigation Tabs */}
        <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none border-b border-slate-200">
          {docList.map((doc) => {
            const isSelected = selectedDocKey === doc.id;
            return (
              <button
                key={doc.id}
                type="button"
                onClick={() => setSelectedDocKey(doc.id)}
                className={`px-3 py-2 text-xs font-bold rounded-xl whitespace-nowrap cursor-pointer transition-all ${
                  isSelected
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200 hover:text-slate-900'
                }`}
              >
                {isEnglish ? doc.titleEn : doc.titleHi}
              </button>
            );
          })}
        </div>

        {/* Active Document Reader */}
        <div className="p-5 bg-white border border-slate-200 rounded-2xl shadow-xs space-y-4 max-h-[60vh] overflow-y-auto">
          <div>
            <h3 className="text-lg font-bold text-slate-900 tracking-tight">
              {isEnglish ? currentDoc.titleEn : currentDoc.titleHi}
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              {isEnglish ? currentDoc.summaryEn : currentDoc.summaryHi}
            </p>
          </div>

          <div className="border-t border-slate-100 pt-3 space-y-4">
            {(isEnglish ? currentDoc.sectionsEn : currentDoc.sectionsHi).map((sec, idx) => (
              <div key={idx} className="space-y-1.5">
                <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                  {sec.heading}
                </h4>
                <p className="text-xs text-slate-600 leading-relaxed">
                  {sec.body}
                </p>
              </div>
            ))}
          </div>

          {/* Critical Non-Banking & Credential Disclosure Footer (LG-02: Placeholders removed) */}
          <div className="mt-6 p-3.5 bg-slate-50 rounded-xl border border-slate-200 text-[11px] text-slate-500 space-y-1">
            <span className="font-bold text-slate-700 block">
              Notice of Legal Entity & Financial Status
            </span>
            <p>
              SPLITO is an independent expense-sharing application. SPLITO is not an authorized banking institution or wallet operator. Never provide your banking passwords, OTPs, or UPI PINs to anyone.
            </p>
          </div>
        </div>

        <div className="flex justify-end pt-1">
          <Button variant="secondary" size="md" onClick={onClose}>
            Close Document
          </Button>
        </div>
      </div>
    </Modal>
  );
};
