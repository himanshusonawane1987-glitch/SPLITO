import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Member,
  PaymentMethod,
  PaymentStatus,
  Space,
  SplitShare,
  SplitType,
  Transaction
} from '../types/finance.ts';
import { CurrencyInput } from './ui/Input.tsx';
import { Button } from './ui/Button.tsx';
import {
  calculateCustomSplits,
  calculateEqualSplits,
  calculatePercentageSplits,
  calculateSinglePersonSplit,
  formatMinorUnits,
  getCurrencyMeta
} from '../lib/finance-engine.ts';
import { DEFAULT_CATEGORIES_BY_MODE } from '../lib/storage-service.ts';
import {
  KNOWN_UPI_APPS,
  KnownUpiApp,
  buildUpiPaymentUri,
  launchUpiPayment,
  saveInFlightPayment,
  clearInFlightPayment,
  getInFlightPayment,
  registerForegroundReturnListener,
  isValidVpa
} from '../lib/upi-service.ts';
import {
  X,
  Wallet,
  ArrowRight,
  CheckCircle2,
  AlertCircle,
  Clock,
  RotateCcw,
  QrCode,
  ShieldCheck,
  Check,
  ChevronRight,
  ExternalLink,
  Users,
  Sparkles
} from 'lucide-react';

interface WalletPayModalProps {
  isOpen: boolean;
  onClose: () => void;
  space: Space;
  currentUserId: string;
  initialTransaction?: Transaction | null;
  onSaveTransaction: (tx: Transaction) => Promise<void>;
  onUpdateTransactionStatus?: (
    txId: string,
    status: PaymentStatus,
    updatedAmountMinorUnits?: number,
    recalculatedSplits?: SplitShare[]
  ) => Promise<void>;
}

type ModalStep = 'entry' | 'select_app' | 'confirm_sheet';

const QUICK_TITLES = [
  'Grocery',
  'Fruit & Veggies',
  'Juice & Snacks',
  'Biscuits & Chai',
  'WiFi Bill',
  'Electricity',
  'Household Supplies'
];

export const WalletPayModal: React.FC<WalletPayModalProps> = ({
  isOpen,
  onClose,
  space,
  currentUserId,
  initialTransaction,
  onSaveTransaction,
  onUpdateTransactionStatus
}) => {
  const [step, setStep] = useState<ModalStep>('entry');
  const [title, setTitle] = useState<string>('');
  const [amountMinorUnits, setAmountMinorUnits] = useState<number>(0);
  const [category, setCategory] = useState<string>('Groceries');
  const [date, setDate] = useState<string>(() => new Date().toISOString().split('T')[0]);
  const [payerId, setPayerId] = useState<string>(currentUserId);
  const [splitType, setSplitType] = useState<SplitType>('equal');
  const [selectedMemberIds, setSelectedMemberIds] = useState<string[]>([]);
  const [singleTargetMemberId, setSingleTargetMemberId] = useState<string>('');
  const [percentageMap, setPercentageMap] = useState<Record<string, number>>({});
  const [customMinorUnitsMap, setCustomMinorUnitsMap] = useState<Record<string, number>>({});

  // UPI Specific State
  const [selectedApp, setSelectedApp] = useState<KnownUpiApp>(KNOWN_UPI_APPS[0]);
  const [payeeVpa, setPayeeVpa] = useState<string>('');
  const [payeeName, setPayeeName] = useState<string>('');
  const [errorMsg, setErrorMsg] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Active in-flight transaction
  const [activeTxId, setActiveTxId] = useState<string>('');
  const [actualPaidAmountMinorUnits, setActualPaidAmountMinorUnits] = useState<number>(0);

  const members = space.members || [];
  const defaultCategories = DEFAULT_CATEGORIES_BY_MODE[space.mode] || DEFAULT_CATEGORIES_BY_MODE.roommates;
  const currencyMeta = getCurrencyMeta(space.currency);

  // Initialize or reset form state when modal opens
  useEffect(() => {
    if (!isOpen) return;

    setErrorMsg('');
    setIsSubmitting(false);

    if (initialTransaction) {
      // Repayment / Retry / Edit mode
      setActiveTxId(initialTransaction.id);
      setTitle(initialTransaction.title);
      setAmountMinorUnits(initialTransaction.amount);
      setActualPaidAmountMinorUnits(initialTransaction.amount);
      setCategory(initialTransaction.category || 'Groceries');
      setDate(initialTransaction.date || new Date().toISOString().split('T')[0]);
      setPayerId(initialTransaction.payerId || currentUserId);
      setSplitType(initialTransaction.splitType || 'equal');
      setPayeeVpa(initialTransaction.upiPayeeVpa || '');
      setPayeeName(initialTransaction.upiPayeeName || '');

      if (initialTransaction.paymentApp) {
        const found = KNOWN_UPI_APPS.find((a) => a.packageName === initialTransaction.paymentApp || a.id === initialTransaction.paymentApp);
        if (found) setSelectedApp(found);
      }

      if (initialTransaction.splits && initialTransaction.splits.length > 0) {
        const splitIds = initialTransaction.splits.map((s) => s.memberId);
        setSelectedMemberIds(splitIds);
        if (initialTransaction.splitType === 'single' && splitIds.length > 0) {
          setSingleTargetMemberId(splitIds[0]);
        }
        const pMap: Record<string, number> = {};
        const cMap: Record<string, number> = {};
        initialTransaction.splits.forEach((s) => {
          if (typeof s.percentage === 'number') pMap[s.memberId] = s.percentage;
          cMap[s.memberId] = s.shareMinorUnits;
        });
        setPercentageMap(pMap);
        setCustomMinorUnitsMap(cMap);
      } else {
        const allIds = members.map((m) => m.id);
        setSelectedMemberIds(allIds);
        setSingleTargetMemberId(allIds[0] || currentUserId);
      }

      // If opening an existing pending transaction, open directly to confirmation or app selection
      if (initialTransaction.paymentStatus === 'pending') {
        setStep('confirm_sheet');
      } else {
        setStep('entry');
      }
    } else {
      // Fresh new Wallet Pay entry
      const newId = `tx_wallet_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
      setActiveTxId(newId);
      setTitle('');
      setAmountMinorUnits(0);
      setActualPaidAmountMinorUnits(0);
      setCategory('Groceries');
      setDate(new Date().toISOString().split('T')[0]);
      setPayerId(currentUserId);
      setSplitType('equal');
      setPayeeVpa('');
      setPayeeName('');

      const allIds = members.map((m) => m.id);
      setSelectedMemberIds(allIds);
      setSingleTargetMemberId(allIds[0] || currentUserId);

      const count = allIds.length;
      const initialPct = count > 0 ? Number((100 / count).toFixed(2)) : 100;
      const pMap: Record<string, number> = {};
      const cMap: Record<string, number> = {};
      allIds.forEach((id) => {
        pMap[id] = initialPct;
        cMap[id] = 0;
      });
      setPercentageMap(pMap);
      setCustomMinorUnitsMap(cMap);
      setStep('entry');
    }
  }, [isOpen, initialTransaction, space, currentUserId]);

  // Compute live split shares
  const computedSplits: SplitShare[] = useMemo(() => {
    if (splitType === 'none') {
      return [];
    }

    if (splitType === 'single') {
      const targetId = singleTargetMemberId || payerId;
      return calculateSinglePersonSplit(amountMinorUnits, targetId);
    }

    if (selectedMemberIds.length === 0) {
      return [];
    }

    if (splitType === 'equal') {
      return calculateEqualSplits(amountMinorUnits, selectedMemberIds);
    }

    if (splitType === 'percentage') {
      const splitsInput = selectedMemberIds.map((id) => ({
        memberId: id,
        percentage: percentageMap[id] || 0
      }));
      return calculatePercentageSplits(amountMinorUnits, splitsInput);
    }

    if (splitType === 'custom') {
      const splitsInput = selectedMemberIds.map((id) => ({
        memberId: id,
        customMinorUnits: customMinorUnitsMap[id] || 0
      }));
      return calculateCustomSplits(amountMinorUnits, splitsInput);
    }

    return [];
  }, [
    splitType,
    amountMinorUnits,
    selectedMemberIds,
    singleTargetMemberId,
    payerId,
    percentageMap,
    customMinorUnitsMap
  ]);

  // Listen for foreground return when in-flight payment is active
  useEffect(() => {
    if (!isOpen) return;

    const cleanup = registerForegroundReturnListener(() => {
      const inFlight = getInFlightPayment();
      if (inFlight && inFlight.transactionId === activeTxId) {
        setStep('confirm_sheet');
      }
    });

    return cleanup;
  }, [isOpen, activeTxId]);

  const toggleMemberSelection = (memberId: string) => {
    if (selectedMemberIds.includes(memberId)) {
      if (selectedMemberIds.length === 1) return;
      setSelectedMemberIds(selectedMemberIds.filter((id) => id !== memberId));
    } else {
      setSelectedMemberIds([...selectedMemberIds, memberId]);
    }
  };

  // Step 1 -> Step 2 validation & transition
  const handleProceedToAppSelect = () => {
    setErrorMsg('');
    if (amountMinorUnits <= 0) {
      setErrorMsg('Please enter an amount greater than ₹0.');
      return;
    }
    if (!title.trim()) {
      setErrorMsg('Please enter an item name or description (e.g. Grocery, WiFi, Juice).');
      return;
    }

    setActualPaidAmountMinorUnits(amountMinorUnits);
    setStep('select_app');
  };

  // Step 2 -> Launch UPI Payment & Save Pending Entry FIRST (PART 7)
  const handleLaunchPayment = async () => {
    setErrorMsg('');
    setIsSubmitting(true);

    try {
      // 1. Determine Payee VPA: use entered VPA or selected single person's upiId if available
      let resolvedVpa = payeeVpa.trim();
      let resolvedPayeeName = payeeName.trim();

      if (!resolvedVpa && splitType === 'single') {
        const targetMember = members.find((m) => m.id === singleTargetMemberId);
        if (targetMember?.upiId) {
          resolvedVpa = targetMember.upiId;
          resolvedPayeeName = targetMember.name;
        }
      }

      // 2. Build UPI URI (INR only, RFC-compliant)
      const uriResult = buildUpiPaymentUri({
        vpa: resolvedVpa,
        payeeName: resolvedPayeeName,
        amountMinorUnits,
        note: `SPLITO: ${title.trim()}`,
        transactionRef: activeTxId
      });

      // 3. Construct Pending Transaction (SAVED BEFORE APP LAUNCH - PART 7)
      const pendingTx: Transaction = {
        id: activeTxId,
        spaceId: space.id,
        creatorId: currentUserId,
        title: title.trim(),
        type: 'expense',
        category: category || 'Groceries',
        amount: amountMinorUnits,
        date,
        payerId,
        paymentMethod: 'UPI',
        paymentStatus: 'pending',
        paymentApp: selectedApp.packageName,
        paymentAppLabel: selectedApp.name,
        upiPayeeVpa: resolvedVpa || undefined,
        upiPayeeName: resolvedPayeeName || undefined,
        paymentAttemptedAt: new Date().toISOString(),
        splitType,
        splits: computedSplits,
        notes: `SPLITO Wallet Pay via ${selectedApp.name}`,
        createdAt: initialTransaction?.createdAt || new Date().toISOString()
      };

      // 4. Persist to storage (cloud/guest authoritative)
      await onSaveTransaction(pendingTx);

      // 5. Persist to localStorage for WebView recovery
      saveInFlightPayment({
        transactionId: activeTxId,
        spaceId: space.id,
        originalAmountMinorUnits: amountMinorUnits,
        title: title.trim(),
        payerId,
        payeeVpa: resolvedVpa,
        payeeName: resolvedPayeeName,
        paymentAppId: selectedApp.id,
        paymentAppLabel: selectedApp.name,
        timestamp: new Date().toISOString()
      });

      // 6. Launch external UPI application
      await launchUpiPayment(selectedApp, uriResult.uri);

      // 7. Transition to Confirmation Sheet
      setStep('confirm_sheet');
    } catch (err: any) {
      const msg = err instanceof Error ? err.message : String(err);
      setErrorMsg(`Failed to initiate payment: ${msg}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Step 3 Confirmation: Manual user confirmation (PART 8)
  const handleConfirmPaid = async () => {
    setErrorMsg('');
    setIsSubmitting(true);

    try {
      const finalAmount = actualPaidAmountMinorUnits > 0 ? actualPaidAmountMinorUnits : amountMinorUnits;

      // Recalculate splits if amount was corrected
      let finalSplits = computedSplits;
      if (finalAmount !== amountMinorUnits) {
        if (splitType === 'single') {
          finalSplits = calculateSinglePersonSplit(finalAmount, singleTargetMemberId || payerId);
        } else if (splitType === 'equal') {
          finalSplits = calculateEqualSplits(finalAmount, selectedMemberIds);
        } else if (splitType === 'percentage') {
          const splitsInput = selectedMemberIds.map((id) => ({
            memberId: id,
            percentage: percentageMap[id] || 0
          }));
          finalSplits = calculatePercentageSplits(finalAmount, splitsInput);
        } else if (splitType === 'custom') {
          const splitsInput = selectedMemberIds.map((id) => ({
            memberId: id,
            customMinorUnits: customMinorUnitsMap[id] || 0
          }));
          finalSplits = calculateCustomSplits(finalAmount, splitsInput);
        }
      }

      if (onUpdateTransactionStatus) {
        await onUpdateTransactionStatus(activeTxId, 'paid', finalAmount, finalSplits);
      } else {
        // Fallback save with 'paid' status
        const confirmedTx: Transaction = {
          id: activeTxId,
          spaceId: space.id,
          creatorId: currentUserId,
          title: title.trim(),
          type: 'expense',
          category,
          amount: finalAmount,
          date,
          payerId,
          paymentMethod: 'UPI',
          paymentStatus: 'paid',
          paymentApp: selectedApp.packageName,
          paymentAppLabel: selectedApp.name,
          paymentConfirmedAt: new Date().toISOString(),
          splitType,
          splits: finalSplits,
          createdAt: initialTransaction?.createdAt || new Date().toISOString()
        };
        await onSaveTransaction(confirmedTx);
      }

      clearInFlightPayment();
      onClose();
    } catch (err: any) {
      const msg = err instanceof Error ? err.message : String(err);
      setErrorMsg(`Confirmation error: ${msg}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleMarkFailed = async () => {
    setErrorMsg('');
    setIsSubmitting(true);

    try {
      if (onUpdateTransactionStatus) {
        await onUpdateTransactionStatus(activeTxId, 'failed');
      } else {
        const failedTx: Transaction = {
          id: activeTxId,
          spaceId: space.id,
          creatorId: currentUserId,
          title: title.trim(),
          type: 'expense',
          category,
          amount: amountMinorUnits,
          date,
          payerId,
          paymentMethod: 'UPI',
          paymentStatus: 'failed',
          paymentApp: selectedApp.packageName,
          paymentAppLabel: selectedApp.name,
          splitType,
          splits: computedSplits,
          createdAt: initialTransaction?.createdAt || new Date().toISOString()
        };
        await onSaveTransaction(failedTx);
      }

      clearInFlightPayment();
      onClose();
    } catch (err: any) {
      const msg = err instanceof Error ? err.message : String(err);
      setErrorMsg(`Update error: ${msg}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
          {/* Animated Overlay Fade (Optimized: No expensive backdrop filter) */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.18, ease: 'easeOut' }}
            className="fixed inset-0 bg-slate-900/50"
            onClick={onClose}
          />

          {/* Animated Modal Dialog (Optimized: Snappy 200ms cubic bezier, GPU-accelerated composite layer) */}
          <motion.div
            initial={{ scale: 0.96, opacity: 0, y: 10 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.96, opacity: 0, y: 10 }}
            transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
            className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-200/80 overflow-hidden z-10 my-auto text-left flex flex-col max-h-[90vh] transform-gpu will-change-[transform,opacity]"
          >
            {/* Modal Header */}
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-emerald-500/10 via-blue-500/5 to-transparent shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shadow-md shadow-emerald-600/20">
                  <Wallet className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-extrabold text-base text-slate-900 tracking-tight">
                      SPLITO Wallet Pay
                    </h3>
                    <span className="text-[10px] font-bold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full uppercase tracking-wider">
                      UPI V1
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500">
                    Pay via external UPI app & split with roommates
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={onClose}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center transition-colors cursor-pointer"
                aria-label="Close"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Scrollable Content Body */}
            <div className="p-5 overflow-y-auto space-y-4">
              {errorMsg && (
                <div className="p-3 rounded-2xl bg-rose-50 border border-rose-200 text-xs text-rose-800 flex items-center gap-2 animate-in fade-in">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                  <span>{errorMsg}</span>
                </div>
              )}

              {/* STEP 1: EXPENSE ENTRY FORM */}
              {step === 'entry' && (
                <div className="space-y-4">
                  {/* Amount Input */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                      Amount to Pay ({currencyMeta.symbol})
                    </label>
                    <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200">
                      <CurrencyInput
                        paise={amountMinorUnits}
                        onChangePaise={setAmountMinorUnits}
                        currency={space.currency}
                        autoFocus
                      />
                    </div>
                  </div>

                  {/* Item Title & Quick Chips */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                      Expense Name / Merchant
                    </label>
                    <input
                      type="text"
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      placeholder="e.g. D-Mart Grocery, Juice & Snacks"
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white transition-all"
                    />
                    <div className="flex items-center gap-1.5 overflow-x-auto py-2 scrollbar-none">
                      {QUICK_TITLES.map((t) => (
                        <button
                          key={t}
                          type="button"
                          onClick={() => setTitle(t)}
                          className="px-2.5 py-1 text-xs font-medium rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 whitespace-nowrap cursor-pointer transition-colors"
                        >
                          {t}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Category Selection */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                      Category
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-36 overflow-y-auto pr-1">
                      {defaultCategories.map((cat) => (
                        <button
                          key={cat}
                          type="button"
                          onClick={() => setCategory(cat)}
                          className={`px-3 py-2 text-xs font-semibold rounded-xl text-left truncate cursor-pointer transition-all border ${
                            category === cat
                              ? 'bg-blue-50 border-blue-600 text-blue-700 font-bold shadow-xs'
                              : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                          }`}
                        >
                          {cat}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Paid By */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                      Paid By
                    </label>
                    <select
                      value={payerId}
                      onChange={(e) => setPayerId(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-bold text-slate-800 cursor-pointer"
                    >
                      {members.map((m) => (
                        <option key={m.id} value={m.id}>
                          {m.name} {m.id === currentUserId ? '(You)' : ''}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Split Configuration (PART 5E: None, Equal, Percentage, Custom, Single) */}
                  <div className="pt-2 border-t border-slate-100">
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                      Split Configuration
                    </label>
                    <div className="grid grid-cols-3 sm:grid-cols-5 gap-1.5">
                      {(['equal', 'single', 'none', 'percentage', 'custom'] as SplitType[]).map((st) => (
                        <button
                          key={st}
                          type="button"
                          onClick={() => setSplitType(st)}
                          className={`py-2 px-1 text-center text-xs font-bold rounded-xl capitalize cursor-pointer transition-all border ${
                            splitType === st
                              ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                              : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                          }`}
                        >
                          {st === 'none' ? 'No Split' : st === 'single' ? 'Single 100%' : st}
                        </button>
                      ))}
                    </div>

                    {/* Single Person Split Details */}
                    {splitType === 'single' && (
                      <div className="mt-3 p-3 bg-emerald-50/70 border border-emerald-200 rounded-2xl space-y-2">
                        <span className="text-xs font-bold text-emerald-900 block">
                          Select the 1 member who bears 100% of this expense:
                        </span>
                        <div className="grid grid-cols-2 gap-1.5">
                          {members.map((m) => (
                            <button
                              key={m.id}
                              type="button"
                              onClick={() => setSingleTargetMemberId(m.id)}
                              className={`p-2 rounded-xl text-xs font-bold flex items-center justify-between border cursor-pointer transition-all ${
                                singleTargetMemberId === m.id
                                  ? 'bg-emerald-600 text-white border-emerald-600'
                                  : 'bg-white text-slate-700 border-emerald-200 hover:bg-emerald-100/50'
                              }`}
                            >
                              <span className="truncate">{m.name}</span>
                              {singleTargetMemberId === m.id && <Check className="w-3.5 h-3.5" />}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Equal / Percentage / Custom Member Selection */}
                    {(splitType === 'equal' || splitType === 'percentage' || splitType === 'custom') && (
                      <div className="mt-3 space-y-2">
                        <span className="text-[11px] font-bold text-slate-500 uppercase">
                          Participants ({selectedMemberIds.length} of {members.length}):
                        </span>
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                          {members.map((m) => {
                            const isSelected = selectedMemberIds.includes(m.id);
                            return (
                              <button
                                key={m.id}
                                type="button"
                                onClick={() => toggleMemberSelection(m.id)}
                                className={`p-2.5 rounded-xl border text-xs font-semibold flex items-center justify-between cursor-pointer transition-all ${
                                  isSelected
                                    ? 'bg-blue-50 border-blue-600 text-blue-900 font-bold'
                                    : 'bg-white border-slate-200 text-slate-500 opacity-60'
                                }`}
                              >
                                <span className="truncate">{m.name}</span>
                                {isSelected && <Check className="w-3.5 h-3.5 text-blue-600" />}
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    {/* Live Split Preview */}
                    {computedSplits.length > 0 && (
                      <div className="mt-3 p-3 bg-slate-50 border border-slate-200/80 rounded-2xl space-y-1 text-xs">
                        <span className="font-bold text-slate-700 block text-[11px] uppercase tracking-wider">
                          Split Calculation Preview (Paise Accurate):
                        </span>
                        <div className="space-y-1">
                          {computedSplits.map((s) => {
                            const mem = members.find((m) => m.id === s.memberId);
                            return (
                              <div key={s.memberId} className="flex items-center justify-between text-slate-600">
                                <span className="truncate">{mem?.name || s.memberId}</span>
                                <span className="font-mono font-bold text-slate-900">
                                  {formatMinorUnits(s.shareMinorUnits, space.currency)}
                                  {typeof s.percentage === 'number' && (
                                    <span className="text-[10px] text-slate-400 ml-1">({s.percentage}%)</span>
                                  )}
                                </span>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Proceed to Payment Button */}
                  <div className="pt-2">
                    <Button
                      type="button"
                      variant="primary"
                      size="lg"
                      onClick={handleProceedToAppSelect}
                      className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3 rounded-2xl flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/20"
                    >
                      <span>Proceed to UPI Payment</span>
                      <ArrowRight className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              )}

              {/* STEP 2: UPI APPLICATION SELECTION */}
              {step === 'select_app' && (
                <div className="space-y-4">
                  <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between">
                    <div>
                      <span className="text-xs text-slate-500 block">Paying for:</span>
                      <span className="text-sm font-extrabold text-slate-900">{title}</span>
                    </div>
                    <span className="font-mono font-black text-lg text-emerald-600">
                      {formatMinorUnits(amountMinorUnits, space.currency)}
                    </span>
                  </div>

                  {/* Optional Payee VPA / Roommate VPA Info */}
                  <div className="space-y-1.5">
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                      Payee UPI ID (Optional)
                    </label>
                    <input
                      type="text"
                      value={payeeVpa}
                      onChange={(e) => setPayeeVpa(e.target.value)}
                      placeholder="e.g. rahul@oksbi or scan merchant QR"
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-mono text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-600"
                    />
                    <p className="text-[11px] text-slate-500">
                      If left blank, SPLITO opens your UPI app so you can scan the merchant QR code manually.
                    </p>
                  </div>

                  {/* Known Apps Grid (PART 6) */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                      Choose UPI Application
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                      {KNOWN_UPI_APPS.map((app) => {
                        const isSelected = selectedApp.id === app.id;
                        return (
                          <button
                            key={app.id}
                            type="button"
                            onClick={() => setSelectedApp(app)}
                            className={`p-3 rounded-2xl border flex flex-col items-center text-center gap-1.5 cursor-pointer transition-all ${
                              isSelected
                                ? 'bg-emerald-50/60 border-emerald-600 shadow-xs ring-2 ring-emerald-600/20'
                                : 'bg-white border-slate-200 hover:bg-slate-50'
                            }`}
                          >
                            <div
                              className="w-10 h-10 rounded-xl flex items-center justify-center font-black text-xs text-white shadow-xs"
                              style={{ backgroundColor: app.brandColor }}
                            >
                              {app.shortCode}
                            </div>
                            <span className="text-xs font-bold text-slate-900 truncate w-full">
                              {app.name}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Safety & Non-Banking Notice */}
                  <div className="p-3 bg-amber-50/70 border border-amber-200 rounded-2xl text-[11px] text-amber-900 flex items-start gap-2">
                    <ShieldCheck className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                    <span>
                      SPLITO records your ledger expense first as <strong>Pending</strong>. SPLITO never asks for or stores UPI PINs. Complete the payment inside {selectedApp.name}.
                    </span>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex items-center gap-2 pt-2">
                    <Button
                      type="button"
                      variant="ghost"
                      onClick={() => setStep('entry')}
                      className="text-slate-600 font-semibold"
                    >
                      Back
                    </Button>
                    <Button
                      type="button"
                      variant="primary"
                      size="lg"
                      disabled={isSubmitting}
                      onClick={handleLaunchPayment}
                      className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3 rounded-2xl flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/20"
                    >
                      <ExternalLink className="w-4 h-4" />
                      <span>{isSubmitting ? 'Opening App...' : `Open ${selectedApp.name} & Pay`}</span>
                    </Button>
                  </div>
                </div>
              )}

              {/* STEP 3: MANUAL PAYMENT CONFIRMATION SHEET (PART 8) */}
              {step === 'confirm_sheet' && (
                <div className="space-y-4">
                  <div className="p-4 bg-amber-50/80 border border-amber-200 rounded-2xl space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4 text-amber-600 animate-pulse" />
                        <span className="font-extrabold text-xs text-amber-900 uppercase tracking-wider">
                          Payment Pending Confirmation
                        </span>
                      </div>
                      <span className="text-[10px] font-bold bg-amber-200 text-amber-900 px-2 py-0.5 rounded-full">
                        Pending
                      </span>
                    </div>
                    <p className="text-xs text-amber-950">
                      External UPI apps cannot confirm payment status automatically. Did your payment through <strong>{selectedApp.name}</strong> succeed?
                    </p>
                  </div>

                  {/* Summary of Expense */}
                  <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-2.5">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-500 font-medium">Expense Item:</span>
                      <span className="font-bold text-slate-900">{title}</span>
                    </div>
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-500 font-medium">Selected App:</span>
                      <span className="font-bold text-slate-900">{selectedApp.name}</span>
                    </div>

                    {/* Actual Amount Correction (PART 8: Allow correcting paid amount) */}
                    <div className="pt-2 border-t border-slate-200">
                      <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                        Actual Amount Paid ({currencyMeta.symbol}):
                      </label>
                      <CurrencyInput
                        paise={actualPaidAmountMinorUnits}
                        onChangePaise={setActualPaidAmountMinorUnits}
                        currency={space.currency}
                      />
                      <p className="text-[11px] text-slate-400 mt-1">
                        If merchant rounded or changed the bill, update it here before confirming.
                      </p>
                    </div>
                  </div>

                  {/* Confirmation Actions */}
                  <div className="space-y-2 pt-2">
                    <Button
                      type="button"
                      variant="primary"
                      size="lg"
                      disabled={isSubmitting}
                      onClick={handleConfirmPaid}
                      className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3 rounded-2xl flex items-center justify-center gap-2 shadow-md shadow-emerald-600/20"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Yes, Payment Successful (Mark Paid)</span>
                    </Button>

                    <div className="grid grid-cols-2 gap-2">
                      <Button
                        type="button"
                        variant="ghost"
                        disabled={isSubmitting}
                        onClick={handleMarkFailed}
                        className="border border-rose-200 text-rose-700 hover:bg-rose-50 font-bold rounded-2xl"
                      >
                        Payment Failed
                      </Button>
                      <Button
                        type="button"
                        variant="secondary"
                        onClick={onClose}
                        className="font-semibold text-slate-600 rounded-2xl"
                      >
                        Decide Later
                      </Button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
