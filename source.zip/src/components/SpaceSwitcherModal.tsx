import React, { useState, useRef, useEffect } from 'react';
import { Space, SpaceMode, CurrencyCode } from '../types/finance.ts';
import { Modal } from './ui/Modal.tsx';
import { Button } from './ui/Button.tsx';
import { Input, CurrencyInput } from './ui/Input.tsx';
import {
  Plus,
  Check,
  Home,
  User,
  Compass,
  Users2,
  Trash2,
  AlertTriangle,
  ShieldAlert,
  WifiOff,
  FileWarning,
  Archive,
  RotateCcw,
  Lock,
  CheckCircle2,
  Loader2,
  ShieldCheck,
  MoreVertical,
  Search,
  X
} from 'lucide-react';
import { formatPaise } from '../lib/finance-engine.ts';
import {
  classifyFirestoreError,
  ClassifiedError,
  checkSpaceDeletionEligibility,
  SpaceDeletionEligibility
} from '../lib/storage-service.ts';

interface SpaceSwitcherModalProps {
  isOpen: boolean;
  onClose: () => void;
  spaces: Space[];
  activeSpaceId: string;
  currentUserId: string;
  onSelectSpace: (spaceId: string) => void;
  onCreateSpace: (spaceData: {
    name: string;
    mode: SpaceMode;
    currency: CurrencyCode;
    startingBalancePaise: number;
    members: string[];
  }) => Promise<void>;
  onArchiveSpace?: (spaceId: string) => Promise<void>;
  onUnarchiveSpace?: (spaceId: string) => Promise<void>;
  onDeleteSpace?: (spaceId: string, spaceName: string) => Promise<void>;
  currentUserName: string;
}

export const SpaceSwitcherModal: React.FC<SpaceSwitcherModalProps> = ({
  isOpen,
  onClose,
  spaces,
  activeSpaceId,
  currentUserId,
  onSelectSpace,
  onCreateSpace,
  onArchiveSpace,
  onUnarchiveSpace,
  onDeleteSpace,
  currentUserName
}) => {
  const [view, setView] = useState<'list' | 'create' | 'manage'>('list');
  const [managedSpace, setManagedSpace] = useState<Space | null>(null);
  const [eligibility, setEligibility] = useState<SpaceDeletionEligibility | null>(null);
  const [isLoadingEligibility, setIsLoadingEligibility] = useState<boolean>(false);

  // Hard delete confirmation state
  const [isConfirmingDelete, setIsConfirmingDelete] = useState<boolean>(false);
  const [deleteConfirmationInput, setDeleteConfirmationInput] = useState<string>('');
  const [isExecutingDelete, setIsExecutingDelete] = useState<boolean>(false);

  // Archive / unarchive confirmation state
  const [isExecutingArchive, setIsExecutingArchive] = useState<boolean>(false);

  // Create Space form state
  const [newMode, setNewMode] = useState<SpaceMode>('roommates');
  const [newName, setNewName] = useState<string>('');
  const [newCurrency, setNewCurrency] = useState<CurrencyCode>('INR');
  const [startingBalance, setStartingBalance] = useState<number>(0);
  const [newMembersText, setNewMembersText] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [errorInfo, setErrorInfo] = useState<ClassifiedError | null>(null);

  // Long-press gesture recognition refs
  const longPressTimerRef = useRef<NodeJS.Timeout | null>(null);
  const pointerStartPosRef = useRef<{ x: number; y: number } | null>(null);
  const didTriggerLongPressRef = useRef<boolean>(false);

  // Search state for spaces list
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Reset state when modal opens/closes
  useEffect(() => {
    if (!isOpen) {
      setView('list');
      setManagedSpace(null);
      setEligibility(null);
      setIsConfirmingDelete(false);
      setDeleteConfirmationInput('');
      setErrorInfo(null);
      setSearchQuery('');
    }
  }, [isOpen]);

  const getModeIcon = (mode: SpaceMode) => {
    switch (mode) {
      case 'roommates':
        return <Home className="w-4 h-4 text-blue-600" />;
      case 'personal':
        return <User className="w-4 h-4 text-emerald-600" />;
      case 'family':
        return <Users2 className="w-4 h-4 text-indigo-600" />;
      case 'trip':
        return <Compass className="w-4 h-4 text-amber-600" />;
    }
  };

  const getErrorIcon = (category: string) => {
    switch (category) {
      case 'permission-denied':
        return <ShieldAlert className="w-4 h-4 text-rose-600 shrink-0" />;
      case 'unauthenticated':
        return <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0" />;
      case 'unavailable':
      case 'deadline-exceeded':
        return <WifiOff className="w-4 h-4 text-amber-600 shrink-0" />;
      case 'invalid-argument':
        return <FileWarning className="w-4 h-4 text-blue-600 shrink-0" />;
      default:
        return <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />;
    }
  };

  // Open contextual management view for a specific space
  const handleOpenManagement = async (sp: Space) => {
    setManagedSpace(sp);
    setView('manage');
    setIsConfirmingDelete(false);
    setDeleteConfirmationInput('');
    setErrorInfo(null);
    setIsLoadingEligibility(true);
    try {
      const result = await checkSpaceDeletionEligibility(sp.id, currentUserId);
      setEligibility(result || null);
    } catch {
      // Fallback local calculation
      const isOwner = sp.ownerId === currentUserId;
      const canDel = (sp.startingBalance || 0) === 0;
      setEligibility({
        canDelete: canDel,
        canArchive: true,
        isOwner,
        transactionCount: 0,
        startingBalance: sp.startingBalance || 0,
        netBalancePaise: sp.startingBalance || 0,
        isArchived: Boolean(sp.isArchived),
        conditionMet: canDel ? 'zero-tx-zero-bal' : 'none',
        reason: isOwner
          ? 'Space loaded from memory.'
          : 'Only the authenticated space owner may archive or delete this space.'
      });
    } finally {
      setIsLoadingEligibility(false);
    }
  };

  // Long-press gesture handlers
  const handlePointerDown = (sp: Space, e: React.PointerEvent) => {
    pointerStartPosRef.current = { x: e.clientX, y: e.clientY };
    didTriggerLongPressRef.current = false;
    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current);
    }
    longPressTimerRef.current = setTimeout(() => {
      didTriggerLongPressRef.current = true;
      handleOpenManagement(sp);
    }, 500); // 500ms deliberate long-press duration
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (pointerStartPosRef.current) {
      const dx = Math.abs(e.clientX - pointerStartPosRef.current.x);
      const dy = Math.abs(e.clientY - pointerStartPosRef.current.y);
      if (dx > 10 || dy > 10) {
        // Pointer moved > 10px (user is scrolling), cancel long press
        if (longPressTimerRef.current) {
          clearTimeout(longPressTimerRef.current);
          longPressTimerRef.current = null;
        }
      }
    }
  };

  const handlePointerUpOrCancel = () => {
    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current);
      longPressTimerRef.current = null;
    }
  };

  const handleRowClick = (sp: Space) => {
    if (didTriggerLongPressRef.current) {
      didTriggerLongPressRef.current = false;
      return;
    }
    onSelectSpace(sp.id);
    onClose();
  };

  // Handle Archive / Restore toggle
  const handleToggleArchive = async () => {
    if (!managedSpace) return;
    setIsExecutingArchive(true);
    setErrorInfo(null);
    try {
      if (managedSpace.isArchived) {
        if (onUnarchiveSpace) {
          await onUnarchiveSpace(managedSpace.id);
        }
      } else {
        if (onArchiveSpace) {
          await onArchiveSpace(managedSpace.id);
        }
      }
      setView('list');
      setManagedSpace(null);
      onClose();
    } catch (err) {
      const classified = classifyFirestoreError(err);
      setErrorInfo(classified);
    } finally {
      setIsExecutingArchive(false);
    }
  };

  // Handle permanent deletion of genuinely empty space
  const handleExecuteDelete = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!managedSpace || !eligibility?.canDelete) return;

    if (deleteConfirmationInput.trim().toLowerCase() !== managedSpace.name.trim().toLowerCase()) {
      return;
    }

    setIsExecutingDelete(true);
    setErrorInfo(null);
    try {
      if (onDeleteSpace) {
        await onDeleteSpace(managedSpace.id, managedSpace.name);
      }
      setIsConfirmingDelete(false);
      setView('list');
      setManagedSpace(null);
      onClose();
    } catch (err) {
      const classified = classifyFirestoreError(err);
      setErrorInfo(classified);
    } finally {
      setIsExecutingDelete(false);
    }
  };

  // Create Space submission
  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) return;
    setIsSubmitting(true);
    setErrorInfo(null);
    try {
      const parsed = newMembersText
        .split(',')
        .map((m) => m.trim())
        .filter(Boolean);

      await onCreateSpace({
        name: newName.trim(),
        mode: newMode,
        currency: newCurrency,
        startingBalancePaise: startingBalance,
        members: parsed
      });
      setView('list');
      setNewName('');
      setStartingBalance(0);
      setNewMembersText('');
      setErrorInfo(null);
      onClose();
    } catch (err) {
      const classified = classifyFirestoreError(err);
      setErrorInfo(classified);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Filter spaces in real-time by name, mode, or doc ID
  const filteredSpaces = spaces.filter((sp) => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.trim().toLowerCase();
    const nameMatch = sp.name?.toLowerCase().includes(q);
    const modeMatch = sp.mode?.toLowerCase().includes(q);
    const idMatch = sp.id?.toLowerCase().includes(q);
    return Boolean(nameMatch || modeMatch || idMatch);
  });

  return (
    <Modal
      isOpen={isOpen}
      onClose={() => {
        setView('list');
        setManagedSpace(null);
        setIsConfirmingDelete(false);
        setSearchQuery('');
        onClose();
      }}
      title={
        view === 'list'
          ? 'Your Financial Spaces'
          : view === 'create'
          ? 'Create New Ledger Space'
          : `Manage Space: ${managedSpace?.name || 'Selected'}`
      }
      subtitle={
        view === 'list'
          ? 'Tap to switch ledger. Long-press any space row to manage or archive.'
          : view === 'create'
          ? 'Define members and mode for your new ledger'
          : 'Safe ledger administration • Zero-sum financial data protection'
      }
      maxWidth="md"
    >
      {view === 'list' ? (
        <div className="space-y-4">
          {/* Spaces Search Bar */}
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
              <Search className="w-4 h-4" />
            </div>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by space name, mode, or ID..."
              className="w-full pl-10 pr-9 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-600 cursor-pointer"
                aria-label="Clear search"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Spaces list or Empty State */}
          <div className="space-y-2 select-none">
            {filteredSpaces.length === 0 ? (
              <div className="p-8 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-200">
                <Search className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                <p className="text-sm font-medium text-slate-600">No spaces found. Try a different search.</p>
                <p className="text-xs text-slate-400 mt-1">Check spelling or search by mode (e.g. personal, trip) or Doc ID.</p>
              </div>
            ) : (
              filteredSpaces.map((sp) => {
                const isActive = sp.id === activeSpaceId;
                const isArchived = Boolean(sp.isArchived);

                return (
                  <div
                    key={sp.id}
                    onClick={() => handleRowClick(sp)}
                    onPointerDown={(e) => handlePointerDown(sp, e)}
                    onPointerMove={handlePointerMove}
                    onPointerUp={handlePointerUpOrCancel}
                    onPointerCancel={handlePointerUpOrCancel}
                    onContextMenu={(e) => {
                      e.preventDefault();
                      handleOpenManagement(sp);
                    }}
                    className={`flex items-center justify-between p-3.5 rounded-2xl border transition-all cursor-pointer relative group ${
                      isActive
                        ? 'border-blue-600 bg-blue-50/50 shadow-xs'
                        : isArchived
                        ? 'border-slate-200 bg-slate-50/70 hover:bg-slate-100 opacity-80'
                        : 'border-slate-200/80 hover:border-slate-300 bg-white hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center shrink-0">
                        {getModeIcon(sp.mode)}
                      </div>
                      <div className="text-left">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-sm text-slate-900">{sp.name}</span>
                          <span
                            className="text-[10px] font-mono text-slate-400 bg-slate-100 px-1 py-0.5 rounded border border-slate-200"
                            title={sp.id}
                          >
                            #{sp.id.slice(-6)}
                          </span>
                          {isActive && (
                            <span className="text-[10px] font-bold text-blue-600 bg-blue-100/70 px-1.5 py-0.5 rounded-md">
                              Active
                            </span>
                          )}
                          {isArchived && (
                            <span className="text-[10px] font-bold text-amber-700 bg-amber-100/80 px-1.5 py-0.5 rounded-md flex items-center gap-1">
                              <Archive className="w-2.5 h-2.5" />
                              Archived
                            </span>
                          )}
                        </div>
                        <div className="text-xs text-slate-500 flex items-center gap-2 mt-0.5">
                          <span className="capitalize">{sp.mode}</span>
                          <span>•</span>
                          <span>{sp.members?.length || 1} members</span>
                          <span>•</span>
                          <span>Start: {formatPaise(sp.startingBalance, sp.currency)}</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      {/* Accessible management button for desktop/assistive tech */}
                      <button
                        type="button"
                        aria-label={`Manage space ${sp.name}`}
                        onClick={(e) => {
                          e.stopPropagation();
                          handleOpenManagement(sp);
                        }}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 opacity-60 group-hover:opacity-100 transition-opacity cursor-pointer"
                        title="Manage space (Long-press)"
                      >
                        <MoreVertical className="w-4 h-4" />
                      </button>
                      {isActive && <Check className="w-5 h-5 text-blue-600 stroke-[2.5]" />}
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Normal state Create New Space Button in same location */}
          <Button
            fullWidth
            variant="outline"
            icon={<Plus className="w-4 h-4" />}
            onClick={() => setView('create')}
            className="border-dashed py-3"
          >
            Create New Space
          </Button>
        </div>
      ) : view === 'manage' && managedSpace ? (
        /* Long-press Contextual Space Management View */
        <div className="space-y-4 text-left">
          {/* Target Space Card */}
          <div className="p-4 bg-slate-50 border border-slate-200/80 rounded-2xl space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-white border border-slate-200 flex items-center justify-center shrink-0">
                  {getModeIcon(managedSpace.mode)}
                </div>
                <div>
                  <h4 className="font-bold text-sm text-slate-900">{managedSpace.name}</h4>
                  <div className="flex items-center gap-1.5 text-[11px] text-slate-500 font-mono mt-0.5">
                    <span>Doc ID: {managedSpace.id}</span>
                  </div>
                </div>
              </div>
              {managedSpace.isArchived ? (
                <span className="text-xs font-bold text-amber-700 bg-amber-100 px-2.5 py-1 rounded-lg flex items-center gap-1">
                  <Archive className="w-3.5 h-3.5" />
                  Archived
                </span>
              ) : (
                <span className="text-xs font-bold text-emerald-700 bg-emerald-100 px-2.5 py-1 rounded-lg flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  Active
                </span>
              )}
            </div>
            <div className="text-xs text-slate-600 flex items-center gap-3 pt-2 border-t border-slate-200/60">
              <span className="capitalize font-medium">Mode: {managedSpace.mode}</span>
              <span>•</span>
              <span>Currency: {managedSpace.currency}</span>
              <span>•</span>
              <span>Members: {managedSpace.members?.length || 1}</span>
            </div>
          </div>

          {/* Error Banner */}
          {errorInfo && (
            <div className="p-3.5 rounded-2xl border bg-rose-50 border-rose-200 text-rose-900 text-xs flex items-start gap-2.5">
              {getErrorIcon(errorInfo.category)}
              <div className="flex-1">
                <span className="font-bold block text-[11px] uppercase tracking-wider">Operation Blocked</span>
                <p className="mt-0.5">{errorInfo.userMessage}</p>
              </div>
              <button
                type="button"
                onClick={() => setErrorInfo(null)}
                className="text-xs font-bold opacity-60 hover:opacity-100 cursor-pointer"
              >
                ×
              </button>
            </div>
          )}

          {/* Eligibility & Data Protection Explanation Banner */}
          {isLoadingEligibility ? (
            <div className="p-4 rounded-2xl bg-blue-50/60 border border-blue-100 flex items-center gap-2.5 text-xs text-blue-800">
              <Loader2 className="w-4 h-4 animate-spin text-blue-600 shrink-0" />
              <span>Verifying server ledger records and deletion eligibility...</span>
            </div>
          ) : eligibility ? (
            <div
              className={`p-4 rounded-2xl border text-xs space-y-1.5 ${
                eligibility.canDelete
                  ? 'bg-blue-50/70 border-blue-200 text-blue-900'
                  : 'bg-amber-50/70 border-amber-200 text-amber-900'
              }`}
            >
              <div className="flex items-center gap-2 font-bold text-xs">
                {eligibility.canDelete ? (
                  <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0" />
                ) : (
                  <Lock className="w-4 h-4 text-amber-700 shrink-0" />
                )}
                <span>
                  {eligibility.canDelete
                    ? 'Eligible for Permanent Hard Deletion'
                    : 'Hard Deletion Blocked — Financial History Protected'}
                </span>
              </div>
              <p className="text-xs leading-relaxed opacity-90">{eligibility.reason}</p>
            </div>
          ) : null}

          {/* Contextual Management Actions */}
          {!isConfirmingDelete ? (
            <div className="space-y-2.5 pt-1">
              {/* Action 1: Safe Archive / Unarchive */}
              <div className="p-3.5 bg-white border border-slate-200 rounded-2xl flex items-center justify-between gap-3">
                <div className="space-y-0.5">
                  <div className="font-bold text-xs text-slate-900 flex items-center gap-1.5">
                    <Archive className="w-3.5 h-3.5 text-amber-600" />
                    <span>{managedSpace.isArchived ? 'Restore Space' : 'Archive Space'}</span>
                    <span className="text-[10px] font-normal text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">
                      Recommended
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500">
                    {managedSpace.isArchived
                      ? 'Re-opens this space for adding new entries and active ledger operations.'
                      : 'Preserves all transactions, balances, and audit history while setting to read-only.'}
                  </p>
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={handleToggleArchive}
                  isLoading={isExecutingArchive}
                  icon={managedSpace.isArchived ? <RotateCcw className="w-3.5 h-3.5" /> : <Archive className="w-3.5 h-3.5" />}
                  className="shrink-0"
                >
                  {managedSpace.isArchived ? 'Restore' : 'Archive'}
                </Button>
              </div>

              {/* Action 2: Hard Delete (Unlocked under Rules a, b, or c) */}
              <div className="p-3.5 bg-white border border-slate-200 rounded-2xl space-y-2">
                <div className="flex items-center justify-between gap-3">
                  <div className="space-y-0.5">
                    <div className="font-bold text-xs text-slate-900 flex items-center gap-1.5">
                      <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                      <span>Permanent Hard Delete</span>
                      {eligibility && !eligibility.canDelete && (
                        <span className="text-[10px] font-bold text-rose-700 bg-rose-50 px-1.5 py-0.5 rounded border border-rose-200 flex items-center gap-1">
                          <Lock className="w-2.5 h-2.5" />
                          Locked
                        </span>
                      )}
                      {eligibility && eligibility.canDelete && (
                        <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200 flex items-center gap-1">
                          <CheckCircle2 className="w-2.5 h-2.5" />
                          {eligibility.conditionMet === 'settled-zero-bal'
                            ? 'Eligible: Settled (₹0.00)'
                            : eligibility.conditionMet === 'archived-override'
                            ? 'Eligible: Archived'
                            : 'Eligible: 0 Transactions'}
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-slate-500">
                      Allowed when net balance is ₹0.00 (settled), space is archived, or 0 transactions.
                    </p>
                  </div>
                  <Button
                    size="sm"
                    variant="danger"
                    disabled={!eligibility?.canDelete}
                    onClick={() => setIsConfirmingDelete(true)}
                    className="shrink-0"
                  >
                    Delete Space
                  </Button>
                </div>
              </div>

              {/* Dismiss / Back button */}
              <div className="pt-2">
                <Button
                  fullWidth
                  variant="secondary"
                  onClick={() => {
                    setView('list');
                    setManagedSpace(null);
                  }}
                >
                  Back to Spaces List
                </Button>
              </div>
            </div>
          ) : (
            /* Explicit Hard Delete Deliberate Confirmation Step */
            <form onSubmit={handleExecuteDelete} className="space-y-3.5 p-4 bg-rose-50/70 border border-rose-200 rounded-2xl">
              <div className="flex items-start gap-2.5">
                <ShieldAlert className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <h5 className="font-bold text-sm text-rose-900">
                    Permanent Hard Delete — Irreversible Action
                  </h5>
                  <p className="text-xs text-rose-800 leading-relaxed">
                    This action is permanent and cannot be undone. All transactions, audit logs, and ledger records for this space will be completely erased.
                  </p>
                  <div className="p-2.5 bg-white/85 rounded-xl border border-rose-200/90 text-xs text-slate-800 space-y-1 mt-2">
                    <div>
                      <span className="font-semibold text-slate-500">Space Name:</span>{' '}
                      <span className="font-bold text-slate-900">{managedSpace.name}</span>
                    </div>
                    <div>
                      <span className="font-semibold text-slate-500">Doc ID:</span>{' '}
                      <span className="font-mono text-rose-700 select-all font-semibold">{managedSpace.id}</span>
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-rose-950 mb-1.5">
                  Type <span className="underline font-mono select-all">&ldquo;{managedSpace.name}&rdquo;</span> to confirm:
                </label>
                <input
                  type="text"
                  value={deleteConfirmationInput}
                  onChange={(e) => setDeleteConfirmationInput(e.target.value)}
                  placeholder={managedSpace.name}
                  autoFocus
                  className="w-full bg-white border border-rose-300 rounded-xl px-3.5 py-2.5 text-sm font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-rose-500"
                />
              </div>

              <div className="flex items-center gap-2 pt-1">
                <Button
                  type="button"
                  variant="secondary"
                  onClick={() => {
                    setIsConfirmingDelete(false);
                    setDeleteConfirmationInput('');
                  }}
                  className="w-1/2"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  variant="danger"
                  disabled={
                    deleteConfirmationInput.trim().toLowerCase() !== managedSpace.name.trim().toLowerCase() ||
                    isExecutingDelete
                  }
                  isLoading={isExecutingDelete}
                  className="w-1/2"
                >
                  Permanently Delete Space
                </Button>
              </div>
            </form>
          )}
        </div>
      ) : (
        /* Create New Space Form */
        <form onSubmit={handleCreate} className="space-y-4 text-left">
          {errorInfo && (
            <div className="p-3.5 rounded-2xl border bg-rose-50 border-rose-200 text-rose-900 text-xs flex items-start gap-3">
              {getErrorIcon(errorInfo.category)}
              <div className="flex-1 space-y-1">
                <div className="font-bold uppercase tracking-wider text-[10px]">
                  {errorInfo.category === 'permission-denied'
                    ? 'Cloud Permission Denied'
                    : errorInfo.category === 'unauthenticated'
                    ? 'Authentication Required'
                    : 'Cloud Write Failed'}
                </div>
                <p className="font-medium text-xs leading-relaxed">{errorInfo.userMessage}</p>
              </div>
              <button
                type="button"
                onClick={() => setErrorInfo(null)}
                className="text-xs font-bold opacity-60 hover:opacity-100 cursor-pointer"
              >
                ×
              </button>
            </div>
          )}

          {/* Mode Selector */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-2">
              Select Mode
            </label>
            <div className="grid grid-cols-2 gap-2">
              {(['roommates', 'personal', 'family', 'trip'] as SpaceMode[]).map((m) => {
                const isSelected = newMode === m;
                return (
                  <button
                    key={m}
                    type="button"
                    onClick={() => {
                      setNewMode(m);
                      if (!newName) {
                        setNewName(
                          m === 'roommates'
                            ? 'Flat #402'
                            : m === 'trip'
                            ? 'Manali Trip'
                            : m === 'family'
                            ? 'Family Khata'
                            : 'My Diary'
                        );
                      }
                    }}
                    className={`flex items-center gap-2 p-2.5 rounded-xl border text-xs font-semibold capitalize cursor-pointer transition-all ${
                      isSelected
                        ? 'border-blue-600 bg-blue-50 text-blue-700 shadow-2xs'
                        : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    {getModeIcon(m)}
                    <span>{m}</span>
                  </button>
                );
              })}
            </div>
          </div>

          <Input
            label="Space Name"
            placeholder="e.g., Goa Trip 2026, Flat 3B"
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            required
          />

          {newMode !== 'personal' && (
            <Input
              label="Members (comma-separated)"
              placeholder="e.g., Alex, Rahul, Sneha"
              value={newMembersText}
              onChange={(e) => setNewMembersText(e.target.value)}
              hint={`You (${currentUserName}) are automatically included.`}
            />
          )}

          <div>
            <CurrencyInput
              label="Starting Balance"
              paise={startingBalance}
              onChangePaise={setStartingBalance}
              currency="INR"
              hint="Initial cash in hand in ₹"
            />
          </div>

          <div className="flex items-center gap-2 pt-2">
            <Button
              type="button"
              variant="secondary"
              onClick={() => setView('list')}
              className="w-1/3"
            >
              Back
            </Button>
            <Button
              type="submit"
              variant="primary"
              isLoading={isSubmitting}
              className="w-2/3"
            >
              Create Space
            </Button>
          </div>
        </form>
      )}
    </Modal>
  );
};
