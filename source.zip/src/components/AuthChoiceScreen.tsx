import React from 'react';
import { Loader2, ShieldCheck, ArrowRight, Wallet, Users, Receipt } from 'lucide-react';

interface AuthChoiceScreenProps {
  onSignInWithGoogle: () => void;
  onContinueAsGuest: () => void;
  isSigningIn?: boolean;
  signInError?: string | null;
}

export const AuthChoiceScreen: React.FC<AuthChoiceScreenProps> = ({
  onSignInWithGoogle,
  onContinueAsGuest,
  isSigningIn = false,
  signInError = null
}) => {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 via-white to-slate-100 flex flex-col items-center justify-center p-4 sm:p-6 text-slate-900 antialiased">
      <div className="w-full max-w-md mx-auto">
        {/* Brand Icon & Heading */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-blue-600 text-white shadow-lg shadow-blue-500/20 mb-4">
            <span className="text-2xl font-black tracking-tight">S</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900">
            SPLITO
          </h1>
          <p className="text-sm font-medium text-slate-500 mt-1">
            Smart Financial Ledger & Expense Manager
          </p>
          <div className="mt-2 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-50 border border-blue-200/60 text-[11px] font-semibold text-blue-700">
            <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
            <span>Zero-Loss Minor Unit Accounting</span>
          </div>
        </div>

        {/* Feature Highlights Card */}
        <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/80 shadow-xl shadow-slate-100 mb-6 space-y-4">
          <div className="space-y-3 pb-5 border-b border-slate-100 text-left">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0 mt-0.5">
                <Wallet className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-xs font-bold text-slate-900">Multiple Ledger Spaces</h3>
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  Dedicated spaces for flatmates, personal khata, family budgets, and group trips.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0 mt-0.5">
                <Users className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-xs font-bold text-slate-900">Fair Splits & Smart Settlement</h3>
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  Automatic zero-sum reconciliation and simplified debt settlement in fewer payments.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center shrink-0 mt-0.5">
                <Receipt className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-xs font-bold text-slate-900">Receipt Capture & Invariant Auditing</h3>
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  Integer minor unit math prevents penny-rounding discrepancies across all splits.
                </p>
              </div>
            </div>
          </div>

          {/* Error Notice */}
          {signInError && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700 text-left">
              {signInError}
            </div>
          )}

          {/* Action Choice: Exactly Two Options */}
          <div className="space-y-3 pt-2">
            {/* Option 1: Sign in with Google */}
            <button
              onClick={onSignInWithGoogle}
              disabled={isSigningIn}
              className="w-full flex items-center justify-center gap-3 py-3.5 px-4 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 disabled:opacity-70 text-white font-semibold text-sm rounded-2xl shadow-md shadow-blue-600/20 transition-all cursor-pointer"
            >
              {isSigningIn ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Connecting with Google...</span>
                </>
              ) : (
                <>
                  {/* Google 'G' icon */}
                  <svg className="w-4 h-4 shrink-0 bg-white rounded-full p-0.5" viewBox="0 0 24 24">
                    <path
                      fill="#4285F4"
                      d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.8-2.4 3.65v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.14z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.26v3.15C3.27 21.36 7.35 24 12 24z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.26C.46 8.16 0 9.94 0 12s.46 3.84 1.26 5.42l4.02-3.15z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.35 0 3.27 2.64 1.26 6.58l4.02 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
                    />
                  </svg>
                  <span>Sign in with Google</span>
                </>
              )}
            </button>

            {/* Option 2: Continue as Guest */}
            <button
              onClick={onContinueAsGuest}
              disabled={isSigningIn}
              className="w-full flex items-center justify-center gap-2 py-3.5 px-4 bg-slate-100 hover:bg-slate-200 active:bg-slate-300 disabled:opacity-50 text-slate-700 font-semibold text-sm rounded-2xl border border-slate-200/80 transition-all cursor-pointer"
            >
              <span>Continue as Guest</span>
              <ArrowRight className="w-4 h-4 text-slate-500" />
            </button>
          </div>
        </div>

        {/* Footnote & Regulatory Disclosures */}
        <div className="text-center space-y-2">
          <p className="text-xs text-slate-400">
            Guest data stays on this device. Sign in with Google to sync across devices.
          </p>
          <p className="text-[11px] text-slate-400 leading-relaxed px-4">
            By proceeding, you agree to SPLITO's User Agreement & Privacy Policy. SPLITO is a financial record-keeping ledger and does not provide banking or payment services. Never enter bank passwords or UPI PINs.
          </p>
        </div>
      </div>
    </div>
  );
};
