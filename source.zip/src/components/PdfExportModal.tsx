import React, { useState } from 'react';
import { Space, Transaction, MemberBalance, ActualBalanceBreakdown } from '../types/finance.ts';
import { formatMinorUnits } from '../lib/finance-engine.ts';
import { exportPdfStatement, exportCsvStatement } from '../lib/export-service.ts';
import { Modal } from './ui/Modal.tsx';
import { Button } from './ui/Button.tsx';
import { Printer, Download, FileText, CheckCircle2, ShieldCheck, Loader2 } from 'lucide-react';

interface PdfExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  space: Space;
  transactions: Transaction[];
  memberBalances: MemberBalance[];
  actualBalanceBreakdown: ActualBalanceBreakdown;
  isPro?: boolean;
  onTriggerRewardedAd?: (type: 'pdf' | 'csv') => void;
}

export const PdfExportModal: React.FC<PdfExportModalProps> = ({
  isOpen,
  onClose,
  space,
  transactions,
  memberBalances,
  actualBalanceBreakdown,
  isPro = false,
  onTriggerRewardedAd
}) => {
  const currency = space.currency || 'INR';
  const isPersonal = space.mode === 'personal';
  const [isExporting, setIsExporting] = useState<boolean>(false);
  const [exportMessage, setExportMessage] = useState<string | null>(null);

  const handlePrintOrExport = async () => {
    if (!isPro && onTriggerRewardedAd) {
      onTriggerRewardedAd('pdf');
      return;
    }

    setIsExporting(true);
    setExportMessage(null);
    try {
      const res = await exportPdfStatement(space, transactions, memberBalances, actualBalanceBreakdown);
      if (res.success) {
        setExportMessage(res.method === 'native-share' ? 'Statement ready in share sheet' : 'PDF downloaded successfully');
        setTimeout(() => setExportMessage(null), 3000);
      } else {
        setExportMessage(res.error || 'Failed to export statement');
      }
    } finally {
      setIsExporting(false);
    }
  };

  const handleExportCsv = async () => {
    if (!isPro && onTriggerRewardedAd) {
      onTriggerRewardedAd('csv');
      return;
    }

    setIsExporting(true);
    setExportMessage(null);
    try {
      const res = await exportCsvStatement(space, transactions);
      if (res.success) {
        setExportMessage(res.method === 'native-share' ? 'CSV ready in share sheet' : 'CSV downloaded successfully');
        setTimeout(() => setExportMessage(null), 3000);
      } else {
        setExportMessage(res.error || 'Failed to export CSV');
      }
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Financial Statement & PDF Export"
      subtitle="Printable ledger report with native sharing & CSV export"
      maxWidth="xl"
    >
      <div className="space-y-4 text-left">
        {/* Action bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 p-3 bg-slate-50 border border-slate-200 rounded-xl">
          <div className="flex items-center gap-2 text-xs text-slate-600 flex-wrap">
            <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>Free Plan • Clean printable ledger report</span>
            <span className="text-[9px] font-bold bg-amber-100 text-amber-800 border border-amber-300 px-1.5 py-0.2 rounded-md">
              Ad-Free Export Coming Soon
            </span>
          </div>
          <div className="flex items-center gap-2">
            <Button
              size="sm"
              variant="outline"
              icon={<Download className="w-3.5 h-3.5" />}
              onClick={handleExportCsv}
              disabled={isExporting}
            >
              Export CSV
            </Button>
            <Button
              size="sm"
              variant="primary"
              icon={isExporting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Printer className="w-3.5 h-3.5" />}
              onClick={handlePrintOrExport}
              disabled={isExporting}
            >
              {isExporting ? 'Generating...' : 'Print / Export PDF'}
            </Button>
          </div>
        </div>

        {exportMessage && (
          <div className="p-2.5 rounded-xl bg-blue-50 border border-blue-200 text-blue-700 text-xs font-medium flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0" />
            <span>{exportMessage}</span>
          </div>
        )}

        {/* Printable Document Sheet */}
        <div
          id="printable-statement"
          className="p-6 bg-white border border-slate-200 rounded-2xl shadow-xs text-slate-900 space-y-6 font-sans print:border-none print:shadow-none print:p-0"
        >
          {/* Header */}
          <div className="border-b border-slate-200 pb-4 flex justify-between items-start">
            <div>
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-blue-600 text-white font-extrabold text-xs flex items-center justify-center">
                  SP
                </div>
                <h1 className="text-xl font-extrabold text-slate-900 tracking-tight">SPLITO</h1>
              </div>
              <p className="text-xs text-slate-500 mt-1">Every Rupee. Accounted For.</p>
              <h2 className="text-base font-bold text-slate-800 mt-3">{space.name}</h2>
              <p className="text-xs text-slate-500 capitalize">
                Mode: {space.mode} • Base Currency: INR (₹)
              </p>
            </div>

            <div className="text-right text-xs text-slate-500">
              <span className="block font-semibold text-slate-700">Statement Date</span>
              <span className="font-mono">{new Date().toLocaleDateString('en-IN', { year: 'numeric', month: 'short', day: 'numeric' })}</span>
              <span className="block mt-2 font-semibold text-slate-700">Total Entries</span>
              <span className="font-mono">{transactions.length} records</span>
            </div>
          </div>

          {/* Balance Summary Box */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 bg-slate-50 rounded-xl border border-slate-200/80 text-xs font-mono">
            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Starting Balance</span>
              <span className="font-bold text-slate-800">
                {formatMinorUnits(actualBalanceBreakdown.startingBalance, currency)}
              </span>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Total Inflow (+)</span>
              <span className="font-bold text-emerald-600">
                +{formatMinorUnits(actualBalanceBreakdown.receivedIncome, currency)}
              </span>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Total Outflow (−)</span>
              <span className="font-bold text-rose-600">
                −{formatMinorUnits(actualBalanceBreakdown.paidExpenses, currency)}
              </span>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Actual Available</span>
              <span className="font-extrabold text-blue-700 text-sm">
                {formatMinorUnits(actualBalanceBreakdown.actualBalance, currency)}
              </span>
            </div>
          </div>

          {/* Member Settlement Reconciliation (if shared space) */}
          {!isPersonal && memberBalances.length > 0 && (
            <div className="space-y-2">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700">
                Member Balances & Zero-Sum Audit
              </h3>
              <table className="w-full text-xs text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-500 font-semibold">
                    <th className="py-1.5">Member</th>
                    <th className="py-1.5 text-right">Total Disbursed</th>
                    <th className="py-1.5 text-right">Consumption Share</th>
                    <th className="py-1.5 text-right">Net Balance</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-mono">
                  {memberBalances.map((m) => (
                    <tr key={m.memberId}>
                      <td className="py-2 font-sans font-medium text-slate-900">{m.memberName}</td>
                      <td className="py-2 text-right">{formatMinorUnits(m.totalPaidMinorUnits, currency)}</td>
                      <td className="py-2 text-right">{formatMinorUnits(m.totalOwedMinorUnits, currency)}</td>
                      <td
                        className={`py-2 text-right font-bold ${
                          m.netBalanceMinorUnits > 0
                            ? 'text-emerald-600'
                            : m.netBalanceMinorUnits < 0
                            ? 'text-rose-600'
                            : 'text-slate-600'
                        }`}
                      >
                        {m.netBalanceMinorUnits > 0 ? '+' : ''}
                        {formatMinorUnits(m.netBalanceMinorUnits, currency)}
                      </td>
                    </tr>
                  ))}
                  <tr className="border-t-2 border-slate-300 font-bold">
                    <td className="py-2 font-sans">Group Reconciliation Sum (Σ)</td>
                    <td colSpan={2} />
                    <td className="py-2 text-right text-emerald-700">
                      {formatMinorUnits(
                        memberBalances.reduce((acc, b) => acc + b.netBalanceMinorUnits, 0),
                        currency
                      )}{' '}
                      (Exact Zero-Sum)
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          )}

          {/* Itemized Transactions Table */}
          <div className="space-y-2">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700">
              Itemized Ledger Records
            </h3>
            <table className="w-full text-xs text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 font-semibold">
                  <th className="py-1.5">Date</th>
                  <th className="py-1.5">Description</th>
                  <th className="py-1.5">Category</th>
                  <th className="py-1.5">Type</th>
                  <th className="py-1.5 text-right">Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-mono text-[11px]">
                {transactions.slice(0, 30).map((tx) => (
                  <tr key={tx.id} className={tx.isReversed ? 'line-through text-slate-400' : ''}>
                    <td className="py-1.5 font-sans">{tx.date}</td>
                    <td className="py-1.5 font-sans font-medium text-slate-900">
                      {tx.title}
                      {tx.isReversal && ' [Reversed Entry]'}
                    </td>
                    <td className="py-1.5 font-sans text-slate-600">{tx.category}</td>
                    <td className="py-1.5 uppercase font-sans text-[10px] text-slate-500">{tx.type}</td>
                    <td
                      className={`py-1.5 text-right font-bold ${
                        tx.type === 'income' ? 'text-emerald-600' : 'text-slate-900'
                      }`}
                    >
                      {formatMinorUnits(tx.amount, currency)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Footer */}
          <div className="border-t border-slate-200 pt-3 flex justify-between items-center text-[10px] text-slate-400">
            <span>Generated securely via SPLITO • Every Rupee. Accounted for.</span>
            <span>Page 1 of 1</span>
          </div>
        </div>
      </div>
    </Modal>
  );
};
