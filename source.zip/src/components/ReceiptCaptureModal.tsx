import React from 'react';
import { CurrencyCode, PaymentMethod } from '../types/finance.ts';
import { Modal } from './ui/Modal.tsx';
import { Button } from './ui/Button.tsx';
import { IS_SCAN_RECEIPT_AVAILABLE } from '../lib/scan-service.ts';
import {
  Camera,
  Receipt,
  Sparkles,
  Clock,
  ShieldCheck,
  FileText,
  CheckCircle2
} from 'lucide-react';

interface ReceiptCaptureModalProps {
  isOpen: boolean;
  onClose: () => void;
  currency?: CurrencyCode;
  onProceedToReview?: (receiptData: {
    title: string;
    amountMinorUnits: number;
    category: string;
    date: string;
    paymentMethod: PaymentMethod;
    receiptPreviewUrl?: string;
  }) => void;
}

export const ReceiptCaptureModal: React.FC<ReceiptCaptureModalProps> = ({
  isOpen,
  onClose
}) => {
  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Scan Receipt"
      subtitle="Smart bill digitization • Coming Soon"
      maxWidth="md"
    >
      <div className="space-y-4 text-left">
        {/* Prominent Coming Soon Banner */}
        <div className="p-4 bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-200/90 rounded-2xl flex items-start gap-3">
          <div className="p-2.5 bg-amber-500/15 rounded-xl border border-amber-300/40 text-amber-700 shrink-0">
            <Camera className="w-5 h-5 text-amber-600" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-[10px] uppercase tracking-wider bg-amber-500 text-white px-2 py-0.5 rounded-full shadow-2xs">
                COMING SOON
              </span>
              <h3 className="font-bold text-sm text-amber-950">
                Receipt Scanning is Coming Soon
              </h3>
            </div>
            <p className="text-xs text-amber-900 mt-1 leading-relaxed">
              Paper bill digitization, optical character recognition (OCR), and automatic expense extraction will be available in an upcoming SPLITO release.
            </p>
            <p className="text-[11px] text-amber-800/90 mt-1 font-medium">
              No camera permissions, external API keys, or cloud OCR credentials are required at this time.
            </p>
          </div>
        </div>

        {/* Feature Preview Cards */}
        <div className="p-4 bg-slate-50 border border-slate-200/80 rounded-2xl space-y-3 text-xs text-slate-700">
          <span className="font-bold text-slate-900 block uppercase tracking-wider text-[10px]">
            Upcoming Receipt Scanner Capabilities:
          </span>
          <div className="space-y-2">
            <div className="flex items-start gap-2.5">
              <Receipt className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
              <div>
                <strong className="text-slate-900 block">Instant Slip Capture</strong>
                <span className="text-slate-600 text-[11px]">
                  Snap supermarket slips, grocery receipts, and restaurant bills directly with your camera.
                </span>
              </div>
            </div>

            <div className="flex items-start gap-2.5">
              <Sparkles className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <div>
                <strong className="text-slate-900 block">Automatic Total & Tax Parsing</strong>
                <span className="text-slate-600 text-[11px]">
                  Automatically identifies merchant name, total expenditure, CGST/SGST, and transaction date.
                </span>
              </div>
            </div>

            <div className="flex items-start gap-2.5">
              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <div>
                <strong className="text-slate-900 block">Zero-Data Leak Architecture</strong>
                <span className="text-slate-600 text-[11px]">
                  On-device processing ensures your private purchase history is never sold or shared.
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Manual Expense Helper */}
        <div className="p-3 bg-blue-50/60 border border-blue-200/70 rounded-xl text-xs text-blue-900 space-y-1">
          <span className="font-bold block">Need to record an expense right now?</span>
          <p className="text-[11px] text-blue-800 leading-relaxed">
            You can manually record expenses anytime using the <strong>Add Expense</strong> button on the Home screen or Ledger with instant splitting, categories, and zero-sum settlement calculation.
          </p>
        </div>

        {/* Prominent Close Action Button Only */}
        <div className="pt-2">
          <Button
            type="button"
            variant="primary"
            fullWidth
            size="lg"
            onClick={onClose}
            className="cursor-pointer font-bold"
          >
            Close
          </Button>
        </div>
      </div>
    </Modal>
  );
};
