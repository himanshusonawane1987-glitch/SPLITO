import React, { useState } from 'react';
import { Modal } from './ui/Modal.tsx';
import { Button } from './ui/Button.tsx';
import { ConsentPreferences } from '../types/subscription.ts';
import { LegalDocKey } from '../lib/legal-content.ts';
import { ShieldCheck, FileText, CheckSquare, Square, ExternalLink, AlertCircle } from 'lucide-react';

interface ConsentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAccept: (prefs: ConsentPreferences) => void;
  onOpenLegalDoc: (docKey: LegalDocKey) => void;
}

export const ConsentModal: React.FC<ConsentModalProps> = ({
  isOpen,
  onClose,
  onAccept,
  onOpenLegalDoc
}) => {
  const [termsAccepted, setTermsAccepted] = useState<boolean>(false);
  const [analyticsConsent, setAnalyticsConsent] = useState<boolean>(false);
  const [marketingConsent, setMarketingConsent] = useState<boolean>(false);
  const [adPersonalizationConsent, setAdPersonalizationConsent] = useState<boolean>(false);
  const [validationError, setValidationError] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!termsAccepted) {
      setValidationError('You must review and accept the User Agreement & Privacy Policy to use SPLITO.');
      return;
    }

    const preferences: ConsentPreferences = {
      termsAndPrivacyAccepted: true,
      termsAcceptedDate: new Date().toISOString(),
      termsVersion: '1.5-draft',
      analyticsConsent,
      marketingConsent,
      adPersonalizationConsent,
      updatedAt: new Date().toISOString()
    };

    try {
      localStorage.setItem('splito_consent_preferences', JSON.stringify(preferences));
    } catch (err) {
      console.warn('Could not cache consent preferences:', err);
    }

    onAccept(preferences);
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Terms of Service & Privacy Choices"
      subtitle="Please review our terms and configure your privacy settings"
      maxWidth="lg"
    >
      <form onSubmit={handleSubmit} className="space-y-4 text-left">
        {/* Core Financial Disclaimer */}
        <div className="p-3.5 bg-blue-50/70 border border-blue-200/80 rounded-2xl text-xs text-blue-900 space-y-1.5">
          <div className="flex items-center gap-2 font-bold text-blue-950">
            <ShieldCheck className="w-4 h-4 text-blue-600 shrink-0" />
            <span>Essential Service Disclosures</span>
          </div>
          <p className="leading-relaxed text-blue-800">
            SPLITO is an expense ledger calculation tool. SPLITO is not a bank or wallet. We never collect or store your UPI PINs, bank passwords, or OTPs. All data is encrypted and backed up via Firebase.
          </p>
        </div>

        {/* Section 1: Mandatory Terms & Agreements (Not preselected) */}
        <div className="p-4 bg-white border border-slate-200 rounded-2xl space-y-3">
          <div className="flex items-start gap-3">
            <button
              type="button"
              onClick={() => {
                setTermsAccepted(!termsAccepted);
                setValidationError(null);
              }}
              className="mt-0.5 text-blue-600 focus:outline-none cursor-pointer"
            >
              {termsAccepted ? (
                <CheckSquare className="w-5 h-5 fill-blue-50" />
              ) : (
                <Square className="w-5 h-5 text-slate-400" />
              )}
            </button>
            <div className="text-xs">
              <span className="font-bold text-slate-900 block">
                Required: User Agreement & Privacy Policy
              </span>
              <p className="text-slate-600 mt-0.5 leading-relaxed">
                I have read and agree to the{' '}
                <button
                  type="button"
                  onClick={() => onOpenLegalDoc('user_agreement')}
                  className="text-blue-600 font-semibold underline inline cursor-pointer"
                >
                  User Agreement
                </button>
                ,{' '}
                <button
                  type="button"
                  onClick={() => onOpenLegalDoc('terms_conditions')}
                  className="text-blue-600 font-semibold underline inline cursor-pointer"
                >
                  Terms & Conditions
                </button>
                , and{' '}
                <button
                  type="button"
                  onClick={() => onOpenLegalDoc('privacy_policy')}
                  className="text-blue-600 font-semibold underline inline cursor-pointer"
                >
                  Privacy Policy
                </button>
                .
              </p>
            </div>
          </div>

          {validationError && (
            <div className="p-2.5 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
              <span>{validationError}</span>
            </div>
          )}
        </div>

        {/* Section 2: Optional Privacy Choices (Granular & separate) */}
        <div className="p-4 bg-slate-50 border border-slate-200/80 rounded-2xl space-y-3">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-600 block">
            Optional Preferences (Unchecked by default)
          </span>

          {/* Analytics */}
          <div className="flex items-start gap-3">
            <button
              type="button"
              onClick={() => setAnalyticsConsent(!analyticsConsent)}
              className="mt-0.5 text-blue-600 focus:outline-none cursor-pointer"
            >
              {analyticsConsent ? (
                <CheckSquare className="w-5 h-5 fill-blue-50" />
              ) : (
                <Square className="w-5 h-5 text-slate-400" />
              )}
            </button>
            <div className="text-xs">
              <span className="font-semibold text-slate-800 block">
                Anonymous Product Diagnostics
              </span>
              <p className="text-slate-500 text-[11px] leading-relaxed">
                Help improve application stability and report crash telemetry. Never includes financial figures or notes.
              </p>
            </div>
          </div>

          {/* Marketing Updates */}
          <div className="flex items-start gap-3 pt-1 border-t border-slate-200/60">
            <button
              type="button"
              onClick={() => setMarketingConsent(!marketingConsent)}
              className="mt-0.5 text-blue-600 focus:outline-none cursor-pointer"
            >
              {marketingConsent ? (
                <CheckSquare className="w-5 h-5 fill-blue-50" />
              ) : (
                <Square className="w-5 h-5 text-slate-400" />
              )}
            </button>
            <div className="text-xs">
              <span className="font-semibold text-slate-800 block">
                Product Updates & Feature Announcements
              </span>
              <p className="text-slate-500 text-[11px] leading-relaxed">
                Receive emails regarding major SPLITO version releases and budgeting tips.
              </p>
            </div>
          </div>
        </div>

        {/* Quick Links to All 7 Legal Policies */}
        <div className="pt-1">
          <span className="text-[11px] font-semibold text-slate-500 block mb-1.5">
            Complete Legal Library:
          </span>
          <div className="flex flex-wrap gap-1.5">
            {[
              { key: 'subscription_terms' as LegalDocKey, label: 'Subscription Terms' },
              { key: 'cancellation_refund' as LegalDocKey, label: 'Refund Policy' },
              { key: 'data_permissions' as LegalDocKey, label: 'Permissions' },
              { key: 'account_deletion' as LegalDocKey, label: 'Account Deletion' }
            ].map((d) => (
              <button
                key={d.key}
                type="button"
                onClick={() => onOpenLegalDoc(d.key)}
                className="text-[11px] px-2.5 py-1 bg-white border border-slate-200 rounded-lg text-slate-700 hover:text-blue-600 hover:border-blue-300 font-medium cursor-pointer transition-colors"
              >
                {d.label}
              </button>
            ))}
          </div>
        </div>

        <div className="pt-2 flex items-center justify-end gap-2">
          <Button type="button" variant="ghost" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" variant="primary" size="md">
            Confirm & Continue
          </Button>
        </div>
      </form>
    </Modal>
  );
};
