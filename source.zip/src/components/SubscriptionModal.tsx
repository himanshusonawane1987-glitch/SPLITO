import React, { useState } from 'react';
import { Modal } from './ui/Modal.tsx';
import { Button } from './ui/Button.tsx';
import {
  UserSubscription,
  SubscriptionEntitlement,
  SubscriptionBillingCycle,
  SUBSCRIPTION_PRICING
} from '../types/subscription.ts';
import {
  startProTrial,
  cancelProSubscription,
  restorePurchases
} from '../lib/billing-service.ts';
import {
  Sparkles,
  Check,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  RotateCcw,
  Clock,
  Zap,
  ArrowRight
} from 'lucide-react';

interface SubscriptionModalProps {
  isOpen: boolean;
  onClose: () => void;
  userId: string;
  subscription: UserSubscription;
  entitlement: SubscriptionEntitlement;
  onSubscriptionUpdated: (updated: UserSubscription) => void;
  onOpenLegalDoc: (docKey: any) => void;
}

export const SubscriptionModal: React.FC<SubscriptionModalProps> = ({
  isOpen,
  onClose,
  userId,
  subscription,
  entitlement,
  onSubscriptionUpdated,
  onOpenLegalDoc
}) => {
  const [selectedCycle, setSelectedCycle] = useState<SubscriptionBillingCycle>('monthly');
  const [explicitConsent, setExplicitConsent] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [feedbackMessage, setFeedbackMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  const pricing = SUBSCRIPTION_PRICING[selectedCycle];
  const isCurrentlyPro = entitlement.isPro;

  const handleStartTrial = async () => {
    if (!explicitConsent) {
      setFeedbackMessage({
        text: 'Please check the box to confirm you accept the auto-renewal terms after the 30-day free trial.',
        type: 'error'
      });
      return;
    }

    setIsLoading(true);
    setFeedbackMessage(null);
    try {
      const res = await startProTrial(userId, selectedCycle, explicitConsent);
      onSubscriptionUpdated(res.subscription);
      setFeedbackMessage({ text: res.message, type: 'success' });
    } catch (err: any) {
      setFeedbackMessage({ text: err?.message || 'Failed to start trial.', type: 'error' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleCancelSubscription = async () => {
    setIsLoading(true);
    setFeedbackMessage(null);
    try {
      const res = await cancelProSubscription(userId);
      onSubscriptionUpdated(res.subscription);
      setFeedbackMessage({ text: res.message, type: 'success' });
    } catch (err: any) {
      setFeedbackMessage({ text: err?.message || 'Failed to cancel subscription.', type: 'error' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleRestore = async () => {
    setIsLoading(true);
    setFeedbackMessage(null);
    try {
      const res = await restorePurchases(userId);
      onSubscriptionUpdated(res.subscription);
      setFeedbackMessage({ text: res.message, type: res.success ? 'success' : 'error' });
    } catch (err: any) {
      setFeedbackMessage({ text: err?.message || 'Restore failed.', type: 'error' });
    } finally {
      setIsLoading(false);
    }
  };

  const comparisonFeatures = [
    { title: 'Personal, Roommates, Family, Trip spaces', free: true, pro: true },
    { title: 'Track Expenses, Incomes, Transfers', free: true, pro: true },
    { title: 'Paid, Pending and Receivable balances', free: true, pro: true },
    { title: 'Smart Settlement (minimal debt solver)', free: true, pro: true },
    { title: 'Cloud Sync via Google Firebase', free: true, pro: true },
    { title: 'Money Timeline & Basic Spending Guard', free: true, pro: true },
    { title: 'PDF Export', free: 'With short 5s ad', pro: 'Instant & ad-free' },
    { title: '100% Ad-Free Application', free: false, pro: true },
    { title: 'Advanced Financial Analytics & Category Reports', free: false, pro: true },
    { title: 'Enhanced Spending Guard & Budget Alerts', free: false, pro: true },
    { title: 'Extended CSV & Multi-Period Statement Exports', free: false, pro: true }
  ];

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="SPLITO Pro"
      subtitle="Premium features are on their way • Coming Soon"
      maxWidth="lg"
    >
      <div className="space-y-4 text-left">
        {/* Prominent Coming Soon Banner */}
        <div className="p-4 bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-200/90 rounded-2xl flex items-start gap-3">
          <div className="p-2 bg-amber-500/15 rounded-xl border border-amber-300/40 text-amber-700 shrink-0">
            <Sparkles className="w-5 h-5 text-amber-600" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-xs uppercase tracking-wider bg-amber-500 text-white px-2 py-0.5 rounded-full shadow-2xs">
                COMING SOON
              </span>
              <h3 className="font-bold text-sm text-amber-950">
                SPLITO Pro is Coming Soon
              </h3>
            </div>
            <p className="text-xs text-amber-900 mt-1 leading-relaxed">
              We are preparing the premium experience. Subscription and Pro features will be available after the official Google Play release.
            </p>
            <p className="text-[11px] text-amber-800/90 mt-1 font-medium">
              Premium features are on their way. Subscription will be available soon.
            </p>
          </div>
        </div>

        {feedbackMessage && (
          <div
            className={`p-3.5 rounded-2xl text-xs font-medium flex items-start gap-2.5 ${
              feedbackMessage.type === 'success'
                ? 'bg-emerald-50 border border-emerald-200 text-emerald-800'
                : 'bg-rose-50 border border-rose-200 text-rose-800'
            }`}
          >
            {feedbackMessage.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
            )}
            <p className="leading-relaxed">{feedbackMessage.text}</p>
          </div>
        )}

        {/* Pro Active State Dashboard (or Coming Soon View) */}
        {isCurrentlyPro ? (
          <div className="p-5 bg-gradient-to-br from-slate-900 to-blue-950 text-white rounded-3xl space-y-4 border border-blue-900/50 shadow-md">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-blue-500/20 rounded-xl border border-blue-400/30">
                  <Sparkles className="w-5 h-5 text-amber-400" />
                </div>
                <div>
                  <h3 className="font-extrabold text-base tracking-tight">SPLITO Pro Active</h3>
                  <span className="text-xs text-blue-200/80">
                    {subscription.status === 'trial' ? '1-Month Free Trial' : 'Active Plan'}
                  </span>
                </div>
              </div>
              <span className="text-[10px] font-bold uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2.5 py-1 rounded-full">
                Active
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-3 border-t border-white/10 text-xs">
              <div>
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Billing Cycle</span>
                <span className="font-semibold text-slate-100 capitalize">
                  {subscription.billingCycle || 'Monthly'} (₹{subscription.billingCycle === 'yearly' ? '599' : '59'})
                </span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px] uppercase font-bold">
                  {subscription.status === 'cancelled' ? 'Access Ends On' : 'Next Renewal'}
                </span>
                <span className="font-semibold text-slate-100">
                  {entitlement.expiresAtFormatted || '30 days from activation'}
                </span>
              </div>
            </div>

            {subscription.status !== 'cancelled' && (
              <div className="pt-2 flex flex-col sm:flex-row gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  isLoading={isLoading}
                  onClick={handleCancelSubscription}
                  className="border-slate-700 text-slate-300 hover:bg-slate-800"
                >
                  Cancel Auto-Renewal
                </Button>
                <button
                  type="button"
                  onClick={() => onOpenLegalDoc('cancellation_refund')}
                  className="text-xs text-blue-300 hover:underline py-1.5 px-2 text-left"
                >
                  View Cancellation Policy
                </button>
              </div>
            )}
          </div>
        ) : (
          /* Subscription Plans Selector (Preview Mode with Disabled Purchases) */
          <div className="space-y-4">
            {/* Monthly / Yearly Preview Cards with COMING SOON badges */}
            <div className="grid grid-cols-2 gap-2.5 p-1 bg-slate-100 rounded-2xl">
              <button
                type="button"
                onClick={() => setSelectedCycle('monthly')}
                className={`py-3 px-3 rounded-xl font-bold text-xs transition-all cursor-pointer relative flex flex-col items-center justify-center gap-0.5 ${
                  selectedCycle === 'monthly'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                <span className="text-[9px] bg-amber-100 text-amber-800 border border-amber-300 font-extrabold px-1.5 py-0.2 rounded-full mb-0.5">
                  COMING SOON
                </span>
                <span>Monthly Plan</span>
                <span className="text-blue-600 font-extrabold text-sm">₹59 / month</span>
                <span className="text-[10px] text-slate-400 font-normal">Includes 1-month free trial</span>
              </button>

              <button
                type="button"
                onClick={() => setSelectedCycle('yearly')}
                className={`py-3 px-3 rounded-xl font-bold text-xs transition-all cursor-pointer relative flex flex-col items-center justify-center gap-0.5 ${
                  selectedCycle === 'yearly'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                <span className="text-[9px] bg-amber-100 text-amber-800 border border-amber-300 font-extrabold px-1.5 py-0.2 rounded-full mb-0.5">
                  COMING SOON
                </span>
                <span className="absolute -top-2 right-2 text-[9px] bg-emerald-600 text-white font-extrabold px-1.5 py-0.5 rounded-full shadow-2xs">
                  SAVE 15%
                </span>
                <span>Yearly Plan</span>
                <span className="text-blue-600 font-extrabold text-sm">₹599 / year</span>
                <span className="text-[10px] text-emerald-600 font-medium">Includes 1-month free trial</span>
              </button>
            </div>

            {/* Pricing & Free Trial Informational Note */}
            <div className="p-4 bg-slate-50 border border-slate-200/90 rounded-2xl text-xs text-slate-700 space-y-1.5">
              <div className="flex items-center gap-2 font-bold text-sm text-slate-900">
                <Clock className="w-4 h-4 text-blue-600" />
                <span>Pricing & Free Trial Overview (Informational)</span>
              </div>
              <p className="leading-relaxed text-slate-600">
                When launched, SPLITO Pro will include a <strong>1-month free trial</strong> for all new subscribers (₹0 charge for the first 30 days). Thereafter, billing will be <strong>₹59/month</strong> or <strong>₹599/year</strong>, cancellable anytime via Google Play.
              </p>
              <p className="text-[11px] text-amber-700 font-medium pt-1">
                🔒 In-app payments and trial activations are currently disabled while we finalize Google Play Billing certification.
              </p>
            </div>

            {/* Disabled Subscribe Action Button */}
            <div className="space-y-2">
              <Button
                type="button"
                variant="outline"
                size="lg"
                fullWidth
                disabled={true}
                className="opacity-70 cursor-not-allowed bg-slate-100 text-slate-500 border-slate-300 font-bold"
                icon={<Sparkles className="w-4 h-4 text-slate-400" />}
              >
                Coming Soon (Purchases Disabled)
              </Button>
              <p className="text-[11px] text-center text-slate-500">
                Subscribe Monthly, Subscribe Yearly, and Free Trial activations will open soon.
              </p>
            </div>
          </div>
        )}

        {/* Feature Comparison Table with COMING SOON Badges */}
        <div className="pt-2 space-y-2">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700">
              Free Plan vs SPLITO Pro Features
            </h4>
            <span className="text-[10px] font-bold text-amber-800 bg-amber-100 border border-amber-300 px-2 py-0.5 rounded-full">
              PRO COMING SOON
            </span>
          </div>

          <div className="border border-slate-200 rounded-2xl overflow-hidden divide-y divide-slate-100 text-xs">
            <div className="grid grid-cols-12 p-2.5 bg-slate-50 font-bold text-slate-700">
              <span className="col-span-6">Features</span>
              <span className="col-span-3 text-center">Free (₹0)</span>
              <span className="col-span-3 text-center text-blue-600">Pro</span>
            </div>

            {comparisonFeatures.map((f, idx) => {
              const isProExclusive = !f.free;
              return (
                <div key={idx} className="grid grid-cols-12 p-2.5 items-center hover:bg-slate-50/50">
                  <div className="col-span-6 font-medium text-slate-800 flex items-center gap-1.5 flex-wrap">
                    <span>{f.title}</span>
                    {isProExclusive && (
                      <span className="text-[9px] font-bold bg-amber-100 text-amber-800 border border-amber-300 px-1.5 py-0.2 rounded-md">
                        COMING SOON
                      </span>
                    )}
                  </div>
                  <span className="col-span-3 text-center text-slate-500">
                    {typeof f.free === 'boolean' ? (
                      f.free ? (
                        <Check className="w-4 h-4 text-emerald-600 mx-auto" />
                      ) : (
                        '—'
                      )
                    ) : (
                      f.free
                    )}
                  </span>
                  <span className="col-span-3 text-center font-semibold text-blue-600">
                    {typeof f.pro === 'boolean' ? (
                      f.pro ? (
                        <div className="flex flex-col items-center justify-center">
                          <Check className="w-4 h-4 text-blue-600 mx-auto" />
                          {isProExclusive && (
                            <span className="text-[8px] text-amber-700 font-bold uppercase tracking-tight">
                              Soon
                            </span>
                          )}
                        </div>
                      ) : (
                        '—'
                      )
                    ) : (
                      <div className="flex flex-col items-center justify-center">
                        <span>{f.pro}</span>
                        <span className="text-[8px] text-amber-700 font-bold uppercase tracking-tight">
                          Soon
                        </span>
                      </div>
                    )}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer Actions: Simple prominent Close button & Legal references */}
        <div className="pt-3 flex flex-wrap items-center justify-between gap-2 border-t border-slate-100">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => onOpenLegalDoc('subscription_terms')}
              className="text-xs text-blue-600 hover:underline cursor-pointer"
            >
              Subscription Terms
            </button>
            <span className="text-slate-300">•</span>
            <button
              type="button"
              onClick={() => onOpenLegalDoc('cancellation_refund')}
              className="text-xs text-blue-600 hover:underline cursor-pointer"
            >
              Cancellation FAQ
            </button>
          </div>

          <Button
            type="button"
            variant="primary"
            size="sm"
            onClick={onClose}
            className="px-5 cursor-pointer font-bold"
          >
            Close
          </Button>
        </div>
      </div>
    </Modal>
  );
};
