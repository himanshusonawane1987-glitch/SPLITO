import React, { useState } from 'react';
import { CurrencyCode, Transaction } from '../types/finance.ts';
import { Modal } from './ui/Modal.tsx';
import { Button } from './ui/Button.tsx';
import { Input } from './ui/Input.tsx';
import { AmountDisplay } from './ui/Typography.tsx';
import { RotateCcw, AlertTriangle, ShieldCheck, Check } from 'lucide-react';

interface ReversalConfirmModalProps {
  isOpen: boolean;
  onClose: () => void;
  transaction: Transaction | null;
  currency: CurrencyCode;
  warningMessage?: string | null;
  onConfirmReversal: (tx: Transaction, reason: string) => Promise<void>;
}

export const ReversalConfirmModal: React.FC<ReversalConfirmModalProps> = ({
  isOpen,
  onClose,
  transaction,
  currency,
  warningMessage,
  onConfirmReversal
}) => {
  const [reason, setReason] = useState<string>('Correction of entry');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  if (!transaction) return null;

  const handleConfirm = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      await onConfirmReversal(transaction, reason.trim() || 'Correction of entry');
      onClose();
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={
        <div className="flex items-center gap-2 text-rose-600">
          <RotateCcw className="w-5 h-5" />
          <span>Confirm Immutable Reversal</span>
        </div>
      }
      subtitle="Financial entries are never deleted silently — they are reversed with an offsetting counter-entry"
      maxWidth="md"
    >
      <form onSubmit={handleConfirm} className="space-y-4 text-left">
        {/* Transaction Summary Box */}
        <div className="p-4 bg-slate-50 border border-slate-200/90 rounded-2xl space-y-2.5">
          <div className="flex items-start justify-between gap-2">
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                Target Transaction
              </span>
              <h4 className="font-bold text-sm text-slate-900 mt-0.5">{transaction.title}</h4>
              <p className="text-xs text-slate-500">
                {transaction.category} • {transaction.date} • {transaction.paymentMethod || 'UPI'}
              </p>
            </div>
            <AmountDisplay
              minorUnits={transaction.amount}
              currency={currency}
              size="metric"
              variant={transaction.type === 'income' ? 'income' : 'expense'}
            />
          </div>

          <div className="text-[11px] text-slate-500 border-t border-slate-200/70 pt-2 flex items-center justify-between">
            <span>Transaction ID:</span>
            <span className="font-mono font-medium">{transaction.id}</span>
          </div>
        </div>

        {warningMessage && (
          <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl flex items-start gap-2.5 text-xs text-rose-900">
            <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
            <div className="space-y-0.5">
              <span className="font-bold block">Active Settlement Warning</span>
              <span>{warningMessage}</span>
            </div>
          </div>
        )}

        {/* Audit explanation */}
        <div className="p-3 bg-amber-50/70 border border-amber-200/70 rounded-xl flex items-start gap-2.5 text-xs text-amber-900">
          <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
          <div className="space-y-0.5">
            <span className="font-bold block">Ledger Guarantee</span>
            <span>
              This will flag #{transaction.id.slice(-6)} as reversed and append an offsetting counter-entry
              linking to the original. Ledger history and audit logs remain mathematically pristine.
            </span>
          </div>
        </div>

        {/* Reason Input */}
        <Input
          label="Reversal Reason / Audit Memo"
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          placeholder="e.g., Wrong amount entered, duplicate entry, refunded"
          required
        />

        <div className="flex items-center gap-2 pt-2">
          <Button type="button" variant="secondary" onClick={onClose} className="w-1/3">
            Cancel
          </Button>
          <Button
            type="submit"
            variant="danger"
            isLoading={isSubmitting}
            className="w-2/3"
            icon={<RotateCcw className="w-4 h-4" />}
          >
            Confirm Reversal
          </Button>
        </div>
      </form>
    </Modal>
  );
};
