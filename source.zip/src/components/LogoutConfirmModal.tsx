import React from 'react';
import { Modal } from './ui/Modal.tsx';
import { Button } from './ui/Button.tsx';
import { LogOut } from 'lucide-react';

interface LogoutConfirmModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirmLogout: () => void;
}

export const LogoutConfirmModal: React.FC<LogoutConfirmModalProps> = ({
  isOpen,
  onClose,
  onConfirmLogout
}) => {
  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Log out of SPLITO?"
      maxWidth="sm"
    >
      <div className="space-y-4 text-left">
        <p className="text-sm text-slate-600 leading-relaxed">
          Are you sure you want to log out? Your spaces and expenses are saved and will be there when you sign back in.
        </p>

        <div className="flex items-center justify-end gap-2.5 pt-2">
          <Button
            type="button"
            variant="ghost"
            onClick={onClose}
            className="text-slate-600 hover:text-slate-900 font-semibold"
          >
            Cancel
          </Button>
          <Button
            type="button"
            variant="danger"
            icon={<LogOut className="w-3.5 h-3.5" />}
            onClick={() => {
              onClose();
              onConfirmLogout();
            }}
            className="bg-rose-600 hover:bg-rose-700 text-white font-bold"
          >
            Yes, log out
          </Button>
        </div>
      </div>
    </Modal>
  );
};
