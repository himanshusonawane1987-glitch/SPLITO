import React, { useState } from 'react';
import { SpaceMode, CurrencyCode } from '../types/finance.ts';
import { Modal } from './ui/Modal.tsx';
import { Button } from './ui/Button.tsx';
import { CurrencyInput, Input } from './ui/Input.tsx';
import { Home, User, Users2, Compass, Check, ArrowRight, AlertTriangle, ShieldAlert, WifiOff, FileWarning, RefreshCw } from 'lucide-react';
import { getModeDefaultSpaceName, classifyFirestoreError, ClassifiedError } from '../lib/storage-service.ts';

interface OnboardingModalProps {
  isOpen: boolean;
  onComplete: (data: {
    mode: SpaceMode;
    spaceName: string;
    startingBalancePaise: number;
    currency: CurrencyCode;
    initialMembers: string[];
  }) => Promise<void>;
  defaultDisplayName?: string;
}

export const OnboardingModal: React.FC<OnboardingModalProps> = ({
  isOpen,
  onComplete,
  defaultDisplayName = 'You'
}) => {
  const [selectedMode, setSelectedMode] = useState<SpaceMode>('roommates');
  const [spaceName, setSpaceName] = useState<string>('');
  const [startingBalancePaise, setStartingBalancePaise] = useState<number>(0);
  const [currency, setCurrency] = useState<CurrencyCode>('INR');
  const [membersText, setMembersText] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [errorInfo, setErrorInfo] = useState<ClassifiedError | null>(null);

  const modes: {
    id: SpaceMode;
    title: string;
    icon: React.ReactNode;
    subtitle: string;
    features: string[];
    defaultMembers: string;
  }[] = [
    {
      id: 'roommates',
      title: 'Roommates & Flat',
      icon: <Home className="w-5 h-5 text-blue-600" />,
      subtitle: 'Flatmates, hostels & PG living',
      features: ['Rent & WiFi splits', 'Maid & Cook wages', 'Shared rations & groceries'],
      defaultMembers: ''
    },
    {
      id: 'personal',
      title: 'Personal Khata',
      icon: <User className="w-5 h-5 text-emerald-600" />,
      subtitle: 'Replace handwritten diary & pocket book',
      features: ['Salary & cash in/out', 'Daily expenses & chai', 'Personal savings rate'],
      defaultMembers: ''
    },
    {
      id: 'family',
      title: 'Family Household',
      icon: <Users2 className="w-5 h-5 text-indigo-600" />,
      subtitle: 'Household budget & recurring commitments',
      features: ['Rations & groceries', 'School & medical bills', 'Domestic help payments'],
      defaultMembers: ''
    },
    {
      id: 'trip',
      title: 'Group / Trip',
      icon: <Compass className="w-5 h-5 text-amber-600" />,
      subtitle: 'Vacations, weekend road trips & outings',
      features: ['Flight & hotel booking', 'Group dining & activities', 'Quick settle up at end'],
      defaultMembers: ''
    }
  ];

  const handleModeChange = (mode: SpaceMode) => {
    setSelectedMode(mode);
    if (!spaceName) {
      setSpaceName(getModeDefaultSpaceName(mode));
    }
    const target = modes.find((m) => m.id === mode);
    if (target && target.defaultMembers) {
      setMembersText(target.defaultMembers);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setErrorInfo(null);
    try {
      const parsedMembers = membersText
        .split(',')
        .map((m) => m.trim())
        .filter(Boolean);

      await onComplete({
        mode: selectedMode,
        spaceName: spaceName.trim() || getModeDefaultSpaceName(selectedMode),
        startingBalancePaise,
        currency,
        initialMembers: parsedMembers
      });
    } catch (err) {
      const classified = classifyFirestoreError(err);
      setErrorInfo(classified);
      // Keep modal open, stop spinner, retain user inputs
    } finally {
      setIsSubmitting(false);
    }
  };

  const getErrorIcon = (category: string) => {
    switch (category) {
      case 'permission-denied':
        return <ShieldAlert className="w-4 h-4 text-rose-600 shrink-0" />;
      case 'unauthenticated':
        return <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0" />;
      case 'unavailable':
      case 'deadline-exceeded':
        return <WifiOff className="w-4 h-4 text-amber-600 shrink-0" />;
      case 'invalid-argument':
        return <FileWarning className="w-4 h-4 text-blue-600 shrink-0" />;
      default:
        return <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />;
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={() => {}} // Non-dismissible until primary mode chosen
      maxWidth="lg"
      title={
        <div className="flex items-center gap-2">
          <span>Welcome to</span>
          <span className="text-blue-600 font-extrabold tracking-tight">HISAAB</span>
        </div>
      }
      subtitle="Replaces handwritten expense diaries with precision minor-unit accounting. Choose your primary mode:"
    >
      <form onSubmit={handleSubmit} className="space-y-5 text-left">
        {/* Categorized Error Alert Banner */}
        {errorInfo && (
          <div
            className={`p-3.5 rounded-2xl border text-xs flex items-start gap-3 animate-in fade-in-50 ${
              errorInfo.category === 'permission-denied'
                ? 'bg-rose-50 border-rose-200 text-rose-900'
                : errorInfo.category === 'unauthenticated'
                ? 'bg-amber-50 border-amber-200 text-amber-900'
                : errorInfo.category === 'unavailable' || errorInfo.category === 'deadline-exceeded'
                ? 'bg-amber-50 border-amber-200 text-amber-900'
                : errorInfo.category === 'invalid-argument'
                ? 'bg-blue-50 border-blue-200 text-blue-900'
                : 'bg-rose-50 border-rose-200 text-rose-900'
            }`}
          >
            {getErrorIcon(errorInfo.category)}
            <div className="flex-1 space-y-1">
              <div className="font-bold uppercase tracking-wider text-[10px]">
                {errorInfo.category === 'permission-denied'
                  ? 'Cloud Permission Denied'
                  : errorInfo.category === 'unauthenticated'
                  ? 'Authentication Required'
                  : errorInfo.category === 'unavailable' || errorInfo.category === 'deadline-exceeded'
                  ? 'Cloud Service Unavailable'
                  : errorInfo.category === 'invalid-argument'
                  ? 'Validation Check Failed'
                  : 'Cloud Write Failed'}
              </div>
              <p className="font-medium text-xs leading-relaxed">{errorInfo.userMessage}</p>
              <p className="text-[10px] opacity-75">Your entered inputs are preserved below. Try submitting again.</p>
            </div>
            <button
              type="button"
              onClick={() => setErrorInfo(null)}
              className="text-xs font-bold opacity-60 hover:opacity-100 cursor-pointer"
            >
              ×
            </button>
          </div>
        )}
        {/* Mode cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {modes.map((m) => {
            const isSelected = selectedMode === m.id;
            return (
              <div
                key={m.id}
                onClick={() => handleModeChange(m.id)}
                className={`p-3.5 rounded-2xl border-2 transition-all cursor-pointer relative text-left ${
                  isSelected
                    ? 'border-blue-600 bg-blue-50/40 shadow-xs'
                    : 'border-slate-200/90 hover:border-slate-300 bg-white hover:bg-slate-50/50'
                }`}
              >
                {isSelected && (
                  <div className="absolute top-3 right-3 w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center">
                    <Check className="w-3.5 h-3.5 stroke-[3]" />
                  </div>
                )}
                <div className="flex items-center gap-2.5 mb-1.5">
                  <div className="p-2 rounded-xl bg-slate-100">{m.icon}</div>
                  <div>
                    <h4 className="font-bold text-sm text-slate-900">{m.title}</h4>
                    <p className="text-[11px] text-slate-500">{m.subtitle}</p>
                  </div>
                </div>
                <ul className="mt-2 space-y-1 text-[11px] text-slate-600">
                  {m.features.map((f, i) => (
                    <li key={i} className="flex items-center gap-1.5">
                      <span className="w-1 h-1 rounded-full bg-slate-400" />
                      <span>{f}</span>
                    </li>
                  ))}
                </ul>
              </div>
            );
          })}
        </div>

        {/* Space details */}
        <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200/80 space-y-3.5">
          <Input
            label="Space / Diary Name"
            value={spaceName}
            onChange={(e) => setSpaceName(e.target.value)}
            placeholder="e.g., Flat 402, Personal Diary"
            required
          />

          {selectedMode !== 'personal' && (
            <Input
              label="Members (comma-separated)"
              value={membersText}
              onChange={(e) => setMembersText(e.target.value)}
              placeholder="e.g. Alex, Sam, Jordan"
              hint={`You (${defaultDisplayName}) will always be included automatically.`}
            />
          )}

          <div>
            <CurrencyInput
              label="Starting Cash / Balance"
              paise={startingBalancePaise}
              onChangePaise={setStartingBalancePaise}
              currency="INR"
              hint="Initial cash-in-hand in ₹ (optional)"
            />
          </div>
        </div>

        <Button
          type="submit"
          fullWidth
          size="lg"
          isLoading={isSubmitting}
          icon={<ArrowRight className="w-4 h-4" />}
        >
          Get Started with HISAAB
        </Button>
      </form>
    </Modal>
  );
};
