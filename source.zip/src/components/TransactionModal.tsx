import React, { useState, useEffect } from 'react';
import {
  CurrencyCode,
  Member,
  PaymentMethod,
  Space,
  SplitShare,
  SplitType,
  Transaction,
  TransactionType
} from '../types/finance.ts';
import { Modal } from './ui/Modal.tsx';
import { Button } from './ui/Button.tsx';
import { CurrencyInput, Input } from './ui/Input.tsx';
import {
  calculateCustomSplits,
  calculateEqualSplits,
  calculatePercentageSplits,
  formatMinorUnits,
  getCurrencyMeta
} from '../lib/finance-engine.ts';
import { DEFAULT_CATEGORIES_BY_MODE } from '../lib/storage-service.ts';
import {
  ArrowDownLeft,
  ArrowUpRight,
  ArrowLeftRight,
  CheckCircle2,
  Split,
  Check,
  Camera,
  Receipt,
  CreditCard
} from 'lucide-react';

interface TransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  space: Space;
  currentUserId: string;
  initialType?: TransactionType;
  editingTransaction?: Transaction | null;
  onSave: (tx: Transaction) => Promise<void>;
  prefillPaidToId?: string;
  prefillAmountMinorUnits?: number;
  prefillTitle?: string;
  prefillCategory?: string;
  prefillDate?: string;
  prefillPaymentMethod?: PaymentMethod;
  prefillReceiptUrl?: string;
  onOpenReceiptCapture?: () => void;
}

export const TransactionModal: React.FC<TransactionModalProps> = ({
  isOpen,
  onClose,
  space,
  currentUserId,
  initialType = 'expense',
  editingTransaction,
  onSave,
  prefillPaidToId,
  prefillAmountMinorUnits,
  prefillTitle,
  prefillCategory,
  prefillDate,
  prefillPaymentMethod,
  prefillReceiptUrl,
  onOpenReceiptCapture
}) => {
  const [type, setType] = useState<TransactionType>(initialType);
  const [title, setTitle] = useState<string>('');
  const [amountMinorUnits, setAmountMinorUnits] = useState<number>(0);
  const [category, setCategory] = useState<string>('');
  const [date, setDate] = useState<string>(() => new Date().toISOString().split('T')[0]);
  const [payerId, setPayerId] = useState<string>(currentUserId);
  const [paidToId, setPaidToId] = useState<string>('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('UPI');
  const [notes, setNotes] = useState<string>('');
  const [receiptUrl, setReceiptUrl] = useState<string | undefined>(undefined);
  const [splitType, setSplitType] = useState<SplitType>('equal');

  const [selectedMemberIds, setSelectedMemberIds] = useState<string[]>([]);
  const [percentageMap, setPercentageMap] = useState<Record<string, number>>({});
  const [customMinorUnitsMap, setCustomMinorUnitsMap] = useState<Record<string, number>>({});
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string>('');

  const members = space.members || [];
  const defaultCategories = DEFAULT_CATEGORIES_BY_MODE[space.mode] || DEFAULT_CATEGORIES_BY_MODE.personal;
  const currencyMeta = getCurrencyMeta(space.currency);

  useEffect(() => {
    if (editingTransaction) {
      setType(editingTransaction.type);
      setTitle(editingTransaction.title);
      setAmountMinorUnits(editingTransaction.amount);
      setCategory(editingTransaction.category);
      setDate(editingTransaction.date);
      setPayerId(editingTransaction.payerId);
      setPaidToId(editingTransaction.paidToId || '');
      setPaymentMethod(editingTransaction.paymentMethod || 'UPI');
      setNotes(editingTransaction.notes || '');
      setReceiptUrl(editingTransaction.receiptUrl);
      setSplitType(editingTransaction.splitType || 'none');

      if (editingTransaction.splits && editingTransaction.splits.length > 0) {
        setSelectedMemberIds(editingTransaction.splits.map((s) => s.memberId));
        const cMap: Record<string, number> = {};
        const pMap: Record<string, number> = {};
        editingTransaction.splits.forEach((s) => {
          cMap[s.memberId] = s.shareMinorUnits;
          if (s.percentage !== undefined) pMap[s.memberId] = s.percentage;
        });
        setCustomMinorUnitsMap(cMap);
        setPercentageMap(pMap);
      }
    } else {
      setType(initialType);
      setTitle(prefillTitle || '');
      setAmountMinorUnits(prefillAmountMinorUnits || 0);
      setCategory(prefillCategory || defaultCategories[0] || 'General');
      setDate(prefillDate || new Date().toISOString().split('T')[0]);
      setPayerId(currentUserId);
      setPaidToId(prefillPaidToId || (members.find((m) => m.id !== currentUserId)?.id || ''));
      setPaymentMethod(prefillPaymentMethod || 'UPI');
      setNotes('');
      setReceiptUrl(prefillReceiptUrl);
      setSplitType(space.mode === 'personal' ? 'none' : 'equal');

      const allIds = members.map((m) => m.id);
      setSelectedMemberIds(allIds);

      const count = allIds.length;
      const initialPct = count > 0 ? Number((100 / count).toFixed(2)) : 100;
      const pMap: Record<string, number> = {};
      const cMap: Record<string, number> = {};
      allIds.forEach((id) => {
        pMap[id] = initialPct;
        cMap[id] = 0;
      });
      setPercentageMap(pMap);
      setCustomMinorUnitsMap(cMap);
    }
  }, [
    isOpen,
    editingTransaction,
    initialType,
    prefillPaidToId,
    prefillAmountMinorUnits,
    prefillTitle,
    prefillCategory,
    prefillDate,
    prefillPaymentMethod,
    prefillReceiptUrl,
    space
  ]);

  // Compute live split preview using Largest Remainder Method
  const computedSplits: SplitShare[] = React.useMemo(() => {
    if (type !== 'expense' || splitType === 'none' || selectedMemberIds.length === 0) {
      return [];
    }

    if (splitType === 'equal') {
      return calculateEqualSplits(amountMinorUnits, selectedMemberIds);
    }

    if (splitType === 'percentage') {
      const splitsInput = selectedMemberIds.map((id) => ({
        memberId: id,
        percentage: percentageMap[id] || 0
      }));
      return calculatePercentageSplits(amountMinorUnits, splitsInput);
    }

    if (splitType === 'custom') {
      const splitsInput = selectedMemberIds.map((id) => ({
        memberId: id,
        customMinorUnits: customMinorUnitsMap[id] || 0
      }));
      return calculateCustomSplits(amountMinorUnits, splitsInput);
    }

    return [];
  }, [type, splitType, amountMinorUnits, selectedMemberIds, percentageMap, customMinorUnitsMap]);

  const toggleMemberSelection = (memberId: string) => {
    if (selectedMemberIds.includes(memberId)) {
      if (selectedMemberIds.length === 1) return;
      setSelectedMemberIds(selectedMemberIds.filter((id) => id !== memberId));
    } else {
      setSelectedMemberIds([...selectedMemberIds, memberId]);
    }
  };

  const handlePercentageChange = (memberId: string, val: string) => {
    const num = parseFloat(val) || 0;
    setPercentageMap((prev) => ({ ...prev, [memberId]: num }));
  };

  const handleCustomMinorUnitsChange = (memberId: string, units: number) => {
    setCustomMinorUnitsMap((prev) => ({ ...prev, [memberId]: units }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (amountMinorUnits <= 0) {
      setErrorMsg('Please enter an amount greater than 0.');
      return;
    }

    if (!title.trim()) {
      setErrorMsg('Please enter merchant or description for this entry.');
      return;
    }

    if ((type === 'transfer' || type === 'settlement') && (!paidToId || paidToId === payerId)) {
      setErrorMsg('Please select a recipient different from the payer.');
      return;
    }

    setIsSubmitting(true);
    try {
      const txId = editingTransaction?.id || `tx_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
      const payload: Transaction = {
        id: txId,
        spaceId: space.id,
        creatorId: currentUserId,
        title: title.trim(),
        type,
        category: type === 'settlement' ? 'Settlement' : (category || 'General'),
        amount: Math.round(amountMinorUnits),
        date,
        payerId,
        paymentMethod,
        version: editingTransaction ? (editingTransaction.version || 1) + 1 : 1,
        createdAt: editingTransaction?.createdAt || new Date().toISOString()
      };

      if ((type === 'transfer' || type === 'settlement') && paidToId) {
        payload.paidToId = paidToId;
      }
      if (type === 'expense' && splitType !== 'none') {
        payload.splitType = splitType;
        payload.splits = computedSplits;
      } else if (type === 'expense') {
        payload.splitType = 'none';
      }
      if (notes.trim()) {
        payload.notes = notes.trim();
      }
      if (receiptUrl) {
        payload.receiptUrl = receiptUrl;
      }

      await onSave(payload);
      onClose();
    } catch (err: any) {
      console.error('Transaction save error:', err);
      setErrorMsg('Failed to save transaction: ' + (err?.message || 'Unknown error'));
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={
        editingTransaction ? 'Edit Diary Entry' : (
          type === 'expense' ? 'Review & Add Expense' :
          type === 'income' ? 'Add Received Money' :
          type === 'settlement' ? 'Record Settlement' : 'Record Transfer'
        )
      }
      subtitle={space.name}
      maxWidth="md"
    >
      <form onSubmit={handleSubmit} className="space-y-4 text-left">
        {/* Type toggle */}
        {!editingTransaction && (
          <div className="grid grid-cols-4 gap-1.5 p-1 bg-slate-100 rounded-xl">
            <button
              type="button"
              onClick={() => setType('expense')}
              className={`py-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1 cursor-pointer ${
                type === 'expense'
                  ? 'bg-white text-rose-600 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <ArrowUpRight className="w-3.5 h-3.5" />
              <span>Expense</span>
            </button>
            <button
              type="button"
              onClick={() => setType('income')}
              className={`py-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1 cursor-pointer ${
                type === 'income'
                  ? 'bg-white text-emerald-600 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <ArrowDownLeft className="w-3.5 h-3.5" />
              <span>Income</span>
            </button>
            <button
              type="button"
              onClick={() => setType('transfer')}
              className={`py-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1 cursor-pointer ${
                type === 'transfer'
                  ? 'bg-white text-slate-800 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <ArrowLeftRight className="w-3.5 h-3.5" />
              <span>Transfer</span>
            </button>
            <button
              type="button"
              onClick={() => setType('settlement')}
              className={`py-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1 cursor-pointer ${
                type === 'settlement'
                  ? 'bg-white text-indigo-600 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Settle</span>
            </button>
          </div>
        )}

        {/* Receipt Scan Banner / Trigger */}
        {type === 'expense' && onOpenReceiptCapture && !editingTransaction && (
          <button
            type="button"
            onClick={onOpenReceiptCapture}
            className="w-full p-2.5 rounded-xl border border-amber-200/90 bg-amber-50/60 hover:bg-amber-100/50 text-amber-900 flex items-center justify-between text-xs font-semibold cursor-pointer transition-colors"
          >
            <div className="flex items-center gap-2">
              <Camera className="w-4 h-4 text-amber-600" />
              <span>Have a paper bill or receipt slip?</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] underline">Scan Receipt</span>
              <span className="text-[8px] font-bold bg-amber-100 text-amber-800 border border-amber-300 px-1 py-0.2 rounded">
                COMING SOON
              </span>
            </div>
          </button>
        )}

        {/* Amount Input with minor units */}
        <CurrencyInput
          label="Total Amount"
          paise={amountMinorUnits}
          onChangePaise={setAmountMinorUnits}
          currency={space.currency}
          autoFocus={!editingTransaction && !prefillAmountMinorUnits}
        />

        {/* Title / Description */}
        <Input
          label="Merchant / Description"
          placeholder={
            type === 'expense'
              ? 'e.g., Starbucks, Swiggy, Flat Rent, Electricity'
              : type === 'income'
              ? 'e.g., Monthly Salary, Freelance project'
              : 'e.g., Wallet to Bank Transfer'
          }
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          required
        />

        {/* Category & Payment Method */}
        <div className="grid grid-cols-2 gap-3">
          {type !== 'settlement' ? (
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                Category
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full bg-white text-slate-900 font-medium border border-slate-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-blue-600 shadow-2xs"
              >
                {defaultCategories.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>
          ) : (
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                Category
              </label>
              <input
                disabled
                value="Settlement"
                className="w-full bg-slate-100 text-slate-500 font-medium border border-slate-200 rounded-xl px-3 py-2.5 text-sm"
              />
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
              Payment Method
            </label>
            <select
              value={paymentMethod}
              onChange={(e) => setPaymentMethod(e.target.value as PaymentMethod)}
              className="w-full bg-white text-slate-900 font-medium border border-slate-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-blue-600 shadow-2xs"
            >
              <option value="UPI">UPI (GPay / PhonePe / Paytm)</option>
              <option value="Cash">Cash in Hand</option>
              <option value="Card">Debit / Credit Card</option>
              <option value="Net Banking">Net Banking / NEFT / IMPS</option>
              <option value="Other">Other</option>
            </select>
          </div>
        </div>

        {/* Date and Payer */}
        <div className="grid grid-cols-2 gap-3">
          <Input
            label="Transaction Date"
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            required
          />

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
              {type === 'income' ? 'Received By' : 'Paid By'}
            </label>
            <select
              value={payerId}
              onChange={(e) => setPayerId(e.target.value)}
              className="w-full bg-white text-slate-900 font-medium border border-slate-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-blue-600 shadow-2xs"
            >
              {members.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.name} {m.id === currentUserId ? '(You)' : ''}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Group Expense Splits (Largest Remainder Method) */}
        {type === 'expense' && space.mode !== 'personal' && members.length > 1 && (
          <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200/80 space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                <Split className="w-3.5 h-3.5 text-blue-600" />
                <span>Split Shares</span>
              </label>
              <div className="flex items-center gap-1 bg-white p-0.5 border border-slate-200 rounded-lg text-[11px] font-semibold">
                <button
                  type="button"
                  onClick={() => setSplitType('equal')}
                  className={`px-2 py-1 rounded-md cursor-pointer transition-colors ${
                    splitType === 'equal' ? 'bg-blue-600 text-white' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Equal
                </button>
                <button
                  type="button"
                  onClick={() => setSplitType('percentage')}
                  className={`px-2 py-1 rounded-md cursor-pointer transition-colors ${
                    splitType === 'percentage' ? 'bg-blue-600 text-white' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  %
                </button>
                <button
                  type="button"
                  onClick={() => setSplitType('custom')}
                  className={`px-2 py-1 rounded-md cursor-pointer transition-colors ${
                    splitType === 'custom' ? 'bg-blue-600 text-white' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Custom
                </button>
                <button
                  type="button"
                  onClick={() => setSplitType('none')}
                  className={`px-2 py-1 rounded-md cursor-pointer transition-colors ${
                    splitType === 'none' ? 'bg-blue-600 text-white' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  No Split
                </button>
              </div>
            </div>

            {splitType !== 'none' && (
              <div className="space-y-2 pt-1">
                <div className="text-[11px] text-slate-500">
                  Select participating members:
                </div>
                <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                  {members.map((m) => {
                    const isSelected = selectedMemberIds.includes(m.id);
                    const share = computedSplits.find((s) => s.memberId === m.id);

                    return (
                      <div
                        key={m.id}
                        className={`flex items-center justify-between p-2 rounded-xl border text-xs transition-colors ${
                          isSelected ? 'bg-white border-blue-200' : 'bg-slate-100/60 border-slate-200/50 opacity-60'
                        }`}
                      >
                        <button
                          type="button"
                          onClick={() => toggleMemberSelection(m.id)}
                          className="flex items-center gap-2 font-medium text-slate-800 cursor-pointer"
                        >
                          <div
                            className={`w-4 h-4 rounded flex items-center justify-center border ${
                              isSelected ? 'bg-blue-600 border-blue-600 text-white' : 'border-slate-300 bg-white'
                            }`}
                          >
                            {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                          </div>
                          <span>
                            {m.name} {m.id === currentUserId ? '(You)' : ''}
                          </span>
                        </button>

                        {isSelected && (
                          <div className="flex items-center gap-2">
                            {splitType === 'percentage' && (
                              <div className="flex items-center gap-1">
                                <input
                                  type="number"
                                  step="0.1"
                                  min="0"
                                  max="100"
                                  value={percentageMap[m.id] ?? ''}
                                  onChange={(e) => handlePercentageChange(m.id, e.target.value)}
                                  className="w-14 px-1.5 py-0.5 border border-slate-200 rounded text-center text-xs font-mono font-bold"
                                />
                                <span className="text-slate-400 font-bold">%</span>
                              </div>
                            )}

                            {splitType === 'custom' && (
                              <div className="flex items-center gap-1">
                                <span className="text-slate-400 font-bold text-xs">{currencyMeta.symbol}</span>
                                <input
                                  type="number"
                                  step="0.01"
                                  min="0"
                                  placeholder="0.00"
                                  value={
                                    customMinorUnitsMap[m.id] !== undefined
                                      ? (customMinorUnitsMap[m.id] / Math.pow(10, currencyMeta.minorUnits)).toString()
                                      : ''
                                  }
                                  onChange={(e) => {
                                    const parsed = parseFloat(e.target.value);
                                    handleCustomMinorUnitsChange(
                                      m.id,
                                      isNaN(parsed) ? 0 : Math.round(parsed * Math.pow(10, currencyMeta.minorUnits))
                                    );
                                  }}
                                  className="w-18 px-1.5 py-0.5 border border-slate-200 rounded text-right text-xs font-mono font-bold"
                                />
                              </div>
                            )}

                            <span className="font-mono font-bold text-slate-900 bg-slate-50 px-2 py-0.5 rounded border border-slate-200/60">
                              {formatMinorUnits(share?.shareMinorUnits || 0, space.currency)}
                            </span>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>

                <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1 border-t border-slate-200/60">
                  <span>Hare-Niemeyer Exact Sum:</span>
                  <span className="font-mono font-bold text-blue-700">
                    {formatMinorUnits(
                      computedSplits.reduce((acc, s) => acc + s.shareMinorUnits, 0),
                      space.currency
                    )}{' '}
                    / {formatMinorUnits(amountMinorUnits, space.currency)}
                  </span>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Optional Notes */}
        <Input
          label="Optional Memo / Reference"
          placeholder="Receipt #, itemized detail, transaction note..."
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
        />

        {errorMsg && (
          <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl text-xs font-medium">
            {errorMsg}
          </div>
        )}

        <div className="flex items-center gap-2 pt-2">
          <Button type="button" variant="secondary" onClick={onClose} className="w-1/3">
            Cancel
          </Button>
          <Button
            type="submit"
            variant={type === 'income' ? 'success' : type === 'expense' ? 'danger' : 'primary'}
            isLoading={isSubmitting}
            className="w-2/3"
          >
            {editingTransaction ? 'Update Entry' : 'Save to Ledger'}
          </Button>
        </div>
      </form>
    </Modal>
  );
};
