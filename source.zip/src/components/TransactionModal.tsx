import React, { useState, useEffect, useMemo } from 'react';
import {
  AdvancePaymentRef,
  CurrencyCode,
  Member,
  PaymentMethod,
  PersonalItemAllocation,
  Space,
  SplitShare,
  SplitType,
  TemporaryParticipant,
  Transaction,
  TransactionType
} from '../types/finance.ts';
import { Modal } from './ui/Modal.tsx';
import { Button } from './ui/Button.tsx';
import { CurrencyInput, Input } from './ui/Input.tsx';
import {
  MAX_TEMP_PARTICIPANT_NAME_LENGTH,
  UNKNOWN_TEMP_PARTICIPANT_LABEL,
  buildActiveLinkedAdvancesMap,
  buildTemporaryParticipantId,
  calculateEnhancedExpenseSplits,
  disambiguateTemporaryParticipantName,
  findActiveManualSettlementsForTempParticipant,
  formatMinorUnits,
  getCurrencyMeta,
  isTemporaryParticipantId,
  minorUnitsToDecimalString,
  parseInputToMinorUnits,
  validateEnhancedExpenseSplits,
  validateTemporaryParticipantName
} from '../lib/finance-engine.ts';
import { DEFAULT_CATEGORIES_BY_MODE } from '../lib/storage-service.ts';
import {
  ArrowDownLeft,
  ArrowUpRight,
  ArrowLeftRight,
  CheckCircle2,
  Split,
  Check,
  Camera,
  Receipt,
  CreditCard,
  Plus,
  UserPlus,
  X
} from 'lucide-react';

interface TransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  space: Space;
  spaceTransactions?: Transaction[];
  currentUserId: string;
  initialType?: TransactionType;
  editingTransaction?: Transaction | null;
  onSave: (tx: Transaction) => Promise<void>;
  prefillPaidToId?: string;
  prefillAmountMinorUnits?: number;
  prefillTitle?: string;
  prefillCategory?: string;
  prefillDate?: string;
  prefillPaymentMethod?: PaymentMethod;
  prefillReceiptUrl?: string;
  onOpenReceiptCapture?: () => void;
}

export const TransactionModal: React.FC<TransactionModalProps> = ({
  isOpen,
  onClose,
  space,
  spaceTransactions,
  currentUserId,
  initialType = 'expense',
  editingTransaction,
  onSave,
  prefillPaidToId,
  prefillAmountMinorUnits,
  prefillTitle,
  prefillCategory,
  prefillDate,
  prefillPaymentMethod,
  prefillReceiptUrl,
  onOpenReceiptCapture
}) => {
  const [type, setType] = useState<TransactionType>(initialType);
  const [title, setTitle] = useState<string>('');
  const [amountMinorUnits, setAmountMinorUnits] = useState<number>(0);
  const [category, setCategory] = useState<string>('');
  const [date, setDate] = useState<string>(() => new Date().toISOString().split('T')[0]);
  const [payerId, setPayerId] = useState<string>(currentUserId);
  const [paidToId, setPaidToId] = useState<string>('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('UPI');
  const [notes, setNotes] = useState<string>('');
  const [receiptUrl, setReceiptUrl] = useState<string | undefined>(undefined);
  const [splitType, setSplitType] = useState<SplitType>('equal');

  const [selectedMemberIds, setSelectedMemberIds] = useState<string[]>([]);
  const [percentageMap, setPercentageMap] = useState<Record<string, number>>({});
  const [customMinorUnitsMap, setCustomMinorUnitsMap] = useState<Record<string, number>>({});
  const [personalItems, setPersonalItems] = useState<PersonalItemAllocation[]>([]);
  const [advancePaidMinorUnitsMap, setAdvancePaidMinorUnitsMap] = useState<Record<string, number>>({});
  const [advanceCapNotices, setAdvanceCapNotices] = useState<Record<string, string>>({});
  const [payerChangeNotice, setPayerChangeNotice] = useState<string>('');
  const [draftExpenseId, setDraftExpenseId] = useState<string>(() => `tx_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`);
  const [tempParticipants, setTempParticipants] = useState<TemporaryParticipant[]>([]);
  const [isAddingTempMember, setIsAddingTempMember] = useState<boolean>(false);
  const [newTempName, setNewTempName] = useState<string>('');
  const [tempInputError, setTempInputError] = useState<string>('');
  const [tempDuplicateHint, setTempDuplicateHint] = useState<string>('');
  const [tempRemovalError, setTempRemovalError] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string>('');

  const members = space.members || [];
  const defaultCategories = DEFAULT_CATEGORIES_BY_MODE[space.mode] || DEFAULT_CATEGORIES_BY_MODE.personal;
  const currencyMeta = getCurrencyMeta(space.currency);
  const amountStep =
    currencyMeta.minorUnits === 0
      ? '1'
      : (1 / Math.pow(10, currencyMeta.minorUnits)).toFixed(currencyMeta.minorUnits);

  const allSplitParticipants = useMemo(() => {
    const permanentRows = members.map((m) => ({
      id: m.id,
      name: m.name,
      isTemporary: false
    }));
    const tempRows = tempParticipants.map((tp) => ({
      id: tp.id,
      name: tp.name,
      isTemporary: true
    }));
    return [...permanentRows, ...tempRows];
  }, [members, tempParticipants]);

  const memberNamesById = useMemo(() => {
    const map: Record<string, string> = {};
    members.forEach((m) => {
      map[m.id] = m.name;
    });
    tempParticipants.forEach((tp) => {
      map[tp.id] = tp.name;
    });
    return map;
  }, [members, tempParticipants]);

  useEffect(() => {
    setErrorMsg('');
    setAdvanceCapNotices({});
    setPayerChangeNotice('');
    setIsAddingTempMember(false);
    setNewTempName('');
    setTempInputError('');
    setTempDuplicateHint('');
    setTempRemovalError('');

    if (editingTransaction) {
      setDraftExpenseId(editingTransaction.id);
      setType(editingTransaction.type);
      setTitle(editingTransaction.title);
      setAmountMinorUnits(editingTransaction.amount);
      setCategory(editingTransaction.category);
      setDate(editingTransaction.date);
      setPayerId(editingTransaction.payerId);
      setPaidToId(editingTransaction.paidToId || '');
      setPaymentMethod(editingTransaction.paymentMethod || 'UPI');
      setNotes(editingTransaction.notes || '');
      setReceiptUrl(editingTransaction.receiptUrl);
      setSplitType(editingTransaction.splitType || 'none');

      // Hydrate expense-scoped temporary participants (including fallback from temp splits)
      const hydratedTemps: TemporaryParticipant[] = [];
      const seenTempIds = new Set<string>();
      for (const tp of editingTransaction.temporaryParticipants || []) {
        if (tp?.id && !seenTempIds.has(tp.id)) {
          seenTempIds.add(tp.id);
          hydratedTemps.push({
            id: tp.id,
            name: (tp.name || '').trim() || UNKNOWN_TEMP_PARTICIPANT_LABEL,
            isTemporary: true
          });
        }
      }
      for (const s of editingTransaction.splits || []) {
        if (s?.memberId && (s.isTemporary || isTemporaryParticipantId(s.memberId)) && !seenTempIds.has(s.memberId)) {
          seenTempIds.add(s.memberId);
          hydratedTemps.push({
            id: s.memberId,
            name: (s.memberName || '').trim() || UNKNOWN_TEMP_PARTICIPANT_LABEL,
            isTemporary: true
          });
        }
      }
      setTempParticipants(hydratedTemps);

      const hydratedPersonalItems = editingTransaction.personalItems
        ? editingTransaction.personalItems.map((item) => ({ ...item }))
        : [];
      setPersonalItems(hydratedPersonalItems);

      if (editingTransaction.splits && editingTransaction.splits.length > 0) {
        const hasSharedField = editingTransaction.splits.some(
          (s) => typeof s.sharedMinorUnits === 'number'
        );
        const sharedParticipants = hasSharedField
          ? editingTransaction.splits
              .filter((s) => (s.sharedMinorUnits ?? 0) > 0)
              .map((s) => s.memberId)
          : editingTransaction.splits.map((s) => s.memberId);

        setSelectedMemberIds(
          sharedParticipants.length > 0
            ? sharedParticipants
            : hydratedPersonalItems.length > 0
            ? []
            : editingTransaction.splits.map((s) => s.memberId)
        );

        const cMap: Record<string, number> = {};
        const pMap: Record<string, number> = {};
        editingTransaction.splits.forEach((s) => {
          cMap[s.memberId] =
            typeof s.sharedMinorUnits === 'number' ? s.sharedMinorUnits : s.shareMinorUnits;
          if (s.percentage !== undefined) pMap[s.memberId] = s.percentage;
        });
        setCustomMinorUnitsMap(cMap);
        setPercentageMap(pMap);
      } else {
        setSelectedMemberIds(members.map((m) => m.id));
        setCustomMinorUnitsMap({});
        setPercentageMap({});
      }

      // Hydrate advances from live ledger transactions when provided so directly reversed advances stay cleared
      if (spaceTransactions) {
        const liveAdvMap = buildActiveLinkedAdvancesMap(editingTransaction.id, spaceTransactions);
        setAdvancePaidMinorUnitsMap(liveAdvMap);
      } else if (editingTransaction.advancePayments && editingTransaction.advancePayments.length > 0) {
        const advMap: Record<string, number> = {};
        editingTransaction.advancePayments.forEach((a) => {
          if (a.memberId !== editingTransaction.payerId && a.amountMinorUnits > 0) {
            advMap[a.memberId] = a.amountMinorUnits;
          }
        });
        setAdvancePaidMinorUnitsMap(advMap);
      } else {
        setAdvancePaidMinorUnitsMap({});
      }
    } else {
      setDraftExpenseId(`tx_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`);
      setTempParticipants([]);
      setType(initialType);
      setTitle(prefillTitle || '');
      setAmountMinorUnits(prefillAmountMinorUnits || 0);
      setCategory(prefillCategory || defaultCategories[0] || 'General');
      setDate(prefillDate || new Date().toISOString().split('T')[0]);
      setPayerId(currentUserId);
      setPaidToId(prefillPaidToId || (members.find((m) => m.id !== currentUserId)?.id || ''));
      setPaymentMethod(prefillPaymentMethod || 'UPI');
      setNotes('');
      setReceiptUrl(prefillReceiptUrl);
      setSplitType(space.mode === 'personal' ? 'none' : 'equal');

      const allIds = members.map((m) => m.id);
      setSelectedMemberIds(allIds);

      const count = allIds.length;
      const initialPct = count > 0 ? Number((100 / count).toFixed(2)) : 100;
      const pMap: Record<string, number> = {};
      const cMap: Record<string, number> = {};
      allIds.forEach((id) => {
        pMap[id] = initialPct;
        cMap[id] = 0;
      });
      setPercentageMap(pMap);
      setCustomMinorUnitsMap(cMap);
      setPersonalItems([]);
      setAdvancePaidMinorUnitsMap({});
    }
  }, [
    isOpen,
    editingTransaction,
    initialType,
    prefillPaidToId,
    prefillAmountMinorUnits,
    prefillTitle,
    prefillCategory,
    prefillDate,
    prefillPaymentMethod,
    prefillReceiptUrl,
    space,
    spaceTransactions
  ]);

  // Compute live enhanced split preview & validation (supports Personal Items + Shared Pool + Advance Payments + Temporary Participants)
  const enhancedValidation = useMemo(() => {
    return validateEnhancedExpenseSplits({
      totalMinorUnits: amountMinorUnits,
      splitType: type === 'expense' ? splitType : 'none',
      payerId,
      selectedMemberIds,
      percentageMap,
      customSharedMinorUnitsMap: customMinorUnitsMap,
      personalItems,
      advancePaidMinorUnitsMap,
      temporaryParticipants: tempParticipants,
      expenseId: editingTransaction?.id || draftExpenseId,
      currency: space.currency,
      memberNamesById
    });
  }, [
    type,
    splitType,
    amountMinorUnits,
    payerId,
    selectedMemberIds,
    percentageMap,
    customMinorUnitsMap,
    personalItems,
    advancePaidMinorUnitsMap,
    tempParticipants,
    editingTransaction?.id,
    draftExpenseId,
    space.currency,
    memberNamesById
  ]);

  const enhancedResult = enhancedValidation.result;
  const computedSplits: SplitShare[] = enhancedResult.splits;

  const handlePayerChange = (newPayerId: string) => {
    setPayerId(newPayerId);
    if ((advancePaidMinorUnitsMap[newPayerId] || 0) > 0) {
      setAdvancePaidMinorUnitsMap((prev) => {
        const next = { ...prev };
        delete next[newPayerId];
        return next;
      });
      setAdvanceCapNotices((prev) => {
        const next = { ...prev };
        delete next[newPayerId];
        return next;
      });
      const newPayerName = memberNamesById[newPayerId] || 'this member';
      setPayerChangeNotice(
        `Already Paid cleared for ${newPayerName} because they are now the bill payer.`
      );
    } else {
      setPayerChangeNotice('');
    }
  };

  const handleAddTempParticipant = () => {
    setTempInputError('');
    setTempRemovalError('');
    const validation = validateTemporaryParticipantName(newTempName);
    if (!validation.isValid) {
      setTempInputError(validation.error || 'Please enter a name.');
      return;
    }

    const matchesPermanent = members.some(
      (m) => m.name.trim().toLowerCase() === validation.trimmed.toLowerCase()
    );
    if (matchesPermanent) {
      setTempDuplicateHint(
        `"${validation.trimmed}" matches a permanent space member — added separately for this expense only.`
      );
    } else {
      setTempDuplicateHint('');
    }

    const finalName = disambiguateTemporaryParticipantName(validation.trimmed, tempParticipants);
    const newTp: TemporaryParticipant = {
      id: buildTemporaryParticipantId(editingTransaction?.id || draftExpenseId),
      name: finalName,
      isTemporary: true
    };

    setTempParticipants((prev) => [...prev, newTp]);
    setSelectedMemberIds((prev) => (prev.includes(newTp.id) ? prev : [...prev, newTp.id]));
    setPercentageMap((prev) => ({ ...prev, [newTp.id]: 0 }));
    setCustomMinorUnitsMap((prev) => ({ ...prev, [newTp.id]: 0 }));
    setNewTempName('');
    setIsAddingTempMember(false);
  };

  const handleRemoveTempParticipant = (temp: TemporaryParticipant) => {
    setTempRemovalError('');
    // Q4 Guard: Block removing a temporary participant if an active manual settlement references them
    const activeManualSettlements = findActiveManualSettlementsForTempParticipant(
      temp.id,
      spaceTransactions || []
    );
    if (activeManualSettlements.length > 0) {
      setTempRemovalError(
        `Cannot remove ${temp.name} because an active settlement references them. Reverse that settlement first.`
      );
      return;
    }

    setTempParticipants((prev) => prev.filter((tp) => tp.id !== temp.id));
    setSelectedMemberIds((prev) => prev.filter((id) => id !== temp.id));
    setPersonalItems((prev) => prev.filter((item) => item.memberId !== temp.id));
    setPercentageMap((prev) => {
      const next = { ...prev };
      delete next[temp.id];
      return next;
    });
    setCustomMinorUnitsMap((prev) => {
      const next = { ...prev };
      delete next[temp.id];
      return next;
    });
    setAdvancePaidMinorUnitsMap((prev) => {
      const next = { ...prev };
      delete next[temp.id];
      return next;
    });
  };

  const toggleMemberSelection = (memberId: string) => {
    const hasPersonalForAny = enhancedResult.totalPersonalMinorUnits > 0;
    if (selectedMemberIds.includes(memberId)) {
      if (isTemporaryParticipantId(memberId)) {
        const hasPersonalForThis = personalItems.some(
          (item) => item.memberId === memberId && item.amountMinorUnits > 0
        );
        if (!hasPersonalForThis) {
          const activeManualSettlements = findActiveManualSettlementsForTempParticipant(
            memberId,
            spaceTransactions || []
          );
          if (activeManualSettlements.length > 0) {
            const label = memberNamesById[memberId] || 'this temporary participant';
            setTempRemovalError(
              `Cannot remove ${label} because an active settlement references them. Reverse that settlement first.`
            );
            return;
          }
        }
      }
      if (selectedMemberIds.length === 1 && !hasPersonalForAny) return;
      setSelectedMemberIds(selectedMemberIds.filter((id) => id !== memberId));
    } else {
      setTempRemovalError('');
      setSelectedMemberIds([...selectedMemberIds, memberId]);
    }
  };

  const handlePercentageChange = (memberId: string, val: string) => {
    const num = parseFloat(val);
    setPercentageMap((prev) => ({ ...prev, [memberId]: isNaN(num) ? 0 : Math.max(0, num) }));
  };

  const handleCustomMinorUnitsChange = (memberId: string, units: number) => {
    setCustomMinorUnitsMap((prev) => ({ ...prev, [memberId]: Math.max(0, Math.round(units)) }));
  };

  const handleAddPersonalItem = () => {
    const defaultMemberId =
      selectedMemberIds[0] || members[0]?.id || currentUserId;
    const newItem: PersonalItemAllocation = {
      id: `pi_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      memberId: defaultMemberId,
      label: '',
      amountMinorUnits: 0
    };
    setPersonalItems((prev) => [...prev, newItem]);
  };

  const handleUpdatePersonalItem = (
    itemId: string,
    patch: Partial<PersonalItemAllocation>
  ) => {
    setPersonalItems((prev) =>
      prev.map((item) => (item.id === itemId ? { ...item, ...patch } : item))
    );
  };

  const handleRemovePersonalItem = (itemId: string) => {
    setPersonalItems((prev) => prev.filter((item) => item.id !== itemId));
  };

  const handleAdvancePaidChange = (memberId: string, rawValue: string, memberShareMinorUnits: number) => {
    if (memberId === payerId) return;
    const trimmed = rawValue.trim();
    if (!trimmed) {
      setAdvancePaidMinorUnitsMap((prev) => ({ ...prev, [memberId]: 0 }));
      setAdvanceCapNotices((prev) => {
        const next = { ...prev };
        delete next[memberId];
        return next;
      });
      return;
    }

    const parsedUnits = parseInputToMinorUnits(trimmed, space.currency);
    if (parsedUnits < 0) {
      setAdvancePaidMinorUnitsMap((prev) => ({ ...prev, [memberId]: 0 }));
      return;
    }

    // Dynamic Cap enforcement in UI: cap equals this member's calculated shareMinorUnits for this expense
    if (parsedUnits > memberShareMinorUnits) {
      const memberLabel = memberNamesById[memberId] || 'this member';
      setAdvancePaidMinorUnitsMap((prev) => ({ ...prev, [memberId]: memberShareMinorUnits }));
      setAdvanceCapNotices((prev) => ({
        ...prev,
        [memberId]: `Maximum Already Paid for ${memberLabel} is ${formatMinorUnits(
          memberShareMinorUnits,
          space.currency
        )} — their share`
      }));
      return;
    }

    setAdvancePaidMinorUnitsMap((prev) => ({ ...prev, [memberId]: parsedUnits }));
    setAdvanceCapNotices((prev) => {
      const next = { ...prev };
      delete next[memberId];
      return next;
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (amountMinorUnits <= 0) {
      setErrorMsg('Please enter an amount greater than 0.');
      return;
    }

    if (!title.trim()) {
      setErrorMsg('Please enter merchant or description for this entry.');
      return;
    }

    if ((type === 'transfer' || type === 'settlement') && (!paidToId || paidToId === payerId)) {
      setErrorMsg('Please select a recipient different from the payer.');
      return;
    }

    if (type === 'expense' && space.mode !== 'personal' && splitType !== 'none') {
      if (!enhancedValidation.isValid) {
        setErrorMsg(enhancedValidation.errors[0] || 'Please fix the split allocation before saving.');
        return;
      }
    }

    // Q4 Guard: Prevent saving an edit that drops a temporary participant referenced by an active manual settlement
    if (editingTransaction && type === 'expense' && spaceTransactions) {
      const existingTempIds = new Set<string>();
      for (const tp of editingTransaction.temporaryParticipants || []) {
        if (tp?.id) existingTempIds.add(tp.id);
      }
      for (const s of editingTransaction.splits || []) {
        if (s?.memberId && (s.isTemporary || isTemporaryParticipantId(s.memberId))) {
          existingTempIds.add(s.memberId);
        }
      }
      const nextSplitIds =
        splitType !== 'none' ? new Set(enhancedResult.splits.map((s) => s.memberId)) : new Set<string>();
      for (const oldTempId of existingTempIds) {
        if (!nextSplitIds.has(oldTempId)) {
          const activeManualSettlements = findActiveManualSettlementsForTempParticipant(
            oldTempId,
            spaceTransactions
          );
          if (activeManualSettlements.length > 0) {
            const label =
              editingTransaction.temporaryParticipants?.find((p) => p.id === oldTempId)?.name ||
              editingTransaction.splits?.find((s) => s.memberId === oldTempId)?.memberName ||
              'this temporary participant';
            setErrorMsg(
              `Cannot remove ${label} because an active settlement references them. Reverse that settlement first.`
            );
            return;
          }
        }
      }
    }

    setIsSubmitting(true);
    try {
      const txId = editingTransaction?.id || draftExpenseId;
      const payload: Transaction = {
        id: txId,
        spaceId: space.id,
        creatorId: currentUserId,
        title: title.trim(),
        type,
        category: type === 'settlement' ? 'Settlement' : (category || 'General'),
        amount: Math.round(amountMinorUnits),
        date,
        payerId,
        paymentMethod,
        version: editingTransaction ? (editingTransaction.version || 1) + 1 : 1,
        createdAt: editingTransaction?.createdAt || new Date().toISOString()
      };

      if ((type === 'transfer' || type === 'settlement') && paidToId) {
        payload.paidToId = paidToId;
      }
      if (type === 'expense' && splitType !== 'none') {
        const finalCalc = calculateEnhancedExpenseSplits({
          totalMinorUnits: amountMinorUnits,
          splitType,
          payerId,
          selectedMemberIds,
          percentageMap,
          customSharedMinorUnitsMap: customMinorUnitsMap,
          personalItems,
          advancePaidMinorUnitsMap,
          temporaryParticipants: tempParticipants,
          expenseId: txId,
          currency: space.currency,
          memberNamesById
        });
        payload.splitType = splitType;
        payload.splits = finalCalc.splits;
        if (finalCalc.temporaryParticipants.length > 0) {
          payload.temporaryParticipants = finalCalc.temporaryParticipants;
        } else if (editingTransaction?.temporaryParticipants?.length) {
          payload.temporaryParticipants = [];
        }
        if (finalCalc.personalItems.length > 0) {
          payload.personalItems = finalCalc.personalItems;
        }
        if (finalCalc.advancePayments.length > 0) {
          payload.advancePayments = finalCalc.advancePayments as AdvancePaymentRef[];
        }
      } else if (type === 'expense') {
        payload.splitType = 'none';
        if (editingTransaction?.temporaryParticipants?.length) {
          payload.temporaryParticipants = [];
        }
      }
      if (notes.trim()) {
        payload.notes = notes.trim();
      }
      if (receiptUrl) {
        payload.receiptUrl = receiptUrl;
      }

      await onSave(payload);
      onClose();
    } catch (err: any) {
      console.error('Transaction save error:', err);
      setErrorMsg('Failed to save transaction: ' + (err?.message || 'Unknown error'));
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={
        editingTransaction ? 'Edit Diary Entry' : (
          type === 'expense' ? 'Review & Add Expense' :
          type === 'income' ? 'Add Received Money' :
          type === 'settlement' ? 'Record Settlement' : 'Record Transfer'
        )
      }
      subtitle={space.name}
      maxWidth="md"
    >
      <form onSubmit={handleSubmit} className="space-y-4 text-left">
        {/* Type toggle */}
        {!editingTransaction && (
          <div className="grid grid-cols-4 gap-1.5 p-1 bg-slate-100 rounded-xl">
            <button
              type="button"
              onClick={() => setType('expense')}
              className={`py-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1 cursor-pointer ${
                type === 'expense'
                  ? 'bg-white text-rose-600 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <ArrowUpRight className="w-3.5 h-3.5" />
              <span>Expense</span>
            </button>
            <button
              type="button"
              onClick={() => setType('income')}
              className={`py-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1 cursor-pointer ${
                type === 'income'
                  ? 'bg-white text-emerald-600 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <ArrowDownLeft className="w-3.5 h-3.5" />
              <span>Income</span>
            </button>
            <button
              type="button"
              onClick={() => setType('transfer')}
              className={`py-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1 cursor-pointer ${
                type === 'transfer'
                  ? 'bg-white text-slate-800 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <ArrowLeftRight className="w-3.5 h-3.5" />
              <span>Transfer</span>
            </button>
            <button
              type="button"
              onClick={() => setType('settlement')}
              className={`py-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1 cursor-pointer ${
                type === 'settlement'
                  ? 'bg-white text-indigo-600 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Settle</span>
            </button>
          </div>
        )}

        {/* Receipt Scan Banner / Trigger */}
        {type === 'expense' && onOpenReceiptCapture && !editingTransaction && (
          <button
            type="button"
            onClick={onOpenReceiptCapture}
            className="w-full p-2.5 rounded-xl border border-amber-200/90 bg-amber-50/60 hover:bg-amber-100/50 text-amber-900 flex items-center justify-between text-xs font-semibold cursor-pointer transition-colors"
          >
            <div className="flex items-center gap-2">
              <Camera className="w-4 h-4 text-amber-600" />
              <span>Have a paper bill or receipt slip?</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] underline">Scan Receipt</span>
              <span className="text-[8px] font-bold bg-amber-100 text-amber-800 border border-amber-300 px-1 py-0.2 rounded">
                COMING SOON
              </span>
            </div>
          </button>
        )}

        {/* Amount Input with minor units */}
        <CurrencyInput
          label="Total Amount"
          paise={amountMinorUnits}
          onChangePaise={setAmountMinorUnits}
          currency={space.currency}
          autoFocus={!editingTransaction && !prefillAmountMinorUnits}
        />

        {/* Title / Description */}
        <Input
          label="Merchant / Description"
          placeholder={
            type === 'expense'
              ? 'e.g., Starbucks, Swiggy, Flat Rent, Electricity'
              : type === 'income'
              ? 'e.g., Monthly Salary, Freelance project'
              : 'e.g., Wallet to Bank Transfer'
          }
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          required
        />

        {/* Category & Payment Method */}
        <div className="grid grid-cols-2 gap-3">
          {type !== 'settlement' ? (
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                Category
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full bg-white text-slate-900 font-medium border border-slate-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-blue-600 shadow-2xs"
              >
                {defaultCategories.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>
          ) : (
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                Category
              </label>
              <input
                disabled
                value="Settlement"
                className="w-full bg-slate-100 text-slate-500 font-medium border border-slate-200 rounded-xl px-3 py-2.5 text-sm"
              />
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
              Payment Method
            </label>
            <select
              value={paymentMethod}
              onChange={(e) => setPaymentMethod(e.target.value as PaymentMethod)}
              className="w-full bg-white text-slate-900 font-medium border border-slate-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-blue-600 shadow-2xs"
            >
              <option value="UPI">UPI (GPay / PhonePe / Paytm)</option>
              <option value="Cash">Cash in Hand</option>
              <option value="Card">Debit / Credit Card</option>
              <option value="Net Banking">Net Banking / NEFT / IMPS</option>
              <option value="Other">Other</option>
            </select>
          </div>
        </div>

        {/* Date and Payer */}
        <div className="grid grid-cols-2 gap-3">
          <Input
            label="Transaction Date"
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            required
          />

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
              {type === 'income' ? 'Received By' : 'Paid By'}
            </label>
            <select
              value={payerId}
              onChange={(e) => handlePayerChange(e.target.value)}
              className="w-full bg-white text-slate-900 font-medium border border-slate-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-blue-600 shadow-2xs"
            >
              {members.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.name} {m.id === currentUserId ? '(You)' : ''}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Group Expense Splits (Largest Remainder Method) — Q2: visible for all non-personal spaces */}
        {type === 'expense' && space.mode !== 'personal' && (
          <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200/80 space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                <Split className="w-3.5 h-3.5 text-blue-600" />
                <span>Split Shares</span>
              </label>
              <div className="flex items-center gap-1 bg-white p-0.5 border border-slate-200 rounded-lg text-[11px] font-semibold">
                <button
                  type="button"
                  onClick={() => setSplitType('equal')}
                  className={`px-2 py-1 rounded-md cursor-pointer transition-colors ${
                    splitType === 'equal' ? 'bg-blue-600 text-white' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Equal
                </button>
                <button
                  type="button"
                  onClick={() => setSplitType('percentage')}
                  className={`px-2 py-1 rounded-md cursor-pointer transition-colors ${
                    splitType === 'percentage' ? 'bg-blue-600 text-white' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  %
                </button>
                <button
                  type="button"
                  onClick={() => setSplitType('custom')}
                  className={`px-2 py-1 rounded-md cursor-pointer transition-colors ${
                    splitType === 'custom' ? 'bg-blue-600 text-white' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Custom
                </button>
                <button
                  type="button"
                  onClick={() => setSplitType('none')}
                  className={`px-2 py-1 rounded-md cursor-pointer transition-colors ${
                    splitType === 'none' ? 'bg-blue-600 text-white' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  No Split
                </button>
              </div>
            </div>

            {splitType !== 'none' && (
              <div className="space-y-2.5 pt-1">
                {/* Personal Items (Individual Share) Sub-section */}
                <div className="bg-white rounded-xl border border-slate-200/80 p-2.5 space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    <div>
                      <span className="text-[11px] font-bold text-slate-700">
                        Personal Items (Individual Share)
                      </span>
                      <p className="text-[10px] text-slate-400">
                        Excluded from shared pool and assigned to one member
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={handleAddPersonalItem}
                      className="inline-flex items-center gap-1 px-2 py-1 rounded-lg text-[11px] font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200/70 transition-colors cursor-pointer shrink-0"
                    >
                      <Plus className="w-3 h-3" />
                      <span>Add Personal Item</span>
                    </button>
                  </div>

                  {personalItems.length > 0 && (
                    <div className="space-y-1.5">
                      {personalItems.map((item) => (
                        <div
                          key={item.id}
                          className="flex flex-wrap sm:flex-nowrap items-center gap-1.5 bg-slate-50/80 border border-slate-200/70 rounded-lg p-1.5"
                        >
                          <select
                            aria-label="Personal item member"
                            value={item.memberId}
                            onChange={(e) =>
                              handleUpdatePersonalItem(item.id, { memberId: e.target.value })
                            }
                            className="bg-white border border-slate-200 rounded-md px-2 py-1 text-xs font-medium text-slate-800 focus:outline-none focus:border-blue-600 min-w-[96px]"
                          >
                            {allSplitParticipants.map((m) => (
                              <option key={m.id} value={m.id}>
                                {m.name}{m.isTemporary ? ' (Temp)' : ''}
                              </option>
                            ))}
                          </select>
                          <input
                            type="text"
                            placeholder="Item (optional)"
                            value={item.label || ''}
                            onChange={(e) =>
                              handleUpdatePersonalItem(item.id, { label: e.target.value })
                            }
                            className="flex-1 min-w-[90px] bg-white border border-slate-200 rounded-md px-2 py-1 text-xs text-slate-800 focus:outline-none focus:border-blue-600"
                          />
                          <div className="flex items-center gap-1 bg-white border border-slate-200 rounded-md px-1.5 py-0.5">
                            <span className="text-slate-400 font-bold text-xs">
                              {currencyMeta.symbol}
                            </span>
                            <input
                              type="number"
                              step={amountStep}
                              min="0"
                              placeholder="0"
                              aria-label="Personal item amount"
                              value={
                                item.amountMinorUnits > 0
                                  ? minorUnitsToDecimalString(item.amountMinorUnits, space.currency)
                                  : ''
                              }
                              onChange={(e) => {
                                const units = e.target.value.trim()
                                  ? Math.max(0, parseInputToMinorUnits(e.target.value, space.currency))
                                  : 0;
                                handleUpdatePersonalItem(item.id, { amountMinorUnits: units });
                              }}
                              className="w-16 text-right text-xs font-mono font-bold text-slate-900 focus:outline-none"
                            />
                          </div>
                          <button
                            type="button"
                            onClick={() => handleRemovePersonalItem(item.id)}
                            className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition-colors cursor-pointer"
                            title="Remove personal item"
                            aria-label="Remove personal item"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ))}

                      <div
                        className={`flex flex-wrap items-center justify-between gap-2 px-2 py-1 rounded-lg text-[10px] font-semibold ${
                          enhancedResult.totalPersonalMinorUnits > amountMinorUnits
                            ? 'bg-rose-50 text-rose-700 border border-rose-200'
                            : 'bg-slate-100/80 text-slate-600'
                        }`}
                      >
                        <span>
                          Total: <strong className="font-mono">{formatMinorUnits(amountMinorUnits, space.currency)}</strong>
                        </span>
                        <span>
                          Personal: <strong className="font-mono">{formatMinorUnits(enhancedResult.totalPersonalMinorUnits, space.currency)}</strong>
                        </span>
                        <span>
                          Shared Pool: <strong className="font-mono text-blue-700">{formatMinorUnits(enhancedResult.sharedPoolMinorUnits, space.currency)}</strong>
                        </span>
                      </div>
                    </div>
                  )}
                </div>

                {payerChangeNotice && (
                  <div className="px-2.5 py-1.5 rounded-lg bg-amber-50 border border-amber-200 text-amber-800 text-[11px] font-medium">
                    {payerChangeNotice}
                  </div>
                )}

                <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-500">
                  <div className="flex items-center gap-2">
                    <span>Select participating members:</span>
                    {enhancedResult.totalPersonalMinorUnits > 0 && (
                      <span className="text-[10px] text-slate-400">
                        Shared pool: {formatMinorUnits(enhancedResult.sharedPoolMinorUnits, space.currency)}
                      </span>
                    )}
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setIsAddingTempMember((v) => !v);
                      setTempInputError('');
                      setTempRemovalError('');
                    }}
                    className="inline-flex items-center gap-1 px-2 py-1 rounded-lg text-[11px] font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200/70 transition-colors cursor-pointer shrink-0"
                  >
                    <UserPlus className="w-3 h-3" />
                    <span>Add New Member</span>
                  </button>
                </div>

                {isAddingTempMember && (
                  <div className="bg-white rounded-xl border border-blue-200/80 p-2.5 space-y-1.5">
                    <div className="flex items-center gap-1.5">
                      <input
                        type="text"
                        maxLength={MAX_TEMP_PARTICIPANT_NAME_LENGTH}
                        placeholder="One-time member name"
                        aria-label="One-time member name"
                        value={newTempName}
                        onChange={(e) => {
                          setNewTempName(e.target.value);
                          if (tempInputError) setTempInputError('');
                        }}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            handleAddTempParticipant();
                          }
                        }}
                        autoFocus
                        className="flex-1 bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs font-medium text-slate-900 focus:outline-none focus:border-blue-600 focus:bg-white"
                      />
                      <button
                        type="button"
                        onClick={handleAddTempParticipant}
                        className="px-2.5 py-1.5 rounded-lg text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 transition-colors cursor-pointer shrink-0"
                      >
                        Add
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setIsAddingTempMember(false);
                          setNewTempName('');
                          setTempInputError('');
                        }}
                        className="px-2 py-1.5 rounded-lg text-xs font-semibold text-slate-600 hover:bg-slate-100 transition-colors cursor-pointer shrink-0"
                      >
                        Cancel
                      </button>
                    </div>
                    <p className="text-[10px] text-slate-500">
                      Added to this expense only — not saved to space members.
                    </p>
                    {tempInputError && (
                      <p className="text-[10px] font-semibold text-rose-600">{tempInputError}</p>
                    )}
                  </div>
                )}

                {tempDuplicateHint && (
                  <div className="px-2.5 py-1.5 rounded-lg bg-amber-50 border border-amber-200/80 text-amber-800 text-[11px] font-medium">
                    {tempDuplicateHint}
                  </div>
                )}

                {tempRemovalError && (
                  <div className="px-2.5 py-1.5 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 text-[11px] font-medium">
                    {tempRemovalError}
                  </div>
                )}

                <div className="space-y-1.5 max-h-64 overflow-y-auto pr-1">
                  {allSplitParticipants.map((m) => {
                    const isSelected = selectedMemberIds.includes(m.id);
                    const share = computedSplits.find((s) => s.memberId === m.id);
                    const personalAmt = share?.personalMinorUnits || 0;
                    const sharedAmt = share?.sharedMinorUnits ?? (isSelected ? share?.shareMinorUnits || 0 : 0);
                    const totalShare = share?.shareMinorUnits || 0;
                    const isParticipating = isSelected || personalAmt > 0;
                    const isBillPayer = !m.isTemporary && m.id === payerId;
                    const advancePaid = isBillPayer || m.isTemporary ? 0 : (advancePaidMinorUnitsMap[m.id] || 0);
                    const remainingBal = Math.max(0, totalShare - advancePaid);
                    const memberCapMsg =
                      enhancedValidation.memberErrors[m.id] || advanceCapNotices[m.id];

                    return (
                      <div
                        key={m.id}
                        className={`p-2 rounded-xl border text-xs transition-colors space-y-1.5 ${
                          isParticipating
                            ? 'bg-white border-blue-200'
                            : 'bg-slate-100/60 border-slate-200/50 opacity-60'
                        }`}
                      >
                        <div className="flex items-center justify-between gap-2">
                          <div className="flex items-center gap-1.5 min-w-0">
                            <button
                              type="button"
                              onClick={() => toggleMemberSelection(m.id)}
                              className="flex items-center gap-2 font-medium text-slate-800 cursor-pointer min-w-0"
                            >
                              <div
                                className={`w-4 h-4 rounded flex items-center justify-center border shrink-0 ${
                                  isSelected
                                    ? 'bg-blue-600 border-blue-600 text-white'
                                    : 'border-slate-300 bg-white'
                                }`}
                              >
                                {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                              </div>
                              <span className="truncate">
                                {m.name} {!m.isTemporary && m.id === currentUserId ? '(You)' : ''}
                              </span>
                            </button>
                            {m.isTemporary && (
                              <span className="text-[9px] font-bold text-amber-800 bg-amber-50 border border-amber-200/80 px-1.5 py-0.2 rounded shrink-0">
                                Temp · One-time
                              </span>
                            )}
                            {!isSelected && personalAmt > 0 && (
                              <span className="text-[10px] font-semibold text-indigo-700 bg-indigo-50 px-1.5 py-0.2 rounded shrink-0">
                                Personal only
                              </span>
                            )}
                          </div>

                          <div className="flex items-center gap-1.5 shrink-0">
                            {isParticipating && (
                              <>
                                {isSelected && splitType === 'percentage' && (
                                  <div className="flex items-center gap-1">
                                    <input
                                      type="number"
                                      step="0.1"
                                      min="0"
                                      max="100"
                                      value={percentageMap[m.id] ?? ''}
                                      onChange={(e) => handlePercentageChange(m.id, e.target.value)}
                                      className="w-14 px-1.5 py-0.5 border border-slate-200 rounded text-center text-xs font-mono font-bold"
                                    />
                                    <span className="text-slate-400 font-bold">%</span>
                                  </div>
                                )}

                                {isSelected && splitType === 'custom' && (
                                  <div className="flex items-center gap-1">
                                    {enhancedResult.totalPersonalMinorUnits > 0 && (
                                      <span className="text-[10px] text-slate-400">Shared</span>
                                    )}
                                    <span className="text-slate-400 font-bold text-xs">
                                      {currencyMeta.symbol}
                                    </span>
                                    <input
                                      type="number"
                                      step={amountStep}
                                      min="0"
                                      placeholder="0.00"
                                      value={
                                        customMinorUnitsMap[m.id] !== undefined &&
                                        customMinorUnitsMap[m.id] > 0
                                          ? minorUnitsToDecimalString(
                                              customMinorUnitsMap[m.id],
                                              space.currency
                                            )
                                          : ''
                                      }
                                      onChange={(e) => {
                                        const units = e.target.value.trim()
                                          ? Math.max(
                                              0,
                                              parseInputToMinorUnits(e.target.value, space.currency)
                                            )
                                          : 0;
                                        handleCustomMinorUnitsChange(m.id, units);
                                      }}
                                      className="w-18 px-1.5 py-0.5 border border-slate-200 rounded text-right text-xs font-mono font-bold"
                                    />
                                  </div>
                                )}

                                <span
                                  className="font-mono font-bold text-slate-900 bg-slate-50 px-2 py-0.5 rounded border border-slate-200/60"
                                  title="Member's total calculated share"
                                >
                                  {formatMinorUnits(totalShare, space.currency)}
                                </span>
                              </>
                            )}
                            {m.isTemporary && (
                              <button
                                type="button"
                                onClick={() =>
                                  handleRemoveTempParticipant({
                                    id: m.id,
                                    name: m.name,
                                    isTemporary: true
                                  })
                                }
                                className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition-colors cursor-pointer"
                                title={`Remove temporary member ${m.name}`}
                                aria-label={`Remove temporary member ${m.name}`}
                              >
                                <X className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </div>

                        {/* Secondary row: Already Paid (Advance) input for permanent non-payer members + Share / Personal / Remaining breakdown */}
                        {isParticipating && (!m.isTemporary || personalAmt > 0) && (
                          <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-slate-100 text-[11px]">
                            <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-slate-500">
                              {personalAmt > 0 && (
                                <span>
                                  Shared{' '}
                                  <strong className="font-mono text-slate-700">
                                    {formatMinorUnits(sharedAmt, space.currency)}
                                  </strong>{' '}
                                  + Personal{' '}
                                  <strong className="font-mono text-indigo-700">
                                    {formatMinorUnits(personalAmt, space.currency)}
                                  </strong>
                                </span>
                              )}
                              {!isBillPayer && !m.isTemporary && (advancePaid > 0 || personalAmt > 0) && (
                                <span className="text-slate-700 font-semibold">
                                  Remaining:{' '}
                                  <strong className="font-mono text-blue-700">
                                    {formatMinorUnits(remainingBal, space.currency)}
                                  </strong>
                                </span>
                              )}
                              {isBillPayer && (
                                <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200/70 px-1.5 py-0.2 rounded">
                                  Bill Payer
                                </span>
                              )}
                            </div>

                            {!isBillPayer && !m.isTemporary && (
                              <div className="flex items-center gap-1.5 ml-auto">
                                <label
                                  htmlFor={`advance-${m.id}`}
                                  className="text-[10px] font-semibold text-slate-500"
                                >
                                  Already Paid
                                </label>
                                <div className="flex items-center gap-0.5 bg-slate-50 border border-slate-200 rounded px-1.5 py-0.5 focus-within:border-blue-600 focus-within:bg-white">
                                  <span className="text-slate-400 font-bold text-[10px]">
                                    {currencyMeta.symbol}
                                  </span>
                                  <input
                                    id={`advance-${m.id}`}
                                    type="number"
                                    step={amountStep}
                                    min="0"
                                    max={minorUnitsToDecimalString(totalShare, space.currency)}
                                    placeholder="0"
                                    disabled={totalShare <= 0}
                                    value={
                                      advancePaid > 0
                                        ? minorUnitsToDecimalString(advancePaid, space.currency)
                                        : ''
                                    }
                                    onChange={(e) =>
                                      handleAdvancePaidChange(m.id, e.target.value, totalShare)
                                    }
                                    className="w-14 bg-transparent text-right text-[11px] font-mono font-bold text-slate-900 focus:outline-none disabled:opacity-40"
                                  />
                                </div>
                              </div>
                            )}
                          </div>
                        )}

                        {memberCapMsg && (
                          <div className="text-[10px] font-medium text-rose-700 bg-rose-50 border border-rose-200/80 rounded-lg px-2 py-1">
                            {memberCapMsg}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>

                <div className="space-y-1 pt-1.5 border-t border-slate-200/60 text-[11px]">
                  <div className="flex items-center justify-between text-slate-500">
                    <span>
                      Allocated Shares
                      {splitType === 'custom' && enhancedResult.customSharedDeltaMinorUnits !== 0 && (
                        <span className="ml-1.5 text-rose-600 font-semibold">
                          (
                          {enhancedResult.customSharedDeltaMinorUnits > 0
                            ? `${formatMinorUnits(
                                enhancedResult.customSharedDeltaMinorUnits,
                                space.currency
                              )} left`
                            : `${formatMinorUnits(
                                Math.abs(enhancedResult.customSharedDeltaMinorUnits),
                                space.currency
                              )} over`}
                          )
                        </span>
                      )}
                      {splitType === 'percentage' &&
                        enhancedResult.sharedPoolMinorUnits > 0 &&
                        Math.abs(enhancedResult.percentageSum - 100) > 0.01 && (
                          <span className="ml-1.5 text-rose-600 font-semibold">
                            ({enhancedResult.percentageSum.toFixed(1)}% / 100%)
                          </span>
                        )}
                    </span>
                    <span
                      className={`font-mono font-bold ${
                        enhancedResult.allocatedMinorUnits === amountMinorUnits
                          ? 'text-blue-700'
                          : 'text-rose-600'
                      }`}
                    >
                      {formatMinorUnits(enhancedResult.allocatedMinorUnits, space.currency)} /{' '}
                      {formatMinorUnits(amountMinorUnits, space.currency)}
                    </span>
                  </div>

                  {enhancedResult.totalAdvanceMinorUnits > 0 && (
                    <div className="flex items-center justify-between text-[10px] text-emerald-700">
                      <span>Advance Paid (logged separately; bill total preserved)</span>
                      <span className="font-mono font-bold">
                        {formatMinorUnits(enhancedResult.totalAdvanceMinorUnits, space.currency)}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Optional Notes */}
        <Input
          label="Optional Memo / Reference"
          placeholder="Receipt #, itemized detail, transaction note..."
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
        />

        {errorMsg && (
          <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl text-xs font-medium">
            {errorMsg}
          </div>
        )}

        <div className="flex items-center gap-2 pt-2">
          <Button type="button" variant="secondary" onClick={onClose} className="w-1/3">
            Cancel
          </Button>
          <Button
            type="submit"
            variant={type === 'income' ? 'success' : type === 'expense' ? 'danger' : 'primary'}
            isLoading={isSubmitting}
            className="w-2/3"
          >
            {editingTransaction ? 'Update Entry' : 'Save to Ledger'}
          </Button>
        </div>
      </form>
    </Modal>
  );
};
