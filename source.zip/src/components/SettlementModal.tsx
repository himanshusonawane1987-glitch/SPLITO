import React, { useState, useEffect } from 'react';
import { DebtSettlement, PaymentMethod, Space, Transaction } from '../types/finance.ts';
import { Modal } from './ui/Modal.tsx';
import { Button } from './ui/Button.tsx';
import { CurrencyInput, Input } from './ui/Input.tsx';
import {
  formatMinorUnits,
  getCurrencyMeta,
  isTemporaryParticipantId
} from '../lib/finance-engine.ts';
import { AmountDisplay } from './ui/Typography.tsx';
import {
  CheckCircle2,
  ArrowRight,
  Receipt,
  ShieldCheck,
  Calendar,
  CreditCard,
  Printer,
  Eye,
  FileCheck2
} from 'lucide-react';

interface SettlementModalProps {
  isOpen: boolean;
  onClose: () => void;
  debt: DebtSettlement | null;
  space: Space;
  temporaryMembers?: { id: string; name: string }[];
  currentUserId: string;
  onRecordSettlement: (tx: Transaction) => Promise<void>;
  initialViewSlip?: boolean;
}

export const SettlementModal: React.FC<SettlementModalProps> = ({
  isOpen,
  onClose,
  debt,
  space,
  temporaryMembers = [],
  currentUserId,
  onRecordSettlement,
  initialViewSlip = false
}) => {
  const members = space.members || [];
  const otherMembers = members.filter((m) => m.id !== currentUserId);

  const [payerId, setPayerId] = useState<string>(currentUserId);
  const [receiverId, setReceiverId] = useState<string>(otherMembers[0]?.id || '');
  const [amountMinorUnits, setAmountMinorUnits] = useState<number>(0);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('UPI');
  const [notes, setNotes] = useState<string>('Settled via UPI');
  const [date, setDate] = useState<string>(() => new Date().toISOString().split('T')[0]);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [isSlipView, setIsSlipView] = useState<boolean>(initialViewSlip);
  const [confirmedTx, setConfirmedTx] = useState<Transaction | null>(null);

  const isTempDebt = Boolean(
    debt &&
      (debt.fromIsTemporary ||
        debt.toIsTemporary ||
        isTemporaryParticipantId(debt.fromMemberId) ||
        isTemporaryParticipantId(debt.toMemberId))
  );

  useEffect(() => {
    setConfirmedTx(null);
    // D2: If opened for a temporary participant's debt, default to Confirmation Slip preview (outside-app note)
    setIsSlipView(initialViewSlip || isTempDebt);

    if (debt) {
      setPayerId(debt.fromMemberId);
      setReceiverId(debt.toMemberId);
      setAmountMinorUnits(debt.amountMinorUnits);
      setPaymentMethod('UPI');
      setNotes(`Settlement from ${debt.fromMemberName} to ${debt.toMemberName}`);
      setDate(new Date().toISOString().split('T')[0]);
    } else {
      const defaultPayer = currentUserId;
      const defaultReceiver = members.find((m) => m.id !== defaultPayer)?.id || (members[1]?.id ?? '');
      setPayerId(defaultPayer);
      setReceiverId(defaultReceiver);
      setAmountMinorUnits(0);
      setPaymentMethod('UPI');
      setNotes('Direct settlement payment');
      setDate(new Date().toISOString().split('T')[0]);
    }
  }, [debt, currentUserId, space, isOpen, initialViewSlip, isTempDebt]);

  // Ensure receiverId is never equal to payerId
  const handlePayerChange = (newPayerId: string) => {
    setPayerId(newPayerId);
    if (receiverId === newPayerId) {
      const nextReceiver = members.find((m) => m.id !== newPayerId)?.id || '';
      setReceiverId(nextReceiver);
    }
  };

  const resolveParticipantName = (id: string, fallback: string) => {
    const permanent = members.find((m) => m.id === id);
    if (permanent?.name) return permanent.name;
    const temp = temporaryMembers.find((t) => t.id === id);
    if (temp?.name) return temp.name;
    if (debt?.fromMemberId === id && debt.fromMemberName) return debt.fromMemberName;
    if (debt?.toMemberId === id && debt.toMemberName) return debt.toMemberName;
    return fallback;
  };

  const payerName = resolveParticipantName(payerId, 'Payer');
  const receiverName = resolveParticipantName(receiverId, 'Receiver');
  const payerIsTemp = isTemporaryParticipantId(payerId) || Boolean(debt?.fromMemberId === payerId && debt.fromIsTemporary);
  const receiverIsTemp = isTemporaryParticipantId(receiverId) || Boolean(debt?.toMemberId === receiverId && debt.toIsTemporary);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    // D2: Temporary participants are excluded from in-app settlement selection
    if (amountMinorUnits <= 0 || !payerId || !receiverId || payerIsTemp || receiverIsTemp) return;

    setIsSubmitting(true);
    try {
      const tx: Transaction = {
        id: `set_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        spaceId: space.id,
        creatorId: currentUserId,
        title: `Settlement: ${payerName} → ${receiverName}`,
        type: 'settlement',
        category: 'Settlement',
        amount: Math.round(amountMinorUnits),
        date,
        payerId,
        paidToId: receiverId,
        ...(payerIsTemp ? { payerNameSnapshot: payerName } : {}),
        ...(receiverIsTemp ? { paidToNameSnapshot: receiverName } : {}),
        paymentMethod,
        createdAt: new Date().toISOString()
      };

      if (notes.trim()) {
        tx.notes = notes.trim();
      }

      await onRecordSettlement(tx);
      setConfirmedTx(tx);
      setIsSlipView(true);
    } catch (err: any) {
      console.error('Settlement record error:', err);
      alert('Failed to record settlement: ' + (err?.message || 'Unknown error'));
    } finally {
      setIsSubmitting(false);
    }
  };

  const currentSlipTx = confirmedTx || {
    id: `slip_preview_${Date.now().toString(36)}`,
    amount: amountMinorUnits || debt?.amountMinorUnits || 0,
    date,
    paymentMethod,
    notes
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={isSlipView ? 'Settlement Confirmation Slip' : 'Record Settlement'}
      subtitle={
        isSlipView
          ? 'Verified settlement transfer record • Zero-sum audited'
          : `Settle outstanding dues in ${space.name}`
      }
      maxWidth="md"
    >
      {isSlipView ? (
        /* Confirmation Slip / Digital Receipt View */
        <div className="space-y-4 text-left">
          <div className="p-5 bg-gradient-to-br from-indigo-50/70 via-blue-50/40 to-white border border-indigo-200/90 rounded-2xl space-y-4 text-slate-900 shadow-2xs">
            <div className="flex items-center justify-between pb-3 border-b border-indigo-100">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-full bg-indigo-600 text-white flex items-center justify-center shadow-xs">
                  <CheckCircle2 className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-sm text-slate-900">
                    {confirmedTx ? 'Payment Verified & Recorded' : 'Settlement Slip Preview'}
                  </h4>
                  <span className="text-[11px] text-slate-500 font-mono">
                    Ref #{currentSlipTx.id.slice(-8).toUpperCase()}
                  </span>
                </div>
              </div>
              <AmountDisplay
                minorUnits={currentSlipTx.amount}
                currency={space.currency}
                size="metric"
                variant="settlement"
              />
            </div>

            {/* Payer and Receiver Info Cards */}
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-3 bg-white rounded-xl border border-slate-200/80">
                <span className="text-[10px] text-slate-400 uppercase font-bold block">
                  Disbursed By
                </span>
                <span className="font-bold text-sm text-slate-900 block mt-0.5">
                  {payerName} {payerId === currentUserId ? '(You)' : ''}
                </span>
                <span className="text-[10px] text-slate-500">Debited personal funds</span>
              </div>
              <div className="p-3 bg-white rounded-xl border border-slate-200/80">
                <span className="text-[10px] text-slate-400 uppercase font-bold block">
                  Received By
                </span>
                <span className="font-bold text-sm text-slate-900 block mt-0.5">
                  {receiverName} {receiverId === currentUserId ? '(You)' : ''}
                </span>
                <span className="text-[10px] text-slate-500">Credited into balance</span>
              </div>
            </div>

            {/* Detail rows */}
            <div className="p-3 bg-white rounded-xl border border-slate-200/80 space-y-1.5 text-xs font-mono">
              <div className="flex justify-between py-0.5 text-slate-600">
                <span className="font-sans">Payment Instrument</span>
                <span className="font-bold text-slate-900">{paymentMethod}</span>
              </div>
              <div className="flex justify-between py-0.5 text-slate-600">
                <span className="font-sans">Settlement Date</span>
                <span className="font-bold text-slate-900">{date}</span>
              </div>
              <div className="flex justify-between py-0.5 text-slate-600">
                <span className="font-sans">Financial Space</span>
                <span className="font-bold text-slate-900">{space.name}</span>
              </div>
              {notes && (
                <div className="flex justify-between py-0.5 text-slate-600 border-t border-slate-100 pt-1">
                  <span className="font-sans">Audit Memo</span>
                  <span className="text-slate-800 italic">{notes}</span>
                </div>
              )}
            </div>

            {(payerIsTemp || receiverIsTemp) && (
              <div className="p-2.5 bg-amber-50 border border-amber-200/80 rounded-xl text-[11px] text-amber-900 font-medium text-center">
                Temporary — settle outside the app. One-time participants are not permanent space members.
              </div>
            )}

            <div className="flex items-center gap-1.5 text-[11px] text-slate-500 justify-center">
              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>Immutable Ledger Guarantee • Every Rupee. Accounted For.</span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {!confirmedTx && !isTempDebt && (
              <Button
                type="button"
                variant="secondary"
                className="w-1/2"
                onClick={() => setIsSlipView(false)}
              >
                Back to Form
              </Button>
            )}
            <Button
              fullWidth={!!confirmedTx || isTempDebt}
              variant="primary"
              className={confirmedTx || isTempDebt ? 'w-full' : 'w-1/2'}
              onClick={onClose}
            >
              {confirmedTx ? 'Done & Return to Ledger' : 'Close Slip'}
            </Button>
          </div>
        </div>
      ) : (
        /* Form View with Visible & Functional Recipient Selector */
        <form onSubmit={handleSubmit} className="space-y-4 text-left">
          {/* Payer and Receiver Selection */}
          <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200/80 space-y-3">
            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider block">
              Transfer Direction
            </span>
            <div className="flex items-center justify-between gap-2">
              {/* Payer Dropdown */}
              <div className="flex-1 text-left">
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">
                  Who Pays (Payer)
                </label>
                <select
                  value={payerId}
                  onChange={(e) => handlePayerChange(e.target.value)}
                  className="w-full bg-white text-slate-900 font-bold border border-slate-200 rounded-xl px-2.5 py-2.5 text-xs focus:outline-none focus:border-blue-600 shadow-2xs cursor-pointer"
                >
                  {members.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.name} {m.id === currentUserId ? '(You)' : ''}
                    </option>
                  ))}
                </select>
              </div>

              <div className="p-2 rounded-full bg-indigo-50 text-indigo-600 shrink-0 mt-3">
                <ArrowRight className="w-4 h-4" />
              </div>

              {/* Recipient Dropdown (Always populated with non-payer members) */}
              <div className="flex-1 text-left">
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">
                  Recipient (Paid To)
                </label>
                <select
                  value={receiverId}
                  onChange={(e) => setReceiverId(e.target.value)}
                  className="w-full bg-white text-slate-900 font-bold border border-slate-200 rounded-xl px-2.5 py-2.5 text-xs focus:outline-none focus:border-blue-600 shadow-2xs cursor-pointer"
                  required
                >
                  {members
                    .filter((m) => m.id !== payerId)
                    .map((m) => (
                      <option key={m.id} value={m.id}>
                        {m.name} {m.id === currentUserId ? '(You)' : ''}
                      </option>
                    ))}
                </select>
              </div>
            </div>
          </div>

          {/* Amount in integer minor units */}
          <CurrencyInput
            label="Settlement Amount"
            paise={amountMinorUnits}
            onChangePaise={setAmountMinorUnits}
            currency={space.currency}
            hint={`Exact minor units in space currency (${space.currency})`}
            autoFocus={amountMinorUnits === 0}
          />

          {/* Payment Method Selector */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
              Payment Method
            </label>
            <div className="grid grid-cols-4 gap-1.5">
              {(['UPI', 'Cash', 'Card', 'Net Banking'] as PaymentMethod[]).map((method) => (
                <button
                  key={method}
                  type="button"
                  onClick={() => {
                    setPaymentMethod(method);
                    if (!notes || notes.startsWith('Settled via')) {
                      setNotes(`Settled via ${method}`);
                    }
                  }}
                  className={`py-2 px-1 rounded-xl border text-xs font-semibold cursor-pointer transition-all ${
                    paymentMethod === method
                      ? 'border-indigo-600 bg-indigo-50 text-indigo-700 shadow-2xs'
                      : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  {method}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <Input
              label="Settlement Date"
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              required
            />
            <Input
              label="UPI Ref / Memo"
              placeholder="e.g., GPay txn ID"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
            />
          </div>

          {/* Working View Slip Trigger Button */}
          <div className="flex items-center justify-between pt-1">
            <button
              type="button"
              onClick={() => setIsSlipView(true)}
              disabled={amountMinorUnits <= 0}
              className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1.5 cursor-pointer disabled:opacity-40 disabled:pointer-events-none"
            >
              <FileCheck2 className="w-3.5 h-3.5" />
              <span>View Confirmation Slip Preview</span>
            </button>
          </div>

          <div className="flex items-center gap-2 pt-2">
            <Button type="button" variant="secondary" onClick={onClose} className="w-1/3">
              Cancel
            </Button>
            <Button
              type="submit"
              variant="primary"
              isLoading={isSubmitting}
              className="w-2/3 bg-indigo-600 hover:bg-indigo-700 focus:ring-indigo-500"
              icon={<CheckCircle2 className="w-4 h-4" />}
            >
              Confirm Settlement
            </Button>
          </div>
        </form>
      )}
    </Modal>
  );
};
