import React, { useState } from 'react';
import { Modal } from './ui/Modal.tsx';
import { Button } from './ui/Button.tsx';
import { AlertTriangle, Trash2, ShieldCheck, CheckCircle2 } from 'lucide-react';

interface AccountDeletionModalProps {
  isOpen: boolean;
  onClose: () => void;
  userEmail?: string | null;
  onConfirmDelete: () => Promise<void>;
}

export const AccountDeletionModal: React.FC<AccountDeletionModalProps> = ({
  isOpen,
  onClose,
  userEmail,
  onConfirmDelete
}) => {
  const [confirmationText, setConfirmationText] = useState<string>('');
  const [finalConsent, setFinalConsent] = useState<boolean>(false);
  const [isDeleting, setIsDeleting] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const isConfirmed = confirmationText.trim().toUpperCase() === 'DELETE MY ACCOUNT';
  const canProceed = isConfirmed && finalConsent && !isDeleting;

  const handleDelete = async () => {
    if (!canProceed) return;
    setIsDeleting(true);
    setErrorMessage(null);
    try {
      await onConfirmDelete();
      onClose();
    } catch (err: any) {
      setErrorMessage(err?.message || 'Failed to complete account deletion. Please try again.');
      setIsDeleting(false);
    }
  };

  const handleModalClose = () => {
    if (isDeleting) return;
    setConfirmationText('');
    setFinalConsent(false);
    setErrorMessage(null);
    onClose();
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={handleModalClose}
      title="Delete Account"
      subtitle="Permanently close your SPLITO account and remove eligible account data"
      maxWidth="md"
    >
      <div className="space-y-4 text-left">
        {/* Warning Banner */}
        <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
          <div className="text-xs text-rose-900 space-y-1">
            <span className="font-bold block">
              Permanent Account Closure Notice
            </span>
            <p className="leading-relaxed text-rose-800">
              You are requesting permanent closure of your SPLITO account ({userEmail || 'Active User'}). This action cannot be undone.
            </p>
          </div>
        </div>

        {/* Detailed Explanation of Data Erasure */}
        <div className="p-4 bg-slate-50 border border-slate-200/80 rounded-2xl space-y-2 text-xs text-slate-700">
          <span className="font-bold text-slate-900 block">
            What happens when you delete your account:
          </span>
          <ul className="list-disc pl-4 space-y-1.5 text-slate-600">
            <li>
              <strong className="text-slate-800">Authentication & Profile:</strong> Your Firebase Google login and profile records are permanently removed.
            </li>
            <li>
              <strong className="text-slate-800">Personal Spaces:</strong> All private ledgers owned exclusively by you are permanently purged.
            </li>
            <li>
              <strong className="text-slate-800">Shared Spaces (Roommates/Trips):</strong> Your personal identifying details are anonymized so that remaining members' financial calculations and debt balances remain intact.
            </li>
            <li>
              <strong className="text-slate-800">Subscriptions:</strong> Any Google Play store subscription should also be cancelled in Google Play Store.
            </li>
          </ul>
        </div>

        {/* Confirmation Input */}
        <div className="space-y-2">
          <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider">
            Type <span className="text-rose-600 font-mono">DELETE MY ACCOUNT</span> to confirm:
          </label>
          <input
            type="text"
            value={confirmationText}
            onChange={(e) => {
              setConfirmationText(e.target.value);
              setErrorMessage(null);
            }}
            placeholder="DELETE MY ACCOUNT"
            className="w-full bg-white text-slate-900 font-mono text-sm px-3.5 py-3 border border-slate-300 focus:border-rose-500 focus:ring-2 focus:ring-rose-200 rounded-xl focus:outline-none transition-all"
            disabled={isDeleting}
          />
        </div>

        {/* Final Checkbox Confirmation */}
        <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-start gap-2.5">
          <input
            id="final-delete-account-consent"
            type="checkbox"
            checked={finalConsent}
            onChange={(e) => setFinalConsent(e.target.checked)}
            disabled={!isConfirmed || isDeleting}
            className="mt-0.5 w-4 h-4 text-rose-600 rounded border-slate-300 focus:ring-rose-500 cursor-pointer disabled:opacity-50"
          />
          <label
            htmlFor="final-delete-account-consent"
            className={`text-xs leading-relaxed select-none ${
              isConfirmed ? 'text-slate-800 cursor-pointer font-medium' : 'text-slate-400 cursor-not-allowed'
            }`}
          >
            I understand that my account will be permanently closed and all eligible data will be erased.
          </label>
        </div>

        {errorMessage && (
          <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl text-xs font-medium leading-relaxed">
            {errorMessage}
          </div>
        )}

        <div className="pt-2 flex items-center justify-end gap-2">
          <Button
            type="button"
            variant="ghost"
            onClick={handleModalClose}
            disabled={isDeleting}
          >
            Cancel
          </Button>
          <Button
            type="button"
            variant="danger"
            size="md"
            icon={<Trash2 className="w-4 h-4" />}
            isLoading={isDeleting}
            disabled={!canProceed}
            onClick={handleDelete}
          >
            Permanently Delete Account
          </Button>
        </div>
      </div>
    </Modal>
  );
};
