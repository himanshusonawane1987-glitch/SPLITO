import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {
  MAX_TEMP_PARTICIPANT_NAME_LENGTH,
  UNKNOWN_TEMP_PARTICIPANT_LABEL,
  buildTemporaryParticipantId,
  calculateDebtSettlements,
  calculateEnhancedExpenseSplits,
  calculateGroupBalances,
  createCascadeReversalPlan,
  disambiguateTemporaryParticipantName,
  filterVisibleMemberBalances,
  findActiveManualSettlementsForExpenseTemps,
  findActiveManualSettlementsForTempParticipant,
  getParticipantDisplayName,
  isTemporaryParticipantId,
  reconcileLinkedAdvanceTransactions,
  validateEnhancedExpenseSplits,
  validateTemporaryParticipantName
} from './finance-engine.ts';
import {
  checkSpaceDeletionEligibility,
  normalizeTransactionPayload
} from './storage-service.ts';
import { buildPdfDocument, exportCsvStatement } from './export-service.ts';
import {
  ActualBalanceBreakdown,
  Member,
  Space,
  TemporaryParticipant,
  Transaction
} from '../types/finance.ts';

// Mock localStorage for node test runner
const localStorageMock = (() => {
  let store: Record<string, string> = {};
  return {
    getItem: (key: string) => store[key] || null,
    setItem: (key: string, value: string) => {
      store[key] = String(value);
    },
    removeItem: (key: string) => {
      delete store[key];
    },
    clear: () => {
      store = {};
    }
  };
})();
(global as any).localStorage = localStorageMock;

const permanentMembers: Member[] = [
  { id: 'u_himanshu', name: 'Himanshu', avatarColor: '#2563eb', isCurrentUser: true, role: 'owner' },
  { id: 'u_alex', name: 'Alex', avatarColor: '#10b981', role: 'member' },
  { id: 'u_purvesh', name: 'Purvesh', avatarColor: '#f59e0b', role: 'member' }
];

const mockSpace: Space = {
  id: 'sp_temp_test',
  ownerId: 'u_himanshu',
  name: 'Goa Trip Squad',
  mode: 'trip',
  currency: 'INR',
  startingBalance: 0,
  memberIds: permanentMembers.map((m) => m.id),
  members: permanentMembers,
  createdAt: '2026-04-01T00:00:00Z',
  updatedAt: '2026-04-01T00:00:00Z'
};

function hasUndefinedDeep(obj: any): boolean {
  if (obj === undefined) return true;
  if (obj === null || typeof obj !== 'object') return false;
  if (Array.isArray(obj)) {
    return obj.some((item) => hasUndefinedDeep(item));
  }
  return Object.values(obj).some((val) => hasUndefinedDeep(val));
}

function readSource(relPath: string): string {
  return fs.readFileSync(path.resolve(process.cwd(), relPath), 'utf8');
}

describe('SPLITO Temporary Member in Split Share (T01–T24)', () => {
  it('T01: Add temporary participant to expense, split equally, save & reload with persisted name and share', () => {
    const expId = 'tx_dinner_01';
    const rohanId = buildTemporaryParticipantId(expId, 'rohan1');
    const rohan: TemporaryParticipant = { id: rohanId, name: 'Rohan', isTemporary: true };

    const splitResult = calculateEnhancedExpenseSplits({
      totalMinorUnits: 120000, // ₹1,200.00
      splitType: 'equal',
      payerId: 'u_himanshu',
      selectedMemberIds: ['u_himanshu', 'u_alex', 'u_purvesh', rohanId],
      temporaryParticipants: [rohan],
      expenseId: expId,
      currency: 'INR'
    });

    assert.strictEqual(splitResult.splits.length, 4);
    assert.strictEqual(splitResult.allocatedMinorUnits, 120000);
    const rohanSplit = splitResult.splits.find((s) => s.memberId === rohanId);
    assert.ok(rohanSplit);
    assert.strictEqual(rohanSplit.shareMinorUnits, 30000);
    assert.strictEqual(rohanSplit.memberName, 'Rohan');
    assert.strictEqual(rohanSplit.isTemporary, true);
    assert.strictEqual(splitResult.temporaryParticipants.length, 1);
    assert.strictEqual(splitResult.temporaryParticipants[0].name, 'Rohan');

    const tx: Transaction = {
      id: expId,
      spaceId: mockSpace.id,
      creatorId: 'u_himanshu',
      title: 'Beach Shack Dinner',
      type: 'expense',
      category: 'Food',
      amount: 120000,
      date: '2026-04-02',
      payerId: 'u_himanshu',
      splitType: 'equal',
      splits: splitResult.splits,
      temporaryParticipants: splitResult.temporaryParticipants,
      createdAt: '2026-04-02T20:00:00Z'
    };

    const normalized = normalizeTransactionPayload(tx);
    const reloaded = JSON.parse(JSON.stringify(normalized)) as Transaction;
    assert.strictEqual(reloaded.temporaryParticipants?.length, 1);
    assert.strictEqual(reloaded.temporaryParticipants?.[0].name, 'Rohan');
    assert.strictEqual(
      getParticipantDisplayName(rohanId, permanentMembers, reloaded),
      'Rohan'
    );
  });

  it('T02: Permanent space members list stays untouched and temp participant does not leak to next expense', () => {
    const membersBefore = JSON.stringify(mockSpace.members);
    const memberIdsBefore = JSON.stringify(mockSpace.memberIds);

    const exp1Id = 'tx_exp_1';
    const tempId = buildTemporaryParticipantId(exp1Id, 'guest1');
    calculateEnhancedExpenseSplits({
      totalMinorUnits: 40000,
      splitType: 'equal',
      payerId: 'u_himanshu',
      selectedMemberIds: ['u_himanshu', tempId],
      temporaryParticipants: [{ id: tempId, name: 'Kabir', isTemporary: true }],
      expenseId: exp1Id
    });

    // Space permanent members remain 100% unchanged
    assert.strictEqual(JSON.stringify(mockSpace.members), membersBefore);
    assert.strictEqual(JSON.stringify(mockSpace.memberIds), memberIdsBefore);
    assert.strictEqual(mockSpace.members.some((m) => m.id === tempId), false);

    // Next expense initialized from space.members does not contain Kabir
    const nextExpenseCalc = calculateEnhancedExpenseSplits({
      totalMinorUnits: 30000,
      splitType: 'equal',
      payerId: 'u_himanshu',
      selectedMemberIds: mockSpace.members.map((m) => m.id),
      expenseId: 'tx_exp_2'
    });
    assert.strictEqual(nextExpenseCalc.splits.length, 3);
    assert.strictEqual(nextExpenseCalc.temporaryParticipants.length, 0);
    assert.strictEqual(nextExpenseCalc.splits.some((s) => s.memberId === tempId), false);
  });

  it('T03: Equal split with Hare-Niemeyer rounding distributes odd paise accurately with temp participants', () => {
    const expId = 'tx_odd_100';
    const tempId = buildTemporaryParticipantId(expId, 'odd1');
    const calc = calculateEnhancedExpenseSplits({
      totalMinorUnits: 10000, // ₹100.00 across 3 -> ₹33.34, ₹33.33, ₹33.33
      splitType: 'equal',
      payerId: 'u_himanshu',
      selectedMemberIds: ['u_himanshu', 'u_alex', tempId],
      temporaryParticipants: [{ id: tempId, name: 'Neha', isTemporary: true }],
      expenseId: expId
    });

    const sum = calc.splits.reduce((acc, s) => acc + s.shareMinorUnits, 0);
    assert.strictEqual(sum, 10000);
    assert.deepStrictEqual(
      calc.splits.map((s) => s.shareMinorUnits).sort((a, b) => b - a),
      [3334, 3333, 3333]
    );
  });

  it('T04: Percentage split supports temporary participants and enforces exact 100% validation', () => {
    const expId = 'tx_pct_01';
    const tempId = buildTemporaryParticipantId(expId, 'pct1');
    const tp: TemporaryParticipant = { id: tempId, name: 'Simran', isTemporary: true };

    const valid = validateEnhancedExpenseSplits({
      totalMinorUnits: 100000,
      splitType: 'percentage',
      payerId: 'u_himanshu',
      selectedMemberIds: ['u_himanshu', 'u_alex', tempId],
      percentageMap: { u_himanshu: 40, u_alex: 35, [tempId]: 25 },
      temporaryParticipants: [tp],
      expenseId: expId
    });
    assert.strictEqual(valid.isValid, true);
    assert.strictEqual(valid.result.splits.find((s) => s.memberId === tempId)?.shareMinorUnits, 25000);
    assert.strictEqual(valid.result.allocatedMinorUnits, 100000);

    const invalid = validateEnhancedExpenseSplits({
      totalMinorUnits: 100000,
      splitType: 'percentage',
      payerId: 'u_himanshu',
      selectedMemberIds: ['u_himanshu', 'u_alex', tempId],
      percentageMap: { u_himanshu: 40, u_alex: 35, [tempId]: 10 },
      temporaryParticipants: [tp],
      expenseId: expId
    });
    assert.strictEqual(invalid.isValid, false);
    assert.ok(invalid.errors.some((e) => e.includes('100%')));
  });

  it('T05: Custom split supports temporary participants and enforces exact total match', () => {
    const expId = 'tx_custom_01';
    const tempId = buildTemporaryParticipantId(expId, 'cust1');
    const tp: TemporaryParticipant = { id: tempId, name: 'Vikram', isTemporary: true };

    const valid = validateEnhancedExpenseSplits({
      totalMinorUnits: 50000,
      splitType: 'custom',
      payerId: 'u_himanshu',
      selectedMemberIds: ['u_himanshu', tempId],
      customSharedMinorUnitsMap: { u_himanshu: 32000, [tempId]: 18000 },
      temporaryParticipants: [tp],
      expenseId: expId
    });
    assert.strictEqual(valid.isValid, true);
    assert.strictEqual(valid.result.splits.find((s) => s.memberId === tempId)?.shareMinorUnits, 18000);

    const short = validateEnhancedExpenseSplits({
      totalMinorUnits: 50000,
      splitType: 'custom',
      payerId: 'u_himanshu',
      selectedMemberIds: ['u_himanshu', tempId],
      customSharedMinorUnitsMap: { u_himanshu: 30000, [tempId]: 10000 },
      temporaryParticipants: [tp],
      expenseId: expId
    });
    assert.strictEqual(short.isValid, false);
    assert.strictEqual(short.result.customSharedDeltaMinorUnits, 10000);
  });

  it('T06: Invalid/empty/whitespace/over-60-char temporary names are rejected cleanly', () => {
    const empty = validateTemporaryParticipantName('');
    assert.strictEqual(empty.isValid, false);
    assert.strictEqual(empty.error, 'Please enter a name.');

    const spaces = validateTemporaryParticipantName('    ');
    assert.strictEqual(spaces.isValid, false);
    assert.strictEqual(spaces.error, 'Please enter a name.');

    const tooLong = validateTemporaryParticipantName('A'.repeat(MAX_TEMP_PARTICIPANT_NAME_LENGTH + 1));
    assert.strictEqual(tooLong.isValid, false);

    const ok = validateTemporaryParticipantName('  Rohan Sharma  ');
    assert.strictEqual(ok.isValid, true);
    assert.strictEqual(ok.trimmed, 'Rohan Sharma');

    assert.throws(() => {
      normalizeTransactionPayload({
        id: 'tx_bad_temp',
        spaceId: mockSpace.id,
        creatorId: 'u_himanshu',
        title: 'Bad Temp',
        type: 'expense',
        category: 'Food',
        amount: 10000,
        date: '2026-04-02',
        payerId: 'u_himanshu',
        splitType: 'equal',
        splits: [{ memberId: 'tmp_tx_bad_1', shareMinorUnits: 10000, isTemporary: true }],
        temporaryParticipants: [{ id: 'tmp_tx_bad_1', name: '   ', isTemporary: true }],
        createdAt: '2026-04-02T10:00:00Z'
      });
    }, /Temporary participant name/);
  });

  it('T07: Duplicate name matching a permanent member stays isolated by unique ID', () => {
    const expId = 'tx_dup_perm';
    const tempAlexId = buildTemporaryParticipantId(expId, 'alex_tmp');
    const calc = calculateEnhancedExpenseSplits({
      totalMinorUnits: 60000,
      splitType: 'equal',
      payerId: 'u_himanshu',
      selectedMemberIds: ['u_himanshu', 'u_alex', tempAlexId],
      temporaryParticipants: [{ id: tempAlexId, name: 'Alex', isTemporary: true }],
      expenseId: expId
    });

    const tx: Transaction = {
      id: expId,
      spaceId: mockSpace.id,
      creatorId: 'u_himanshu',
      title: 'Snacks',
      type: 'expense',
      category: 'Food',
      amount: 60000,
      date: '2026-04-03',
      payerId: 'u_himanshu',
      splitType: 'equal',
      splits: calc.splits,
      temporaryParticipants: calc.temporaryParticipants,
      createdAt: '2026-04-03T10:00:00Z'
    };

    const balances = calculateGroupBalances(permanentMembers, [tx]);
    const permAlex = balances.find((b) => b.memberId === 'u_alex');
    const tempAlex = balances.find((b) => b.memberId === tempAlexId);
    assert.ok(permAlex && tempAlex);
    assert.strictEqual(permAlex.isTemporary, undefined);
    assert.strictEqual(tempAlex.isTemporary, true);
    assert.strictEqual(permAlex.netBalanceMinorUnits, -20000);
    assert.strictEqual(tempAlex.netBalanceMinorUnits, -20000);
    assert.strictEqual(balances.reduce((acc, b) => acc + b.netBalanceMinorUnits, 0), 0);
  });

  it('T08: Duplicate temporary names within the same expense are disambiguated ("Rohan (2)", "Rohan (3)")', () => {
    const list: TemporaryParticipant[] = [];
    const n1 = disambiguateTemporaryParticipantName('Rohan', list);
    assert.strictEqual(n1, 'Rohan');
    list.push({ id: 'tmp_1', name: n1, isTemporary: true });

    const n2 = disambiguateTemporaryParticipantName('rohan', list);
    assert.strictEqual(n2, 'rohan (2)');
    list.push({ id: 'tmp_2', name: n2, isTemporary: true });

    const n3 = disambiguateTemporaryParticipantName('Rohan', list);
    assert.strictEqual(n3, 'Rohan (3)');
  });

  it('T09: Malformed temp record with missing name never leaks raw tmp_ ID and falls back to Unknown (Temp)', () => {
    const brokenId = 'tmp_legacy_broken_99';
    const malformedTx: Transaction = {
      id: 'tx_broken',
      spaceId: mockSpace.id,
      creatorId: 'u_himanshu',
      title: 'Malformed Split',
      type: 'expense',
      category: 'Food',
      amount: 20000,
      date: '2026-04-03',
      payerId: 'u_himanshu',
      splitType: 'equal',
      splits: [
        { memberId: 'u_himanshu', shareMinorUnits: 10000 },
        { memberId: brokenId, shareMinorUnits: 10000, isTemporary: true }
      ],
      createdAt: '2026-04-03T10:00:00Z'
    };

    assert.strictEqual(isTemporaryParticipantId(brokenId), true);
    assert.strictEqual(
      getParticipantDisplayName(brokenId, permanentMembers, malformedTx),
      UNKNOWN_TEMP_PARTICIPANT_LABEL
    );

    const balances = calculateGroupBalances(permanentMembers, [malformedTx]);
    const brokenBal = balances.find((b) => b.memberId === brokenId);
    assert.ok(brokenBal);
    assert.strictEqual(brokenBal.memberName, UNKNOWN_TEMP_PARTICIPANT_LABEL);
    assert.strictEqual(brokenBal.isTemporary, true);

    const normalized = normalizeTransactionPayload(malformedTx);
    const brokenSplit = normalized.splits.find((s: any) => s.memberId === brokenId);
    assert.strictEqual(brokenSplit.memberName, UNKNOWN_TEMP_PARTICIPANT_LABEL);
  });

  it('T10: Group balances include temporary participant with exact zero-sum invariant (Σ === 0)', () => {
    const expId = 'tx_zero_sum';
    const tempId = buildTemporaryParticipantId(expId, 'zs1');
    const calc = calculateEnhancedExpenseSplits({
      totalMinorUnits: 100000,
      splitType: 'equal',
      payerId: 'u_himanshu',
      selectedMemberIds: ['u_himanshu', 'u_alex', 'u_purvesh', tempId],
      temporaryParticipants: [{ id: tempId, name: 'Rohan', isTemporary: true }],
      expenseId: expId
    });

    const tx: Transaction = {
      id: expId,
      spaceId: mockSpace.id,
      creatorId: 'u_himanshu',
      title: 'Hotel',
      type: 'expense',
      category: 'Accommodation',
      amount: 100000,
      date: '2026-04-04',
      payerId: 'u_himanshu',
      splitType: 'equal',
      splits: calc.splits,
      temporaryParticipants: calc.temporaryParticipants,
      createdAt: '2026-04-04T10:00:00Z'
    };

    const balances = calculateGroupBalances(permanentMembers, [tx]);
    const netSum = balances.reduce((acc, b) => acc + b.netBalanceMinorUnits, 0);
    assert.strictEqual(netSum, 0);

    const himanshu = balances.find((b) => b.memberId === 'u_himanshu')!;
    const rohan = balances.find((b) => b.memberId === tempId)!;
    assert.strictEqual(himanshu.netBalanceMinorUnits, 75000);
    assert.strictEqual(rohan.netBalanceMinorUnits, -25000);
    assert.strictEqual(rohan.memberName, 'Rohan');
    assert.strictEqual(rohan.isTemporary, true);
    assert.strictEqual(rohan.linkedExpenseId, expId);
  });

  it('T11: Smart Settlement includes temporary debt with fromIsTemporary flag and does not reassign share', () => {
    const expId = 'tx_smart_01';
    const tempId = buildTemporaryParticipantId(expId, 'sm1');
    const tx: Transaction = {
      id: expId,
      spaceId: mockSpace.id,
      creatorId: 'u_himanshu',
      title: 'Cab',
      type: 'expense',
      category: 'Transport',
      amount: 90000,
      date: '2026-04-04',
      payerId: 'u_himanshu',
      splitType: 'equal',
      splits: [
        { memberId: 'u_himanshu', shareMinorUnits: 30000 },
        { memberId: 'u_alex', shareMinorUnits: 30000 },
        { memberId: tempId, shareMinorUnits: 30000, memberName: 'Rohan', isTemporary: true }
      ],
      temporaryParticipants: [{ id: tempId, name: 'Rohan', isTemporary: true }],
      createdAt: '2026-04-04T12:00:00Z'
    };

    const balances = calculateGroupBalances(permanentMembers, [tx]);
    const settlements = calculateDebtSettlements(balances);

    const rohanDebt = settlements.find((d) => d.fromMemberId === tempId);
    const alexDebt = settlements.find((d) => d.fromMemberId === 'u_alex');
    assert.ok(rohanDebt);
    assert.ok(alexDebt);
    assert.strictEqual(rohanDebt.fromMemberName, 'Rohan');
    assert.strictEqual(rohanDebt.toMemberId, 'u_himanshu');
    assert.strictEqual(rohanDebt.amountMinorUnits, 30000);
    assert.strictEqual(rohanDebt.fromIsTemporary, true);
    assert.strictEqual(alexDebt.amountMinorUnits, 30000); // Not inflated by Rohan's share
    assert.strictEqual(alexDebt.fromIsTemporary, undefined);
  });

  it('T12: Decision D2 — SettlementModal dropdowns exclude temp participants & views display outside-app note', () => {
    const settlementModalSrc = readSource('src/components/SettlementModal.tsx');
    const groupsViewSrc = readSource('src/components/views/GroupsView.tsx');
    const homeViewSrc = readSource('src/components/views/HomeView.tsx');

    // Dropdowns strictly map over permanent `members` only
    assert.ok(settlementModalSrc.includes('{members.map((m) => ('));
    assert.ok(settlementModalSrc.includes('.filter((m) => m.id !== payerId)'));
    assert.ok(settlementModalSrc.includes('temporaryMembers?: { id: string; name: string }[]'));
    assert.ok(settlementModalSrc.includes('Temporary — settle outside the app'));
    assert.ok(settlementModalSrc.includes('payerIsTemp || receiverIsTemp'));

    // GroupsView & HomeView show outside-app note and omit in-app Settle button on temp debts
    assert.ok(groupsViewSrc.includes('Temporary — settle outside the app'));
    assert.ok(groupsViewSrc.includes('{!isTempDebt && ('));
    assert.ok(homeViewSrc.includes('Temporary — settle outside the app'));
    assert.ok(homeViewSrc.includes('{!isTempDebt && ('));
  });

  it('T13: Decision Q1 — Settled temporary participants hidden by default, shown when Settings toggle enabled', () => {
    const tempId = 'tmp_tx_q1_rohan';
    const expTx: Transaction = {
      id: 'tx_q1',
      spaceId: mockSpace.id,
      creatorId: 'u_himanshu',
      title: 'Lunch',
      type: 'expense',
      category: 'Food',
      amount: 40000,
      date: '2026-04-04',
      payerId: 'u_himanshu',
      splitType: 'equal',
      splits: [
        { memberId: 'u_himanshu', shareMinorUnits: 20000 },
        { memberId: tempId, shareMinorUnits: 20000, memberName: 'Rohan', isTemporary: true }
      ],
      temporaryParticipants: [{ id: tempId, name: 'Rohan', isTemporary: true }],
      createdAt: '2026-04-04T13:00:00Z'
    };
    const settleTx: Transaction = {
      id: 'set_q1',
      spaceId: mockSpace.id,
      creatorId: 'u_himanshu',
      title: 'Settlement: Rohan → Himanshu',
      type: 'settlement',
      category: 'Settlement',
      amount: 20000,
      date: '2026-04-04',
      payerId: tempId,
      paidToId: 'u_himanshu',
      payerNameSnapshot: 'Rohan',
      createdAt: '2026-04-04T14:00:00Z'
    };

    const balances = calculateGroupBalances(permanentMembers, [expTx, settleTx]);
    const rohanBal = balances.find((b) => b.memberId === tempId);
    assert.ok(rohanBal);
    assert.strictEqual(rohanBal.netBalanceMinorUnits, 0);

    // Default (Q1 toggle OFF = false): settled temp is hidden, permanent members stay visible
    const hiddenByDefault = filterVisibleMemberBalances(balances, false);
    assert.strictEqual(hiddenByDefault.some((b) => b.memberId === tempId), false);
    assert.strictEqual(hiddenByDefault.some((b) => b.memberId === 'u_himanshu'), true);

    // Q1 toggle ON = true: settled temp remains visible
    const shownWhenOptedIn = filterVisibleMemberBalances(balances, true);
    assert.strictEqual(shownWhenOptedIn.some((b) => b.memberId === tempId), true);

    // Settings UI switch exists in ProfileView & wired in App.tsx
    const profileSrc = readSource('src/components/views/ProfileView.tsx');
    const appSrc = readSource('src/App.tsx');
    assert.ok(profileSrc.includes('Keep settled one-time participants in balances'));
    assert.ok(appSrc.includes('splito_keep_settled_temp_participants'));
  });

  it('T14: Decision Q2 — Solo-member non-personal space shows Split Shares and protects unsettled temp dues on deletion', async () => {
    const txModalSrc = readSource('src/components/TransactionModal.tsx');
    assert.ok(txModalSrc.includes("type === 'expense' && space.mode !== 'personal' && ("));
    assert.strictEqual(
      txModalSrc.includes("type === 'expense' && space.mode !== 'personal' && members.length > 1"),
      false
    );

    const soloSpace: Space = {
      ...mockSpace,
      id: 'sp_solo_trip',
      mode: 'trip',
      memberIds: ['u_himanshu'],
      members: [permanentMembers[0]]
    };

    const tempId = buildTemporaryParticipantId('tx_solo_1', 'guest');
    const soloTx: Transaction = {
      id: 'tx_solo_1',
      spaceId: soloSpace.id,
      creatorId: 'u_himanshu',
      title: 'Tickets',
      type: 'expense',
      category: 'Travel',
      amount: 50000,
      date: '2026-04-05',
      payerId: 'u_himanshu',
      splitType: 'equal',
      splits: [
        { memberId: 'u_himanshu', shareMinorUnits: 25000 },
        { memberId: tempId, shareMinorUnits: 25000, memberName: 'Rohan', isTemporary: true }
      ],
      temporaryParticipants: [{ id: tempId, name: 'Rohan', isTemporary: true }],
      createdAt: '2026-04-05T10:00:00Z'
    };

    // Add a ₹500 startingBalance so raw cash balance (500 - 500) is ₹0;
    // deletion MUST STILL be blocked because temp participant Rohan still owes ₹250!
    const zeroCashSoloSpace: Space = {
      ...soloSpace,
      startingBalance: 50000
    };

    localStorageMock.clear();
    localStorageMock.setItem('hisaab_guest_spaces', JSON.stringify([zeroCashSoloSpace]));
    localStorageMock.setItem(`hisaab_local_tx_${zeroCashSoloSpace.id}`, JSON.stringify([soloTx]));

    const eligibility = await checkSpaceDeletionEligibility(zeroCashSoloSpace.id, 'u_himanshu');
    assert.strictEqual(eligibility.canDelete, false);
    assert.ok(eligibility.netBalancePaise > 0);
  });

  it('T15: Decision Q3 — Paid By dropdown strictly stays permanent space members only', () => {
    const txModalSrc = readSource('src/components/TransactionModal.tsx');
    // Verify Paid By select maps exclusively over `members`, NOT `allSplitParticipants`
    const paidByIdx = txModalSrc.indexOf("type === 'income' ? 'Received By' : 'Paid By'");
    assert.ok(paidByIdx > 0);
    const paidBySnippet = txModalSrc.slice(paidByIdx, paidByIdx + 600);
    assert.ok(paidBySnippet.includes('{members.map((m) => ('));
    assert.strictEqual(paidBySnippet.includes('allSplitParticipants'), false);
  });

  it('T16: Decision Q4 — Blocks removing temp with active manual settlement on edit & warns on expense reversal', () => {
    const tempId = 'tmp_tx_q4_rohan';
    const expenseTx: Transaction = {
      id: 'tx_q4',
      spaceId: mockSpace.id,
      creatorId: 'u_himanshu',
      title: 'Boat Ride',
      type: 'expense',
      category: 'Activities',
      amount: 40000,
      date: '2026-04-05',
      payerId: 'u_himanshu',
      splitType: 'equal',
      splits: [
        { memberId: 'u_himanshu', shareMinorUnits: 20000 },
        { memberId: tempId, shareMinorUnits: 20000, memberName: 'Rohan', isTemporary: true }
      ],
      temporaryParticipants: [{ id: tempId, name: 'Rohan', isTemporary: true }],
      createdAt: '2026-04-05T11:00:00Z'
    };

    const manualSettlement: Transaction = {
      id: 'set_q4_manual',
      spaceId: mockSpace.id,
      creatorId: 'u_himanshu',
      title: 'Settlement: Rohan → Himanshu',
      type: 'settlement',
      category: 'Settlement',
      amount: 10000,
      date: '2026-04-05',
      payerId: tempId,
      paidToId: 'u_himanshu',
      payerNameSnapshot: 'Rohan',
      createdAt: '2026-04-05T12:00:00Z'
    };

    const activeForTemp = findActiveManualSettlementsForTempParticipant(tempId, [expenseTx, manualSettlement]);
    assert.strictEqual(activeForTemp.length, 1);

    const activeForExpense = findActiveManualSettlementsForExpenseTemps(expenseTx, [expenseTx, manualSettlement]);
    assert.strictEqual(activeForExpense.length, 1);

    // Once manual settlement is reversed, block & warning clear cleanly
    const { originalUpdated, reversalTx } = createCascadeReversalPlan(
      manualSettlement,
      [expenseTx, manualSettlement],
      'u_himanshu'
    ).primary;
    const afterReverseList = [expenseTx, originalUpdated, reversalTx];
    assert.strictEqual(findActiveManualSettlementsForTempParticipant(tempId, afterReverseList).length, 0);
    assert.strictEqual(findActiveManualSettlementsForExpenseTemps(expenseTx, afterReverseList).length, 0);

    // Verify UI wiring in TransactionModal, TransactionsView, and ReversalConfirmModal
    const txModalSrc = readSource('src/components/TransactionModal.tsx');
    const txViewSrc = readSource('src/components/views/TransactionsView.tsx');
    const revModalSrc = readSource('src/components/ReversalConfirmModal.tsx');
    assert.ok(txModalSrc.includes('findActiveManualSettlementsForTempParticipant'));
    assert.ok(txModalSrc.includes('Reverse that settlement first'));
    assert.ok(txViewSrc.includes('findActiveManualSettlementsForExpenseTemps'));
    assert.ok(revModalSrc.includes('warningMessage'));
  });

  it('T17: Personal Item assigned to temporary participant is excluded from shared pool with exact math', () => {
    const expId = 'tx_pi_temp';
    const tempId = buildTemporaryParticipantId(expId, 'pi1');
    const tp: TemporaryParticipant = { id: tempId, name: 'Rohan', isTemporary: true };

    // Total ₹120: ₹40 personal dessert for Rohan; remaining ₹80 shared equally among 4 (₹20 each)
    // Rohan total = ₹60; Himanshu/Alex/Purvesh = ₹20 each
    const calc = calculateEnhancedExpenseSplits({
      totalMinorUnits: 12000,
      splitType: 'equal',
      payerId: 'u_himanshu',
      selectedMemberIds: ['u_himanshu', 'u_alex', 'u_purvesh', tempId],
      personalItems: [{ id: 'pi_1', memberId: tempId, label: 'Dessert', amountMinorUnits: 4000 }],
      temporaryParticipants: [tp],
      expenseId: expId
    });

    assert.strictEqual(calc.totalPersonalMinorUnits, 4000);
    assert.strictEqual(calc.sharedPoolMinorUnits, 8000);
    assert.strictEqual(calc.allocatedMinorUnits, 12000);

    const rohanSplit = calc.splits.find((s) => s.memberId === tempId)!;
    assert.strictEqual(rohanSplit.sharedMinorUnits, 2000);
    assert.strictEqual(rohanSplit.personalMinorUnits, 4000);
    assert.strictEqual(rohanSplit.shareMinorUnits, 6000);
    assert.strictEqual(rohanSplit.isTemporary, true);
    assert.strictEqual(rohanSplit.memberName, 'Rohan');

    const tx: Transaction = {
      id: expId,
      spaceId: mockSpace.id,
      creatorId: 'u_himanshu',
      title: 'Cafe',
      type: 'expense',
      category: 'Food',
      amount: 12000,
      date: '2026-04-05',
      payerId: 'u_himanshu',
      splitType: 'equal',
      splits: calc.splits,
      personalItems: calc.personalItems,
      temporaryParticipants: calc.temporaryParticipants,
      createdAt: '2026-04-05T15:00:00Z'
    };

    const balances = calculateGroupBalances(permanentMembers, [tx]);
    assert.strictEqual(balances.find((b) => b.memberId === tempId)?.netBalanceMinorUnits, -6000);
    assert.strictEqual(balances.find((b) => b.memberId === 'u_himanshu')?.netBalanceMinorUnits, 10000);
    assert.strictEqual(balances.reduce((acc, b) => acc + b.netBalanceMinorUnits, 0), 0);
  });

  it('T18: Advance Payment works alongside temp participant with zero double deduction and no temp Already Paid input', () => {
    const expId = 'tx_adv_temp';
    const tempId = buildTemporaryParticipantId(expId, 'adv1');
    const tp: TemporaryParticipant = { id: tempId, name: 'Rohan', isTemporary: true };

    // Total ₹120 across 4 (₹30 each); Purvesh already paid ₹10 -> Purvesh owes ₹20, Rohan owes ₹30
    const validation = validateEnhancedExpenseSplits({
      totalMinorUnits: 12000,
      splitType: 'equal',
      payerId: 'u_himanshu',
      selectedMemberIds: ['u_himanshu', 'u_alex', 'u_purvesh', tempId],
      advancePaidMinorUnitsMap: { u_purvesh: 1000 },
      temporaryParticipants: [tp],
      expenseId: expId
    });
    assert.strictEqual(validation.isValid, true);

    const expTx: Transaction = {
      id: expId,
      spaceId: mockSpace.id,
      creatorId: 'u_himanshu',
      title: 'Snacks & Tea',
      type: 'expense',
      category: 'Food',
      amount: 12000,
      date: '2026-04-06',
      payerId: 'u_himanshu',
      splitType: 'equal',
      splits: validation.result.splits,
      advancePayments: validation.result.advancePayments,
      temporaryParticipants: validation.result.temporaryParticipants,
      createdAt: '2026-04-06T10:00:00Z'
    };

    const plan = reconcileLinkedAdvanceTransactions(expTx, [], permanentMembers, 'u_himanshu');
    assert.strictEqual(plan.toCreate.length, 1);

    const balances = calculateGroupBalances(permanentMembers, [expTx, ...plan.toCreate]);
    assert.strictEqual(balances.find((b) => b.memberId === 'u_purvesh')?.netBalanceMinorUnits, -2000);
    assert.strictEqual(balances.find((b) => b.memberId === tempId)?.netBalanceMinorUnits, -3000);
    assert.strictEqual(balances.find((b) => b.memberId === 'u_alex')?.netBalanceMinorUnits, -3000);
    assert.strictEqual(balances.find((b) => b.memberId === 'u_himanshu')?.netBalanceMinorUnits, 8000);
    assert.strictEqual(balances.reduce((acc, b) => acc + b.netBalanceMinorUnits, 0), 0);

    // TransactionModal hides Already Paid input for temporary participants
    const txModalSrc = readSource('src/components/TransactionModal.tsx');
    assert.ok(txModalSrc.includes('{!isBillPayer && !m.isTemporary && ('));
  });

  it('T19: Edit lifecycle — adding, renaming, and removing temporary participant recalculates balances cleanly', () => {
    const expId = 'tx_edit_life';
    const tempId = buildTemporaryParticipantId(expId, 'ed1');

    // Step 1: Initial expense with Rohan
    const calc1 = calculateEnhancedExpenseSplits({
      totalMinorUnits: 60000,
      splitType: 'equal',
      payerId: 'u_himanshu',
      selectedMemberIds: ['u_himanshu', 'u_alex', tempId],
      temporaryParticipants: [{ id: tempId, name: 'Rohan', isTemporary: true }],
      expenseId: expId
    });
    const txV1: Transaction = {
      id: expId,
      spaceId: mockSpace.id,
      creatorId: 'u_himanshu',
      title: 'Dinner',
      type: 'expense',
      category: 'Food',
      amount: 60000,
      date: '2026-04-06',
      payerId: 'u_himanshu',
      splitType: 'equal',
      splits: calc1.splits,
      temporaryParticipants: calc1.temporaryParticipants,
      createdAt: '2026-04-06T12:00:00Z'
    };

    // Step 2: Edit to remove Rohan -> split among 2 permanent members (₹300 each)
    const calc2 = calculateEnhancedExpenseSplits({
      totalMinorUnits: 60000,
      splitType: 'equal',
      payerId: 'u_himanshu',
      selectedMemberIds: ['u_himanshu', 'u_alex'],
      temporaryParticipants: [],
      expenseId: expId
    });
    const txV2: Transaction = {
      ...txV1,
      splits: calc2.splits,
      temporaryParticipants: []
    };

    const balancesAfterRemoval = calculateGroupBalances(permanentMembers, [txV2]);
    assert.strictEqual(balancesAfterRemoval.some((b) => b.memberId === tempId), false);
    assert.strictEqual(balancesAfterRemoval.find((b) => b.memberId === 'u_alex')?.netBalanceMinorUnits, -30000);
    assert.strictEqual(balancesAfterRemoval.find((b) => b.memberId === 'u_himanshu')?.netBalanceMinorUnits, 30000);
    assert.strictEqual(balancesAfterRemoval.reduce((acc, b) => acc + b.netBalanceMinorUnits, 0), 0);
  });

  it('T20: Reversing an expense with a temporary participant zeroes all balances and removes temp debt', () => {
    const expId = 'tx_rev_temp';
    const tempId = buildTemporaryParticipantId(expId, 'rv1');
    const expTx: Transaction = {
      id: expId,
      spaceId: mockSpace.id,
      creatorId: 'u_himanshu',
      title: 'Kayaking',
      type: 'expense',
      category: 'Activities',
      amount: 40000,
      date: '2026-04-06',
      payerId: 'u_himanshu',
      splitType: 'equal',
      splits: [
        { memberId: 'u_himanshu', shareMinorUnits: 20000 },
        { memberId: tempId, shareMinorUnits: 20000, memberName: 'Rohan', isTemporary: true }
      ],
      temporaryParticipants: [{ id: tempId, name: 'Rohan', isTemporary: true }],
      createdAt: '2026-04-06T14:00:00Z'
    };

    const { primary } = createCascadeReversalPlan(expTx, [expTx], 'u_himanshu', 'Cancelled');
    const ledger = [primary.originalUpdated, primary.reversalTx];
    const balances = calculateGroupBalances(permanentMembers, ledger);
    const settlements = calculateDebtSettlements(balances);

    assert.strictEqual(settlements.length, 0);
    assert.ok(balances.every((b) => b.netBalanceMinorUnits === 0));
  });

  it('T21: Historical backward compatibility — legacy transactions without temp fields calculate identically', () => {
    const legacyTx: Transaction = {
      id: 'tx_legacy_01',
      spaceId: mockSpace.id,
      creatorId: 'u_himanshu',
      title: 'Old Electricity Bill',
      type: 'expense',
      category: 'Utilities',
      amount: 90000,
      date: '2026-01-15',
      payerId: 'u_himanshu',
      splitType: 'equal',
      splits: [
        { memberId: 'u_himanshu', shareMinorUnits: 30000 },
        { memberId: 'u_alex', shareMinorUnits: 30000 },
        { memberId: 'u_purvesh', shareMinorUnits: 30000 }
      ],
      createdAt: '2026-01-15T09:00:00Z'
    };

    const normalized = normalizeTransactionPayload(legacyTx);
    assert.strictEqual(normalized.temporaryParticipants, undefined);
    assert.strictEqual(hasUndefinedDeep(normalized), false);

    const balances = calculateGroupBalances(permanentMembers, [legacyTx]);
    assert.strictEqual(balances.find((b) => b.memberId === 'u_himanshu')?.netBalanceMinorUnits, 60000);
    assert.strictEqual(balances.find((b) => b.memberId === 'u_alex')?.netBalanceMinorUnits, -30000);
    assert.strictEqual(balances.find((b) => b.memberId === 'u_purvesh')?.netBalanceMinorUnits, -30000);
  });

  it('T22: Offline / Firestore serialization produces zero undefined values anywhere in payload', () => {
    const expId = 'tx_offline_01';
    const tempId = buildTemporaryParticipantId(expId, 'off1');
    const calc = calculateEnhancedExpenseSplits({
      totalMinorUnits: 80000,
      splitType: 'equal',
      payerId: 'u_himanshu',
      selectedMemberIds: ['u_himanshu', tempId],
      temporaryParticipants: [{ id: tempId, name: 'Meera', isTemporary: true }],
      expenseId: expId
    });

    const payload = normalizeTransactionPayload({
      id: expId,
      spaceId: mockSpace.id,
      creatorId: 'u_himanshu',
      title: 'Offline Ferry',
      type: 'expense',
      category: 'Transport',
      amount: 80000,
      date: '2026-04-07',
      payerId: 'u_himanshu',
      splitType: 'equal',
      splits: calc.splits,
      temporaryParticipants: calc.temporaryParticipants,
      createdAt: '2026-04-07T08:00:00Z'
    });

    assert.strictEqual(hasUndefinedDeep(payload), false);
    assert.strictEqual(payload.temporaryParticipants.length, 1);
    assert.strictEqual(payload.temporaryParticipants[0].isTemporary, true);
  });

  it('T23: Multi-expense isolation — same temporary name on two expenses gets distinct expense-scoped IDs', () => {
    const id1 = buildTemporaryParticipantId('tx_e1', 'a');
    const id2 = buildTemporaryParticipantId('tx_e2', 'a');
    assert.notStrictEqual(id1, id2);

    const tx1: Transaction = {
      id: 'tx_e1',
      spaceId: mockSpace.id,
      creatorId: 'u_himanshu',
      title: 'Lunch 1',
      type: 'expense',
      category: 'Food',
      amount: 20000,
      date: '2026-04-07',
      payerId: 'u_himanshu',
      splitType: 'equal',
      splits: [
        { memberId: 'u_himanshu', shareMinorUnits: 10000 },
        { memberId: id1, shareMinorUnits: 10000, memberName: 'Rohan', isTemporary: true }
      ],
      temporaryParticipants: [{ id: id1, name: 'Rohan', isTemporary: true }],
      createdAt: '2026-04-07T12:00:00Z'
    };

    const tx2: Transaction = {
      id: 'tx_e2',
      spaceId: mockSpace.id,
      creatorId: 'u_himanshu',
      title: 'Lunch 2',
      type: 'expense',
      category: 'Food',
      amount: 40000,
      date: '2026-04-07',
      payerId: 'u_alex',
      splitType: 'equal',
      splits: [
        { memberId: 'u_alex', shareMinorUnits: 20000 },
        { memberId: id2, shareMinorUnits: 20000, memberName: 'Rohan', isTemporary: true }
      ],
      temporaryParticipants: [{ id: id2, name: 'Rohan', isTemporary: true }],
      createdAt: '2026-04-07T18:00:00Z'
    };

    const balances = calculateGroupBalances(permanentMembers, [tx1, tx2]);
    const b1 = balances.find((b) => b.memberId === id1)!;
    const b2 = balances.find((b) => b.memberId === id2)!;
    assert.ok(b1 && b2);
    assert.strictEqual(b1.netBalanceMinorUnits, -10000);
    assert.strictEqual(b2.netBalanceMinorUnits, -20000);
    assert.strictEqual(b1.linkedExpenseId, 'tx_e1');
    assert.strictEqual(b2.linkedExpenseId, 'tx_e2');
    assert.strictEqual(balances.reduce((acc, b) => acc + b.netBalanceMinorUnits, 0), 0);
  });

  it('T24: PDF and CSV exports handle temporary participants cleanly with zero-sum audit and resolved names', async () => {
    const tempId = buildTemporaryParticipantId('tx_exp_pdf', 'r1');
    const tx: Transaction = {
      id: 'tx_exp_pdf',
      spaceId: mockSpace.id,
      creatorId: 'u_himanshu',
      title: 'Sunset Cruise',
      type: 'expense',
      category: 'Activities',
      amount: 60000,
      date: '2026-04-08',
      payerId: 'u_himanshu',
      splitType: 'equal',
      splits: [
        { memberId: 'u_himanshu', shareMinorUnits: 30000 },
        { memberId: tempId, shareMinorUnits: 30000, memberName: 'Rohan', isTemporary: true }
      ],
      temporaryParticipants: [{ id: tempId, name: 'Rohan', isTemporary: true }],
      createdAt: '2026-04-08T17:00:00Z'
    };

    const balances = calculateGroupBalances(permanentMembers, [tx]);
    const breakdown: ActualBalanceBreakdown = {
      startingBalance: 0,
      receivedIncome: 0,
      paidExpenses: 60000,
      incomingTransfers: 0,
      outgoingTransfers: 0,
      actualBalance: -60000
    };

    const pdfDoc = buildPdfDocument(mockSpace, [tx], balances, breakdown);
    assert.ok(pdfDoc);
    assert.ok(pdfDoc.output('datauristring').startsWith('data:application/pdf;'));

    const csvRes = await exportCsvStatement(mockSpace, [tx]);
    assert.strictEqual(csvRes.success, true);
    assert.ok(csvRes.filename?.endsWith('.csv'));
  });
});
