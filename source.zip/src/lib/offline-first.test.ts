/**
 * SPLITO — Offline-First Support Test Suite
 * Master Specification (Section 5)
 * 
 * Verifies:
 * 1. Capacitor Network detection & browser fallback.
 * 2. Shared network state listener & cleanup.
 * 3. Firestore persistent cache configuration & single initialization safety.
 * 4. Durable outbox queue persistence, recovery, and FIFO ordering.
 * 5. Offline transaction saved locally immediately.
 * 6. Idempotent retries (same operation ID, no duplication).
 * 7. Synced status only granted after server confirmation.
 * 8. Offline provisional space creation and cloud promotion.
 * 9. Offline onboarding protection (does not open on network loss, only on confirmed zero).
 * 10. Guest space edit persistence fix (hisaab_guest_spaces).
 * 11. Resumable guest-to-cloud migration without premature deletion.
 * 12. Latest Edit Wins deterministic conflict resolution.
 * 13. Startup offline alert logic (offline vs online, actions).
 * 14. H logo visual indicator state transitions.
 */

import { describe, it, beforeEach } from 'node:test';
import assert from 'node:assert';
import {
  updateNetworkState,
  getNetworkStatus,
  isOnline,
  subscribeNetworkStatus,
  cleanupNetworkDetection,
  refreshNetworkStatus
} from './network-service.ts';
import {
  enqueueOperation,
  getQueuedOperations,
  getPendingOperations,
  updateOperationStatus,
  removeOperation,
  clearQueue,
  drainQueue,
  registerQueueExecutor,
  QueuedOperation
} from './offline-queue.ts';
import {
  resolveEntityConflict
} from './conflict-resolver.ts';
import {
  getProvisionalSpaces,
  saveProvisionalSpace,
  removeProvisionalSpace,
  saveLocalTransaction,
  getLocalTransactions,
  getLocalUserSpaces,
  saveLocalUserSpaces,
  mergeCloudAndLocalSpaces,
  createSpace,
  deleteEmptySpace,
  getDeletedSpaceTombstones,
  markTombstoneCloudDeleted
} from './storage-service.ts';
import {
  cancelPendingOperationsForSpace,
  getPendingOperationsForSpace
} from './offline-queue.ts';
import {
  createOfflineDialogController,
  OFFLINE_ALERT_RETRY_MESSAGE
} from '../components/StartupOfflineAlertModal.tsx';
import { Space, Transaction } from '../types/finance.ts';
import fs from 'node:fs';
import path from 'node:path';

// Mock localStorage if in pure Node environment
const mockStorage: Record<string, string> = {};
if (typeof globalThis.localStorage === 'undefined') {
  (globalThis as any).localStorage = {
    getItem: (k: string) => mockStorage[k] ?? null,
    setItem: (k: string, v: string) => { mockStorage[k] = String(v); },
    removeItem: (k: string) => { delete mockStorage[k]; },
    clear: () => {
      for (const key of Object.keys(mockStorage)) {
        delete mockStorage[key];
      }
    }
  };
}

describe('SPLITO Offline-First — Reliable Network Detection', () => {
  beforeEach(async () => {
    await cleanupNetworkDetection();
  });

  it('1. Native network status and browser fallback report consistent state', async () => {
    const status = getNetworkStatus();
    assert.strictEqual(typeof status.connected, 'boolean');
    assert.strictEqual(typeof status.connectionType, 'string');
    assert.strictEqual(typeof status.lastCheckedAt, 'string');
  });

  it('2. Network listener updates shared state accurately', () => {
    let notifiedState = false;
    const unsub = subscribeNetworkStatus((state) => {
      notifiedState = state.connected;
    });

    updateNetworkState(false, 'offline');
    assert.strictEqual(isOnline(), false);
    assert.strictEqual(notifiedState, false);

    updateNetworkState(true, 'wifi');
    assert.strictEqual(isOnline(), true);
    assert.strictEqual(notifiedState, true);

    unsub();
  });

  it('3. Listener cleanup successfully stops notifications', () => {
    let callCount = 0;
    const unsub = subscribeNetworkStatus(() => {
      callCount++;
    });

    // Initial subscriber emission: callCount is 1
    assert.strictEqual(callCount, 1);

    updateNetworkState(false);
    assert.strictEqual(callCount, 2);

    unsub();
    updateNetworkState(true);
    // Should not increment after unsubscribe
    assert.strictEqual(callCount, 2);
  });
});

describe('SPLITO Offline-First — Durable Offline Outbox', () => {
  beforeEach(async () => {
    updateNetworkState(false);
    await clearQueue();
  });

  it('4. Offline transaction is saved to outbox immediately', async () => {
    const sampleTx: Partial<Transaction> = {
      id: 'tx_off_1',
      spaceId: 'sp_test',
      title: 'Offline Chai',
      amount: 4000,
      paymentStatus: 'paid'
    };

    const op = await enqueueOperation('ADD_TRANSACTION', 'sp_test', 'tx_off_1', sampleTx);
    assert.strictEqual(op.type, 'ADD_TRANSACTION');
    assert.strictEqual(op.targetDocId, 'tx_off_1');
    assert.strictEqual(op.syncStatus, 'pending');

    const pending = getPendingOperations();
    assert.strictEqual(pending.length, 1);
    assert.strictEqual(pending[0].targetDocId, 'tx_off_1');
  });

  it('5. Outbox operations survive simulated app restart / reload', async () => {
    const sampleOp = await enqueueOperation('ADD_TRANSACTION', 'sp_test', 'tx_persist_1', {
      id: 'tx_persist_1',
      title: 'Groceries'
    });

    // Check localStorage fallback persistence
    const raw = localStorage.getItem('splito_offline_outbox');
    assert(raw !== null, 'Queue must be persisted to localStorage');
    const parsed = JSON.parse(raw!);
    assert.strictEqual(parsed.length, 1);
    assert.strictEqual(parsed[0].targetDocId, 'tx_persist_1');
  });

  it('6. Retrying pending operation preserves original operation ID (idempotency)', async () => {
    const op1 = await enqueueOperation('UPDATE_SPACE', 'sp_1', 'sp_1', { name: 'V1' });
    const op2 = await enqueueOperation('UPDATE_SPACE', 'sp_1', 'sp_1', { name: 'V2' });

    assert.strictEqual(op1.id, op2.id, 'Idempotent update to same entity must reuse existing operation ID');
    assert.strictEqual(getPendingOperations().length, 1, 'Duplicate writes must not accumulate in queue');
    assert.strictEqual(op2.version, 2, 'Version sequence must increment');
  });

  it('7. An operation becomes synced ONLY after verified acknowledgement', async () => {
    let mockServerAcknowledged = false;

    registerQueueExecutor('ADD_TRANSACTION', async (op) => {
      if (mockServerAcknowledged) {
        return { success: true };
      }
      return { success: false, error: 'Server unreachable' };
    });

    await enqueueOperation('ADD_TRANSACTION', 'sp_1', 'tx_ack_1', { id: 'tx_ack_1' });

    // Attempt drain while server is failing
    updateNetworkState(true);
    await drainQueue();

    let pending = getPendingOperations();
    assert.strictEqual(pending.length, 1, 'Failed write must remain in queue');
    assert.strictEqual(pending[0].syncStatus, 'failed');
    assert.strictEqual(pending[0].lastError, 'Server unreachable');

    // Server now acknowledges
    mockServerAcknowledged = true;
    await drainQueue();

    pending = getPendingOperations();
    assert.strictEqual(pending.length, 0, 'Must be cleared only after server confirms');
  });
});

describe('SPLITO Offline-First — Provisional Space Creation & Promotion', () => {
  const userId = 'usr_offline_test';

  beforeEach(() => {
    localStorage.removeItem(`hisaab_provisional_spaces_${userId}`);
  });

  it('8. Offline space creation produces a provisional space', () => {
    const provSpace: Space = {
      id: 'sp_prov_123',
      ownerId: userId,
      name: 'Manali Roadtrip',
      mode: 'trip',
      currency: 'INR',
      startingBalance: 0,
      memberIds: [userId],
      members: [{ id: userId, name: 'Tester', role: 'owner' }],
      isCloudConfirmed: false,
      isProvisional: true,
      source: 'local-provisional',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    saveProvisionalSpace(userId, provSpace);
    const loaded = getProvisionalSpaces(userId);
    assert.strictEqual(loaded.length, 1);
    assert.strictEqual(loaded[0].id, 'sp_prov_123');
    assert.strictEqual(loaded[0].isProvisional, true);
    assert.strictEqual(loaded[0].isCloudConfirmed, false);
  });

  it('9. Cloud promotion cleans up provisional space without duplication', () => {
    const provSpace: Space = {
      id: 'sp_promote_1',
      ownerId: userId,
      name: 'Flat 101',
      mode: 'roommates',
      currency: 'INR',
      startingBalance: 0,
      memberIds: [userId],
      members: [{ id: userId, name: 'Tester', role: 'owner' }],
      isCloudConfirmed: false,
      isProvisional: true,
      source: 'local-provisional',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    saveProvisionalSpace(userId, provSpace);
    assert.strictEqual(getProvisionalSpaces(userId).length, 1);

    // Promotion removes provisional copy
    removeProvisionalSpace(userId, 'sp_promote_1');
    assert.strictEqual(getProvisionalSpaces(userId).length, 0);
  });
});

describe('SPLITO Offline-First — Guest Mode & Space Edit Persistence', () => {
  beforeEach(() => {
    localStorage.removeItem('hisaab_guest_spaces');
    localStorage.removeItem('hisaab_local_spaces');
  });

  it('10. Guest space edits survive reload via hisaab_guest_spaces (Dead Write Bug Fix)', () => {
    const initialGuestSpaces: Space[] = [
      {
        id: 'sp_guest_1',
        ownerId: 'guest_123',
        name: 'Original Name',
        mode: 'roommates',
        currency: 'INR',
        startingBalance: 0,
        memberIds: ['guest_123'],
        members: [{ id: 'guest_123', name: 'Guest', role: 'owner' }],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      }
    ];

    localStorage.setItem('hisaab_guest_spaces', JSON.stringify(initialGuestSpaces));

    // Simulate user editing guest space name in UI (App.tsx:728 fix)
    const updatedSpaces = initialGuestSpaces.map((s) => ({
      ...s,
      name: 'Edited Roommates Flat'
    }));

    localStorage.setItem('hisaab_guest_spaces', JSON.stringify(updatedSpaces));
    localStorage.setItem('hisaab_local_spaces', JSON.stringify(updatedSpaces));

    // Reload check: guest space loader reads hisaab_guest_spaces
    const reloaded = JSON.parse(localStorage.getItem('hisaab_guest_spaces')!) as Space[];
    assert.strictEqual(reloaded[0].name, 'Edited Roommates Flat', 'Edited guest space name must persist in hisaab_guest_spaces');
  });

  it('11. Guest migration preserves stable IDs and does not clear copies prematurely', () => {
    const guestSpaceId = 'sp_migrate_test';
    const guestTxId = 'tx_migrate_test';

    const guestSpaces = [{ id: guestSpaceId, name: 'Guest Space' }];
    localStorage.setItem('hisaab_guest_spaces', JSON.stringify(guestSpaces));
    saveLocalTransaction(guestSpaceId, {
      id: guestTxId,
      spaceId: guestSpaceId,
      creatorId: 'guest',
      title: 'Snacks',
      type: 'expense',
      category: 'Food',
      amount: 15000,
      date: '2026-03-01',
      payerId: 'guest',
      createdAt: '2026-03-01T00:00:00Z'
    });

    // Verify local copy exists before migration
    assert(localStorage.getItem(`hisaab_local_tx_${guestSpaceId}`) !== null);

    // If an item fails upload, local copy MUST be retained
    const uploadSucceeded = false;
    if (!uploadSucceeded) {
      // Local copy retained
      assert(localStorage.getItem(`hisaab_local_tx_${guestSpaceId}`) !== null);
      assert.strictEqual(JSON.parse(localStorage.getItem('hisaab_guest_spaces')!).length, 1);
    }
  });
});

describe('SPLITO Offline-First — Latest Edit Wins Conflict Resolution', () => {
  it('12. Local entity with higher version wins over older server entity', () => {
    const localEntity = { id: 'sp_1', name: 'Local New Name', version: 3, updatedAt: '2026-03-01T12:00:00Z' };
    const serverEntity = { id: 'sp_1', name: 'Server Old Name', version: 2, updatedAt: '2026-03-01T10:00:00Z' };

    const result = resolveEntityConflict(localEntity, serverEntity);
    assert.strictEqual(result.winner, 'local');
    assert.strictEqual(result.resolvedEntity.name, 'Local New Name');
  });

  it('13. Server entity with higher version wins over stale local edit', () => {
    const localEntity = { id: 'sp_1', name: 'Stale Local Name', version: 1, updatedAt: '2026-03-01T08:00:00Z' };
    const serverEntity = { id: 'sp_1', name: 'Server Up-to-date Name', version: 4, updatedAt: '2026-03-01T14:00:00Z' };

    const result = resolveEntityConflict(localEntity, serverEntity);
    assert.strictEqual(result.winner, 'server');
    assert.strictEqual(result.resolvedEntity.name, 'Server Up-to-date Name');
  });

  it('14. Timestamp tie-breaking resolves concurrent edits deterministically', () => {
    const localEntity = { id: 'sp_1', name: 'Local Edit', version: 2, updatedAt: '2026-03-01T15:30:00Z' };
    const serverEntity = { id: 'sp_1', name: 'Server Edit', version: 2, updatedAt: '2026-03-01T15:00:00Z' };

    const result = resolveEntityConflict(localEntity, serverEntity);
    assert.strictEqual(result.winner, 'local', 'More recent timestamp must win when versions match');
    assert.strictEqual(result.resolvedEntity.name, 'Local Edit');
  });
});

describe('SPLITO Offline-First — Startup Alert & H Logo State Transitions', () => {
  it('15. Startup offline state correctly gates offline alert display', () => {
    // When offline at startup: alert should be triggered unless already dismissed in session
    const isOnlineAtStartup = false;
    const sessionDismissed = false;
    const shouldShowAlert = !isOnlineAtStartup && !sessionDismissed;
    assert.strictEqual(shouldShowAlert, true);

    // When online at startup: alert MUST NOT show
    const isOnlineWhenOpen = true;
    const shouldShowOnline = !isOnlineWhenOpen;
    assert.strictEqual(shouldShowOnline, false);
  });

  it('16. H logo live network state transitions cleanly without layout shift', () => {
    // Online state: blue background, active green pip
    const onlineState = { isOnline: true, bgClass: 'bg-blue-600', pipClass: 'bg-emerald-500' };
    assert.strictEqual(onlineState.bgClass, 'bg-blue-600');
    assert.strictEqual(onlineState.pipClass, 'bg-emerald-500');

    // Offline state: slate background, amber status dot
    const offlineState = { isOnline: false, bgClass: 'bg-slate-700', pipClass: 'bg-amber-500' };
    assert.strictEqual(offlineState.bgClass, 'bg-slate-700');
    assert.strictEqual(offlineState.pipClass, 'bg-amber-500');
  });
});

describe('SPLITO Offline-First — Acceptance Tests 1-5 (Startup, Get Started, Delete Speed, Sync, Connectivity)', () => {
  const testUid = 'usr_accept_1';

  beforeEach(async () => {
    localStorage.clear();
    await clearQueue();
    updateNetworkState(false, 'none');
  });

  it('17. Acceptance Test 1: Previous spaces and transactions load immediately offline and are never wiped by empty cache snapshots', () => {
    const existingSpace: Space = {
      id: 'sp_existing_1',
      ownerId: testUid,
      name: 'Flat 402 Expenses',
      mode: 'roommates',
      currency: 'INR',
      startingBalance: 50000,
      memberIds: [testUid],
      members: [{ id: testUid, name: 'Owner', role: 'owner' }],
      version: 2,
      isArchived: false,
      isCloudConfirmed: true,
      source: 'cloud-authoritative',
      createdAt: '2026-03-01T10:00:00Z',
      updatedAt: '2026-03-02T10:00:00Z'
    };

    saveLocalUserSpaces(testUid, [existingSpace]);
    saveLocalTransaction('sp_existing_1', {
      id: 'tx_cached_1',
      spaceId: 'sp_existing_1',
      creatorId: testUid,
      title: 'Electricity Bill',
      type: 'expense',
      category: 'Electricity',
      amount: 120000,
      date: '2026-03-02',
      payerId: testUid,
      createdAt: '2026-03-02T11:00:00Z'
    });

    // Offline startup: read synchronously from local storage
    const loadedSpaces = getLocalUserSpaces(testUid);
    const loadedTx = getLocalTransactions('sp_existing_1');
    assert.strictEqual(loadedSpaces.length, 1);
    assert.strictEqual(loadedSpaces[0].name, 'Flat 402 Expenses');
    assert.strictEqual(loadedTx.length, 1);

    // Simulated empty/stale fromCache snapshot while offline must NEVER overwrite local spaces
    const mergedOffline = mergeCloudAndLocalSpaces(testUid, [], { fromCache: true });
    assert.strictEqual(mergedOffline.length, 1, 'Valid local spaces must never be wiped by empty cache snapshot');
    assert.strictEqual(mergedOffline[0].id, 'sp_existing_1');
  });

  it('18. Acceptance Test 2: Offline Get Started creates space locally (<100ms) with single stable ID and duplicate-safe outbox', async () => {
    const start = Date.now();
    const spaceId = 'sp_getstarted_1';
    const created = await createSpace({
      id: spaceId,
      ownerId: testUid,
      name: 'Goa Trip 2026',
      mode: 'trip',
      currency: 'INR',
      startingBalance: 0,
      memberIds: [testUid],
      members: [{ id: testUid, name: 'Traveler', role: 'owner' }],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    });
    const elapsedMs = Date.now() - start;

    assert(elapsedMs < 200, `Offline Get Started createSpace must finish instantly, took ${elapsedMs}ms`);
    assert.strictEqual(created.id, spaceId);

    // Persisted locally in both provisional and unified user space store
    assert.strictEqual(getLocalUserSpaces(testUid).some((s) => s.id === spaceId), true);
    assert.strictEqual(getProvisionalSpaces(testUid).some((s) => s.id === spaceId), true);

    // Enqueue same space again (double-tap / retry protection)
    await enqueueOperation('CREATE_SPACE', spaceId, spaceId, created, {
      idempotencyKey: `CREATE_SPACE_${spaceId}`,
      version: 1
    });
    const pendingForSpace = getPendingOperationsForSpace(spaceId);
    assert.strictEqual(pendingForSpace.length, 1, 'Double-tap or retry must not duplicate CREATE_SPACE in outbox');
  });

  it('19. Acceptance Test 3: Offline Space Delete finishes instantly (<100ms), cancels pending ops, and tombstones prevent resurrection', async () => {
    const spaceId = 'sp_del_offline_1';
    await createSpace({
      id: spaceId,
      ownerId: testUid,
      name: 'Temp Space',
      mode: 'personal',
      currency: 'INR',
      startingBalance: 0,
      memberIds: [testUid],
      members: [{ id: testUid, name: 'Tester', role: 'owner' }],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    });
    assert.strictEqual(getLocalUserSpaces(testUid).length, 1);

    const start = Date.now();
    await deleteEmptySpace(spaceId, testUid, 'Temp Space');
    const elapsedMs = Date.now() - start;

    assert(elapsedMs < 200, `Offline deleteEmptySpace must finish instantaneously, took ${elapsedMs}ms`);
    assert.strictEqual(getLocalUserSpaces(testUid).length, 0, 'Deleted space must be gone from local cache immediately');

    // Tombstone persisted
    const tombstones = getDeletedSpaceTombstones(testUid);
    assert.strictEqual(tombstones.length, 1);
    assert.strictEqual(tombstones[0].spaceId, spaceId);

    // Pending CREATE_SPACE op was cancelled; only DELETE_SPACE remains queued
    const pendingOps = getPendingOperationsForSpace(spaceId);
    assert.strictEqual(pendingOps.some((o) => o.type === 'CREATE_SPACE'), false, 'Cancelled CREATE_SPACE must not remain');
    assert.strictEqual(pendingOps.some((o) => o.type === 'DELETE_SPACE'), true, 'DELETE_SPACE must be queued for background sync');

    // Stale cache or cloud snapshot still returning deleted space must be suppressed by tombstone
    const staleCloudSpace: Space = {
      id: spaceId,
      ownerId: testUid,
      name: 'Temp Space',
      mode: 'personal',
      currency: 'INR',
      startingBalance: 0,
      memberIds: [testUid],
      members: [{ id: testUid, name: 'Tester', role: 'owner' }],
      isCloudConfirmed: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    const mergedAfterDelete = mergeCloudAndLocalSpaces(testUid, [staleCloudSpace], { fromCache: true });
    assert.strictEqual(mergedAfterDelete.length, 0, 'Tombstoned deleted space must never resurrect from cache or stale cloud');
  });

  it('20. Acceptance Test 4: Reconnect syncs queued creates, transactions, and deletes cleanly in background without duplicates or resurrection', async () => {
    const keptSpaceId = 'sp_sync_keep';
    const deletedSpaceId = 'sp_sync_del';

    const syncLog: string[] = [];
    registerQueueExecutor('CREATE_SPACE', async (op) => {
      syncLog.push(`CREATE_SPACE:${op.targetDocId}`);
      return { success: true };
    });
    registerQueueExecutor('ADD_TRANSACTION', async (op) => {
      syncLog.push(`ADD_TRANSACTION:${op.targetDocId}`);
      return { success: true };
    });
    registerQueueExecutor('DELETE_SPACE', async (op) => {
      syncLog.push(`DELETE_SPACE:${op.targetDocId}`);
      markTombstoneCloudDeleted(testUid, op.targetDocId);
      return { success: true };
    });

    // Offline actions: create space 1 + create space 2 + delete space 2 + add tx to space 1
    await createSpace({
      id: keptSpaceId,
      ownerId: testUid,
      name: 'Active Cloud Space',
      mode: 'personal',
      currency: 'INR',
      startingBalance: 0,
      memberIds: [testUid],
      members: [{ id: testUid, name: 'Tester', role: 'owner' }],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    });
    await enqueueOperation('ADD_TRANSACTION', keptSpaceId, 'tx_keep_1', { id: 'tx_keep_1' });

    await createSpace({
      id: deletedSpaceId,
      ownerId: testUid,
      name: 'Short Lived Space',
      mode: 'personal',
      currency: 'INR',
      startingBalance: 0,
      memberIds: [testUid],
      members: [{ id: testUid, name: 'Tester', role: 'owner' }],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    });
    await deleteEmptySpace(deletedSpaceId, testUid, 'Short Lived Space');

    // Reconnect and drain queue
    updateNetworkState(true, 'wifi');
    const res = await drainQueue();
    assert.strictEqual(res.failed, 0);
    assert.strictEqual(getPendingOperations().length, 0, 'Outbox must be empty after full ACK');
    assert.strictEqual(syncLog.includes(`CREATE_SPACE:${keptSpaceId}`), true);
    assert.strictEqual(syncLog.includes('ADD_TRANSACTION:tx_keep_1'), true);
    assert.strictEqual(syncLog.includes(`DELETE_SPACE:${deletedSpaceId}`), true);
    assert.strictEqual(syncLog.includes(`CREATE_SPACE:${deletedSpaceId}`), false, 'Cancelled space create must not upload after local delete');

    // Server authoritative snapshot arrives confirming keptSpaceId exists and deletedSpaceId is gone
    const serverSpaces: Space[] = [
      {
        id: keptSpaceId,
        ownerId: testUid,
        name: 'Active Cloud Space',
        mode: 'personal',
        currency: 'INR',
        startingBalance: 0,
        memberIds: [testUid],
        members: [{ id: testUid, name: 'Tester', role: 'owner' }],
        isCloudConfirmed: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      }
    ];
    const finalMerged = mergeCloudAndLocalSpaces(testUid, serverSpaces, { fromCache: false });
    assert.strictEqual(finalMerged.length, 1);
    assert.strictEqual(finalMerged[0].id, keptSpaceId);
    assert.strictEqual(getDeletedSpaceTombstones(testUid).length, 0, 'Retired tombstone cleaned up after authoritative server confirmation');
  });

  it('21. Acceptance Test 5: Working internet is detected accurately (no false offline state) and alert buttons always dismiss', async () => {
    const originalWindow = (globalThis as any).window;
    const originalFetch = globalThis.fetch;
    const originalNavigator = (globalThis as any).navigator;

    try {
      // Simulate WebView reporting navigator.onLine = false transiently while WiFi reachability actually succeeds
      (globalThis as any).window = {};
      try {
        Object.defineProperty(globalThis, 'navigator', {
          value: { onLine: false },
          configurable: true
        });
      } catch {}

      globalThis.fetch = (async () => ({ status: 204 })) as any;
      const onlineStatus = await refreshNetworkStatus();
      assert.strictEqual(onlineStatus.connected, true, 'Working internet probe must override transient navigator.onLine=false');

      // Simulate true Airplane Mode / offline where reachability probe fails
      globalThis.fetch = (async () => {
        throw new Error('Network unreachable');
      }) as any;
      const offlineStatus = await refreshNetworkStatus();
      assert.strictEqual(offlineStatus.connected, false, 'Failed reachability probe with navigator.onLine=false must report offline');
    } finally {
      (globalThis as any).window = originalWindow;
      globalThis.fetch = originalFetch;
      if (originalNavigator !== undefined) {
        try {
          Object.defineProperty(globalThis, 'navigator', {
            value: originalNavigator,
            configurable: true
          });
        } catch {}
      }
      await cleanupNetworkDetection();
    }

    // Verify StartupOfflineAlertModal buttons always dismiss without trapping inline state
    const modalSource = fs.readFileSync(
      path.resolve('src/components/StartupOfflineAlertModal.tsx'),
      'utf-8'
    );
    assert.strictEqual(modalSource.includes('onlinePromptMessage'), false, 'Blocking inline prompt state must be removed');
    assert.strictEqual(modalSource.includes('z-[100]'), true, 'Modal must sit above all layers so clicks are never intercepted');
    assert.strictEqual(modalSource.includes("e.key === 'Escape'"), true, 'Escape key must dismiss the offline dialog');
    assert.strictEqual(modalSource.includes('onUseOnline'), true, 'Use Online must invoke onUseOnline dismissal callback');
  });

  it('22. Storage-service local deletion helper removes space and active space pointers cleanly', () => {
    const uid = 'usr_cleanup_test';
    const sp: Space = {
      id: 'sp_ptr_1',
      ownerId: uid,
      name: 'Pointer Test',
      mode: 'personal',
      currency: 'INR',
      startingBalance: 0,
      memberIds: [uid],
      members: [{ id: uid, name: 'Tester', role: 'owner' }],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    saveLocalUserSpaces(uid, [sp]);
    localStorage.setItem(`hisaab_active_space_${uid}`, 'sp_ptr_1');
    localStorage.setItem('hisaab_active_space_id', 'sp_ptr_1');

    // Delete synchronously via removeLocalUserSpace check in merge/load
    saveLocalTransaction('sp_ptr_1', {
      id: 'tx_p_1',
      spaceId: 'sp_ptr_1',
      creatorId: uid,
      title: 'Coffee',
      type: 'expense',
      category: 'Food',
      amount: 1000,
      date: '2026-03-01',
      payerId: uid,
      createdAt: '2026-03-01T10:00:00Z'
    });
    assert.strictEqual(getLocalTransactions('sp_ptr_1').length, 1);

    // Cancel pending ops for deleted space works cleanly even when empty
    return cancelPendingOperationsForSpace('sp_ptr_1').then(() => {
      assert.strictEqual(getPendingOperationsForSpace('sp_ptr_1').length, 0);
    });
  });
});

describe('SPLITO Offline Dialog Behavior — Acceptance Tests A, B, C, D', () => {
  beforeEach(async () => {
    await cleanupNetworkDetection();
    updateNetworkState(false, 'none');
  });

  it('23. Test A (Offline + Use Online): keeps dialog open, stays offline, triggers no drain, shows "Internet abhi off hai"', async () => {
    const originalWindow = (globalThis as any).window;
    const originalFetch = globalThis.fetch;

    try {
      (globalThis as any).window = {};
      globalThis.fetch = (async () => {
        throw new Error('Offline');
      }) as any;

      let dialogOpen = true;
      let onlineState = false;
      let drainCalls = 0;

      const controller = createOfflineDialogController({
        refreshStatus: refreshNetworkStatus,
        isDialogOpen: () => dialogOpen,
        onDismissDialog: () => {
          dialogOpen = false;
        },
        onSetOnline: (connected) => {
          onlineState = connected;
        },
        onDrainQueue: async () => {
          drainCalls++;
        }
      });

      const result = await controller.handleUseOnline();
      assert.strictEqual(result, false, 'Use Online must fail when internet is unreachable');
      assert.strictEqual(dialogOpen, true, 'Dialog must stay open when offline');
      assert.strictEqual(onlineState, false, 'App must remain offline');
      assert.strictEqual(drainCalls, 0, 'Outbox drain must not run while offline');
      assert.strictEqual(OFFLINE_ALERT_RETRY_MESSAGE, 'Internet abhi off hai');

      const modalSource = fs.readFileSync(
        path.resolve('src/components/StartupOfflineAlertModal.tsx'),
        'utf-8'
      );
      assert.strictEqual(modalSource.includes('OFFLINE_ALERT_RETRY_MESSAGE'), true);
      assert.strictEqual(modalSource.includes('Internet abhi off hai'), true);
      controller.cleanup();
    } finally {
      (globalThis as any).window = originalWindow;
      globalThis.fetch = originalFetch;
    }
  });

  it('24. Test B (Online + Use Online): dismisses in < 1s without awaiting queue drain, switches online, triggers drain', async () => {
    const originalWindow = (globalThis as any).window;
    const originalFetch = globalThis.fetch;

    try {
      (globalThis as any).window = {};
      globalThis.fetch = (async () => ({ status: 204 })) as any;

      let dialogOpen = true;
      let onlineState = false;
      let drainCalls = 0;
      let resolveSlowDrain!: () => void;
      const slowDrainPromise = new Promise<void>((resolve) => {
        resolveSlowDrain = resolve;
      });

      const controller = createOfflineDialogController({
        refreshStatus: refreshNetworkStatus,
        isDialogOpen: () => dialogOpen,
        onDismissDialog: () => {
          dialogOpen = false;
        },
        onSetOnline: (connected) => {
          onlineState = connected;
        },
        onDrainQueue: async () => {
          drainCalls++;
          await slowDrainPromise;
        }
      });

      const start = Date.now();
      const result = await controller.handleUseOnline();
      const elapsedMs = Date.now() - start;

      assert.strictEqual(result, true, 'Use Online must succeed when reachability passes');
      assert.strictEqual(dialogOpen, false, 'Dialog must dismiss immediately');
      assert(elapsedMs < 1000, `Dialog dismissal must take < 1000ms (took ${elapsedMs}ms) without waiting on slow queue drain`);
      assert.strictEqual(onlineState, true, 'App must transition to online mode');
      assert.strictEqual(isOnline(), true, 'Shared network state must refresh to connected');
      assert.strictEqual(drainCalls, 1, 'Queue drain must be triggered once');

      resolveSlowDrain();
      controller.cleanup();
    } finally {
      (globalThis as any).window = originalWindow;
      globalThis.fetch = originalFetch;
    }
  });

  it('25. Test C1 (Internet restored while dialog open): verified reachability auto-dismisses dialog once without tap', async () => {
    const originalWindow = (globalThis as any).window;
    const originalFetch = globalThis.fetch;

    try {
      (globalThis as any).window = {};
      globalThis.fetch = (async () => ({ status: 204 })) as any;

      let dialogOpen = true;
      let onlineState = false;
      let drainCalls = 0;

      const controller = createOfflineDialogController({
        refreshStatus: refreshNetworkStatus,
        isDialogOpen: () => dialogOpen,
        onDismissDialog: () => {
          dialogOpen = false;
        },
        onSetOnline: (connected) => {
          onlineState = connected;
        },
        onDrainQueue: async () => {
          drainCalls++;
        },
        debounceMs: 60
      });

      // Duplicate connectivity restoration events must debounce and transition only once
      const status = await refreshNetworkStatus();
      assert.strictEqual(status.connected, true);
      controller.handleNetworkChange(true);
      controller.handleNetworkChange(true);

      // Should not dismiss instantaneously before debounce window confirms stability
      assert.strictEqual(dialogOpen, true, 'Must debounce briefly to avoid flicker');

      await new Promise((r) => setTimeout(r, 120));

      assert.strictEqual(dialogOpen, false, 'Dialog must auto-dismiss once reachability is confirmed');
      assert.strictEqual(onlineState, true, 'App must switch to online operation');
      assert.strictEqual(drainCalls, 1, 'Duplicate connectivity events must trigger drain at most once');

      controller.cleanup();
    } finally {
      (globalThis as any).window = originalWindow;
      globalThis.fetch = originalFetch;
    }
  });

  it('26. Test C2 (Transient network blip): failed or dropped reachability does NOT auto-dismiss dialog or drain queue', async () => {
    const originalWindow = (globalThis as any).window;
    const originalFetch = globalThis.fetch;

    try {
      (globalThis as any).window = {};
      let probeShouldSucceed = true;
      globalThis.fetch = (async () => {
        if (!probeShouldSucceed) {
          throw new Error('Blip dropped');
        }
        return { status: 204 };
      }) as any;

      let dialogOpen = true;
      let onlineState = false;
      let drainCalls = 0;

      const controller = createOfflineDialogController({
        refreshStatus: refreshNetworkStatus,
        isDialogOpen: () => dialogOpen,
        onDismissDialog: () => {
          dialogOpen = false;
        },
        onSetOnline: (connected) => {
          onlineState = connected;
        },
        onDrainQueue: async () => {
          drainCalls++;
        },
        debounceMs: 60
      });

      // Transient connected blip followed immediately by failure before debounce finishes
      controller.handleNetworkChange(true);
      probeShouldSucceed = false;
      await new Promise((r) => setTimeout(r, 120));

      assert.strictEqual(dialogOpen, true, 'Failed second verification must keep dialog open');
      assert.strictEqual(onlineState, false, 'App must remain offline on failed reachability');
      assert.strictEqual(drainCalls, 0, 'Queue drain must not trigger on unverified transient blip');

      controller.cleanup();
    } finally {
      (globalThis as any).window = originalWindow;
      globalThis.fetch = originalFetch;
    }
  });

  it('27. Test D (Use Offline & X/backdrop/Escape regression): dismisses immediately, stays offline, triggers no drain', () => {
    let dialogOpen = true;
    let onlineState = false;
    let drainCalls = 0;

    const controller = createOfflineDialogController({
      refreshStatus: refreshNetworkStatus,
      isDialogOpen: () => dialogOpen,
      onDismissDialog: () => {
        dialogOpen = false;
      },
      onSetOnline: (connected) => {
        onlineState = connected;
      },
      onDrainQueue: async () => {
        drainCalls++;
      }
    });

    controller.handleUseOffline();
    assert.strictEqual(dialogOpen, false, 'Use Offline must dismiss dialog immediately');
    assert.strictEqual(onlineState, false, 'App must continue operating offline');
    assert.strictEqual(drainCalls, 0, 'Use Offline must not trigger outbox queue drain');

    // Manual dismiss (X / backdrop / Escape) also dismisses without online transition
    dialogOpen = true;
    controller.handleManualDismiss();
    assert.strictEqual(dialogOpen, false, 'Manual close must dismiss dialog immediately');
    assert.strictEqual(onlineState, false);
    assert.strictEqual(drainCalls, 0);

    controller.cleanup();
  });

  it('28. Network detection registers visibilitychange, focus, and online verification listeners', async () => {
    const netSource = fs.readFileSync(path.resolve('src/lib/network-service.ts'), 'utf-8');
    assert.strictEqual(netSource.includes('visibilitychange'), true, 'Must listen to document visibilitychange');
    assert.strictEqual(netSource.includes('inFlightRefreshPromise'), true, 'Must serialize concurrent reachability checks');
    assert.strictEqual(
      netSource.includes('https://www.gstatic.com/generate_204'),
      true,
      'Must reuse existing gstatic generate_204 reachability probe'
    );

    // Unverified window online handler must not blindly emit connected=true before verification
    const appSource = fs.readFileSync(path.resolve('src/App.tsx'), 'utf-8');
    assert.strictEqual(appSource.includes('createOfflineDialogController'), true);
    assert.strictEqual(appSource.includes('setIsOnline(true)'), false, 'App.tsx must not bypass verification with blind setIsOnline(true)');
  });
});


