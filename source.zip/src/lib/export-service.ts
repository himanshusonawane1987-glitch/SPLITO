import { jsPDF } from 'jspdf';
import { Capacitor } from '@capacitor/core';
import { Filesystem, Directory } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';
import { Space, Transaction, MemberBalance, ActualBalanceBreakdown } from '../types/finance.ts';
import {
  formatMinorUnits,
  getParticipantDisplayName,
  isTemporaryParticipantId
} from './finance-engine.ts';

export interface ExportResult {
  success: boolean;
  method: 'native-share' | 'web-download';
  filename?: string;
  error?: string;
}

/**
 * Builds a structured, publication-grade financial ledger PDF in jsPDF
 * adhering strictly to INR (₹) formatting and Indian numbering grouping.
 */
export function buildPdfDocument(
  space: Space,
  transactions: Transaction[],
  memberBalances: MemberBalance[],
  actualBalanceBreakdown: ActualBalanceBreakdown
): jsPDF {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4'
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 14;
  let y = margin;

  // Colors
  const primaryBlue = [37, 99, 235]; // #2563eb
  const textDark = [15, 23, 42]; // #0f172a
  const textMuted = [100, 116, 139]; // #64748b
  const cardBg = [248, 250, 252]; // #f8fafc
  const borderLight = [226, 232, 240]; // #e2e8f0
  const greenText = [22, 101, 52]; // #166534
  const redText = [159, 18, 57]; // #9f1239

  // Header Banner
  doc.setFillColor(primaryBlue[0], primaryBlue[1], primaryBlue[2]);
  doc.roundedRect(margin, y, 10, 10, 2, 2, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(8);
  doc.setFont('helvetica', 'bold');
  doc.text('SP', margin + 2.5, y + 6.5);

  doc.setTextColor(textDark[0], textDark[1], textDark[2]);
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.text('SPLITO', margin + 13, y + 7.5);

  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(textMuted[0], textMuted[1], textMuted[2]);
  doc.text('Every Rupee. Accounted For.', margin + 13, y + 11.5);

  // Right-aligned Metadata
  const dateStr = new Date().toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric'
  });
  doc.setFontSize(8);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(textDark[0], textDark[1], textDark[2]);
  doc.text('Statement Date:', pageWidth - margin, y + 4, { align: 'right' });
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(textMuted[0], textMuted[1], textMuted[2]);
  doc.text(dateStr, pageWidth - margin, y + 8, { align: 'right' });
  doc.text(`Total Records: ${transactions.length}`, pageWidth - margin, y + 12, { align: 'right' });

  y += 18;

  // Space Details Subheader
  doc.setDrawColor(borderLight[0], borderLight[1], borderLight[2]);
  doc.setLineWidth(0.3);
  doc.line(margin, y, pageWidth - margin, y);
  y += 5;

  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(textDark[0], textDark[1], textDark[2]);
  doc.text(space.name, margin, y);

  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(textMuted[0], textMuted[1], textMuted[2]);
  const modeLabel = space.mode ? space.mode.toUpperCase() : 'SHARED';
  doc.text(`Mode: ${modeLabel} • Base Currency: INR (Rs.)`, margin, y + 4);

  y += 10;

  // Financial Summary Cards Box
  const summaryBoxWidth = pageWidth - margin * 2;
  const colW = summaryBoxWidth / 4;
  doc.setFillColor(cardBg[0], cardBg[1], cardBg[2]);
  doc.roundedRect(margin, y, summaryBoxWidth, 18, 2, 2, 'F');
  doc.rect(margin, y, summaryBoxWidth, 18, 'S');

  const summaries = [
    { label: 'STARTING BALANCE', val: formatMinorUnits(actualBalanceBreakdown.startingBalance, 'INR') },
    { label: 'TOTAL INFLOW (+)', val: `+${formatMinorUnits(actualBalanceBreakdown.receivedIncome, 'INR')}`, color: greenText },
    { label: 'TOTAL OUTFLOW (-)', val: `-${formatMinorUnits(actualBalanceBreakdown.paidExpenses, 'INR')}`, color: redText },
    { label: 'ACTUAL AVAILABLE', val: formatMinorUnits(actualBalanceBreakdown.actualBalance, 'INR'), bold: true, color: primaryBlue }
  ];

  summaries.forEach((s, idx) => {
    const cx = margin + idx * colW + 4;
    doc.setFontSize(6.5);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(textMuted[0], textMuted[1], textMuted[2]);
    doc.text(s.label, cx, y + 6);

    doc.setFontSize(9);
    doc.setFont('helvetica', s.bold ? 'bold' : 'normal');
    if (s.color) {
      doc.setTextColor(s.color[0], s.color[1], s.color[2]);
    } else {
      doc.setTextColor(textDark[0], textDark[1], textDark[2]);
    }
    doc.text(s.val, cx, y + 13);
  });

  y += 24;

  // Member Balances & Zero-Sum Audit (for Shared spaces)
  if (space.mode !== 'personal' && memberBalances.length > 0) {
    doc.setFontSize(9);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(textDark[0], textDark[1], textDark[2]);
    doc.text('MEMBER BALANCES & ZERO-SUM AUDIT', margin, y);
    y += 4;

    // Table Header
    doc.setFillColor(cardBg[0], cardBg[1], cardBg[2]);
    doc.rect(margin, y, summaryBoxWidth, 6, 'F');
    doc.setFontSize(7.5);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(textMuted[0], textMuted[1], textMuted[2]);
    doc.text('Member Name', margin + 3, y + 4.2);
    doc.text('Disbursed (Paid)', margin + 60, y + 4.2);
    doc.text('Consumption Share', margin + 110, y + 4.2);
    doc.text('Net Balance', pageWidth - margin - 3, y + 4.2, { align: 'right' });
    y += 7;

    memberBalances.forEach((m) => {
      doc.setFontSize(8);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(textDark[0], textDark[1], textDark[2]);
      const displayName = m.isTemporary
        ? `${m.memberName || 'Unknown (Temp)'} (Temp)`
        : (m.memberName || 'Member');
      doc.text(displayName, margin + 3, y + 3.5);

      doc.text(formatMinorUnits(m.totalPaidMinorUnits, 'INR'), margin + 60, y + 3.5);
      doc.text(formatMinorUnits(m.totalOwedMinorUnits, 'INR'), margin + 110, y + 3.5);

      if (m.netBalanceMinorUnits > 0) {
        doc.setTextColor(greenText[0], greenText[1], greenText[2]);
        doc.setFont('helvetica', 'bold');
        doc.text(`+${formatMinorUnits(m.netBalanceMinorUnits, 'INR')}`, pageWidth - margin - 3, y + 3.5, { align: 'right' });
      } else if (m.netBalanceMinorUnits < 0) {
        doc.setTextColor(redText[0], redText[1], redText[2]);
        doc.setFont('helvetica', 'bold');
        doc.text(formatMinorUnits(m.netBalanceMinorUnits, 'INR'), pageWidth - margin - 3, y + 3.5, { align: 'right' });
      } else {
        doc.setTextColor(textMuted[0], textMuted[1], textMuted[2]);
        doc.text(formatMinorUnits(0, 'INR'), pageWidth - margin - 3, y + 3.5, { align: 'right' });
      }
      y += 5.5;
    });

    const netSum = memberBalances.reduce((acc, b) => acc + b.netBalanceMinorUnits, 0);
    doc.setDrawColor(borderLight[0], borderLight[1], borderLight[2]);
    doc.line(margin, y, pageWidth - margin, y);
    y += 4;
    doc.setFontSize(7.5);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(greenText[0], greenText[1], greenText[2]);
    doc.text(`Group Reconciliation Sum: ${formatMinorUnits(netSum, 'INR')} (Exact Zero-Sum Audit Confirmed)`, margin + 3, y);
    y += 8;
  }

  // Itemized Ledger Records Table
  doc.setFontSize(9);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(textDark[0], textDark[1], textDark[2]);
  doc.text('ITEMIZED LEDGER RECORDS', margin, y);
  y += 4;

  // Ledger Table Header
  doc.setFillColor(cardBg[0], cardBg[1], cardBg[2]);
  doc.rect(margin, y, summaryBoxWidth, 6, 'F');
  doc.setFontSize(7.5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(textMuted[0], textMuted[1], textMuted[2]);
  doc.text('Date', margin + 3, y + 4.2);
  doc.text('Description', margin + 28, y + 4.2);
  doc.text('Category', margin + 95, y + 4.2);
  doc.text('Type', margin + 130, y + 4.2);
  doc.text('Amount (INR)', pageWidth - margin - 3, y + 4.2, { align: 'right' });
  y += 7;

  // Ledger Rows (with automatic page break if long)
  const displayTransactions = transactions.slice(0, 100);
  displayTransactions.forEach((tx) => {
    // Check page overflow
    if (y > pageHeight - 20) {
      doc.addPage();
      y = margin;
      // Header for next page
      doc.setFontSize(7.5);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(textMuted[0], textMuted[1], textMuted[2]);
      doc.text('SPLITO Statement Ledger (Continued)', margin, y);
      y += 6;
    }

    doc.setFontSize(7.5);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(textMuted[0], textMuted[1], textMuted[2]);
    doc.text(tx.date || '-', margin + 3, y + 3.2);

    doc.setTextColor(textDark[0], textDark[1], textDark[2]);
    doc.setFont('helvetica', 'bold');
    const title = tx.title.length > 35 ? tx.title.substring(0, 32) + '...' : tx.title;
    doc.text(title + (tx.isReversal ? ' [Reversal]' : ''), margin + 28, y + 3.2);

    doc.setFont('helvetica', 'normal');
    doc.setTextColor(textMuted[0], textMuted[1], textMuted[2]);
    doc.text(tx.category || 'General', margin + 95, y + 3.2);
    doc.text(tx.type.toUpperCase(), margin + 130, y + 3.2);

    if (tx.type === 'income') {
      doc.setTextColor(greenText[0], greenText[1], greenText[2]);
      doc.setFont('helvetica', 'bold');
      doc.text(`+${formatMinorUnits(tx.amount, 'INR')}`, pageWidth - margin - 3, y + 3.2, { align: 'right' });
    } else {
      doc.setTextColor(textDark[0], textDark[1], textDark[2]);
      doc.setFont('helvetica', 'bold');
      doc.text(formatMinorUnits(tx.amount, 'INR'), pageWidth - margin - 3, y + 3.2, { align: 'right' });
    }

    y += 5.2;
  });

  // Footer on bottom of current page
  const footerY = pageHeight - margin + 2;
  doc.setDrawColor(borderLight[0], borderLight[1], borderLight[2]);
  doc.setLineWidth(0.2);
  doc.line(margin, footerY - 4, pageWidth - margin, footerY - 4);

  doc.setFontSize(7);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(textMuted[0], textMuted[1], textMuted[2]);
  doc.text('Generated securely via SPLITO • Confidential Financial Ledger', margin, footerY);
  doc.text(`Page 1 of ${doc.getNumberOfPages()}`, pageWidth - margin, footerY, { align: 'right' });

  return doc;
}

/**
 * Exports statement PDF via Capacitor Filesystem + Share on native Android,
 * or triggers direct browser download in preview.
 */
export async function exportPdfStatement(
  space: Space,
  transactions: Transaction[],
  memberBalances: MemberBalance[],
  actualBalanceBreakdown: ActualBalanceBreakdown
): Promise<ExportResult> {
  const safeSpaceName = space.name.toLowerCase().replace(/[^a-z0-9]/g, '_');
  const filename = `splito_statement_${safeSpaceName}_${Date.now()}.pdf`;

  try {
    const doc = buildPdfDocument(space, transactions, memberBalances, actualBalanceBreakdown);

    if (Capacitor.isNativePlatform()) {
      // In native Android WebView: generate base64, save to Filesystem, share via native dialog
      const dataUri = doc.output('datauristring');
      const base64Data = dataUri.split(',')[1] || '';

      const writtenFile = await Filesystem.writeFile({
        path: filename,
        data: base64Data,
        directory: Directory.Cache
      });

      const uriResult = await Filesystem.getUri({
        path: filename,
        directory: Directory.Cache
      });

      await Share.share({
        title: `${space.name} Financial Statement`,
        text: `Financial statement for ${space.name} from SPLITO`,
        url: uriResult.uri,
        dialogTitle: 'Share or Print Statement'
      });

      return {
        success: true,
        method: 'native-share',
        filename
      };
    } else {
      // Browser preview: save directly
      doc.save(filename);
      return {
        success: true,
        method: 'web-download',
        filename
      };
    }
  } catch (err) {
    const errorMsg = err instanceof Error ? err.message : String(err);
    console.error('PDF export error:', err);
    return {
      success: false,
      method: Capacitor.isNativePlatform() ? 'native-share' : 'web-download',
      filename,
      error: errorMsg
    };
  }
}

/**
 * Builds CSV string and exports via Capacitor Filesystem + Share on native Android,
 * or triggers Blob download in browser preview.
 */
export async function exportCsvStatement(
  space: Space,
  transactions: Transaction[]
): Promise<ExportResult> {
  const safeSpaceName = space.name.toLowerCase().replace(/[^a-z0-9]/g, '_');
  const filename = `splito_ledger_${safeSpaceName}_${Date.now()}.csv`;

  try {
    const headers = [
      'Date',
      'Title',
      'Type',
      'Category',
      'Amount Minor Units (Paise)',
      'Formatted Amount (INR)',
      'Payer ID',
      'Payment Method',
      'Notes',
      'Is Reversed'
    ];

    const rows = transactions.map((t) => [
      t.date,
      `"${(t.title || '').replace(/"/g, '""')}"`,
      t.type,
      `"${(t.category || '').replace(/"/g, '""')}"`,
      t.amount,
      `"${formatMinorUnits(t.amount, 'INR')}"`,
      `"${(t.payerNameSnapshot || (isTemporaryParticipantId(t.payerId) ? getParticipantDisplayName(t.payerId, space.members || [], transactions) : t.payerId || '')).replace(/"/g, '""')}"`,
      `"${t.paymentMethod || 'UPI'}"`,
      `"${(t.notes || '').replace(/"/g, '""')}"`,
      t.isReversed ? 'YES' : 'NO'
    ]);

    const csvContent = '\uFEFF' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\r\n');

    if (Capacitor.isNativePlatform()) {
      // In native Android WebView: convert UTF-8 string to base64, save to Filesystem, share via Share sheet
      const base64Data = btoa(unescape(encodeURIComponent(csvContent)));

      await Filesystem.writeFile({
        path: filename,
        data: base64Data,
        directory: Directory.Cache
      });

      const uriResult = await Filesystem.getUri({
        path: filename,
        directory: Directory.Cache
      });

      await Share.share({
        title: `${space.name} CSV Ledger`,
        text: `CSV ledger export for ${space.name} from SPLITO`,
        url: uriResult.uri,
        dialogTitle: 'Share or Save CSV'
      });

      return {
        success: true,
        method: 'native-share',
        filename
      };
    } else {
      // Browser preview: Blob download
      if (typeof document !== 'undefined') {
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', filename);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
      }

      return {
        success: true,
        method: 'web-download',
        filename
      };
    }
  } catch (err) {
    const errorMsg = err instanceof Error ? err.message : String(err);
    console.error('CSV export error:', err);
    return {
      success: false,
      method: Capacitor.isNativePlatform() ? 'native-share' : 'web-download',
      filename,
      error: errorMsg
    };
  }
}
