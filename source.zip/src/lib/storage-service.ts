import {
  collection,
  doc,
  getDoc,
  getDocFromServer,
  getDocs,
  onSnapshot,
  query,
  setDoc,
  updateDoc,
  deleteDoc,
  writeBatch,
  where,
  Unsubscribe
} from 'firebase/firestore';
import { db, auth, handleFirestoreError, OperationType } from './firebase.ts';
import { isOnline } from './network-service.ts';
import {
  enqueueOperation,
  registerQueueExecutor,
  getPendingOperationsForSpace,
  QueuedOperation
} from './offline-queue.ts';
import {
  Space,
  Transaction,
  UserProfile,
  SpaceMode,
  CurrencyCode,
  Member,
  AuditLog
} from '../types/finance.ts';
import {
  createReversalTransaction,
  getActiveLedgerTransactions,
  calculateGroupBalances,
  formatPaise
} from './finance-engine.ts';

export const DEFAULT_CATEGORIES_BY_MODE: Record<SpaceMode, string[]> = {
  roommates: [
    'Rent',
    'Groceries',
    'WiFi & Cable',
    'Maid & Cook',
    'Electricity',
    'Water',
    'Maintenance',
    'Snacks & Drinks',
    'Household Items',
    'Other'
  ],
  personal: [
    'Salary & Income',
    'Groceries & Food',
    'Dining Out',
    'Commute & Fuel',
    'Shopping',
    'Subscriptions & Bills',
    'Health & Medicine',
    'Entertainment',
    'Personal Care',
    'Savings & Investments',
    'Other'
  ],
  family: [
    'Rations & Groceries',
    'School & Education',
    'Rent & EMI',
    'Utilities & Bills',
    'Medical & Healthcare',
    'Domestic Help',
    'Home Maintenance',
    'Festivals & Gifts',
    'Travel & Outings',
    'Other'
  ],
  trip: [
    'Flights & Transit',
    'Hotels & Stay',
    'Food & Dining',
    'Sightseeing & Entry',
    'Activities & Sports',
    'Shopping & Souvenirs',
    'Fuel & Cabs',
    'Snacks & Drinks',
    'Emergency',
    'Other'
  ]
};

/**
 * Creates or gets an existing user profile in Firestore
 */
export async function syncUserProfile(
  userId: string,
  email: string | null,
  displayName: string,
  initialMode: SpaceMode = 'roommates'
): Promise<UserProfile> {
  const userPath = `users/${userId}`;
  try {
    const userDocRef = doc(db, 'users', userId);
    const snap = await getDoc(userDocRef);

    if (snap.exists()) {
      return snap.data() as UserProfile;
    }

    // Check if user already has spaces in Firestore to prevent duplicate seeding
    const spacesQuery = query(
      collection(db, 'spaces'),
      where('memberIds', 'array-contains', userId)
    );
    const existingSpacesSnap = await getDocs(spacesQuery);

    if (!existingSpacesSnap.empty) {
      const existingSpace = existingSpacesSnap.docs[0].data() as Space;
      const newProfile: UserProfile = {
        userId,
        email: email || '',
        displayName: displayName || (email ? email.split('@')[0] : 'User'),
        primaryMode: existingSpace.mode || initialMode,
        activeSpaceId: existingSpace.id,
        currency: existingSpace.currency || 'INR',
        createdAt: new Date().toISOString()
      };
      await setDoc(userDocRef, newProfile);
      return newProfile;
    }

    // Clean initialization: A new user starts with 0 spaces, 0 members, 0 transactions.
    // They will create their first real space via the UI.
    const newProfile: UserProfile = {
      userId,
      email: email || '',
      displayName: displayName || (email ? email.split('@')[0] : 'User'),
      primaryMode: initialMode,
      activeSpaceId: '',
      currency: 'INR',
      createdAt: new Date().toISOString()
    };

    await setDoc(userDocRef, newProfile);
    return newProfile;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, userPath);
  }
}

/**
 * Seeds initial shared living expenses for 3 roommates
 */
export async function seedThreeRoommatesTransactions(
  spaceId: string,
  himanshuId: string,
  alexId: string,
  jordanId: string
): Promise<Transaction[]> {
  const today = new Date().toISOString().split('T')[0];

  const transactions: Transaction[] = [
    {
      id: `tx_${Date.now()}_1`,
      spaceId,
      creatorId: himanshuId,
      title: 'Flat 402 Rent (Monthly)',
      type: 'expense',
      category: 'Rent',
      amount: 4500000, // ₹45,000.00
      date: today,
      payerId: himanshuId,
      paymentMethod: 'Net Banking',
      splitType: 'equal',
      splits: [
        { memberId: himanshuId, shareMinorUnits: 1500000 },
        { memberId: alexId, shareMinorUnits: 1500000 },
        { memberId: jordanId, shareMinorUnits: 1500000 }
      ],
      notes: 'Transferred directly to Landlord via RTGS',
      version: 1,
      createdAt: new Date(Date.now() - 7200000).toISOString()
    },
    {
      id: `tx_${Date.now()}_2`,
      spaceId,
      creatorId: himanshuId,
      title: 'Airtel Xstream Fiber 300Mbps',
      type: 'expense',
      category: 'WiFi & Cable',
      amount: 149900, // ₹1,499.00
      date: today,
      payerId: alexId,
      paymentMethod: 'UPI',
      splitType: 'equal',
      splits: [
        { memberId: himanshuId, shareMinorUnits: 50000 },
        { memberId: alexId, shareMinorUnits: 49950 },
        { memberId: jordanId, shareMinorUnits: 49950 }
      ],
      notes: 'Monthly broadband renewal',
      version: 1,
      createdAt: new Date(Date.now() - 3600000).toISOString()
    },
    {
      id: `tx_${Date.now()}_3`,
      spaceId,
      creatorId: himanshuId,
      title: 'Cook & Housekeeping Wages',
      type: 'expense',
      category: 'Maid & Cook',
      amount: 600000, // ₹6,000.00
      date: today,
      payerId: jordanId,
      paymentMethod: 'Cash',
      splitType: 'equal',
      splits: [
        { memberId: himanshuId, shareMinorUnits: 200000 },
        { memberId: alexId, shareMinorUnits: 200000 },
        { memberId: jordanId, shareMinorUnits: 200000 }
      ],
      notes: 'Paid cash with signed register receipt',
      version: 1,
      createdAt: new Date().toISOString()
    }
  ];

  for (const tx of transactions) {
    try {
      await setDoc(doc(db, 'spaces', spaceId, 'transactions', tx.id), tx);
    } catch (e) {
      // Ignore if offline
    }
  }

  return transactions;
}

export function getModeDefaultSpaceName(mode: SpaceMode): string {
  switch (mode) {
    case 'roommates':
      return 'Flat 402 Roommates';
    case 'family':
      return 'Family Household';
    case 'trip':
      return 'Goa Trip 2026';
    case 'personal':
    default:
      return 'My Personal Diary';
  }
}

export type ErrorCategory =
  | 'unauthenticated'
  | 'permission-denied'
  | 'unavailable'
  | 'deadline-exceeded'
  | 'invalid-argument'
  | 'failed-precondition'
  | 'unknown';

export interface ClassifiedError {
  category: ErrorCategory;
  userMessage: string;
  technicalDetails: string;
  docId?: string;
}

export function classifyFirestoreError(error: unknown, docId?: string): ClassifiedError {
  const msg = error instanceof Error ? error.message : String(error);
  const lower = msg.toLowerCase();

  let category: ErrorCategory = 'unknown';
  let userMessage = 'An unexpected cloud ledger error occurred. Your inputs have been kept safe.';

  if (
    lower.includes('unauthenticated') ||
    lower.includes('not signed in') ||
    lower.includes('auth/no-current-user') ||
    lower.includes('auth-expired') ||
    lower.includes('token')
  ) {
    category = 'unauthenticated';
    userMessage = 'Your sign-in session is unauthenticated or expired. Please sign in to verify your ledger.';
  } else if (
    lower.includes('permission') ||
    lower.includes('insufficient') ||
    lower.includes('access-denied')
  ) {
    category = 'permission-denied';
    userMessage = 'Permission denied by cloud ledger security rules. Verify space membership and ownership.';
  } else if (
    lower.includes('unavailable') ||
    lower.includes('network') ||
    lower.includes('offline')
  ) {
    category = 'unavailable';
    userMessage = 'Firestore service unavailable or offline. Write could not be confirmed on the server.';
  } else if (
    lower.includes('deadline') ||
    lower.includes('timeout')
  ) {
    category = 'deadline-exceeded';
    userMessage = 'Cloud verification timed out waiting for server confirmation. Please retry.';
  } else if (
    lower.includes('invalid') ||
    lower.includes('argument') ||
    lower.includes('schema') ||
    lower.includes('missing')
  ) {
    category = 'invalid-argument';
    userMessage = 'Invalid ledger data or parameters. Please review your input and retry.';
  } else if (
    lower.includes('failed-precondition') ||
    lower.includes('conflict') ||
    lower.includes('verification')
  ) {
    category = 'failed-precondition';
    userMessage = 'Cloud precondition failed: document state could not be verified on the server.';
  }

  return {
    category,
    userMessage,
    technicalDetails: msg,
    docId
  };
}

const PROVISIONAL_SPACES_PREFIX = 'hisaab_provisional_spaces_';

export function getProvisionalSpaces(userId: string): Space[] {
  try {
    if (typeof localStorage === 'undefined') return [];
    const raw = localStorage.getItem(`${PROVISIONAL_SPACES_PREFIX}${userId}`);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function saveProvisionalSpace(userId: string, space: Space): void {
  try {
    if (typeof localStorage === 'undefined') return;
    const existing = getProvisionalSpaces(userId);
    const updated = existing.filter((s) => s.id !== space.id);
    updated.push(space);
    localStorage.setItem(`${PROVISIONAL_SPACES_PREFIX}${userId}`, JSON.stringify(updated));
  } catch (err) {
    console.warn('Unable to save provisional space locally', err);
  }
}

export function removeProvisionalSpace(userId: string, spaceId: string): void {
  try {
    if (typeof localStorage === 'undefined') return;
    const existing = getProvisionalSpaces(userId);
    const updated = existing.filter((s) => s.id !== spaceId);
    localStorage.setItem(`${PROVISIONAL_SPACES_PREFIX}${userId}`, JSON.stringify(updated));
  } catch {
    // Ignore
  }
}

export function saveLocalTransaction(spaceId: string, tx: Transaction): void {
  try {
    if (typeof localStorage === 'undefined') return;
    const key = `hisaab_local_tx_${spaceId}`;
    const raw = localStorage.getItem(key);
    const list: Transaction[] = raw ? JSON.parse(raw) : [];
    const updated = list.filter((t) => t.id !== tx.id);
    updated.unshift(tx);
    localStorage.setItem(key, JSON.stringify(updated));
  } catch (err) {
    console.warn('Local transaction cache write notice:', err);
  }
}

/**
 * Creates a new financial Space / Ledger following the 12-step authoritative contract
 * with strict server-confirmed read-after-write verification and offline-tolerant outbox fallback.
 */
export async function createSpace(space: Space): Promise<Space> {
  const path = `spaces/${space.id}`;

  // Step 1: Validate auth state
  if (!auth.currentUser) {
    throw new Error('UNAUTHENTICATED: Must be signed in to create an authoritative cloud space.');
  }

  // Step 2: Obtain UID from authenticated session
  const currentUid = auth.currentUser.uid;
  const currentEmail = auth.currentUser.email || '';
  const currentDisplayName = auth.currentUser.displayName || (currentEmail ? currentEmail.split('@')[0] : 'User');

  // Step 3: Validate required fields
  if (!space.name || !space.name.trim()) {
    throw new Error('INVALID_ARGUMENT: Space name cannot be empty.');
  }
  if (!space.currency) {
    throw new Error('INVALID_ARGUMENT: Currency must be specified.');
  }
  if (typeof space.startingBalance !== 'number' || !Number.isInteger(space.startingBalance)) {
    throw new Error('INVALID_ARGUMENT: Starting balance must be an integer minor units value.');
  }

  // Step 4: Construct authoritative payload
  const memberIds = Array.from(new Set([currentUid, ...(space.memberIds || [])]));
  const existingMembers = space.members || [];
  const hasCurrentUserMember = existingMembers.some((m) => m.id === currentUid);

  const members: Member[] = hasCurrentUserMember
    ? existingMembers.map((m) => (m.id === currentUid ? { ...m, role: 'owner' as const, isCurrentUser: true } : m))
    : [
        {
          id: currentUid,
          name: currentDisplayName,
          email: currentEmail,
          avatarColor: '#2563eb',
          isCurrentUser: true,
          role: 'owner' as const
        },
        ...existingMembers
      ];

  const now = new Date().toISOString();
  const spaceData: Space = {
    id: space.id,
    ownerId: currentUid,
    name: space.name.trim(),
    mode: space.mode,
    currency: space.currency,
    startingBalance: space.startingBalance,
    memberIds,
    members,
    version: 1,
    isArchived: false,
    createdAt: space.createdAt || now,
    updatedAt: now,
    isCloudConfirmed: false,
    source: 'cloud-authoritative'
  };

  // Offline fast-path: if offline, save locally as provisional space and enqueue in outbox
  if (!isOnline()) {
    const provisionalSpace: Space = {
      ...spaceData,
      isCloudConfirmed: false,
      isProvisional: true,
      source: 'local-provisional'
    };
    saveProvisionalSpace(currentUid, provisionalSpace);
    await enqueueOperation('CREATE_SPACE', space.id, space.id, spaceData);
    try {
      localStorage.setItem(`hisaab_active_space_${currentUid}`, space.id);
      localStorage.setItem('hisaab_active_space_id', space.id);
    } catch {}
    return provisionalSpace;
  }

  try {
    // Step 5: Obtain document reference
    const spaceRef = doc(db, 'spaces', space.id);

    // Step 6: Await the actual Firestore write operation
    await setDoc(spaceRef, { ...spaceData, isCloudConfirmed: true });

    // Step 7: Confirm stable document reference
    if (spaceRef.id !== space.id) {
      throw new Error(`DOC_ID_MISMATCH: Created doc ID ${spaceRef.id} does not match target ${space.id}`);
    }

    // Step 8: Mandatory server-side read-after-write verification (bypasses cache)
    const serverSnap = await getDocFromServer(spaceRef);

    // Step 9: Confirm document exists on server
    if (!serverSnap.exists()) {
      throw new Error(`SERVER_READ_NOT_FOUND: Space ${space.id} could not be confirmed on Firestore cloud.`);
    }

    // Step 10: Verify essential fields from server document
    const serverData = serverSnap.data() as Space;
    if (serverData.id !== space.id || serverData.name !== spaceData.name || serverData.currency !== spaceData.currency) {
      throw new Error(`SERVER_VALIDATION_MISMATCH: Server state does not match written payload for space ${space.id}`);
    }

    // Step 11: Verify authorized membership on server record
    if (serverData.ownerId !== currentUid || !serverData.memberIds.includes(currentUid)) {
      throw new Error(`MEMBERSHIP_AUTHORIZATION_FAILED: Current user ${currentUid} is not authorized owner/member.`);
    }

    // Step 12: Record audit log & synchronize user's active space preference in Firestore
    try {
      await recordAuditLog(space.id, {
        id: `audit_${Date.now()}_create`,
        spaceId: space.id,
        action: 'SPACE_UPDATED',
        actorId: currentUid,
        actorName: currentDisplayName,
        targetType: 'space',
        targetId: space.id,
        details: `Created new authoritative space "${space.name}" in mode ${space.mode} with base currency ${space.currency}`,
        timestamp: new Date().toISOString()
      });
    } catch (auditErr) {
      console.warn('Audit log write notice:', auditErr);
    }

    try {
      await updateUserActiveSpace(currentUid, space.id);
    } catch (prefErr) {
      console.warn('Active space preference sync notice:', prefErr);
    }

    // Clean up any matching provisional space
    removeProvisionalSpace(currentUid, space.id);

    // Return the server-confirmed authoritative space
    return {
      ...serverData,
      isCloudConfirmed: true,
      source: 'cloud-authoritative'
    };
  } catch (error: any) {
    const errMsg = error instanceof Error ? error.message : String(error);
    const isNetworkError =
      errMsg.includes('the client is offline') ||
      errMsg.includes('network-request-failed') ||
      errMsg.includes('unavailable') ||
      errMsg.includes('could not be confirmed on Firestore cloud') ||
      (error && error.code === 'unavailable');

    if (isNetworkError) {
      const provisionalSpace: Space = {
        ...spaceData,
        isCloudConfirmed: false,
        isProvisional: true,
        source: 'local-provisional'
      };
      saveProvisionalSpace(currentUid, provisionalSpace);
      await enqueueOperation('CREATE_SPACE', space.id, space.id, spaceData);
      try {
        localStorage.setItem(`hisaab_active_space_${currentUid}`, space.id);
        localStorage.setItem('hisaab_active_space_id', space.id);
      } catch {}
      return provisionalSpace;
    }

    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

/**
 * Updates an existing space
 */
export async function updateSpaceDetails(spaceId: string, updates: Partial<Space>): Promise<void> {
  const path = `spaces/${spaceId}`;
  try {
    const spaceRef = doc(db, 'spaces', spaceId);
    await updateDoc(spaceRef, {
      ...updates,
      updatedAt: new Date().toISOString()
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export interface SpaceDeletionEligibility {
  canDelete: boolean;
  canArchive: boolean;
  isOwner: boolean;
  transactionCount: number;
  startingBalance: number;
  netBalancePaise: number;
  isArchived: boolean;
  conditionMet: 'zero-tx-zero-bal' | 'settled-zero-bal' | 'archived-override' | 'none';
  reason: string;
}

/**
 * Authoritatively verifies whether a space is eligible for hard deletion or archive.
 * New Unlocked Eligibility Rules (SPLITO v1.5):
 * (a) 0 transactions AND net balance == 0, OR
 * (b) Net balance == 0, even if transactions > 0 (all dues settled or entries reversed), OR
 * (c) Space is already marked Archived AND user explicitly confirms in dialog.
 */
export async function checkSpaceDeletionEligibility(
  spaceId: string,
  currentUserId: string
): Promise<SpaceDeletionEligibility> {
  const path = `spaces/${spaceId}`;
  try {
    const spaceRef = doc(db, 'spaces', spaceId);
    let space: Space | null = null;
    try {
      const spaceSnap = await getDocFromServer(spaceRef);
      if (spaceSnap.exists()) {
        space = spaceSnap.data() as Space;
      }
    } catch {
      // offline/guest fallback
    }

    if (!space) {
      try {
        const guestSpacesRaw = localStorage.getItem('hisaab_guest_spaces');
        if (guestSpacesRaw) {
          const guestSpaces = JSON.parse(guestSpacesRaw) as Space[];
          space = guestSpaces.find((s) => s.id === spaceId) || null;
        }
      } catch (err) {
        console.warn('Local guest check notice:', err);
      }
    }

    if (!space) {
      return {
        canDelete: false,
        canArchive: false,
        isOwner: false,
        transactionCount: 0,
        startingBalance: 0,
        netBalancePaise: 0,
        isArchived: false,
        conditionMet: 'none',
        reason: 'Space document does not exist.'
      };
    }

    const isOwner = space.ownerId === currentUserId || currentUserId.startsWith('guest_') || !space.ownerId;
    const isArchived = Boolean(space.isArchived);
    const startingBalance = space.startingBalance || 0;

    if (!isOwner) {
      return {
        canDelete: false,
        canArchive: false,
        isOwner: false,
        transactionCount: 0,
        startingBalance,
        netBalancePaise: startingBalance,
        isArchived,
        conditionMet: 'none',
        reason: 'Only the authenticated space owner has permission to archive or delete this space.'
      };
    }

    // Query server transactions
    let transactions: Transaction[] = [];
    try {
      const txCol = collection(db, 'spaces', spaceId, 'transactions');
      const txSnap = await getDocs(txCol);
      transactions = txSnap.docs.map((d) => d.data() as Transaction);
    } catch {
      // local transactions fallback if guest or offline
    }

    const transactionCount = transactions.length;
    const activeTx = getActiveLedgerTransactions(transactions);

    // Compute net balance:
    // 1. Ledger actual balance
    let netBalancePaise = startingBalance;
    for (const tx of activeTx) {
      if (tx.type === 'income') {
        netBalancePaise += tx.amount;
      } else if (tx.type === 'expense') {
        netBalancePaise -= tx.amount;
      }
    }

    // 2. Outstanding group member dues check
    if (space.members && space.members.length > 1) {
      const groupBalances = calculateGroupBalances(space.members, activeTx);
      const outstandingDues = groupBalances.reduce((acc, b) => acc + Math.abs(b.netBalanceMinorUnits), 0);
      if (outstandingDues > 0) {
        netBalancePaise = outstandingDues;
      }
    }

    // Condition (a): Space has 0 transactions AND net balance of ₹0.00
    if (transactionCount === 0 && netBalancePaise === 0) {
      return {
        canDelete: true,
        canArchive: true,
        isOwner: true,
        transactionCount: 0,
        startingBalance: 0,
        netBalancePaise: 0,
        isArchived,
        conditionMet: 'zero-tx-zero-bal',
        reason: 'This space has 0 transactions and ₹0.00 balance. It is eligible for permanent hard deletion.'
      };
    }

    // Condition (b): Space has net balance of ₹0.00, even if transactions > 0 (all dues settled or entries reversed)
    if (netBalancePaise === 0) {
      return {
        canDelete: true,
        canArchive: true,
        isOwner: true,
        transactionCount,
        startingBalance,
        netBalancePaise: 0,
        isArchived,
        conditionMet: 'settled-zero-bal',
        reason: `All financial dues and balances in this space are fully settled (₹0.00 balance across ${transactionCount} entries). It is eligible for permanent hard deletion.`
      };
    }

    // Condition (c): Space is already marked Archived AND user explicitly confirms in dialog
    if (isArchived) {
      return {
        canDelete: true,
        canArchive: false,
        isOwner: true,
        transactionCount,
        startingBalance,
        netBalancePaise,
        isArchived: true,
        conditionMet: 'archived-override',
        reason: 'This space is archived. It is eligible for permanent hard deletion with explicit confirmation in the warning dialog.'
      };
    }

    // Otherwise: Non-zero net balance and not archived (safety protected)
    return {
      canDelete: false,
      canArchive: true,
      isOwner: true,
      transactionCount,
      startingBalance,
      netBalancePaise,
      isArchived: false,
      conditionMet: 'none',
      reason: `Hard Deletion Blocked — Financial History Protected. This space contains an unsettled balance of ${formatPaise(netBalancePaise, space.currency)}. To permanently delete it, settle all balances to ₹0.00, or Archive the space first.`
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
    return {
      canDelete: false,
      canArchive: false,
      isOwner: false,
      transactionCount: 0,
      startingBalance: 0,
      netBalancePaise: 0,
      isArchived: false,
      conditionMet: 'none',
      reason: 'Failed to evaluate space deletion eligibility.'
    };
  }
}

/**
 * Safely archives a space, making it read-only for new transactions while preserving all historical records.
 */
export async function archiveSpace(spaceId: string, currentUserId: string): Promise<void> {
  const path = `spaces/${spaceId}`;
  try {
    const spaceRef = doc(db, 'spaces', spaceId);
    const snap = await getDocFromServer(spaceRef);
    if (!snap.exists()) {
      throw new Error(`Space ${spaceId} not found.`);
    }
    const data = snap.data() as Space;
    if (data.ownerId !== currentUserId) {
      throw new Error('PERMISSION_DENIED: Only the owner can archive this space.');
    }

    await updateDoc(spaceRef, {
      isArchived: true,
      updatedAt: new Date().toISOString()
    });

    try {
      const actorName = data.members?.find((m) => m.id === currentUserId)?.name || (auth?.currentUser?.displayName) || 'User';
      await recordAuditLog(spaceId, {
        id: `audit_${Date.now()}_archive`,
        spaceId,
        action: 'SPACE_ARCHIVED',
        actorId: currentUserId,
        actorName,
        targetType: 'space',
        targetId: spaceId,
        details: `Space "${data.name}" archived safely. Financial history preserved.`,
        timestamp: new Date().toISOString()
      });
    } catch (auditErr) {
      console.warn('Audit log write notice:', auditErr);
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

/**
 * Restores an archived space back to active status.
 */
export async function unarchiveSpace(spaceId: string, currentUserId: string): Promise<void> {
  const path = `spaces/${spaceId}`;
  try {
    const spaceRef = doc(db, 'spaces', spaceId);
    const snap = await getDocFromServer(spaceRef);
    if (!snap.exists()) {
      throw new Error(`Space ${spaceId} not found.`);
    }
    const data = snap.data() as Space;
    if (data.ownerId !== currentUserId) {
      throw new Error('PERMISSION_DENIED: Only the owner can restore this space.');
    }

    await updateDoc(spaceRef, {
      isArchived: false,
      updatedAt: new Date().toISOString()
    });

    try {
      const actorName = data.members?.find((m) => m.id === currentUserId)?.name || (auth?.currentUser?.displayName) || 'User';
      await recordAuditLog(spaceId, {
        id: `audit_${Date.now()}_unarchive`,
        spaceId,
        action: 'SPACE_UNARCHIVED',
        actorId: currentUserId,
        actorName,
        targetType: 'space',
        targetId: spaceId,
        details: `Space "${data.name}" restored from archive.`,
        timestamp: new Date().toISOString()
      });
    } catch (auditErr) {
      console.warn('Audit log write notice:', auditErr);
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

/**
 * Permanently deletes a space after strict server-side verification, unlocked eligibility check,
 * and explicit confirmation. Explicitly performs cascade deletion of all subcollection documents
 * (transactions and audit_logs) before removing the parent document.
 */
export async function deleteEmptySpace(
  spaceId: string,
  currentUserId: string,
  confirmationSpaceName: string
): Promise<void> {
  const path = `spaces/${spaceId}`;
  try {
    const spaceRef = doc(db, 'spaces', spaceId);
    let spaceData: Space | null = null;
    try {
      const snap = await getDocFromServer(spaceRef);
      if (snap.exists()) {
        spaceData = snap.data() as Space;
      }
    } catch {
      // offline / guest fallback
    }

    if (!spaceData) {
      try {
        const guestSpacesRaw = localStorage.getItem('hisaab_guest_spaces');
        if (guestSpacesRaw) {
          const guestSpaces = JSON.parse(guestSpacesRaw) as Space[];
          spaceData = guestSpaces.find((s) => s.id === spaceId) || null;
        }
      } catch (err) {
        console.warn('Guest lookup notice:', err);
      }
    }

    if (!spaceData) {
      throw new Error(`Space ${spaceId} does not exist on the server or locally.`);
    }

    const isOwner = spaceData.ownerId === currentUserId || currentUserId.startsWith('guest_') || !spaceData.ownerId;
    if (!isOwner) {
      throw new Error('PERMISSION_DENIED: Only the space owner can delete this space.');
    }

    if (spaceData.name.trim().toLowerCase() !== confirmationSpaceName.trim().toLowerCase()) {
      throw new Error('NAME_CONFIRMATION_MISMATCH: The confirmed space name does not match.');
    }

    // Verify eligibility under unlocked rules: (a), (b), or (c)
    const eligibility = await checkSpaceDeletionEligibility(spaceId, currentUserId);
    if (!eligibility.canDelete) {
      throw new Error(`DELETION_BLOCKED: ${eligibility.reason}`);
    }

    // 1. Explicit Cascade Cleanup: Delete all subcollection transactions
    const txCol = collection(db, 'spaces', spaceId, 'transactions');
    try {
      const txSnap = await getDocs(txCol);
      for (const tDoc of txSnap.docs) {
        await deleteDoc(tDoc.ref);
      }
    } catch (txErr) {
      console.warn('Subcollection transactions delete notice:', txErr);
    }

    // 2. Explicit Cascade Cleanup: Delete all subcollection audit logs
    const auditCol = collection(db, 'spaces', spaceId, 'audit_logs');
    try {
      const auditSnap = await getDocs(auditCol);
      for (const aDoc of auditSnap.docs) {
        await deleteDoc(aDoc.ref);
      }
    } catch (auditErr) {
      console.warn('Subcollection audit logs delete notice:', auditErr);
    }

    // 3. Delete parent space document from Firestore
    await deleteDoc(spaceRef);

    // 4. Verify server read-after-delete
    try {
      const verifySnap = await getDocFromServer(spaceRef);
      if (verifySnap.exists()) {
        throw new Error('DELETE_VERIFICATION_FAILED: Space document still exists on server.');
      }
      const verifyTxSnap = await getDocs(txCol);
      if (!verifyTxSnap.empty) {
        throw new Error('DELETE_VERIFICATION_FAILED: Subcollection transactions still exist on server.');
      }
    } catch (verifyErr: any) {
      if (verifyErr?.message?.includes('DELETE_VERIFICATION_FAILED')) {
        throw verifyErr;
      }
      // Non-existence or permission-denied confirms deletion
    }

    // 5. Clean up local storage caches
    try {
      const guestSpacesRaw = localStorage.getItem('hisaab_guest_spaces');
      if (guestSpacesRaw) {
        const parsed = JSON.parse(guestSpacesRaw) as Space[];
        const filtered = parsed.filter((s) => s.id !== spaceId);
        localStorage.setItem('hisaab_guest_spaces', JSON.stringify(filtered));
      }
      const activeStored = localStorage.getItem('hisaab_active_space_id');
      if (activeStored === spaceId) {
        localStorage.removeItem('hisaab_active_space_id');
      }
      const userActiveStored = localStorage.getItem(`hisaab_active_space_${currentUserId}`);
      if (userActiveStored === spaceId) {
        localStorage.removeItem(`hisaab_active_space_${currentUserId}`);
      }
    } catch (lsErr) {
      console.warn('Local cache purge notice:', lsErr);
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export const deleteSpaceWithCascade = deleteEmptySpace;

/**
 * Server-authoritative query for spaces where current user is a member
 */
export async function fetchServerUserSpaces(userId: string): Promise<Space[]> {
  const q = query(
    collection(db, 'spaces'),
    where('memberIds', 'array-contains', userId)
  );
  const snap = await getDocs(q);
  const spaces: Space[] = [];
  snap.forEach((docSnap) => {
    const sp = docSnap.data() as Space;
    spaces.push({
      ...sp,
      isCloudConfirmed: true,
      source: 'cloud-authoritative'
    });
  });
  return spaces;
}

/**
 * Subscribes to spaces where current user is owner or member
 */
export function subscribeToUserSpaces(
  userId: string,
  onSpaces: (spaces: Space[]) => void,
  onError: (error: Error) => void
): Unsubscribe {
  const path = 'spaces';
  try {
    const q = query(
      collection(db, 'spaces'),
      where('memberIds', 'array-contains', userId)
    );

    return onSnapshot(
      q,
      (snapshot) => {
        const spaces: Space[] = [];
        snapshot.forEach((docSnap) => {
          const sp = docSnap.data() as Space;
          spaces.push({
            ...sp,
            isCloudConfirmed: true,
            source: 'cloud-authoritative'
          });
        });

        // Merge any local provisional spaces not yet reflected on the cloud
        const provisional = getProvisionalSpaces(userId);
        for (const p of provisional) {
          if (!spaces.some((s) => s.id === p.id)) {
            spaces.unshift(p);
          }
        }

        onSpaces(spaces);
      },
      (error) => {
        console.warn(`Firestore subscription error on ${path}:`, error.message);
        // On offline/cache error, still deliver any local provisional spaces
        const provisional = getProvisionalSpaces(userId);
        if (provisional.length > 0) {
          onSpaces(provisional);
        } else {
          onError(error);
        }
      }
    );
  } catch (error) {
    console.warn(`Firestore query creation error on ${path}:`, error);
    onError(error instanceof Error ? error : new Error(String(error)));
    return () => {};
  }
}

/**
 * Subscribes to real-time transactions within a space
 */
export function subscribeToTransactions(
  spaceId: string,
  onTransactions: (transactions: Transaction[]) => void,
  onError: (error: Error) => void
): Unsubscribe {
  const path = `spaces/${spaceId}/transactions`;
  try {
    const colRef = collection(db, 'spaces', spaceId, 'transactions');
    return onSnapshot(
      colRef,
      (snapshot) => {
        const list: Transaction[] = [];
        snapshot.forEach((docSnap) => {
          list.push(docSnap.data() as Transaction);
        });

        // Merge local transactions cached while offline
        try {
          if (typeof localStorage !== 'undefined') {
            const raw = localStorage.getItem(`hisaab_local_tx_${spaceId}`);
            if (raw) {
              const localList = JSON.parse(raw) as Transaction[];
              for (const ltx of localList) {
                if (!list.some((t) => t.id === ltx.id)) {
                  list.unshift(ltx);
                }
              }
            }
          }
        } catch {}

        list.sort((a, b) => {
          const dateDiff = new Date(b.date).getTime() - new Date(a.date).getTime();
          if (dateDiff !== 0) return dateDiff;
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
        });
        onTransactions(list);
      },
      (error) => {
        console.warn(`Firestore subscription error on ${path}:`, error.message);
        // On offline error, deliver local cached transactions if available
        try {
          if (typeof localStorage !== 'undefined') {
            const raw = localStorage.getItem(`hisaab_local_tx_${spaceId}`);
            if (raw) {
              const localList = JSON.parse(raw) as Transaction[];
              onTransactions(localList);
              return;
            }
          }
        } catch {}
        onError(error);
      }
    );
  } catch (error) {
    console.warn(`Firestore collection error on ${path}:`, error);
    onError(error instanceof Error ? error : new Error(String(error)));
    return () => {};
  }
}

/**
 * Subscribes to real-time audit logs within a space
 */
export function subscribeToAuditLogs(
  spaceId: string,
  onLogs: (logs: AuditLog[]) => void
): Unsubscribe {
  const path = `spaces/${spaceId}/audit_logs`;
  try {
    const colRef = collection(db, 'spaces', spaceId, 'audit_logs');
    return onSnapshot(
      colRef,
      (snapshot) => {
        const list: AuditLog[] = [];
        snapshot.forEach((docSnap) => {
          list.push(docSnap.data() as AuditLog);
        });
        list.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
        onLogs(list);
      },
      (error) => {
        console.warn('Audit logs listener note:', error);
      }
    );
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
  }
}

/**
 * Recursively cleans an object to ensure no keys have `undefined` values,
 * which Firestore strictly rejects with "Unsupported field value: undefined".
 * Undefined properties are omitted completely from the payload.
 */
export function sanitizeForFirestore<T extends Record<string, any>>(obj: T): T {
  if (obj === null || typeof obj !== 'object') {
    return obj;
  }

  if (Array.isArray(obj)) {
    return obj
      .filter((item) => item !== undefined)
      .map((item) => sanitizeForFirestore(item)) as unknown as T;
  }

  const cleaned: Record<string, any> = {};
  for (const [key, value] of Object.entries(obj)) {
    if (value !== undefined) {
      if (value !== null && typeof value === 'object') {
        cleaned[key] = sanitizeForFirestore(value);
      } else {
        cleaned[key] = value;
      }
    }
  }
  return cleaned as T;
}

/**
 * Validates and normalizes transaction payloads according to domain semantics.
 * Critical guarantees:
 * 1. For 'expense' and 'income': 'paidToId' is omitted completely (never undefined).
 * 2. For 'transfer' and 'settlement': 'paidToId' is validated to exist and differ from 'payerId'.
 * 3. Monetary amounts must be strictly positive integer minor units.
 * 4. All undefined values are stripped so Firestore setDoc never throws Unsupported field value: undefined.
 */
export function normalizeTransactionPayload(tx: Transaction): Record<string, any> {
  if (!tx.id || !tx.spaceId || !tx.creatorId || !tx.title || !tx.type || typeof tx.amount !== 'number') {
    throw new Error('INVALID_ARGUMENT: Transaction missing core required fields (id, spaceId, creatorId, title, type, amount).');
  }

  if (tx.amount <= 0 || !Number.isInteger(tx.amount)) {
    throw new Error('INVALID_ARGUMENT: Transaction amount must be a positive integer in minor units.');
  }

  if (tx.type === 'transfer' || tx.type === 'settlement') {
    if (!tx.paidToId || !tx.paidToId.trim()) {
      throw new Error(`INVALID_ARGUMENT: ${tx.type === 'settlement' ? 'Settlement' : 'Transfer'} requires a valid recipient (paidToId).`);
    }
    if (tx.paidToId === tx.payerId) {
      throw new Error('INVALID_ARGUMENT: Payer and recipient cannot be the same member.');
    }
  }

  const payload: Record<string, any> = {
    id: tx.id,
    spaceId: tx.spaceId,
    creatorId: tx.creatorId,
    title: tx.title.trim(),
    type: tx.type,
    category: tx.category || 'General',
    amount: Math.round(tx.amount),
    date: tx.date || new Date().toISOString().split('T')[0],
    payerId: tx.payerId,
    paymentMethod: tx.paymentMethod || 'UPI',
    createdAt: tx.createdAt || new Date().toISOString()
  };

  // Only attach paidToId when applicable (transfer or settlement)
  if ((tx.type === 'transfer' || tx.type === 'settlement') && tx.paidToId && tx.paidToId.trim()) {
    payload.paidToId = tx.paidToId.trim();
  }

  // Only attach splitType and splits when applicable (expense)
  if (tx.type === 'expense') {
    if (tx.splitType && tx.splitType !== 'none') {
      payload.splitType = tx.splitType;
      if (Array.isArray(tx.splits) && tx.splits.length > 0) {
        payload.splits = tx.splits.map((s) => ({
          memberId: s.memberId,
          shareMinorUnits: Math.round(s.shareMinorUnits),
          ...(typeof s.percentage === 'number' ? { percentage: s.percentage } : {})
        }));
      }
    } else {
      payload.splitType = 'none';
    }
  }

  // Optional string fields: only attach if non-empty string
  if (tx.notes && tx.notes.trim()) {
    payload.notes = tx.notes.trim();
  }
  if (tx.receiptUrl && tx.receiptUrl.trim()) {
    payload.receiptUrl = tx.receiptUrl.trim();
  }

  // Version sequence
  payload.version = typeof tx.version === 'number' ? tx.version : 1;

  // Reversal metadata
  if (tx.isReversal) {
    payload.isReversal = true;
    if (tx.reversesTransactionId) payload.reversesTransactionId = tx.reversesTransactionId;
  }
  if (tx.isReversed) {
    payload.isReversed = true;
    if (tx.reversedAt) payload.reversedAt = tx.reversedAt;
    if (tx.reversedBy) payload.reversedBy = tx.reversedBy;
  }

  // Converted currency metadata
  if (tx.originalCurrency) payload.originalCurrency = tx.originalCurrency;
  if (typeof tx.originalAmountMinorUnits === 'number') payload.originalAmountMinorUnits = tx.originalAmountMinorUnits;
  if (typeof tx.exchangeRateBasisPoints === 'number') payload.exchangeRateBasisPoints = tx.exchangeRateBasisPoints;

  // SPLITO Wallet Pay metadata
  if (tx.paymentStatus) {
    payload.paymentStatus = tx.paymentStatus;
  }
  if (tx.paymentApp && tx.paymentApp.trim()) {
    payload.paymentApp = tx.paymentApp.trim();
  }
  if (tx.paymentAppLabel && tx.paymentAppLabel.trim()) {
    payload.paymentAppLabel = tx.paymentAppLabel.trim();
  }
  if (tx.upiPayeeVpa && tx.upiPayeeVpa.trim()) {
    payload.upiPayeeVpa = tx.upiPayeeVpa.trim();
  }
  if (tx.upiPayeeName && tx.upiPayeeName.trim()) {
    payload.upiPayeeName = tx.upiPayeeName.trim();
  }
  if (tx.paymentAttemptedAt && tx.paymentAttemptedAt.trim()) {
    payload.paymentAttemptedAt = tx.paymentAttemptedAt.trim();
  }
  if (tx.paymentConfirmedAt && tx.paymentConfirmedAt.trim()) {
    payload.paymentConfirmedAt = tx.paymentConfirmedAt.trim();
  }

  return sanitizeForFirestore(payload);
}

/**
 * Saves (creates) a new transaction in Firestore with strict serialization,
 * server read-after-write verification, and offline-tolerant outbox fallback.
 */
export async function addTransaction(spaceId: string, transaction: Transaction): Promise<Transaction> {
  const path = `spaces/${spaceId}/transactions/${transaction.id}`;
  const normalized = normalizeTransactionPayload(transaction);

  // Fast offline path: persist to local cache immediately and enqueue in durable outbox
  if (!isOnline()) {
    const offlineTx: Transaction = {
      ...(normalized as Transaction),
      isCloudConfirmed: false
    };
    saveLocalTransaction(spaceId, offlineTx);
    await enqueueOperation('ADD_TRANSACTION', spaceId, transaction.id, offlineTx);
    return offlineTx;
  }

  try {
    const txDocRef = doc(db, 'spaces', spaceId, 'transactions', transaction.id);
    await setDoc(txDocRef, { ...normalized, isCloudConfirmed: true });

    // Verify server read-after-write
    try {
      const serverSnap = await getDocFromServer(txDocRef);
      if (!serverSnap.exists()) {
        throw new Error(`Write verification failed: Transaction ${transaction.id} could not be confirmed on the cloud.`);
      }
    } catch (readErr) {
      console.warn('Transaction read-after-write server check notice:', readErr);
    }

    saveLocalTransaction(spaceId, { ...(normalized as Transaction), isCloudConfirmed: true });

    // Record audit log with sanitized payload
    try {
      await recordAuditLog(spaceId, {
        id: `audit_${Date.now()}_tx`,
        spaceId,
        action: transaction.type === 'settlement' ? 'SETTLEMENT_RECORDED' : 'TRANSACTION_CREATED',
        actorId: transaction.creatorId,
        actorName: 'Member',
        targetType: 'transaction',
        targetId: transaction.id,
        details: `${transaction.type.toUpperCase()}: "${transaction.title}" for ${transaction.amount} minor units`,
        timestamp: new Date().toISOString()
      });
    } catch {
      // Audit notice
    }

    return { ...(normalized as Transaction), isCloudConfirmed: true };
  } catch (error: any) {
    const errMsg = error instanceof Error ? error.message : String(error);
    const isNetworkError =
      errMsg.includes('the client is offline') ||
      errMsg.includes('network-request-failed') ||
      errMsg.includes('unavailable') ||
      errMsg.includes('could not be confirmed on the cloud') ||
      (error && error.code === 'unavailable');

    if (isNetworkError) {
      const offlineTx: Transaction = {
        ...(normalized as Transaction),
        isCloudConfirmed: false
      };
      saveLocalTransaction(spaceId, offlineTx);
      await enqueueOperation('ADD_TRANSACTION', spaceId, transaction.id, offlineTx);
      return offlineTx;
    }

    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

// Register queue executors for background offline synchronization
registerQueueExecutor('CREATE_SPACE', async (op) => {
  const spaceData = op.payload as Space;
  try {
    const spaceRef = doc(db, 'spaces', spaceData.id);
    await setDoc(spaceRef, { ...spaceData, isCloudConfirmed: true, source: 'cloud-authoritative' });
    const serverSnap = await getDocFromServer(spaceRef);
    if (!serverSnap.exists()) {
      return { success: false, error: 'Server read confirmation failed' };
    }
    if (auth.currentUser) {
      removeProvisionalSpace(auth.currentUser.uid, spaceData.id);
    }
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err instanceof Error ? err.message : String(err) };
  }
});

registerQueueExecutor('ADD_TRANSACTION', async (op) => {
  const tx = op.payload as Transaction;
  try {
    const txRef = doc(db, 'spaces', op.targetSpaceId, 'transactions', tx.id);
    const normalized = normalizeTransactionPayload({ ...tx, isCloudConfirmed: true });
    await setDoc(txRef, normalized);
    const serverSnap = await getDocFromServer(txRef);
    if (!serverSnap.exists()) {
      return { success: false, error: 'Server read confirmation failed' };
    }
    saveLocalTransaction(op.targetSpaceId, { ...tx, isCloudConfirmed: true });
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err instanceof Error ? err.message : String(err) };
  }
});

registerQueueExecutor('UPDATE_SPACE', async (op) => {
  try {
    const spaceRef = doc(db, 'spaces', op.targetSpaceId);
    await updateDoc(spaceRef, op.payload);
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err instanceof Error ? err.message : String(err) };
  }
});

registerQueueExecutor('REVERSE_TRANSACTION', async (op) => {
  try {
    const { originalUpdated, reversalTx } = op.payload;
    const batch = writeBatch(db);
    batch.set(doc(db, 'spaces', op.targetSpaceId, 'transactions', originalUpdated.id), originalUpdated);
    batch.set(doc(db, 'spaces', op.targetSpaceId, 'transactions', reversalTx.id), reversalTx);
    await batch.commit();
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err instanceof Error ? err.message : String(err) };
  }
});

/**
 * Immutably reverses a transaction rather than destructive deletion
 */
export async function reverseLedgerTransaction(
  spaceId: string,
  originalTx: Transaction,
  actorId: string,
  actorName: string,
  reason: string = 'User requested reversal'
): Promise<{ originalUpdated: Transaction; reversalTx: Transaction }> {
  const { originalUpdated, reversalTx } = createReversalTransaction(originalTx, actorId, reason);

  try {
    // 1. Update original transaction with reversal flags
    const sanitizedOriginal = sanitizeForFirestore({
      isReversed: true,
      reversedAt: originalUpdated.reversedAt,
      reversedBy: originalUpdated.reversedBy,
      version: originalUpdated.version
    });
    await updateDoc(doc(db, 'spaces', spaceId, 'transactions', originalTx.id), sanitizedOriginal);

    // 2. Add the reversal transaction
    const normalizedReversal = normalizeTransactionPayload(reversalTx);
    await setDoc(doc(db, 'spaces', spaceId, 'transactions', reversalTx.id), normalizedReversal);

    // 3. Append to immutable audit log
    await recordAuditLog(spaceId, {
      id: `audit_${Date.now()}_rev`,
      spaceId,
      action: 'TRANSACTION_REVERSED',
      actorId,
      actorName,
      targetType: 'transaction',
      targetId: originalTx.id,
      details: `Reversed transaction #${originalTx.id.slice(-6)} ("${originalTx.title}"): ${reason}`,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.warn('Error during reversal:', error);
  }

  return { originalUpdated, reversalTx };
}

/**
 * Updates a transaction in Firestore
 */
export async function updateTransaction(
  spaceId: string,
  transactionId: string,
  updates: Partial<Transaction>
): Promise<void> {
  const path = `spaces/${spaceId}/transactions/${transactionId}`;
  try {
    const sanitizedUpdates = sanitizeForFirestore({
      ...updates,
      version: (updates.version || 1) + 1
    });
    await updateDoc(doc(db, 'spaces', spaceId, 'transactions', transactionId), sanitizedUpdates);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

/**
 * Hard deletion fallback (if user strictly requests deletion rather than reversal)
 */
export async function deleteTransaction(spaceId: string, transactionId: string): Promise<void> {
  const path = `spaces/${spaceId}/transactions/${transactionId}`;
  try {
    await deleteDoc(doc(db, 'spaces', spaceId, 'transactions', transactionId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

/**
 * Records an immutable audit log entry
 */
export async function recordAuditLog(spaceId: string, log: AuditLog): Promise<void> {
  const path = `spaces/${spaceId}/audit_logs/${log.id}`;
  try {
    const sanitized = sanitizeForFirestore(log);
    await setDoc(doc(db, 'spaces', spaceId, 'audit_logs', log.id), sanitized);
  } catch (error) {
    console.warn('Audit log write error:', error);
  }
}

/**
 * Updates user's active space preference in Firestore using setDoc merge to guarantee atomic persistence
 */
export async function updateUserActiveSpace(userId: string, activeSpaceId: string): Promise<void> {
  const userPath = `users/${userId}`;
  try {
    const userDocRef = doc(db, 'users', userId);
    await setDoc(
      userDocRef,
      {
        activeSpaceId,
        updatedAt: new Date().toISOString()
      },
      { merge: true }
    );
  } catch (error) {
    console.warn('Could not update active space in Firestore user profile:', error);
  }
}

/**
 * Data-Only Deletion: Permanently erases personal spaces and entries while KEEPING account and login intact
 */
export async function deleteUserPersonalData(userId: string): Promise<{ deletedPersonalSpacesCount: number; anonymizedSharedSpacesCount: number }> {
  if (!userId || userId.startsWith('guest_')) {
    // Clear local storage guest session spaces
    localStorage.removeItem('hisaab_guest_spaces');
    localStorage.removeItem(`hisaab_active_space_${userId}`);
    localStorage.removeItem('hisaab_active_space');
    return { deletedPersonalSpacesCount: 1, anonymizedSharedSpacesCount: 0 };
  }

  let deletedPersonalSpacesCount = 0;
  let anonymizedSharedSpacesCount = 0;

  try {
    // 1. Fetch spaces where user is a member or owner using array-contains (supported by firestore.rules)
    const spacesRef = collection(db, 'spaces');
    const q = query(spacesRef, where('memberIds', 'array-contains', userId));
    const snap = await getDocs(q);

    for (const spaceDoc of snap.docs) {
      const spaceData = spaceDoc.data() as Space;
      const isPersonal = spaceData.mode === 'personal' ||
        (spaceData.ownerId === userId && (!spaceData.members || spaceData.members.length <= 1));

      if (isPersonal) {
        // Cascade delete subcollection: transactions
        const txCol = collection(db, 'spaces', spaceDoc.id, 'transactions');
        try {
          const txSnap = await getDocs(txCol);
          for (const tDoc of txSnap.docs) {
            await deleteDoc(tDoc.ref);
          }
        } catch (txErr) {
          console.warn(`Cascade transactions delete notice for space ${spaceDoc.id}:`, txErr);
        }

        // Cascade delete subcollection: audit logs
        const auditCol = collection(db, 'spaces', spaceDoc.id, 'audit_logs');
        try {
          const auditSnap = await getDocs(auditCol);
          for (const aDoc of auditSnap.docs) {
            await deleteDoc(aDoc.ref);
          }
        } catch (auditErr) {
          console.warn(`Cascade audit logs delete notice for space ${spaceDoc.id}:`, auditErr);
        }

        // Delete parent personal space document
        await deleteDoc(doc(db, 'spaces', spaceDoc.id));
        deletedPersonalSpacesCount++;
      } else {
        // Shared space (Roommates, Family, Trip):
        // NEVER delete shared space or other members' transactions/records!
        // Anonymize the user's identifying details in members list
        const updatedMembers = (spaceData.members || []).map((m: any) =>
          m.id === userId ? { id: userId, name: 'Former Member' } : m
        );
        await updateDoc(doc(db, 'spaces', spaceDoc.id), {
          members: updatedMembers
        });
        anonymizedSharedSpacesCount++;
      }
    }

    // 2. Clear user-specific active space cache so app returns to clean empty state or remaining shared space
    localStorage.removeItem(`hisaab_active_space_${userId}`);
    localStorage.removeItem('hisaab_active_space');
    localStorage.removeItem('hisaab_guest_spaces');

    return { deletedPersonalSpacesCount, anonymizedSharedSpacesCount };
  } catch (err) {
    console.error('Personal data deletion error:', err);
    throw err;
  }
}

/**
 * Account Deletion: Permanently erases user account, profile, and auth credentials
 */
export async function deleteUserAccountAndData(userId: string): Promise<void> {
  if (!userId || userId.startsWith('guest_')) {
    // Clear local storage guest session
    localStorage.clear();
    return;
  }

  try {
    // 1. First perform full personal data and shared-space anonymization
    await deleteUserPersonalData(userId);

    // 2. Delete user profile doc in Firestore
    try {
      await deleteDoc(doc(db, 'users', userId));
    } catch (userDocErr) {
      console.warn('User profile document delete notice:', userDocErr);
    }

    // 3. Clear all remaining local storage caches
    localStorage.removeItem(`hisaab_active_space_${userId}`);
    localStorage.removeItem(`splito_user_subscription_${userId}`);
    localStorage.removeItem('splito_user_subscription');
    localStorage.removeItem('splito_auth_choice');
    localStorage.removeItem('splito_consent_preferences');

    // 4. Delete Firebase Auth user credentials
    if (auth.currentUser && auth.currentUser.uid === userId) {
      try {
        await auth.currentUser.delete();
      } catch (authErr: any) {
        if (authErr?.code === 'auth/requires-recent-login' || authErr?.message?.includes('requires-recent-login')) {
          throw new Error('REAUTH_REQUIRED: Deleting your Google login credentials requires a fresh login. Please sign out, sign back in, and try again.');
        }
        console.warn('Firebase user delete notice, signing out:', authErr);
        await auth.signOut();
      }
    }
  } catch (err) {
    console.error('Account deletion error:', err);
    throw err;
  }
}

