import {
  collection,
  doc,
  getDoc,
  getDocFromServer,
  getDocs,
  onSnapshot,
  query,
  setDoc,
  updateDoc,
  deleteDoc,
  writeBatch,
  where,
  Unsubscribe
} from 'firebase/firestore';
import { db, auth, handleFirestoreError, OperationType } from './firebase.ts';
import { isOnline } from './network-service.ts';
import {
  enqueueOperation,
  registerQueueExecutor,
  getPendingOperationsForSpace,
  cancelPendingOperationsForSpace,
  QueuedOperation
} from './offline-queue.ts';
import { resolveEntityConflict } from './conflict-resolver.ts';
import {
  Space,
  Transaction,
  UserProfile,
  SpaceMode,
  CurrencyCode,
  Member,
  AuditLog
} from '../types/finance.ts';
import {
  createReversalTransaction,
  getActiveLedgerTransactions,
  calculateGroupBalances,
  formatPaise
} from './finance-engine.ts';

export const DEFAULT_CATEGORIES_BY_MODE: Record<SpaceMode, string[]> = {
  roommates: [
    'Rent',
    'Groceries',
    'WiFi & Cable',
    'Maid & Cook',
    'Electricity',
    'Water',
    'Maintenance',
    'Snacks & Drinks',
    'Household Items',
    'Other'
  ],
  personal: [
    'Salary & Income',
    'Groceries & Food',
    'Dining Out',
    'Commute & Fuel',
    'Shopping',
    'Subscriptions & Bills',
    'Health & Medicine',
    'Entertainment',
    'Personal Care',
    'Savings & Investments',
    'Other'
  ],
  family: [
    'Rations & Groceries',
    'School & Education',
    'Rent & EMI',
    'Utilities & Bills',
    'Medical & Healthcare',
    'Domestic Help',
    'Home Maintenance',
    'Festivals & Gifts',
    'Travel & Outings',
    'Other'
  ],
  trip: [
    'Flights & Transit',
    'Hotels & Stay',
    'Food & Dining',
    'Sightseeing & Entry',
    'Activities & Sports',
    'Shopping & Souvenirs',
    'Fuel & Cabs',
    'Snacks & Drinks',
    'Emergency',
    'Other'
  ]
};

const USER_PROFILE_PREFIX = 'hisaab_user_profile_';

export function getLocalUserProfile(userId: string): UserProfile | null {
  try {
    if (typeof localStorage === 'undefined' || !userId) return null;
    const raw = localStorage.getItem(`${USER_PROFILE_PREFIX}${userId}`);
    return raw ? (JSON.parse(raw) as UserProfile) : null;
  } catch {
    return null;
  }
}

export function saveLocalUserProfile(profile: UserProfile): void {
  try {
    if (typeof localStorage === 'undefined' || !profile?.userId) return;
    localStorage.setItem(`${USER_PROFILE_PREFIX}${profile.userId}`, JSON.stringify(profile));
  } catch {
    // Ignore
  }
}

/**
 * Creates or gets an existing user profile in Firestore (local-first when offline)
 */
export async function syncUserProfile(
  userId: string,
  email: string | null,
  displayName: string,
  initialMode: SpaceMode = 'roommates'
): Promise<UserProfile> {
  const userPath = `users/${userId}`;
  const cachedProfile = getLocalUserProfile(userId);
  const fallbackProfile: UserProfile = cachedProfile || {
    userId,
    email: email || '',
    displayName: displayName || (email ? email.split('@')[0] : 'User'),
    primaryMode: initialMode,
    activeSpaceId: '',
    currency: 'INR',
    createdAt: new Date().toISOString()
  };

  if (!isOnline()) {
    saveLocalUserProfile(fallbackProfile);
    return fallbackProfile;
  }

  try {
    const userDocRef = doc(db, 'users', userId);
    const snap = await getDoc(userDocRef);

    if (snap.exists()) {
      const data = snap.data() as UserProfile;
      saveLocalUserProfile(data);
      return data;
    }

    // Check if user already has spaces in Firestore to prevent duplicate seeding
    const spacesQuery = query(
      collection(db, 'spaces'),
      where('memberIds', 'array-contains', userId)
    );
    const existingSpacesSnap = await getDocs(spacesQuery);

    if (!existingSpacesSnap.empty) {
      const existingSpace = existingSpacesSnap.docs[0].data() as Space;
      const newProfile: UserProfile = {
        userId,
        email: email || '',
        displayName: displayName || (email ? email.split('@')[0] : 'User'),
        primaryMode: existingSpace.mode || initialMode,
        activeSpaceId: existingSpace.id,
        currency: existingSpace.currency || 'INR',
        createdAt: new Date().toISOString()
      };
      await setDoc(userDocRef, newProfile);
      saveLocalUserProfile(newProfile);
      return newProfile;
    }

    // Clean initialization: A new user starts with 0 spaces, 0 members, 0 transactions.
    // They will create their first real space via the UI.
    const newProfile: UserProfile = {
      userId,
      email: email || '',
      displayName: displayName || (email ? email.split('@')[0] : 'User'),
      primaryMode: initialMode,
      activeSpaceId: '',
      currency: 'INR',
      createdAt: new Date().toISOString()
    };

    await setDoc(userDocRef, newProfile);
    saveLocalUserProfile(newProfile);
    return newProfile;
  } catch (error) {
    if (cachedProfile || !isOnline()) {
      return fallbackProfile;
    }
    handleFirestoreError(error, OperationType.WRITE, userPath);
  }
}

/**
 * Seeds initial shared living expenses for 3 roommates
 */
export async function seedThreeRoommatesTransactions(
  spaceId: string,
  himanshuId: string,
  alexId: string,
  jordanId: string
): Promise<Transaction[]> {
  const today = new Date().toISOString().split('T')[0];

  const transactions: Transaction[] = [
    {
      id: `tx_${Date.now()}_1`,
      spaceId,
      creatorId: himanshuId,
      title: 'Flat 402 Rent (Monthly)',
      type: 'expense',
      category: 'Rent',
      amount: 4500000, // ₹45,000.00
      date: today,
      payerId: himanshuId,
      paymentMethod: 'Net Banking',
      splitType: 'equal',
      splits: [
        { memberId: himanshuId, shareMinorUnits: 1500000 },
        { memberId: alexId, shareMinorUnits: 1500000 },
        { memberId: jordanId, shareMinorUnits: 1500000 }
      ],
      notes: 'Transferred directly to Landlord via RTGS',
      version: 1,
      createdAt: new Date(Date.now() - 7200000).toISOString()
    },
    {
      id: `tx_${Date.now()}_2`,
      spaceId,
      creatorId: himanshuId,
      title: 'Airtel Xstream Fiber 300Mbps',
      type: 'expense',
      category: 'WiFi & Cable',
      amount: 149900, // ₹1,499.00
      date: today,
      payerId: alexId,
      paymentMethod: 'UPI',
      splitType: 'equal',
      splits: [
        { memberId: himanshuId, shareMinorUnits: 50000 },
        { memberId: alexId, shareMinorUnits: 49950 },
        { memberId: jordanId, shareMinorUnits: 49950 }
      ],
      notes: 'Monthly broadband renewal',
      version: 1,
      createdAt: new Date(Date.now() - 3600000).toISOString()
    },
    {
      id: `tx_${Date.now()}_3`,
      spaceId,
      creatorId: himanshuId,
      title: 'Cook & Housekeeping Wages',
      type: 'expense',
      category: 'Maid & Cook',
      amount: 600000, // ₹6,000.00
      date: today,
      payerId: jordanId,
      paymentMethod: 'Cash',
      splitType: 'equal',
      splits: [
        { memberId: himanshuId, shareMinorUnits: 200000 },
        { memberId: alexId, shareMinorUnits: 200000 },
        { memberId: jordanId, shareMinorUnits: 200000 }
      ],
      notes: 'Paid cash with signed register receipt',
      version: 1,
      createdAt: new Date().toISOString()
    }
  ];

  for (const tx of transactions) {
    try {
      await setDoc(doc(db, 'spaces', spaceId, 'transactions', tx.id), tx);
    } catch (e) {
      // Ignore if offline
    }
  }

  return transactions;
}

export function getModeDefaultSpaceName(mode: SpaceMode): string {
  switch (mode) {
    case 'roommates':
      return 'Flat 402 Roommates';
    case 'family':
      return 'Family Household';
    case 'trip':
      return 'Goa Trip 2026';
    case 'personal':
    default:
      return 'My Personal Diary';
  }
}

export type ErrorCategory =
  | 'unauthenticated'
  | 'permission-denied'
  | 'unavailable'
  | 'deadline-exceeded'
  | 'invalid-argument'
  | 'failed-precondition'
  | 'unknown';

export interface ClassifiedError {
  category: ErrorCategory;
  userMessage: string;
  technicalDetails: string;
  docId?: string;
}

export function classifyFirestoreError(error: unknown, docId?: string): ClassifiedError {
  const msg = error instanceof Error ? error.message : String(error);
  const lower = msg.toLowerCase();

  let category: ErrorCategory = 'unknown';
  let userMessage = 'An unexpected cloud ledger error occurred. Your inputs have been kept safe.';

  if (
    lower.includes('unauthenticated') ||
    lower.includes('not signed in') ||
    lower.includes('auth/no-current-user') ||
    lower.includes('auth-expired') ||
    lower.includes('token')
  ) {
    category = 'unauthenticated';
    userMessage = 'Your sign-in session is unauthenticated or expired. Please sign in to verify your ledger.';
  } else if (
    lower.includes('permission') ||
    lower.includes('insufficient') ||
    lower.includes('access-denied')
  ) {
    category = 'permission-denied';
    userMessage = 'Permission denied by cloud ledger security rules. Verify space membership and ownership.';
  } else if (
    lower.includes('unavailable') ||
    lower.includes('network') ||
    lower.includes('offline')
  ) {
    category = 'unavailable';
    userMessage = 'Firestore service unavailable or offline. Write could not be confirmed on the server.';
  } else if (
    lower.includes('deadline') ||
    lower.includes('timeout')
  ) {
    category = 'deadline-exceeded';
    userMessage = 'Cloud verification timed out waiting for server confirmation. Please retry.';
  } else if (
    lower.includes('invalid') ||
    lower.includes('argument') ||
    lower.includes('schema') ||
    lower.includes('missing')
  ) {
    category = 'invalid-argument';
    userMessage = 'Invalid ledger data or parameters. Please review your input and retry.';
  } else if (
    lower.includes('failed-precondition') ||
    lower.includes('conflict') ||
    lower.includes('verification')
  ) {
    category = 'failed-precondition';
    userMessage = 'Cloud precondition failed: document state could not be verified on the server.';
  }

  return {
    category,
    userMessage,
    technicalDetails: msg,
    docId
  };
}

const PROVISIONAL_SPACES_PREFIX = 'hisaab_provisional_spaces_';
const USER_SPACES_PREFIX = 'hisaab_user_spaces_';
const TOMBSTONES_PREFIX = 'hisaab_deleted_space_tombstones_';

export interface SpaceTombstone {
  spaceId: string;
  userId: string;
  deletedAt: string;
  cloudDeleted: boolean;
}

export function getDeletedSpaceTombstones(userId: string): SpaceTombstone[] {
  try {
    if (typeof localStorage === 'undefined' || !userId) return [];
    const raw = localStorage.getItem(`${TOMBSTONES_PREFIX}${userId}`);
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function isSpaceDeleted(userId: string, spaceId: string): boolean {
  return getDeletedSpaceTombstones(userId).some((t) => t.spaceId === spaceId);
}

export function recordDeletedSpaceTombstone(userId: string, spaceId: string): SpaceTombstone[] {
  try {
    if (typeof localStorage === 'undefined' || !userId) return [];
    const existing = getDeletedSpaceTombstones(userId).filter((t) => t.spaceId !== spaceId);
    const updated: SpaceTombstone[] = [
      ...existing,
      {
        spaceId,
        userId,
        deletedAt: new Date().toISOString(),
        cloudDeleted: false
      }
    ];
    localStorage.setItem(`${TOMBSTONES_PREFIX}${userId}`, JSON.stringify(updated));
    return updated;
  } catch (err) {
    console.warn('Tombstone write notice:', err);
    return [];
  }
}

export function markTombstoneCloudDeleted(userId: string, spaceId: string): void {
  try {
    if (typeof localStorage === 'undefined' || !userId) return;
    const existing = getDeletedSpaceTombstones(userId);
    const updated = existing.map((t) =>
      t.spaceId === spaceId ? { ...t, cloudDeleted: true } : t
    );
    localStorage.setItem(`${TOMBSTONES_PREFIX}${userId}`, JSON.stringify(updated));
  } catch {
    // Ignore
  }
}

export function clearDeletedSpaceTombstone(userId: string, spaceId: string): void {
  try {
    if (typeof localStorage === 'undefined' || !userId) return;
    const existing = getDeletedSpaceTombstones(userId);
    const updated = existing.filter((t) => t.spaceId !== spaceId);
    localStorage.setItem(`${TOMBSTONES_PREFIX}${userId}`, JSON.stringify(updated));
  } catch {
    // Ignore
  }
}

export function filterOutDeletedSpaces(userId: string, spaces: Space[]): Space[] {
  const deletedIds = new Set(getDeletedSpaceTombstones(userId).map((t) => t.spaceId));
  if (deletedIds.size === 0) return spaces;
  return spaces.filter((s) => !deletedIds.has(s.id));
}

export function getProvisionalSpaces(userId: string): Space[] {
  try {
    if (typeof localStorage === 'undefined') return [];
    const raw = localStorage.getItem(`${PROVISIONAL_SPACES_PREFIX}${userId}`);
    const parsed = raw ? (JSON.parse(raw) as Space[]) : [];
    return filterOutDeletedSpaces(userId, Array.isArray(parsed) ? parsed : []);
  } catch {
    return [];
  }
}

export function saveProvisionalSpace(userId: string, space: Space): void {
  try {
    if (typeof localStorage === 'undefined') return;
    if (isSpaceDeleted(userId, space.id)) return;
    const existing = getProvisionalSpaces(userId);
    const updated = existing.filter((s) => s.id !== space.id);
    updated.push(space);
    localStorage.setItem(`${PROVISIONAL_SPACES_PREFIX}${userId}`, JSON.stringify(updated));
  } catch (err) {
    console.warn('Unable to save provisional space locally', err);
  }
}

export function removeProvisionalSpace(userId: string, spaceId: string): void {
  try {
    if (typeof localStorage === 'undefined') return;
    const raw = localStorage.getItem(`${PROVISIONAL_SPACES_PREFIX}${userId}`);
    const existing: Space[] = raw ? JSON.parse(raw) : [];
    const updated = existing.filter((s) => s.id !== spaceId);
    localStorage.setItem(`${PROVISIONAL_SPACES_PREFIX}${userId}`, JSON.stringify(updated));
  } catch {
    // Ignore
  }
}

export function getLocalUserSpaces(userId: string): Space[] {
  try {
    if (typeof localStorage === 'undefined' || !userId) return [];
    const storageKey = userId.startsWith('guest_') ? 'hisaab_guest_spaces' : `${USER_SPACES_PREFIX}${userId}`;
    const raw = localStorage.getItem(storageKey);
    const cached: Space[] = raw ? JSON.parse(raw) : [];
    const provisional = userId.startsWith('guest_') ? [] : getProvisionalSpaces(userId);

    const byId = new Map<string, Space>();
    for (const sp of [...cached, ...provisional]) {
      if (!sp?.id) continue;
      const existing = byId.get(sp.id);
      if (!existing) {
        byId.set(sp.id, sp);
      } else {
        const resolved = resolveEntityConflict(existing, sp).resolvedEntity;
        byId.set(sp.id, resolved);
      }
    }

    return filterOutDeletedSpaces(userId, Array.from(byId.values()));
  } catch {
    return [];
  }
}

export function saveLocalUserSpaces(userId: string, spaces: Space[]): void {
  try {
    if (typeof localStorage === 'undefined' || !userId) return;
    const storageKey = userId.startsWith('guest_') ? 'hisaab_guest_spaces' : `${USER_SPACES_PREFIX}${userId}`;
    const filtered = filterOutDeletedSpaces(userId, spaces);
    const deduped = new Map<string, Space>();
    for (const sp of filtered) {
      if (sp?.id) deduped.set(sp.id, sp);
    }
    localStorage.setItem(storageKey, JSON.stringify(Array.from(deduped.values())));
  } catch (err) {
    console.warn('Local user spaces write notice:', err);
    throw err;
  }
}

export function upsertLocalUserSpace(userId: string, space: Space): Space[] {
  if (isSpaceDeleted(userId, space.id)) {
    return getLocalUserSpaces(userId);
  }
  const existing = getLocalUserSpaces(userId);
  const idx = existing.findIndex((s) => s.id === space.id);
  let next: Space[];
  if (idx >= 0) {
    const resolved = resolveEntityConflict(space, existing[idx]).resolvedEntity;
    next = existing.map((s, i) => (i === idx ? resolved : s));
  } else {
    next = [space, ...existing];
  }
  saveLocalUserSpaces(userId, next);
  return next;
}

export function removeLocalUserSpace(userId: string, spaceId: string): Space[] {
  try {
    if (typeof localStorage !== 'undefined') {
      const userKey = `${USER_SPACES_PREFIX}${userId}`;
      const rawUser = localStorage.getItem(userKey);
      if (rawUser) {
        const parsed = JSON.parse(rawUser) as Space[];
        localStorage.setItem(userKey, JSON.stringify(parsed.filter((s) => s.id !== spaceId)));
      }
      removeProvisionalSpace(userId, spaceId);

      const guestRaw = localStorage.getItem('hisaab_guest_spaces');
      if (guestRaw) {
        const parsedGuest = JSON.parse(guestRaw) as Space[];
        localStorage.setItem('hisaab_guest_spaces', JSON.stringify(parsedGuest.filter((s) => s.id !== spaceId)));
      }

      localStorage.removeItem(`hisaab_local_tx_${spaceId}`);

      if (localStorage.getItem('hisaab_active_space_id') === spaceId) {
        localStorage.removeItem('hisaab_active_space_id');
      }
      if (localStorage.getItem(`hisaab_active_space_${userId}`) === spaceId) {
        localStorage.removeItem(`hisaab_active_space_${userId}`);
      }
      if (localStorage.getItem('hisaab_guest_active_space') === spaceId) {
        localStorage.removeItem('hisaab_guest_active_space');
      }
    }
  } catch (err) {
    console.warn('Local space purge notice:', err);
  }
  return getLocalUserSpaces(userId);
}

/**
 * Safely merges Firestore cloud spaces with local cached/provisional spaces:
 * 1. Filters out tombstoned/deleted spaces so deleted spaces NEVER resurrect.
 * 2. Preserves local provisional spaces and newer local edits (Latest Edit Wins).
 * 3. Never wipes valid local spaces with an empty array when offline or reading stale cache.
 * 4. Persists the merged authoritative result to local storage for instant future offline startups.
 */
export function mergeCloudAndLocalSpaces(
  userId: string,
  cloudSpaces: Space[],
  options?: { fromCache?: boolean }
): Space[] {
  const fromCache = Boolean(options?.fromCache);
  const tombstones = getDeletedSpaceTombstones(userId);
  const deletedIds = new Set(tombstones.map((t) => t.spaceId));

  // Safe cleanup: if a space is marked cloudDeleted AND we got an authoritative server snapshot
  // that no longer contains it, its tombstone can safely be retired.
  if (!fromCache && isOnline()) {
    for (const t of tombstones) {
      if (t.cloudDeleted && !cloudSpaces.some((cs) => cs.id === t.spaceId)) {
        clearDeletedSpaceTombstone(userId, t.spaceId);
      }
    }
  }

  const localSpaces = getLocalUserSpaces(userId);
  const provisionalSpaces = getProvisionalSpaces(userId);
  const localById = new Map<string, Space>();
  for (const l of [...localSpaces, ...provisionalSpaces]) {
    if (!deletedIds.has(l.id)) {
      localById.set(l.id, l);
    }
  }

  const mergedById = new Map<string, Space>();

  // 1. Merge incoming cloud spaces against local edits (Latest Edit Wins + pending ops protection)
  for (const cs of cloudSpaces) {
    if (!cs?.id || deletedIds.has(cs.id)) continue;
    const localMatch = localById.get(cs.id);
    const normalizedCloud: Space = {
      ...cs,
      isCloudConfirmed: true,
      isProvisional: false,
      source: 'cloud-authoritative'
    };

    if (localMatch) {
      const pendingOps = getPendingOperationsForSpace(cs.id);
      if (pendingOps.length > 0) {
        const res = resolveEntityConflict(localMatch, normalizedCloud);
        mergedById.set(cs.id, res.winner === 'local' ? { ...res.resolvedEntity, isCloudConfirmed: false } : normalizedCloud);
      } else {
        const res = resolveEntityConflict(localMatch, normalizedCloud);
        mergedById.set(cs.id, res.winner === 'local' ? res.resolvedEntity : normalizedCloud);
      }
    } else {
      mergedById.set(cs.id, normalizedCloud);
    }
  }

  // 2. Preserve local spaces not yet reflected in the cloud snapshot
  for (const [id, localSp] of localById.entries()) {
    if (deletedIds.has(id) || mergedById.has(id)) continue;
    const pendingOps = getPendingOperationsForSpace(id);
    const hasPendingCreateOrUpdate = pendingOps.length > 0;

    if (localSp.isProvisional || hasPendingCreateOrUpdate || fromCache || !isOnline()) {
      mergedById.set(id, localSp);
    }
  }

  const merged = Array.from(mergedById.values());
  try {
    saveLocalUserSpaces(userId, merged);
  } catch {
    // Non-fatal if storage full
  }
  return merged;
}

export function getLocalTransactions(spaceId: string): Transaction[] {
  try {
    if (typeof localStorage === 'undefined' || !spaceId) return [];
    const raw = localStorage.getItem(`hisaab_local_tx_${spaceId}`);
    const parsed = raw ? (JSON.parse(raw) as Transaction[]) : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function saveLocalTransactions(spaceId: string, list: Transaction[]): void {
  try {
    if (typeof localStorage === 'undefined' || !spaceId) return;
    localStorage.setItem(`hisaab_local_tx_${spaceId}`, JSON.stringify(list));
  } catch (err) {
    console.warn('Local transactions list write notice:', err);
  }
}

export function saveLocalTransaction(spaceId: string, tx: Transaction): void {
  try {
    if (typeof localStorage === 'undefined') return;
    const key = `hisaab_local_tx_${spaceId}`;
    const raw = localStorage.getItem(key);
    const list: Transaction[] = raw ? JSON.parse(raw) : [];
    const updated = list.filter((t) => t.id !== tx.id);
    updated.unshift(tx);
    localStorage.setItem(key, JSON.stringify(updated));
  } catch (err) {
    console.warn('Local transaction cache write notice:', err);
  }
}

/**
 * Creates a new financial Space / Ledger local-first:
 * 1. Validates fields & builds the space payload with a single stable ID.
 * 2. Persists immediately to local storage so UI navigation finishes within milliseconds.
 * 3. Enqueues CREATE_SPACE in the durable offline outbox for non-blocking background Firestore sync.
 */
export async function createSpace(space: Space): Promise<Space> {
  // Step 1: Validate auth state
  const currentUid = auth.currentUser?.uid || space.ownerId;
  if (!currentUid) {
    throw new Error('UNAUTHENTICATED: Must be signed in to create an authoritative cloud space.');
  }

  const currentEmail = auth.currentUser?.email || '';
  const currentDisplayName =
    auth.currentUser?.displayName || (currentEmail ? currentEmail.split('@')[0] : 'User');

  // Step 2: Validate required fields
  if (!space.name || !space.name.trim()) {
    throw new Error('INVALID_ARGUMENT: Space name cannot be empty.');
  }
  if (!space.currency) {
    throw new Error('INVALID_ARGUMENT: Currency must be specified.');
  }
  if (typeof space.startingBalance !== 'number' || !Number.isInteger(space.startingBalance)) {
    throw new Error('INVALID_ARGUMENT: Starting balance must be an integer minor units value.');
  }

  // Step 3: Construct authoritative payload with the single stable space.id
  const memberIds = Array.from(new Set([currentUid, ...(space.memberIds || [])]));
  const existingMembers = space.members || [];
  const hasCurrentUserMember = existingMembers.some((m) => m.id === currentUid);

  const members: Member[] = hasCurrentUserMember
    ? existingMembers.map((m) => (m.id === currentUid ? { ...m, role: 'owner' as const, isCurrentUser: true } : m))
    : [
        {
          id: currentUid,
          name: currentDisplayName,
          email: currentEmail,
          avatarColor: '#2563eb',
          isCurrentUser: true,
          role: 'owner' as const
        },
        ...existingMembers
      ];

  const now = new Date().toISOString();
  const spaceData: Space = {
    id: space.id,
    ownerId: currentUid,
    name: space.name.trim(),
    mode: space.mode,
    currency: space.currency,
    startingBalance: space.startingBalance,
    memberIds,
    members,
    version: space.version || 1,
    isArchived: false,
    createdAt: space.createdAt || now,
    updatedAt: now,
    isCloudConfirmed: false,
    isProvisional: true,
    source: 'local-provisional'
  };

  // Step 4: Persist locally FIRST (if local save fails, throw immediately so UI shows error)
  saveProvisionalSpace(currentUid, spaceData);
  upsertLocalUserSpace(currentUid, spaceData);
  try {
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem(`hisaab_active_space_${currentUid}`, space.id);
      localStorage.setItem('hisaab_active_space_id', space.id);
    }
  } catch (lsErr) {
    console.warn('Active space preference local write notice:', lsErr);
  }

  // Step 5: Enqueue durable outbox operation with deterministic idempotency key.
  // If online, enqueueOperation triggers drainQueue() in the background without blocking navigation.
  await enqueueOperation(
    'CREATE_SPACE',
    space.id,
    space.id,
    { ...spaceData, source: 'cloud-authoritative' },
    { idempotencyKey: `CREATE_SPACE_${space.id}`, version: spaceData.version }
  );

  return spaceData;
}

/**
 * Updates an existing space local-first and queues background Firestore update.
 */
export async function updateSpaceDetails(spaceId: string, updates: Partial<Space>, userId?: string): Promise<void> {
  const currentUid =
    auth.currentUser?.uid ||
    userId ||
    (typeof localStorage !== 'undefined' ? localStorage.getItem('splito_last_user_id') : null) ||
    undefined;
  const now = new Date().toISOString();

  let nextVersion = (updates.version || 1) + 1;
  if (currentUid) {
    const local = getLocalUserSpaces(currentUid).find((s) => s.id === spaceId);
    if (local) {
      nextVersion = (local.version || 1) + 1;
      upsertLocalUserSpace(currentUid, {
        ...local,
        ...updates,
        version: nextVersion,
        updatedAt: now
      });
    }
  }

  await enqueueOperation(
    'UPDATE_SPACE',
    spaceId,
    spaceId,
    sanitizeForFirestore({
      ...updates,
      version: nextVersion,
      updatedAt: now
    }),
    { idempotencyKey: `UPDATE_SPACE_${spaceId}`, version: nextVersion }
  );
}

export interface SpaceDeletionEligibility {
  canDelete: boolean;
  canArchive: boolean;
  isOwner: boolean;
  transactionCount: number;
  startingBalance: number;
  netBalancePaise: number;
  isArchived: boolean;
  conditionMet: 'zero-tx-zero-bal' | 'settled-zero-bal' | 'archived-override' | 'none';
  reason: string;
}

/**
 * Resolves a space from local caches first (instant) before optionally querying Firestore.
 */
function findSpaceLocally(spaceId: string, currentUserId: string): Space | null {
  try {
    const userSpaces = getLocalUserSpaces(currentUserId);
    const matchUser = userSpaces.find((s) => s.id === spaceId);
    if (matchUser) return matchUser;

    const provisional = getProvisionalSpaces(currentUserId);
    const matchProv = provisional.find((s) => s.id === spaceId);
    if (matchProv) return matchProv;

    if (typeof localStorage !== 'undefined') {
      const guestSpacesRaw = localStorage.getItem('hisaab_guest_spaces');
      if (guestSpacesRaw) {
        const guestSpaces = JSON.parse(guestSpacesRaw) as Space[];
        const matchGuest = guestSpaces.find((s) => s.id === spaceId);
        if (matchGuest) return matchGuest;
      }
    }
  } catch (err) {
    console.warn('Local space lookup notice:', err);
  }
  return null;
}

/**
 * Authoritatively verifies whether a space is eligible for hard deletion or archive.
 * Reads local cached spaces/transactions FIRST so UI opens and confirms instantaneously.
 */
export async function checkSpaceDeletionEligibility(
  spaceId: string,
  currentUserId: string
): Promise<SpaceDeletionEligibility> {
  const path = `spaces/${spaceId}`;
  try {
    // 1. Instant local lookup first
    let space: Space | null = findSpaceLocally(spaceId, currentUserId);

    // 2. Only fall back to Firestore cache/server if missing locally and online
    if (!space && isOnline()) {
      try {
        const spaceRef = doc(db, 'spaces', spaceId);
        const spaceSnap = await getDoc(spaceRef);
        if (spaceSnap.exists()) {
          space = spaceSnap.data() as Space;
        }
      } catch {
        // offline/cache fallback
      }
    }

    if (!space) {
      return {
        canDelete: false,
        canArchive: false,
        isOwner: false,
        transactionCount: 0,
        startingBalance: 0,
        netBalancePaise: 0,
        isArchived: false,
        conditionMet: 'none',
        reason: 'Space document does not exist.'
      };
    }

    const isOwner = space.ownerId === currentUserId || currentUserId.startsWith('guest_') || !space.ownerId;
    const isArchived = Boolean(space.isArchived);
    const startingBalance = space.startingBalance || 0;

    if (!isOwner) {
      return {
        canDelete: false,
        canArchive: false,
        isOwner: false,
        transactionCount: 0,
        startingBalance,
        netBalancePaise: startingBalance,
        isArchived,
        conditionMet: 'none',
        reason: 'Only the authenticated space owner has permission to archive or delete this space.'
      };
    }

    // 3. Read local cached transactions FIRST (instant), fall back to Firestore only if absent locally & online
    let transactions: Transaction[] = getLocalTransactions(spaceId);
    if (transactions.length === 0 && isOnline() && !space.isProvisional && !currentUserId.startsWith('guest_')) {
      try {
        const txCol = collection(db, 'spaces', spaceId, 'transactions');
        const txSnap = await getDocs(txCol);
        transactions = txSnap.docs.map((d) => d.data() as Transaction);
        if (transactions.length > 0) {
          saveLocalTransactions(spaceId, transactions);
        }
      } catch {
        // local transactions fallback if guest or offline
      }
    }

    const transactionCount = transactions.length;
    const activeTx = getActiveLedgerTransactions(transactions);

    // Compute net balance:
    // 1. Ledger actual balance
    let netBalancePaise = startingBalance;
    for (const tx of activeTx) {
      if (tx.type === 'income') {
        netBalancePaise += tx.amount;
      } else if (tx.type === 'expense') {
        netBalancePaise -= tx.amount;
      }
    }

    // 2. Outstanding group member dues check
    if (space.members && space.members.length > 1) {
      const groupBalances = calculateGroupBalances(space.members, activeTx);
      const outstandingDues = groupBalances.reduce((acc, b) => acc + Math.abs(b.netBalanceMinorUnits), 0);
      if (outstandingDues > 0) {
        netBalancePaise = outstandingDues;
      }
    }

    // Condition (a): Space has 0 transactions AND net balance of ₹0.00
    if (transactionCount === 0 && netBalancePaise === 0) {
      return {
        canDelete: true,
        canArchive: true,
        isOwner: true,
        transactionCount: 0,
        startingBalance: 0,
        netBalancePaise: 0,
        isArchived,
        conditionMet: 'zero-tx-zero-bal',
        reason: 'This space has 0 transactions and ₹0.00 balance. It is eligible for permanent hard deletion.'
      };
    }

    // Condition (b): Space has net balance of ₹0.00, even if transactions > 0 (all dues settled or entries reversed)
    if (netBalancePaise === 0) {
      return {
        canDelete: true,
        canArchive: true,
        isOwner: true,
        transactionCount,
        startingBalance,
        netBalancePaise: 0,
        isArchived,
        conditionMet: 'settled-zero-bal',
        reason: `All financial dues and balances in this space are fully settled (₹0.00 balance across ${transactionCount} entries). It is eligible for permanent hard deletion.`
      };
    }

    // Condition (c): Space is already marked Archived AND user explicitly confirms in dialog
    if (isArchived) {
      return {
        canDelete: true,
        canArchive: false,
        isOwner: true,
        transactionCount,
        startingBalance,
        netBalancePaise,
        isArchived: true,
        conditionMet: 'archived-override',
        reason: 'This space is archived. It is eligible for permanent hard deletion with explicit confirmation in the warning dialog.'
      };
    }

    // Otherwise: Non-zero net balance and not archived (safety protected)
    return {
      canDelete: false,
      canArchive: true,
      isOwner: true,
      transactionCount,
      startingBalance,
      netBalancePaise,
      isArchived: false,
      conditionMet: 'none',
      reason: `Hard Deletion Blocked — Financial History Protected. This space contains an unsettled balance of ${formatPaise(netBalancePaise, space.currency)}. To permanently delete it, settle all balances to ₹0.00, or Archive the space first.`
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
    return {
      canDelete: false,
      canArchive: false,
      isOwner: false,
      transactionCount: 0,
      startingBalance: 0,
      netBalancePaise: 0,
      isArchived: false,
      conditionMet: 'none',
      reason: 'Failed to evaluate space deletion eligibility.'
    };
  }
}

/**
 * Safely archives a space local-first while queuing cloud update in background.
 */
export async function archiveSpace(spaceId: string, currentUserId: string): Promise<void> {
  const path = `spaces/${spaceId}`;
  try {
    let data: Space | null = findSpaceLocally(spaceId, currentUserId);
    if (!data && isOnline()) {
      const spaceRef = doc(db, 'spaces', spaceId);
      const snap = await getDoc(spaceRef);
      if (snap.exists()) {
        data = snap.data() as Space;
      }
    }
    if (!data) {
      throw new Error(`Space ${spaceId} not found.`);
    }
    if (data.ownerId !== currentUserId) {
      throw new Error('PERMISSION_DENIED: Only the owner can archive this space.');
    }

    const now = new Date().toISOString();
    const nextVersion = (data.version || 1) + 1;
    upsertLocalUserSpace(currentUserId, { ...data, isArchived: true, version: nextVersion, updatedAt: now });

    await enqueueOperation(
      'UPDATE_SPACE',
      spaceId,
      spaceId,
      { isArchived: true, version: nextVersion, updatedAt: now },
      { idempotencyKey: `UPDATE_SPACE_${spaceId}`, version: nextVersion }
    );
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

/**
 * Restores an archived space back to active status local-first.
 */
export async function unarchiveSpace(spaceId: string, currentUserId: string): Promise<void> {
  const path = `spaces/${spaceId}`;
  try {
    let data: Space | null = findSpaceLocally(spaceId, currentUserId);
    if (!data && isOnline()) {
      const spaceRef = doc(db, 'spaces', spaceId);
      const snap = await getDoc(spaceRef);
      if (snap.exists()) {
        data = snap.data() as Space;
      }
    }
    if (!data) {
      throw new Error(`Space ${spaceId} not found.`);
    }
    if (data.ownerId !== currentUserId) {
      throw new Error('PERMISSION_DENIED: Only the owner can restore this space.');
    }

    const now = new Date().toISOString();
    const nextVersion = (data.version || 1) + 1;
    upsertLocalUserSpace(currentUserId, { ...data, isArchived: false, version: nextVersion, updatedAt: now });

    await enqueueOperation(
      'UPDATE_SPACE',
      spaceId,
      spaceId,
      { isArchived: false, version: nextVersion, updatedAt: now },
      { idempotencyKey: `UPDATE_SPACE_${spaceId}`, version: nextVersion }
    );
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

/**
 * Optimistically and instantaneously deletes a space locally (< 50ms),
 * records a persistent deletion tombstone so it can never resurrect,
 * cancels any pending creates/updates for it, removes it from local storage,
 * and enqueues cascade cloud deletion in the background outbox.
 */
export async function deleteEmptySpace(
  spaceId: string,
  currentUserId: string,
  confirmationSpaceName: string
): Promise<void> {
  const path = `spaces/${spaceId}`;
  try {
    let spaceData: Space | null = findSpaceLocally(spaceId, currentUserId);

    if (!spaceData && isOnline()) {
      try {
        const spaceRef = doc(db, 'spaces', spaceId);
        const snap = await getDoc(spaceRef);
        if (snap.exists()) {
          spaceData = snap.data() as Space;
        }
      } catch {
        // offline / guest fallback
      }
    }

    if (!spaceData) {
      throw new Error(`Space ${spaceId} does not exist on the server or locally.`);
    }

    const isOwner = spaceData.ownerId === currentUserId || currentUserId.startsWith('guest_') || !spaceData.ownerId;
    if (!isOwner) {
      throw new Error('PERMISSION_DENIED: Only the space owner can delete this space.');
    }

    if (spaceData.name.trim().toLowerCase() !== confirmationSpaceName.trim().toLowerCase()) {
      throw new Error('NAME_CONFIRMATION_MISMATCH: The confirmed space name does not match.');
    }

    // Verify eligibility locally under unlocked rules: (a), (b), or (c)
    const eligibility = await checkSpaceDeletionEligibility(spaceId, currentUserId);
    if (!eligibility.canDelete) {
      throw new Error(`DELETION_BLOCKED: ${eligibility.reason}`);
    }

    // 1. Immediately persist deletion tombstone so space can never be resurrected by cache or sync
    recordDeletedSpaceTombstone(currentUserId, spaceId);

    // 2. Cancel any pending outbox creates/updates/transactions for this space
    await cancelPendingOperationsForSpace(spaceId);

    // 3. Immediately purge from all local caches (user spaces, provisional spaces, guest spaces, tx, active IDs)
    removeLocalUserSpace(currentUserId, spaceId);

    // 4. Queue cascade cloud deletion in durable outbox (executes in background if online, retries on reconnect)
    if (!currentUserId.startsWith('guest_')) {
      await enqueueOperation(
        'DELETE_SPACE',
        spaceId,
        spaceId,
        { spaceId, userId: currentUserId },
        { idempotencyKey: `DELETE_SPACE_${spaceId}` }
      );
    } else {
      markTombstoneCloudDeleted(currentUserId, spaceId);
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export const deleteSpaceWithCascade = deleteEmptySpace;

/**
 * Server-authoritative query for spaces where current user is a member (filtered by tombstones)
 */
export async function fetchServerUserSpaces(userId: string): Promise<Space[]> {
  const q = query(
    collection(db, 'spaces'),
    where('memberIds', 'array-contains', userId)
  );
  const snap = await getDocs(q);
  const spaces: Space[] = [];
  snap.forEach((docSnap) => {
    const sp = docSnap.data() as Space;
    spaces.push({
      ...sp,
      isCloudConfirmed: true,
      source: 'cloud-authoritative'
    });
  });
  return mergeCloudAndLocalSpaces(userId, spaces, { fromCache: snap.metadata.fromCache });
}

/**
 * Subscribes to spaces where current user is owner or member.
 * Immediately emits locally cached spaces first so offline startup renders instantly,
 * then merges Firestore snapshots in the background while honoring deleted-space tombstones.
 */
export function subscribeToUserSpaces(
  userId: string,
  onSpaces: (spaces: Space[], meta?: { fromCache: boolean }) => void,
  onError: (error: Error) => void
): Unsubscribe {
  const path = 'spaces';

  // Emit local cached/provisional spaces immediately without waiting for Firestore
  const initialLocal = getLocalUserSpaces(userId);
  if (initialLocal.length > 0) {
    onSpaces(initialLocal, { fromCache: true });
  }

  try {
    const q = query(
      collection(db, 'spaces'),
      where('memberIds', 'array-contains', userId)
    );

    return onSnapshot(
      q,
      (snapshot) => {
        const cloudSpaces: Space[] = [];
        snapshot.forEach((docSnap) => {
          const sp = docSnap.data() as Space;
          cloudSpaces.push({
            ...sp,
            isCloudConfirmed: true,
            source: 'cloud-authoritative'
          });
        });

        const merged = mergeCloudAndLocalSpaces(userId, cloudSpaces, {
          fromCache: snapshot.metadata.fromCache
        });

        onSpaces(merged, { fromCache: snapshot.metadata.fromCache });
      },
      (error) => {
        console.warn(`Firestore subscription error on ${path}:`, error.message);
        const localSpaces = getLocalUserSpaces(userId);
        if (localSpaces.length > 0) {
          onSpaces(localSpaces, { fromCache: true });
        } else {
          onError(error);
        }
      }
    );
  } catch (error) {
    console.warn(`Firestore query creation error on ${path}:`, error);
    const localSpaces = getLocalUserSpaces(userId);
    if (localSpaces.length > 0) {
      onSpaces(localSpaces, { fromCache: true });
    } else {
      onError(error instanceof Error ? error : new Error(String(error)));
    }
    return () => {};
  }
}

/**
 * Subscribes to real-time transactions within a space.
 * Emits locally cached transactions immediately, then merges Firestore snapshots in background.
 */
export function subscribeToTransactions(
  spaceId: string,
  onTransactions: (transactions: Transaction[]) => void,
  onError: (error: Error) => void
): Unsubscribe {
  const path = `spaces/${spaceId}/transactions`;

  const initialLocalTx = getLocalTransactions(spaceId);
  if (initialLocalTx.length > 0) {
    onTransactions(initialLocalTx);
  }

  try {
    const colRef = collection(db, 'spaces', spaceId, 'transactions');
    return onSnapshot(
      colRef,
      (snapshot) => {
        const cloudList: Transaction[] = [];
        snapshot.forEach((docSnap) => {
          cloudList.push(docSnap.data() as Transaction);
        });

        const localList = getLocalTransactions(spaceId);
        const pendingOps = getPendingOperationsForSpace(spaceId);
        const pendingTxIds = new Set(pendingOps.map((op) => op.targetDocId));
        const deletedTxIds = new Set(
          pendingOps.filter((op) => op.type === 'DELETE_TRANSACTION').map((op) => op.targetDocId)
        );

        const byId = new Map<string, Transaction>();
        for (const ctx of cloudList) {
          if (!ctx?.id || deletedTxIds.has(ctx.id)) continue;
          byId.set(ctx.id, { ...ctx, isCloudConfirmed: true });
        }

        // Preserve any locally created/modified pending transactions
        for (const ltx of localList) {
          if (!ltx?.id || deletedTxIds.has(ltx.id)) continue;
          const existing = byId.get(ltx.id);
          if (!existing) {
            if (!ltx.isCloudConfirmed || pendingTxIds.has(ltx.id) || snapshot.metadata.fromCache || !isOnline()) {
              byId.set(ltx.id, ltx);
            }
          } else if (pendingTxIds.has(ltx.id)) {
            const res = resolveEntityConflict(ltx, existing);
            byId.set(ltx.id, res.resolvedEntity);
          }
        }

        const merged = Array.from(byId.values()).sort((a, b) => {
          const dateDiff = new Date(b.date).getTime() - new Date(a.date).getTime();
          if (dateDiff !== 0) return dateDiff;
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
        });

        if (merged.length > 0 || !snapshot.metadata.fromCache) {
          saveLocalTransactions(spaceId, merged);
        }

        onTransactions(merged);
      },
      (error) => {
        console.warn(`Firestore subscription error on ${path}:`, error.message);
        const localList = getLocalTransactions(spaceId);
        if (localList.length > 0) {
          onTransactions(localList);
          return;
        }
        onError(error);
      }
    );
  } catch (error) {
    console.warn(`Firestore collection error on ${path}:`, error);
    const localList = getLocalTransactions(spaceId);
    if (localList.length > 0) {
      onTransactions(localList);
      return () => {};
    }
    onError(error instanceof Error ? error : new Error(String(error)));
    return () => {};
  }
}

/**
 * Subscribes to real-time audit logs within a space
 */
export function subscribeToAuditLogs(
  spaceId: string,
  onLogs: (logs: AuditLog[]) => void
): Unsubscribe {
  const path = `spaces/${spaceId}/audit_logs`;
  try {
    const colRef = collection(db, 'spaces', spaceId, 'audit_logs');
    return onSnapshot(
      colRef,
      (snapshot) => {
        const list: AuditLog[] = [];
        snapshot.forEach((docSnap) => {
          list.push(docSnap.data() as AuditLog);
        });
        list.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
        onLogs(list);
      },
      (error) => {
        console.warn('Audit logs listener note:', error);
      }
    );
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
  }
}

/**
 * Recursively cleans an object to ensure no keys have `undefined` values,
 * which Firestore strictly rejects with "Unsupported field value: undefined".
 * Undefined properties are omitted completely from the payload.
 */
export function sanitizeForFirestore<T extends Record<string, any>>(obj: T): T {
  if (obj === null || typeof obj !== 'object') {
    return obj;
  }

  if (Array.isArray(obj)) {
    return obj
      .filter((item) => item !== undefined)
      .map((item) => sanitizeForFirestore(item)) as unknown as T;
  }

  const cleaned: Record<string, any> = {};
  for (const [key, value] of Object.entries(obj)) {
    if (value !== undefined) {
      if (value !== null && typeof value === 'object') {
        cleaned[key] = sanitizeForFirestore(value);
      } else {
        cleaned[key] = value;
      }
    }
  }
  return cleaned as T;
}

/**
 * Validates and normalizes transaction payloads according to domain semantics.
 * Critical guarantees:
 * 1. For 'expense' and 'income': 'paidToId' is omitted completely (never undefined).
 * 2. For 'transfer' and 'settlement': 'paidToId' is validated to exist and differ from 'payerId'.
 * 3. Monetary amounts must be strictly positive integer minor units.
 * 4. All undefined values are stripped so Firestore setDoc never throws Unsupported field value: undefined.
 */
export function normalizeTransactionPayload(tx: Transaction): Record<string, any> {
  if (!tx.id || !tx.spaceId || !tx.creatorId || !tx.title || !tx.type || typeof tx.amount !== 'number') {
    throw new Error('INVALID_ARGUMENT: Transaction missing core required fields (id, spaceId, creatorId, title, type, amount).');
  }

  if (tx.amount <= 0 || !Number.isInteger(tx.amount)) {
    throw new Error('INVALID_ARGUMENT: Transaction amount must be a positive integer in minor units.');
  }

  if (tx.type === 'transfer' || tx.type === 'settlement') {
    if (!tx.paidToId || !tx.paidToId.trim()) {
      throw new Error(`INVALID_ARGUMENT: ${tx.type === 'settlement' ? 'Settlement' : 'Transfer'} requires a valid recipient (paidToId).`);
    }
    if (tx.paidToId === tx.payerId) {
      throw new Error('INVALID_ARGUMENT: Payer and recipient cannot be the same member.');
    }
  }

  const payload: Record<string, any> = {
    id: tx.id,
    spaceId: tx.spaceId,
    creatorId: tx.creatorId,
    title: tx.title.trim(),
    type: tx.type,
    category: tx.category || 'General',
    amount: Math.round(tx.amount),
    date: tx.date || new Date().toISOString().split('T')[0],
    payerId: tx.payerId,
    paymentMethod: tx.paymentMethod || 'UPI',
    createdAt: tx.createdAt || new Date().toISOString()
  };

  // Only attach paidToId when applicable (transfer or settlement)
  if ((tx.type === 'transfer' || tx.type === 'settlement') && tx.paidToId && tx.paidToId.trim()) {
    payload.paidToId = tx.paidToId.trim();
  }

  // Only attach splitType and splits when applicable (expense)
  if (tx.type === 'expense') {
    if (tx.splitType && tx.splitType !== 'none') {
      payload.splitType = tx.splitType;
      if (Array.isArray(tx.splits) && tx.splits.length > 0) {
        payload.splits = tx.splits.map((s) => ({
          memberId: s.memberId,
          shareMinorUnits: Math.round(s.shareMinorUnits),
          ...(typeof s.percentage === 'number' ? { percentage: s.percentage } : {})
        }));
      }
    } else {
      payload.splitType = 'none';
    }
  }

  // Optional string fields: only attach if non-empty string
  if (tx.notes && tx.notes.trim()) {
    payload.notes = tx.notes.trim();
  }
  if (tx.receiptUrl && tx.receiptUrl.trim()) {
    payload.receiptUrl = tx.receiptUrl.trim();
  }

  // Version sequence
  payload.version = typeof tx.version === 'number' ? tx.version : 1;

  // Reversal metadata
  if (tx.isReversal) {
    payload.isReversal = true;
    if (tx.reversesTransactionId) payload.reversesTransactionId = tx.reversesTransactionId;
  }
  if (tx.isReversed) {
    payload.isReversed = true;
    if (tx.reversedAt) payload.reversedAt = tx.reversedAt;
    if (tx.reversedBy) payload.reversedBy = tx.reversedBy;
  }

  // Converted currency metadata
  if (tx.originalCurrency) payload.originalCurrency = tx.originalCurrency;
  if (typeof tx.originalAmountMinorUnits === 'number') payload.originalAmountMinorUnits = tx.originalAmountMinorUnits;
  if (typeof tx.exchangeRateBasisPoints === 'number') payload.exchangeRateBasisPoints = tx.exchangeRateBasisPoints;

  // SPLITO Wallet Pay metadata
  if (tx.paymentStatus) {
    payload.paymentStatus = tx.paymentStatus;
  }
  if (tx.paymentApp && tx.paymentApp.trim()) {
    payload.paymentApp = tx.paymentApp.trim();
  }
  if (tx.paymentAppLabel && tx.paymentAppLabel.trim()) {
    payload.paymentAppLabel = tx.paymentAppLabel.trim();
  }
  if (tx.upiPayeeVpa && tx.upiPayeeVpa.trim()) {
    payload.upiPayeeVpa = tx.upiPayeeVpa.trim();
  }
  if (tx.upiPayeeName && tx.upiPayeeName.trim()) {
    payload.upiPayeeName = tx.upiPayeeName.trim();
  }
  if (tx.paymentAttemptedAt && tx.paymentAttemptedAt.trim()) {
    payload.paymentAttemptedAt = tx.paymentAttemptedAt.trim();
  }
  if (tx.paymentConfirmedAt && tx.paymentConfirmedAt.trim()) {
    payload.paymentConfirmedAt = tx.paymentConfirmedAt.trim();
  }

  return sanitizeForFirestore(payload);
}

/**
 * Direct cloud transaction write used by Guest Migration where server ACK is strictly required
 * before clearing local guest storage.
 */
export async function pushTransactionToCloud(spaceId: string, transaction: Transaction): Promise<Transaction> {
  const normalized = normalizeTransactionPayload(transaction);
  const txDocRef = doc(db, 'spaces', spaceId, 'transactions', transaction.id);
  await setDoc(txDocRef, { ...normalized, isCloudConfirmed: true });
  const serverSnap = await getDocFromServer(txDocRef);
  if (!serverSnap.exists()) {
    throw new Error(`Write verification failed: Transaction ${transaction.id} could not be confirmed on the cloud.`);
  }
  return { ...(normalized as Transaction), isCloudConfirmed: true };
}

/**
 * Saves (creates) a new transaction local-first and queues cloud sync in background.
 * Never blocks UI on Firestore round-trips when offline or on slow connections.
 */
export async function addTransaction(spaceId: string, transaction: Transaction): Promise<Transaction> {
  const normalized = normalizeTransactionPayload(transaction);
  const localTx: Transaction = {
    ...(normalized as Transaction),
    isCloudConfirmed: false
  };

  saveLocalTransaction(spaceId, localTx);
  await enqueueOperation('ADD_TRANSACTION', spaceId, transaction.id, localTx, {
    idempotencyKey: `ADD_TRANSACTION_${transaction.id}`,
    version: localTx.version || 1
  });
  return localTx;
}

// Register queue executors for background offline synchronization
registerQueueExecutor('CREATE_SPACE', async (op) => {
  const spaceData = op.payload as Space;
  const uid = auth.currentUser?.uid || spaceData.ownerId;
  if (uid && isSpaceDeleted(uid, spaceData.id)) {
    return { success: true };
  }
  try {
    const spaceRef = doc(db, 'spaces', spaceData.id);
    await setDoc(spaceRef, { ...spaceData, isCloudConfirmed: true, isProvisional: false, source: 'cloud-authoritative' });
    const serverSnap = await getDocFromServer(spaceRef);
    if (!serverSnap.exists()) {
      return { success: false, error: 'Server read confirmation failed' };
    }
    const confirmedSpace: Space = {
      ...(serverSnap.data() as Space),
      isCloudConfirmed: true,
      isProvisional: false,
      source: 'cloud-authoritative'
    };
    if (uid) {
      removeProvisionalSpace(uid, spaceData.id);
      upsertLocalUserSpace(uid, confirmedSpace);
      updateUserActiveSpace(uid, spaceData.id).catch(() => {});
    }
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err instanceof Error ? err.message : String(err) };
  }
});

registerQueueExecutor('DELETE_SPACE', async (op) => {
  const { spaceId, userId } = (op.payload || {}) as { spaceId: string; userId: string };
  const targetSpaceId = spaceId || op.targetSpaceId;
  try {
    const spaceRef = doc(db, 'spaces', targetSpaceId);

    // 1. Delete subcollection transactions in parallel
    const txCol = collection(db, 'spaces', targetSpaceId, 'transactions');
    try {
      const txSnap = await getDocs(txCol);
      await Promise.all(txSnap.docs.map((d) => deleteDoc(d.ref)));
    } catch (txErr) {
      console.warn('Subcollection transactions background delete notice:', txErr);
    }

    // 2. Delete subcollection audit_logs in parallel
    const auditCol = collection(db, 'spaces', targetSpaceId, 'audit_logs');
    try {
      const auditSnap = await getDocs(auditCol);
      await Promise.all(auditSnap.docs.map((d) => deleteDoc(d.ref)));
    } catch (auditErr) {
      console.warn('Subcollection audit logs background delete notice:', auditErr);
    }

    // 3. Delete parent space doc
    await deleteDoc(spaceRef);

    // 4. Verify non-existence on server
    try {
      const verifySnap = await getDocFromServer(spaceRef);
      if (verifySnap.exists()) {
        return { success: false, error: 'Server delete verification failed: document still exists' };
      }
    } catch {
      // Non-existence or permission-denied confirms deletion
    }

    if (userId) {
      markTombstoneCloudDeleted(userId, targetSpaceId);
    }
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err instanceof Error ? err.message : String(err) };
  }
});

registerQueueExecutor('ADD_TRANSACTION', async (op) => {
  const tx = op.payload as Transaction;
  if (auth.currentUser && isSpaceDeleted(auth.currentUser.uid, op.targetSpaceId)) {
    return { success: true };
  }
  try {
    const txRef = doc(db, 'spaces', op.targetSpaceId, 'transactions', tx.id);
    const normalized = normalizeTransactionPayload({ ...tx, isCloudConfirmed: true });
    await setDoc(txRef, { ...normalized, isCloudConfirmed: true });
    const serverSnap = await getDocFromServer(txRef);
    if (!serverSnap.exists()) {
      return { success: false, error: 'Server read confirmation failed' };
    }
    saveLocalTransaction(op.targetSpaceId, { ...tx, isCloudConfirmed: true });
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err instanceof Error ? err.message : String(err) };
  }
});

registerQueueExecutor('UPDATE_TRANSACTION', async (op) => {
  if (auth.currentUser && isSpaceDeleted(auth.currentUser.uid, op.targetSpaceId)) {
    return { success: true };
  }
  try {
    const txRef = doc(db, 'spaces', op.targetSpaceId, 'transactions', op.targetDocId);
    await updateDoc(txRef, op.payload);
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err instanceof Error ? err.message : String(err) };
  }
});

registerQueueExecutor('DELETE_TRANSACTION', async (op) => {
  try {
    const txRef = doc(db, 'spaces', op.targetSpaceId, 'transactions', op.targetDocId);
    await deleteDoc(txRef);
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err instanceof Error ? err.message : String(err) };
  }
});

registerQueueExecutor('UPDATE_SPACE', async (op) => {
  if (auth.currentUser && isSpaceDeleted(auth.currentUser.uid, op.targetSpaceId)) {
    return { success: true };
  }
  try {
    const spaceRef = doc(db, 'spaces', op.targetSpaceId);
    await updateDoc(spaceRef, op.payload);
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err instanceof Error ? err.message : String(err) };
  }
});

registerQueueExecutor('REVERSE_TRANSACTION', async (op) => {
  if (auth.currentUser && isSpaceDeleted(auth.currentUser.uid, op.targetSpaceId)) {
    return { success: true };
  }
  try {
    const { originalUpdated, reversalTx } = op.payload;
    const batch = writeBatch(db);
    batch.set(doc(db, 'spaces', op.targetSpaceId, 'transactions', originalUpdated.id), originalUpdated);
    batch.set(doc(db, 'spaces', op.targetSpaceId, 'transactions', reversalTx.id), normalizeTransactionPayload(reversalTx));
    await batch.commit();
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err instanceof Error ? err.message : String(err) };
  }
});

/**
 * Immutably reverses a transaction local-first and queues cloud sync in background
 */
export async function reverseLedgerTransaction(
  spaceId: string,
  originalTx: Transaction,
  actorId: string,
  actorName: string,
  reason: string = 'User requested reversal'
): Promise<{ originalUpdated: Transaction; reversalTx: Transaction }> {
  const { originalUpdated, reversalTx } = createReversalTransaction(originalTx, actorId, reason);

  saveLocalTransaction(spaceId, originalUpdated);
  saveLocalTransaction(spaceId, { ...reversalTx, isCloudConfirmed: false });

  await enqueueOperation(
    'REVERSE_TRANSACTION',
    spaceId,
    originalTx.id,
    { originalUpdated, reversalTx },
    { idempotencyKey: `REVERSE_${originalTx.id}` }
  );

  return { originalUpdated, reversalTx };
}

/**
 * Updates a transaction local-first and queues background Firestore update
 */
export async function updateTransaction(
  spaceId: string,
  transactionId: string,
  updates: Partial<Transaction>
): Promise<void> {
  const existingList = getLocalTransactions(spaceId);
  const existing = existingList.find((t) => t.id === transactionId);
  const nextVersion = ((updates.version ?? existing?.version) || 1) + 1;

  if (existing) {
    saveLocalTransaction(spaceId, {
      ...existing,
      ...updates,
      version: nextVersion
    });
  }

  const sanitizedUpdates = sanitizeForFirestore({
    ...updates,
    version: nextVersion
  });

  await enqueueOperation('UPDATE_TRANSACTION', spaceId, transactionId, sanitizedUpdates, {
    idempotencyKey: `UPDATE_TX_${transactionId}`,
    version: nextVersion
  });
}

/**
 * Deletes a transaction local-first and queues background Firestore deletion
 */
export async function deleteTransaction(spaceId: string, transactionId: string): Promise<void> {
  const existingList = getLocalTransactions(spaceId);
  saveLocalTransactions(
    spaceId,
    existingList.filter((t) => t.id !== transactionId)
  );

  await enqueueOperation(
    'DELETE_TRANSACTION',
    spaceId,
    transactionId,
    { spaceId, transactionId },
    { idempotencyKey: `DELETE_TX_${transactionId}` }
  );
}

/**
 * Records an immutable audit log entry (non-blocking when offline)
 */
export async function recordAuditLog(spaceId: string, log: AuditLog): Promise<void> {
  if (!isOnline()) return;
  try {
    const sanitized = sanitizeForFirestore(log);
    await setDoc(doc(db, 'spaces', spaceId, 'audit_logs', log.id), sanitized);
  } catch (error) {
    console.warn('Audit log write error:', error);
  }
}

/**
 * Updates user's active space preference in local cache immediately and Firestore in background
 */
export async function updateUserActiveSpace(userId: string, activeSpaceId: string): Promise<void> {
  try {
    if (typeof localStorage !== 'undefined' && userId) {
      localStorage.setItem(`hisaab_active_space_${userId}`, activeSpaceId);
      const cachedProfile = getLocalUserProfile(userId);
      if (cachedProfile) {
        saveLocalUserProfile({ ...cachedProfile, activeSpaceId });
      }
    }
  } catch {}

  if (!isOnline()) return;

  try {
    const userDocRef = doc(db, 'users', userId);
    await setDoc(
      userDocRef,
      {
        activeSpaceId,
        updatedAt: new Date().toISOString()
      },
      { merge: true }
    );
  } catch (error) {
    console.warn('Could not update active space in Firestore user profile:', error);
  }
}

/**
 * Data-Only Deletion: Permanently erases personal spaces and entries while KEEPING account and login intact
 */
export async function deleteUserPersonalData(userId: string): Promise<{ deletedPersonalSpacesCount: number; anonymizedSharedSpacesCount: number }> {
  if (!userId || userId.startsWith('guest_')) {
    // Clear local storage guest session spaces
    localStorage.removeItem('hisaab_guest_spaces');
    localStorage.removeItem(`hisaab_active_space_${userId}`);
    localStorage.removeItem('hisaab_active_space');
    return { deletedPersonalSpacesCount: 1, anonymizedSharedSpacesCount: 0 };
  }

  let deletedPersonalSpacesCount = 0;
  let anonymizedSharedSpacesCount = 0;

  try {
    // 1. Fetch spaces where user is a member or owner using array-contains (supported by firestore.rules)
    const spacesRef = collection(db, 'spaces');
    const q = query(spacesRef, where('memberIds', 'array-contains', userId));
    const snap = await getDocs(q);

    for (const spaceDoc of snap.docs) {
      const spaceData = spaceDoc.data() as Space;
      const isPersonal = spaceData.mode === 'personal' ||
        (spaceData.ownerId === userId && (!spaceData.members || spaceData.members.length <= 1));

      if (isPersonal) {
        // Cascade delete subcollection: transactions
        const txCol = collection(db, 'spaces', spaceDoc.id, 'transactions');
        try {
          const txSnap = await getDocs(txCol);
          for (const tDoc of txSnap.docs) {
            await deleteDoc(tDoc.ref);
          }
        } catch (txErr) {
          console.warn(`Cascade transactions delete notice for space ${spaceDoc.id}:`, txErr);
        }

        // Cascade delete subcollection: audit logs
        const auditCol = collection(db, 'spaces', spaceDoc.id, 'audit_logs');
        try {
          const auditSnap = await getDocs(auditCol);
          for (const aDoc of auditSnap.docs) {
            await deleteDoc(aDoc.ref);
          }
        } catch (auditErr) {
          console.warn(`Cascade audit logs delete notice for space ${spaceDoc.id}:`, auditErr);
        }

        // Delete parent personal space document
        await deleteDoc(doc(db, 'spaces', spaceDoc.id));
        deletedPersonalSpacesCount++;
      } else {
        // Shared space (Roommates, Family, Trip):
        // NEVER delete shared space or other members' transactions/records!
        // Anonymize the user's identifying details in members list
        const updatedMembers = (spaceData.members || []).map((m: any) =>
          m.id === userId ? { id: userId, name: 'Former Member' } : m
        );
        await updateDoc(doc(db, 'spaces', spaceDoc.id), {
          members: updatedMembers
        });
        anonymizedSharedSpacesCount++;
      }
    }

    // 2. Clear user-specific active space cache so app returns to clean empty state or remaining shared space
    localStorage.removeItem(`hisaab_active_space_${userId}`);
    localStorage.removeItem('hisaab_active_space');
    localStorage.removeItem('hisaab_guest_spaces');

    return { deletedPersonalSpacesCount, anonymizedSharedSpacesCount };
  } catch (err) {
    console.error('Personal data deletion error:', err);
    throw err;
  }
}

/**
 * Account Deletion: Permanently erases user account, profile, and auth credentials
 */
export async function deleteUserAccountAndData(userId: string): Promise<void> {
  if (!userId || userId.startsWith('guest_')) {
    // Clear local storage guest session
    localStorage.clear();
    return;
  }

  try {
    // 1. First perform full personal data and shared-space anonymization
    await deleteUserPersonalData(userId);

    // 2. Delete user profile doc in Firestore
    try {
      await deleteDoc(doc(db, 'users', userId));
    } catch (userDocErr) {
      console.warn('User profile document delete notice:', userDocErr);
    }

    // 3. Clear all remaining local storage caches
    localStorage.removeItem(`hisaab_active_space_${userId}`);
    localStorage.removeItem(`splito_user_subscription_${userId}`);
    localStorage.removeItem('splito_user_subscription');
    localStorage.removeItem('splito_auth_choice');
    localStorage.removeItem('splito_consent_preferences');

    // 4. Delete Firebase Auth user credentials
    if (auth.currentUser && auth.currentUser.uid === userId) {
      try {
        await auth.currentUser.delete();
      } catch (authErr: any) {
        if (authErr?.code === 'auth/requires-recent-login' || authErr?.message?.includes('requires-recent-login')) {
          throw new Error('REAUTH_REQUIRED: Deleting your Google login credentials requires a fresh login. Please sign out, sign back in, and try again.');
        }
        console.warn('Firebase user delete notice, signing out:', authErr);
        await auth.signOut();
      }
    }
  } catch (err) {
    console.error('Account deletion error:', err);
    throw err;
  }
}

