import {
  LocalNotifications,
  PermissionStatus,
  LocalNotificationSchema
} from '@capacitor/local-notifications';
import { Capacitor } from '@capacitor/core';
import { Space, SpaceMode, Transaction } from '../types/finance.ts';

export const REMINDERS_ENABLED_KEY = 'splito_expense_reminders_enabled';
export const TROLL_CHANNEL_ID = 'splito_troll_reminders';
export const DAILY_NOTIFICATION_COUNT = 10;

// Deterministic ID block for the 10 daily funny/troll notifications (prevents accumulation/duplicates)
export const TROLL_NOTIFICATION_IDS: readonly number[] = [
  3001, 3002, 3003, 3004, 3005, 3006, 3007, 3008, 3009, 3010
];

// Legacy IDs kept exported for compatibility and cleanup
export const MODE_NOTIFICATION_IDS: Record<SpaceMode, number> = {
  personal: 2001,
  roommates: 2002,
  family: 2003,
  trip: 2004
};

const ALL_MANAGED_IDS: number[] = [
  ...Object.values(MODE_NOTIFICATION_IDS),
  ...TROLL_NOTIFICATION_IDS
];

const LAST_TROLL_INDEX_KEY = 'splito_troll_last_msg_idx';
const RECENT_TROLL_INDICES_KEY = 'splito_troll_recent_msg_idxs';
const SCHEDULED_BATCH_KEY = 'splito_troll_scheduled_batch_v2';
const PERMISSION_STATE_KEY = 'splito_notification_permission_state';
const PERMISSION_PROMPTED_KEY = 'splito_notification_permission_prompted';

export type NotificationPermissionState = 'granted' | 'denied' | 'prompt';

export interface ScheduledTrollNotification {
  id: number;
  title: string;
  body: string;
  at: string;
}

export interface DailyNotificationScheduleResult {
  enabled: boolean;
  permissionStatus: NotificationPermissionState;
  exactAlarmStatus: 'granted' | 'denied' | 'unknown';
  scheduledCount: number;
  notifications: ScheduledTrollNotification[];
  reusedExistingBatch: boolean;
  error?: string;
}

export interface ReminderSchedulePlan {
  mode: SpaceMode;
  scheduled: boolean;
  reason?:
    | 'scheduled_success'
    | 'disabled_by_user'
    | 'permission_denied'
    | 'schedule_error';
  targetTime?: string;
  message?: string;
  notificationId: number;
}

export interface NotificationPluginAdapter {
  isNativePlatform: () => boolean;
  checkPermissions: () => Promise<PermissionStatus>;
  requestPermissions: () => Promise<PermissionStatus>;
  areEnabled?: () => Promise<{ value: boolean }>;
  checkExactNotificationSetting?: () => Promise<{ exact_alarm: string }>;
  createChannel?: (options: {
    id: string;
    name: string;
    description?: string;
    importance: 1 | 2 | 3 | 4 | 5;
    visibility?: -1 | 0 | 1;
    vibration?: boolean;
    lights?: boolean;
    lightColor?: string;
  }) => Promise<void>;
  schedule: (options: { notifications: LocalNotificationSchema[] }) => Promise<unknown>;
  cancel: (options: { notifications: Array<{ id: number }> }) => Promise<void>;
  getPending: () => Promise<{ notifications: Array<{ id: number; schedule?: { at?: string | Date } }> }>;
}

const defaultPluginAdapter: NotificationPluginAdapter = {
  isNativePlatform: () => Capacitor.isNativePlatform(),
  checkPermissions: () => LocalNotifications.checkPermissions(),
  requestPermissions: () => LocalNotifications.requestPermissions(),
  areEnabled: () => LocalNotifications.areEnabled(),
  checkExactNotificationSetting: () => LocalNotifications.checkExactNotificationSetting(),
  createChannel: (options) => LocalNotifications.createChannel(options),
  schedule: (options) => LocalNotifications.schedule(options),
  cancel: (options) => LocalNotifications.cancel(options),
  getPending: () => LocalNotifications.getPending()
};

let activePluginAdapter: NotificationPluginAdapter = defaultPluginAdapter;
let inFlightSchedulePromise: Promise<DailyNotificationScheduleResult> | null = null;
let lastScheduleResult: DailyNotificationScheduleResult | null = null;

/**
 * Allows deterministic unit testing of native Android paths without altering production defaults.
 */
export function setNotificationPluginAdapterForTesting(
  adapter: NotificationPluginAdapter | null
): void {
  activePluginAdapter = adapter || defaultPluginAdapter;
  inFlightSchedulePromise = null;
  lastScheduleResult = null;
}

/**
 * Large pool of original, funny/troll Hinglish money & expense reminders.
 * Every message includes at least one emoji and avoids copyrighted lyrics.
 */
export const TROLL_REMINDER_MESSAGES: readonly string[] = [
  'Bhai aaj phir Swiggy pe ₹300 uda diye kya? SPLITO mein likh le, wallet ro raha hai 😭💸',
  'Chai-sutta aur momos free nahi milte dost, hisaab likh le warna month-end pe shock lagega 🥟☕',
  'Zomato kholne se pehle apna SPLITO balance dekh le ek baar 👀📉',
  'Roommate ne phir "baad mein deta hoon" bola? Abhi split daal de warna gayab ho jayega 🏃‍♂️💨',
  'Saving plan Monday se start hona tha na? Aaj phir kharcha ho hi gaya 😂🪙',
  'Tera bank account tujhse puch raha hai: bhai itna confidence aata kahan se hai? 🏦😵',
  'Chhote chhote ₹20-₹50 hi mahine ke end mein kidney maang lete hain 💸😅',
  'Late night cravings pe order karne se pehle SPLITO pe purane dues check kar le 🍕🧾',
  'UPI PIN toh bijli ki speed se dalta hai, SPLITO mein entry karne mein kya aalas hai? ⚡🧠',
  'Aaj kitna udaya sach-sach bata de, SPLITO kisi ko nahi batayega (sirf tujhe rulayega) 🤫😭',
  'Pending dues dekh ke dost online aana band kar dete hain, jaldi reminder bhej de 📱👀',
  'Salary aaye 3 din hue hain aur tu phir broke feel kar raha hai? Hisaab check kar 💀💰',
  'Iced coffee aur impulse shopping ka bill SPLITO mein daal, khud ko jhooth mat bol ☕🛍️',
  'Flat ka doodh, bread aur WiFi ka hisaab likh le warna subah Mahabharat hogi 🥛🔥',
  'Paisa ped pe nahi ugta bhai, par tere haath se patte jaisa zaroor gir raha hai 🌳💸',
  'Aaj phir "bas ₹100 hi toh hai" bolke ₹1000 uda diye na? Entry daal abhi 🤡💳',
  'Kal se pakka budget follow karunga — famous last words before online sale 📦😂',
  'Mummy ne puch liya "itne paise kahan gaye?" toh SPLITO hi izzat bachayega 🙏📊',
  'Raat ke 2 baje bhi tera kharcha yaad dila raha hoon kyunki tera wallet so nahi pa raha 🌙💸',
  'Ek aur subscription le liya kya? SPLITO mein likh le warna auto-debit surprise dega 📺😱',
  'Doston ke saath treat split ki thi ya phir sabka bill akele bhar ke hero ban gaya? 🦸‍♂️💔',
  'Tere kharchon ki speed dekh ke toh calculator bhi thak gaya hai 🧮🥵',
  'Auto-rickshaw, chai aur random UPI scans — sabka hisaab chahiye abhi 🛺🪙',
  'Bachat karne ka sapna tootne se pehle aaj ke saare kharche note kar le 🛡️💰',
  'Tera wallet patla ho raha hai aur food delivery bag mota — thoda control bhai 🍔📉',
  'Trip ke photos daal diye Instagram pe, par split abhi tak SPLITO pe nahi daala 📸🧾',
  'Kisne kitna diya tha kal raat? Yaadash kamzor hai toh SPLITO khol le turant 🧠🔍',
  'Paise bacha le mere bhai, har weekend Goa plan cancel hone ke baad bhi zero savings hai 🏖️😭',
  'Chalo uth jao, check karo aaj kahin bina soche ₹500 scan toh nahi kar diya 📲😵‍💫',
  'Roommate ka udhaar lene ka mood hai ya usko gift samajh ke bhool gaye? 🎁💸',
  'Har baar "split kar lenge" bolke bhool jaane waale logon ke liye special alert 🚨😂',
  'Agar ₹10-₹10 bhi count kiya hota toh aaj ek extra biryani aa jaati 🍗✨',
  'Subah ho ya raat, SPLITO ki nazar tere kharchon par hamesha hai 👁️💳',
  'Sale mein 50% off dekh ke jo ₹2000 kharch kiye hain, uska entry kaun karega? 🏷️😅',
  'Aaj koi faltu kharcha nahi kiya? Shabaash! Par kal ka pending bill toh likh le 🏆🧾',
  'Bank statement dekhne se darr lagta hai toh aaj hi SPLITO update rakh le 😬📄',
  'Pet bhar gaya par account khali ho gaya — chal ab likh le kitne gaye 🍜💸',
  'Dost "GPay chal nahi raha" bole toh turant uska naam SPLITO due list mein daal de 🚫📲',
  'Ek aur coffee mangwa li? Tera savings goal kone mein baith ke ro raha hai ☕😢',
  'Raat ko neend nahi aa rahi? Soch le iss hafte kitna faaltu kharcha hua aur likh le 🌃🤔'
];

// Kept for backward test & module compatibility (each contains emoji too)
export const MODE_REMINDER_MESSAGES: Record<SpaceMode, string[]> = {
  personal: [
    'Bhai, did you buy another iced latte? Log it before your bank balance logs out! ☕💸',
    'Paiso ka hisaab rakh lo dost! That midnight snack won\'t account for itself. 🍕😭',
    'Remember that mystery ₹500 you spent today? Add it now before your memory formats. 🧠💳',
    'Future you is looking at your wallet with tears. Log today\'s kharcha in SPLITO! 😭🪙',
    'Ek chai, do samosa, aur teesra kharcha bhool gaye? Track it in SPLITO now. 🥟☕',
    'Wallet check! Log your personal expenses today before they disappear into thin air. 👛💨'
  ],
  roommates: [
    'Who bought the milk today? Add it to SPLITO before Flat 402 enters civil war! 🥛🔥',
    'WiFi bill paid? Gas cylinder booked? Hisaab karo, roommate dosti bachao! 📶😂',
    'Don\'t let your roommate claim "maine toh kal hi diya tha". Log the split now! 🧾👀',
    'Roommate diplomacy rule #1: Settle the eggs and bread bill before dinner tonight. 🍳🍞',
    'Did someone order late-night Maggi? Log it in SPLITO before morning amnesia hits! 🍜🌙',
    'Rent, groceries, or cleaning supplies? Add your roommate share before month-end! 🏠💸'
  ],
  family: [
    'Sabji, doodh, rashan ka hisaab? Mom is definitely going to ask, log it now! 🥦🧾',
    'Family budget rule: Every rupee spent on Dhaniya needs an entry in SPLITO. 🌿💸',
    'Sunday grocery run accounted for? Add family expenses before Mummy takes an audit. 🛒😅',
    'Ghar ka hisaab, sabse zaroori hisaab! Log today\'s household expenses. 🏡📊',
    'Did someone ask Papa for ₹2000? Log the family kharcha before dinnertime! 🍽️💰',
    'Sweet box for relatives or electricity bill? Keep the family ledger clear. ⚡🍬'
  ],
  trip: [
    'Goa trip is still in debt! Log that beach shack seafood bill right now. 🏖️💸',
    'Toll plaza paid? Cab booked? Log trip kharcha before everyone leaves the group! 🚕🧾',
    'Who paid for highway dhaba parathas? Put it on SPLITO before the road trip ends! 🫓🚗',
    'Vacation mode is great, but vacation debt isn\'t. Record who paid for what! ✈️😅',
    'Mountains are calling, and so are your unpaid trip splits! Add travel expenses. 🏔️💳',
    'Fuel split or adventure tickets? Log it in SPLITO before boarding the flight home. ⛽🎟️'
  ]
};

function getRandomFloat(): number {
  try {
    if (typeof globalThis !== 'undefined' && globalThis.crypto?.getRandomValues) {
      const arr = new Uint32Array(1);
      globalThis.crypto.getRandomValues(arr);
      return arr[0] / (0xffffffff + 1);
    }
  } catch {
    // Fallback to Math.random
  }
  return Math.random();
}

function getStorage(): Storage | null {
  try {
    if (typeof localStorage !== 'undefined') {
      return localStorage;
    }
  } catch {
    // ignore
  }
  return null;
}

/**
 * Returns whether expense reminders master toggle is enabled. Default true.
 */
export function areExpenseRemindersEnabled(): boolean {
  const storage = getStorage();
  if (!storage) return true;
  const stored = storage.getItem(REMINDERS_ENABLED_KEY);
  if (stored === null) return true;
  return stored === 'true';
}

/**
 * Sets master toggle for expense reminders.
 */
export async function setExpenseRemindersEnabled(enabled: boolean): Promise<void> {
  const storage = getStorage();
  if (storage) {
    storage.setItem(REMINDERS_ENABLED_KEY, enabled ? 'true' : 'false');
  }
  if (!enabled) {
    await cancelAllExpenseReminders();
  }
}

/**
 * Checks if today is the same local calendar day as a transaction date (YYYY-MM-DD).
 */
export function isTransactionFromToday(dateStr: string): boolean {
  if (!dateStr) return false;
  const today = new Date();
  const year = today.getFullYear();
  const month = String(today.getMonth() + 1).padStart(2, '0');
  const day = String(today.getDate()).padStart(2, '0');
  const todayStr = `${year}-${month}-${day}`;
  return dateStr === todayStr || dateStr.startsWith(todayStr);
}

/**
 * Quiet hours are intentionally disabled per product requirement (full 24-hour random distribution).
 */
export function isWithinQuietHours(_date: Date): boolean {
  return false;
}

/**
 * Picks a random Hinglish funny/troll notification message, guaranteeing:
 * 1) Never repeating the same message twice in a row.
 * 2) Avoiding small-subset repetition using a sliding recent-history window.
 * 3) Every returned message contains at least one emoji.
 */
export function pickRandomTrollMessage(
  pool: readonly string[] = TROLL_REMINDER_MESSAGES
): string {
  if (pool.length === 0) {
    return 'SPLITO reminder: apna aaj ka kharcha likh le bhai! 💸😂';
  }
  if (pool.length === 1) {
    return pool[0];
  }

  const storage = getStorage();
  const lastIndex = storage
    ? parseInt(storage.getItem(LAST_TROLL_INDEX_KEY) || '-1', 10)
    : -1;

  let recentIndices: number[] = [];
  if (storage) {
    try {
      const parsed = JSON.parse(storage.getItem(RECENT_TROLL_INDICES_KEY) || '[]');
      if (Array.isArray(parsed)) {
        recentIndices = parsed.filter((n) => typeof n === 'number' && n >= 0 && n < pool.length);
      }
    } catch {
      recentIndices = [];
    }
  }

  const maxHistory = Math.min(12, Math.floor(pool.length / 2));
  const blocked = new Set<number>(recentIndices.slice(-maxHistory));
  if (lastIndex >= 0 && lastIndex < pool.length) {
    blocked.add(lastIndex);
  }

  let candidateIndices: number[] = [];
  for (let i = 0; i < pool.length; i++) {
    if (!blocked.has(i)) {
      candidateIndices.push(i);
    }
  }
  if (candidateIndices.length === 0) {
    candidateIndices = [];
    for (let i = 0; i < pool.length; i++) {
      if (i !== lastIndex) candidateIndices.push(i);
    }
  }

  const chosenPos = Math.floor(getRandomFloat() * candidateIndices.length);
  const chosenIdx = candidateIndices[Math.min(chosenPos, candidateIndices.length - 1)];

  if (storage) {
    storage.setItem(LAST_TROLL_INDEX_KEY, String(chosenIdx));
    const updatedRecent = [...recentIndices, chosenIdx].slice(-maxHistory);
    storage.setItem(RECENT_TROLL_INDICES_KEY, JSON.stringify(updatedRecent));
  }

  return pool[chosenIdx];
}

/**
 * Selects a random message for a mode while guaranteeing no consecutive repeat.
 */
export function pickHumorousMessage(mode: SpaceMode): string {
  const pool = MODE_REMINDER_MESSAGES[mode] || MODE_REMINDER_MESSAGES.personal;
  const storage = getStorage();
  const lastIndexKey = `splito_last_msg_idx_${mode}`;
  const lastIndex = storage ? parseInt(storage.getItem(lastIndexKey) || '-1', 10) : -1;

  const candidates: number[] = [];
  for (let i = 0; i < pool.length; i++) {
    if (i !== lastIndex) candidates.push(i);
  }
  const poolToPick = candidates.length > 0 ? candidates : [0];
  const newIndex = poolToPick[Math.floor(getRandomFloat() * poolToPick.length)];

  if (storage) {
    storage.setItem(lastIndexKey, String(newIndex));
  }

  return pool[newIndex];
}

/**
 * Generates `count` (default 10) strictly distinct random Date timestamps distributed
 * across the entire upcoming 24-hour period with NO quiet hours blocking.
 * Divides the 24-hour window into `count` contiguous 2.4h strata with an internal margin
 * so all times are guaranteed distinct, randomized across daytime + nighttime (00:00–23:59),
 * and comfortably in the future relative to `now`.
 */
export function generateDailyRandomScheduleTimes(
  now: Date = new Date(),
  count: number = DAILY_NOTIFICATION_COUNT
): Date[] {
  const startOffsetMs = 2 * 60 * 1000; // 2 minutes from now
  const fullDayMs = 24 * 60 * 60 * 1000;
  const endOffsetMs = fullDayMs - 60 * 1000; // within 24h
  const totalWindowMs = endOffsetMs - startOffsetMs;
  const bucketMs = Math.floor(totalWindowMs / count);
  const marginMs = Math.min(2 * 60 * 1000, Math.floor(bucketMs * 0.05));

  const times: Date[] = [];
  const usedMinutes = new Set<number>();

  for (let i = 0; i < count; i++) {
    const bucketStart = now.getTime() + startOffsetMs + i * bucketMs + marginMs;
    const bucketSpan = Math.max(60 * 1000, bucketMs - marginMs * 2);

    let candidateMs = bucketStart + Math.floor(getRandomFloat() * bucketSpan);
    let candidateDate = new Date(candidateMs);
    candidateDate.setSeconds(Math.floor(getRandomFloat() * 59), 0);

    // Guarantee uniqueness even at minute granularity
    let minuteKey = Math.floor(candidateDate.getTime() / 60000);
    while (usedMinutes.has(minuteKey)) {
      candidateDate = new Date(candidateDate.getTime() + 60 * 1000);
      minuteKey = Math.floor(candidateDate.getTime() / 60000);
    }
    usedMinutes.add(minuteKey);
    times.push(candidateDate);
  }

  return times.sort((a, b) => a.getTime() - b.getTime());
}

/**
 * Legacy helper updated to return a randomized future time without quiet-hours blocking.
 */
export function calculateNextReminderTime(targetDate: Date = new Date()): Date {
  const [next] = generateDailyRandomScheduleTimes(targetDate, 1);
  return next;
}

/**
 * Returns user-facing Android settings instructions when notification permission is denied.
 */
export function getNotificationDeniedGuidance(
  permissionStatus: NotificationPermissionState
): string | null {
  if (permissionStatus !== 'denied') {
    return null;
  }
  return 'Notifications are blocked in Android settings. Open Android Settings → Apps → SPLITO → Notifications and turn on Allow notifications.';
}

/**
 * Reads persisted permission state ('granted' | 'denied' | 'prompt').
 */
export function getPersistedNotificationPermission(): NotificationPermissionState {
  const storage = getStorage();
  const saved = storage?.getItem(PERMISSION_STATE_KEY);
  if (saved === 'granted' || saved === 'denied' || saved === 'prompt') {
    return saved;
  }
  return 'prompt';
}

function setPersistedNotificationPermission(status: NotificationPermissionState): void {
  const storage = getStorage();
  storage?.setItem(PERMISSION_STATE_KEY, status);
}

export function getLastNotificationScheduleResult(): DailyNotificationScheduleResult | null {
  return lastScheduleResult;
}

/**
 * Queries current native/web notification permission status without triggering a system prompt.
 */
export async function getNotificationPermissionStatus(): Promise<NotificationPermissionState> {
  if (!activePluginAdapter.isNativePlatform()) {
    return 'granted';
  }

  try {
    const perm = await activePluginAdapter.checkPermissions();
    let display = perm?.display;

    if (display === 'granted' && activePluginAdapter.areEnabled) {
      try {
        const enabledRes = await activePluginAdapter.areEnabled();
        if (enabledRes && enabledRes.value === false) {
          display = 'denied';
        }
      } catch {
        // ignore if unsupported
      }
    }

    const mapped: NotificationPermissionState =
      display === 'granted' ? 'granted' : display === 'denied' ? 'denied' : 'prompt';
    setPersistedNotificationPermission(mapped);
    return mapped;
  } catch {
    return getPersistedNotificationPermission();
  }
}

/**
 * Ensures the Android High-Importance notification channel exists (API 26+).
 * Uses system default sound via high-importance channel instead of invalid 'default' asset string.
 */
export async function ensureNotificationChannel(): Promise<void> {
  if (!activePluginAdapter.isNativePlatform() || !activePluginAdapter.createChannel) {
    return;
  }
  try {
    await activePluginAdapter.createChannel({
      id: TROLL_CHANNEL_ID,
      name: 'SPLITO Reminders',
      description: 'Daily funny Hinglish expense and split reminders',
      importance: 4,
      visibility: 1,
      vibration: true,
      lights: true,
      lightColor: '#2563EB'
    });
  } catch (err) {
    console.warn('Notification channel creation failed:', err);
  }
}

/**
 * Explicit permission flow:
 * - Never repeatedly prompts on background runs once prompted/denied.
 * - Prompts when `fromUserAction` is true or on first unprompted startup.
 * - Returns clear 'granted' | 'denied' | 'prompt' status.
 */
export async function resolveNotificationPermission(options?: {
  fromUserAction?: boolean;
}): Promise<NotificationPermissionState> {
  if (!activePluginAdapter.isNativePlatform()) {
    setPersistedNotificationPermission('granted');
    return 'granted';
  }

  const fromUserAction = Boolean(options?.fromUserAction);
  const storage = getStorage();

  try {
    const currentStatus = await getNotificationPermissionStatus();
    if (currentStatus === 'granted') {
      return 'granted';
    }

    if (currentStatus === 'denied' && !fromUserAction) {
      return 'denied';
    }

    const alreadyPrompted = storage?.getItem(PERMISSION_PROMPTED_KEY) === '1';
    if (!fromUserAction && alreadyPrompted) {
      return currentStatus;
    }

    storage?.setItem(PERMISSION_PROMPTED_KEY, '1');
    const req = await activePluginAdapter.requestPermissions();
    let finalDisplay = req?.display;

    if (finalDisplay === 'granted' && activePluginAdapter.areEnabled) {
      try {
        const enabledRes = await activePluginAdapter.areEnabled();
        if (enabledRes && enabledRes.value === false) {
          finalDisplay = 'denied';
        }
      } catch {
        // ignore
      }
    }

    const mapped: NotificationPermissionState =
      finalDisplay === 'granted' ? 'granted' : 'denied';
    setPersistedNotificationPermission(mapped);
    return mapped;
  } catch (err) {
    console.warn('Notification permission check/request failed:', err);
    setPersistedNotificationPermission('denied');
    return 'denied';
  }
}

/**
 * Polite permission check and request for Android 13+.
 * Returns true if granted (or non-native web preview), false if denied.
 */
export async function requestNotificationPermissionPolitely(
  fromUserAction: boolean = false
): Promise<boolean> {
  const status = await resolveNotificationPermission({ fromUserAction });
  return status === 'granted';
}

/**
 * Cancels all SPLITO managed local notifications cleanly (never wipes unrelated notifications).
 */
export async function cancelAllExpenseReminders(): Promise<void> {
  const storage = getStorage();
  storage?.removeItem(SCHEDULED_BATCH_KEY);

  try {
    await activePluginAdapter.cancel({
      notifications: ALL_MANAGED_IDS.map((id) => ({ id }))
    });
  } catch (err) {
    console.warn('Local notifications cancellation notice:', err);
  }
}

interface StoredBatch {
  expiresAt: number;
  notifications: ScheduledTrollNotification[];
}

function readStoredBatch(): StoredBatch | null {
  const storage = getStorage();
  if (!storage) return null;
  try {
    const raw = storage.getItem(SCHEDULED_BATCH_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as StoredBatch;
    if (
      parsed &&
      typeof parsed.expiresAt === 'number' &&
      Array.isArray(parsed.notifications)
    ) {
      return parsed;
    }
  } catch {
    // ignore corrupt JSON
  }
  return null;
}

function writeStoredBatch(batch: StoredBatch): void {
  const storage = getStorage();
  storage?.setItem(SCHEDULED_BATCH_KEY, JSON.stringify(batch));
}

async function hasValidPendingBatch(
  nowMs: number,
  stored: StoredBatch | null
): Promise<boolean> {
  if (!stored) return false;
  if (stored.notifications.length !== DAILY_NOTIFICATION_COUNT) return false;
  if (stored.expiresAt <= nowMs) return false;

  const allFutureInStorage = stored.notifications.every(
    (n) => new Date(n.at).getTime() > nowMs + 30 * 1000
  );
  if (!allFutureInStorage) return false;

  if (activePluginAdapter.isNativePlatform()) {
    try {
      const pending = await activePluginAdapter.getPending();
      const pendingSet = new Set(
        (pending?.notifications || [])
          .filter((p) => TROLL_NOTIFICATION_IDS.includes(p.id))
          .map((p) => p.id)
      );
      return TROLL_NOTIFICATION_IDS.every((id) => pendingSet.has(id));
    } catch {
      return false;
    }
  }

  return true;
}

/**
 * Core 10/day funny Hinglish local notification scheduler.
 * - Guarantees 10 random notifications spread across the next 24h (zero quiet hours).
 * - Never resets/duplicates when called repeatedly unless batch expired or forced.
 * - Explicitly configures Android channel & AlarmManager exact/inexact allowWhileIdle flags
 *   to avoid Android 12+/14+ settings hijacks and Doze drops.
 */
export async function scheduleDailyTrollNotifications(options?: {
  force?: boolean;
  fromUserAction?: boolean;
  now?: Date;
}): Promise<DailyNotificationScheduleResult> {
  if (inFlightSchedulePromise && !options?.force) {
    return inFlightSchedulePromise;
  }

  const run = async (): Promise<DailyNotificationScheduleResult> => {
    const now = options?.now || new Date();
    const nowMs = now.getTime();
    const enabled = areExpenseRemindersEnabled();

    if (!enabled) {
      await cancelAllExpenseReminders();
      const disabledResult: DailyNotificationScheduleResult = {
        enabled: false,
        permissionStatus: await getNotificationPermissionStatus(),
        exactAlarmStatus: 'unknown',
        scheduledCount: 0,
        notifications: [],
        reusedExistingBatch: false
      };
      lastScheduleResult = disabledResult;
      return disabledResult;
    }

    const permissionStatus = await resolveNotificationPermission({
      fromUserAction: options?.fromUserAction
    });

    if (permissionStatus !== 'granted') {
      await cancelAllExpenseReminders();
      const deniedResult: DailyNotificationScheduleResult = {
        enabled: true,
        permissionStatus,
        exactAlarmStatus: 'unknown',
        scheduledCount: 0,
        notifications: [],
        reusedExistingBatch: false,
        error:
          getNotificationDeniedGuidance(permissionStatus) ||
          'Notification permission not granted.'
      };
      lastScheduleResult = deniedResult;
      return deniedResult;
    }

    await ensureNotificationChannel();

    let exactAlarmStatus: 'granted' | 'denied' | 'unknown' = 'unknown';
    let useExactAlarm = false;
    if (
      activePluginAdapter.isNativePlatform() &&
      activePluginAdapter.checkExactNotificationSetting
    ) {
      try {
        const exactRes = await activePluginAdapter.checkExactNotificationSetting();
        exactAlarmStatus = exactRes?.exact_alarm === 'granted' ? 'granted' : 'denied';
        useExactAlarm = exactAlarmStatus === 'granted';
      } catch {
        exactAlarmStatus = 'unknown';
        useExactAlarm = false;
      }
    }

    const stored = readStoredBatch();
    if (!options?.force && (await hasValidPendingBatch(nowMs, stored)) && stored) {
      const reusedResult: DailyNotificationScheduleResult = {
        enabled: true,
        permissionStatus: 'granted',
        exactAlarmStatus,
        scheduledCount: stored.notifications.length,
        notifications: stored.notifications,
        reusedExistingBatch: true
      };
      lastScheduleResult = reusedResult;
      return reusedResult;
    }

    // Cancel previously scheduled managed notifications to prevent duplicates/drift
    try {
      await activePluginAdapter.cancel({
        notifications: ALL_MANAGED_IDS.map((id) => ({ id }))
      });
    } catch {
      // ignore if nothing pending
    }

    const triggerTimes = generateDailyRandomScheduleTimes(now, DAILY_NOTIFICATION_COUNT);
    const schemas: LocalNotificationSchema[] = [];
    const scheduledRecords: ScheduledTrollNotification[] = [];

    for (let i = 0; i < DAILY_NOTIFICATION_COUNT; i++) {
      const id = TROLL_NOTIFICATION_IDS[i];
      const triggerDate = triggerTimes[i];
      const body = pickRandomTrollMessage();
      const title = 'SPLITO Reminder 💸';

      schemas.push({
        id,
        title,
        body,
        channelId: TROLL_CHANNEL_ID,
        schedule: {
          at: triggerDate,
          allowWhileIdle: true
        },
        autoCancel: true,
        foreground: true,
        isExactNotification: useExactAlarm,
        isExactMandatory: false,
        extra: {
          type: 'troll_expense_reminder',
          slotIndex: i
        }
      });

      scheduledRecords.push({
        id,
        title,
        body,
        at: triggerDate.toISOString()
      });
    }

    try {
      if (activePluginAdapter.isNativePlatform()) {
        await activePluginAdapter.schedule({ notifications: schemas });
      }
    } catch (err) {
      const message =
        err instanceof Error ? err.message : 'Failed to schedule local notifications.';
      console.warn('Local notification schedule failure:', err);
      const errResult: DailyNotificationScheduleResult = {
        enabled: true,
        permissionStatus: 'granted',
        exactAlarmStatus,
        scheduledCount: 0,
        notifications: [],
        reusedExistingBatch: false,
        error: message
      };
      lastScheduleResult = errResult;
      return errResult;
    }

    const lastTriggerMs = triggerTimes[triggerTimes.length - 1].getTime();
    writeStoredBatch({
      expiresAt: lastTriggerMs,
      notifications: scheduledRecords
    });

    const successResult: DailyNotificationScheduleResult = {
      enabled: true,
      permissionStatus: 'granted',
      exactAlarmStatus,
      scheduledCount: scheduledRecords.length,
      notifications: scheduledRecords,
      reusedExistingBatch: false
    };
    lastScheduleResult = successResult;
    return successResult;
  };

  const promise = run().finally(() => {
    if (inFlightSchedulePromise === promise) {
      inFlightSchedulePromise = null;
    }
  });
  inFlightSchedulePromise = promise;
  return promise;
}

/**
 * Compatibility wrapper invoked from App.tsx and tests.
 * Always schedules 10 random daily notifications across 24h whenever enabled & permitted,
 * regardless of whether an expense was logged today.
 */
export async function scheduleDailyExpenseReminders(
  _spaces: Space[] = [],
  _transactions: Transaction[] = [],
  options?: { force?: boolean; fromUserAction?: boolean; now?: Date }
): Promise<ReminderSchedulePlan[]> {
  const result = await scheduleDailyTrollNotifications(options);
  if (!result.enabled || result.permissionStatus !== 'granted' || result.scheduledCount === 0) {
    return [];
  }

  return result.notifications.map((n) => ({
    mode: 'personal' as SpaceMode,
    scheduled: true,
    reason: 'scheduled_success' as const,
    targetTime: n.at,
    message: n.body,
    notificationId: n.id
  }));
}
