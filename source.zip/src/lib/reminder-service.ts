import { LocalNotifications, ScheduleOptions, PermissionStatus } from '@capacitor/local-notifications';
import { Capacitor } from '@capacitor/core';
import { Space, SpaceMode, Transaction } from '../types/finance.ts';

export const REMINDERS_ENABLED_KEY = 'splito_expense_reminders_enabled';

// Fixed notification IDs per mode to prevent duplicate accumulation
export const MODE_NOTIFICATION_IDS: Record<SpaceMode, number> = {
  personal: 2001,
  roommates: 2002,
  family: 2003,
  trip: 2004
};

// Humorous, witty, Hinglish-friendly message pools (at least 5 per mode)
export const MODE_REMINDER_MESSAGES: Record<SpaceMode, string[]> = {
  personal: [
    'Bhai, did you buy another iced latte? Log it before your bank balance logs out!',
    'Paiso ka hisaab rakh lo dost! That midnight snack won\'t account for itself.',
    'Remember that mystery ₹500 you spent today? Add it now before your memory formats.',
    'Future you is looking at your wallet with tears. Log today\'s kharcha in SPLITO!',
    'Ek chai, do samosa, aur teesra kharcha bhool gaye? Track it in SPLITO now.',
    'Wallet check! Log your personal expenses today before they disappear into thin air.'
  ],
  roommates: [
    'Who bought the milk today? Add it to SPLITO before Flat 402 enters civil war!',
    'WiFi bill paid? Gas cylinder booked? Hisaab karo, roommate dosti bachao!',
    'Don\'t let your roommate claim "maine toh kal hi diya tha". Log the split now!',
    'Roommate diplomacy rule #1: Settle the eggs and bread bill before dinner tonight.',
    'Did someone order late-night Maggi? Log it in SPLITO before morning amnesia hits!',
    'Rent, groceries, or cleaning supplies? Add your roommate share before the month ends!'
  ],
  family: [
    'Sabji, doodh, rashan ka hisaab? Mom is definitely going to ask, log it now!',
    'Family budget rule: Every rupee spent on Dhaniya needs an entry in SPLITO.',
    'Sunday grocery run accounted for? Add family expenses before Mummy takes an audit.',
    'Ghar ka hisaab, sabse zaroori hisaab! Log today\'s household expenses.',
    'Did someone ask Papa for ₹2000? Log the family kharcha before dinnertime!',
    'Sweet box for relatives or electricity bill? Keep the family ledger clear.'
  ],
  trip: [
    'Goa trip is still in debt! Log that beach shack seafood bill right now.',
    'Toll plaza paid? Cab booked? Log trip kharcha before everyone leaves the group!',
    'Who paid for highway dhaba parathas? Put it on SPLITO before the road trip ends!',
    'Vacation mode is great, but vacation debt isn\'t. Record who paid for what!',
    'Mountains are calling, and so are your unpaid trip splits! Add today\'s travel expenses.',
    'Fuel split or adventure tickets? Log it in SPLITO before boarding the flight home.'
  ]
};

/**
 * Returns whether expense reminders master toggle is enabled. Default true.
 */
export function areExpenseRemindersEnabled(): boolean {
  if (typeof localStorage === 'undefined') return true;
  const stored = localStorage.getItem(REMINDERS_ENABLED_KEY);
  if (stored === null) return true;
  return stored === 'true';
}

/**
 * Sets master toggle for expense reminders.
 */
export async function setExpenseRemindersEnabled(enabled: boolean): Promise<void> {
  if (typeof localStorage !== 'undefined') {
    localStorage.setItem(REMINDERS_ENABLED_KEY, enabled ? 'true' : 'false');
  }
  if (!enabled) {
    await cancelAllExpenseReminders();
  }
}

/**
 * Checks if a given Date falls within quiet hours (10:00 PM to 8:00 AM).
 */
export function isWithinQuietHours(date: Date): boolean {
  const hours = date.getHours();
  return hours >= 22 || hours < 8;
}

/**
 * Checks if today is the same local calendar day as a transaction date (YYYY-MM-DD).
 */
export function isTransactionFromToday(dateStr: string): boolean {
  if (!dateStr) return false;
  const today = new Date();
  const year = today.getFullYear();
  const month = String(today.getMonth() + 1).padStart(2, '0');
  const day = String(today.getDate()).padStart(2, '0');
  const todayStr = `${year}-${month}-${day}`;
  return dateStr === todayStr || dateStr.startsWith(todayStr);
}

/**
 * Generates a random time between 18:00 (6:00 PM) and 21:00 (9:00 PM) for either today or tomorrow.
 */
export function calculateNextReminderTime(targetDate: Date = new Date()): Date {
  const reminderTime = new Date(targetDate);
  // Random hour in [18, 19, 20] (6 PM, 7 PM, 8 PM)
  const randomHour = 18 + Math.floor(Math.random() * 3);
  const randomMinute = Math.floor(Math.random() * 60);

  reminderTime.setHours(randomHour, randomMinute, 0, 0);

  // If this target time today has already elapsed, schedule for tomorrow at the same random time
  const now = new Date();
  if (reminderTime.getTime() <= now.getTime()) {
    reminderTime.setDate(reminderTime.getDate() + 1);
  }

  // Ensure strict quiet hours guarantee (10 PM to 8 AM)
  if (isWithinQuietHours(reminderTime)) {
    reminderTime.setHours(19, 30, 0, 0);
  }

  return reminderTime;
}

/**
 * Selects a random message for a mode while guaranteeing no repeat from yesterday.
 */
export function pickHumorousMessage(mode: SpaceMode): string {
  const pool = MODE_REMINDER_MESSAGES[mode] || MODE_REMINDER_MESSAGES.personal;
  const lastIndexKey = `splito_last_msg_idx_${mode}`;
  const lastIndex = typeof localStorage !== 'undefined' ? parseInt(localStorage.getItem(lastIndexKey) || '-1', 10) : -1;

  let newIndex = Math.floor(Math.random() * pool.length);
  if (pool.length > 1 && newIndex === lastIndex) {
    newIndex = (newIndex + 1) % pool.length;
  }

  if (typeof localStorage !== 'undefined') {
    localStorage.setItem(lastIndexKey, String(newIndex));
  }

  return pool[newIndex];
}

/**
 * Cancels all scheduled mode reminders.
 */
export async function cancelAllExpenseReminders(): Promise<void> {
  try {
    const ids = Object.values(MODE_NOTIFICATION_IDS).map((id) => ({ id }));
    await LocalNotifications.cancel({ notifications: ids });
  } catch (err) {
    // In web preview or unsupported environments, ignore gracefully
    console.warn('Local notifications cancellation notice:', err);
  }
}

/**
 * Polite permission check and request for Android 13+.
 * Returns true if granted or in web preview, false if denied.
 */
export async function requestNotificationPermissionPolitely(): Promise<boolean> {
  if (!Capacitor.isNativePlatform()) {
    return true; // Web preview allows safe execution
  }

  try {
    const status: PermissionStatus = await LocalNotifications.checkPermissions();
    if (status.display === 'granted') {
      return true;
    }
    if (status.display === 'denied') {
      return false; // Denied by user, do not nag
    }
    const requestResult = await LocalNotifications.requestPermissions();
    return requestResult.display === 'granted';
  } catch (err) {
    console.warn('Notification permission request error:', err);
    return false;
  }
}

export interface ReminderSchedulePlan {
  mode: SpaceMode;
  scheduled: boolean;
  reason?: 'skipped_already_logged_today' | 'scheduled_success' | 'no_spaces_for_mode';
  targetTime?: string;
  message?: string;
  notificationId: number;
}

/**
 * Master scheduling engine:
 * 1. Checks master toggle.
 * 2. Checks permissions politely.
 * 3. Inspects active spaces and today's transactions.
 * 4. Schedules one reminder per mode between 6:00 PM and 9:00 PM.
 * 5. Performs smart skip if an expense was already logged today in that mode.
 */
export async function scheduleDailyExpenseReminders(
  spaces: Space[],
  transactions: Transaction[]
): Promise<ReminderSchedulePlan[]> {
  const isEnabled = areExpenseRemindersEnabled();
  if (!isEnabled) {
    await cancelAllExpenseReminders();
    return [];
  }

  // Find active space modes that the user has
  const activeModes = Array.from(new Set(spaces.map((s) => s.mode)));
  const plans: ReminderSchedulePlan[] = [];

  // Polite permission check
  const hasPermission = await requestNotificationPermissionPolitely();
  if (!hasPermission && Capacitor.isNativePlatform()) {
    return [];
  }

  for (const mode of ['personal', 'roommates', 'family', 'trip'] as SpaceMode[]) {
    const notificationId = MODE_NOTIFICATION_IDS[mode];

    // If user has no spaces in this mode, cancel any existing reminder for it
    if (!activeModes.includes(mode)) {
      try {
        await LocalNotifications.cancel({ notifications: [{ id: notificationId }] });
      } catch {
        // ignore
      }
      plans.push({
        mode,
        scheduled: false,
        reason: 'no_spaces_for_mode',
        notificationId
      });
      continue;
    }

    // Smart skip check: did user already add an expense today in any space of this mode?
    const spaceIdsInMode = new Set(spaces.filter((s) => s.mode === mode).map((s) => s.id));
    const hasExpenseToday = transactions.some(
      (tx) => tx.type === 'expense' && spaceIdsInMode.has(tx.spaceId || '') && isTransactionFromToday(tx.date)
    );

    if (hasExpenseToday) {
      // User has already accounted for expenses today in this mode! Smart skip today.
      try {
        await LocalNotifications.cancel({ notifications: [{ id: notificationId }] });
      } catch {
        // ignore
      }
      plans.push({
        mode,
        scheduled: false,
        reason: 'skipped_already_logged_today',
        notificationId
      });
      continue;
    }

    // Schedule notification for this mode
    const scheduledTime = calculateNextReminderTime();
    const message = pickHumorousMessage(mode);
    const title = `SPLITO ${mode.charAt(0).toUpperCase() + mode.slice(1)} Reminder`;

    try {
      // First cancel existing to prevent duplicates
      await LocalNotifications.cancel({ notifications: [{ id: notificationId }] });

      await LocalNotifications.schedule({
        notifications: [
          {
            id: notificationId,
            title,
            body: message,
            schedule: { at: scheduledTime },
            sound: 'default',
            smallIcon: 'ic_stat_splito',
            extra: {
              mode,
              type: 'expense_reminder'
            }
          }
        ]
      });
    } catch (err) {
      // In web preview or node without Web Notifications support, proceed safely
    }

    plans.push({
      mode,
      scheduled: true,
      reason: 'scheduled_success',
      targetTime: scheduledTime.toISOString(),
      message,
      notificationId
    });
  }

  return plans;
}
