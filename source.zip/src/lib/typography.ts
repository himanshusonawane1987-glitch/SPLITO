/**
 * HISAAB Typography Design System — Definitive Master Specification v1.3
 * 
 * Fonts:
 * 1. Primary: 'Plus Jakarta Sans', 'Inter', system-ui, sans-serif
 *    Chosen for high x-height, open apertures, geometric clarity, and crisp legibility
 *    at small sizes (11px-14px) and modern fintech elegance at display scale.
 * 2. Monospace & Tabular Numeric: 'JetBrains Mono', 'SF Mono', monospace
 *    Used for all financial amounts with tabular numerals (tnum) so digits align vertically
 *    across ledger tables, split share matrices, and monthly statements without jitter.
 */

export const TYPOGRAPHY = {
  fonts: {
    primary: "'Plus Jakarta Sans', 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
    monospace: "'JetBrains Mono', 'SF Mono', 'Roboto Mono', Menlo, monospace"
  },
  sizes: {
    display: 'text-[32px] sm:text-[36px]',
    h1: 'text-[28px]',
    h2: 'text-[24px]',
    h3: 'text-[20px]',
    bodyLg: 'text-[16px]',
    body: 'text-[14px]',
    bodySm: 'text-[13px]',
    label: 'text-[12px]',
    caption: 'text-[11px]',
    financialLg: 'text-[30px] sm:text-[34px]',
    financialMd: 'text-[22px]',
    financialSm: 'text-[15px]'
  },
  weights: {
    regular: 'font-normal', // 400
    medium: 'font-medium',   // 500
    semibold: 'font-semibold', // 600
    bold: 'font-bold',       // 700
    extrabold: 'font-extrabold' // 800
  },
  lineHeights: {
    tight: 'leading-[1.15]',
    heading: 'leading-[1.25]',
    body: 'leading-[1.5]',
    relaxed: 'leading-[1.65]',
    label: 'leading-[1.35]'
  },
  tracking: {
    tighter: 'tracking-[-0.03em]',
    tight: 'tracking-[-0.02em]',
    normal: 'tracking-[0]',
    wide: 'tracking-[0.02em]',
    wider: 'tracking-[0.04em]'
  }
} as const;

/**
 * Standard semantic typography style tokens
 */
export const TEXT_STYLES = {
  // Display & Headings
  display: 'font-extrabold tracking-[-0.025em] leading-[1.15] font-sans',
  h1: 'font-bold tracking-[-0.02em] leading-[1.25] font-sans',
  h2: 'font-bold tracking-[-0.015em] leading-[1.25] font-sans',
  h3: 'font-semibold tracking-[-0.01em] leading-[1.3] font-sans',
  
  // Body text
  bodyLarge: 'text-base font-normal leading-relaxed text-slate-700',
  body: 'text-sm font-normal leading-normal text-slate-700',
  bodyMedium: 'text-sm font-medium leading-normal text-slate-800',
  bodySmall: 'text-[13px] font-normal leading-normal text-slate-600',
  
  // Labels & Captions
  label: 'text-xs font-semibold uppercase tracking-wider text-slate-500 leading-tight',
  caption: 'text-[11px] font-medium leading-tight text-slate-400',
  
  // Interactive
  button: 'text-sm font-semibold tracking-[0.01em] leading-tight select-none',
  navigation: 'text-[10px] font-medium tracking-tight leading-none',
  
  // Financial Amounts
  amountHero: 'font-mono font-extrabold tracking-[-0.02em] leading-[1.15] tabular-nums',
  amountMetric: 'font-mono font-bold tracking-[-0.01em] leading-[1.2] tabular-nums',
  amountRow: 'font-mono font-bold leading-tight tabular-nums',
  amountSmall: 'font-mono font-semibold text-xs leading-none tabular-nums'
} as const;
