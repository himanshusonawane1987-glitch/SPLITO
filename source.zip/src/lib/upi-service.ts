/**
 * SPLITO Wallet Pay — UPI Service
 * Spec V1.0
 * 
 * Responsibilities:
 * 1. Known UPI application registry with local assets & brand colors (no remote URLs).
 * 2. Safe, RFC-compliant UPI payment URI generator (INR only, integer minor units to rupees).
 * 3. Strict VPA validation (no invalid or fake merchant VPAs).
 * 4. External UPI application launch with fallback.
 * 5. In-flight payment persistence in localStorage for crash resilience.
 * 6. Foreground return detection via Capacitor App listener + document.visibilitychange.
 * 7. Clear separation between: (a) app launch, (b) foreground return, and (c) manual payment confirmation.
 */

import { App } from '@capacitor/app';
import { AppLauncher } from '@capacitor/app-launcher';
import { Capacitor } from '@capacitor/core';

export interface KnownUpiApp {
  id: string;
  name: string;
  packageName: string;
  brandColor: string;
  accentBg: string;
  shortCode: string;
  isPopular?: boolean;
}

export const KNOWN_UPI_APPS: KnownUpiApp[] = [
  {
    id: 'gpay',
    name: 'Google Pay',
    packageName: 'com.google.android.apps.nbu.paisa.user',
    brandColor: '#4285F4',
    accentBg: '#E8F0FE',
    shortCode: 'GPay',
    isPopular: true
  },
  {
    id: 'phonepe',
    name: 'PhonePe',
    packageName: 'com.phonepe.app',
    brandColor: '#5F259F',
    accentBg: '#F3E8FF',
    shortCode: 'Pe',
    isPopular: true
  },
  {
    id: 'paytm',
    name: 'Paytm',
    packageName: 'net.one97.paytm',
    brandColor: '#002E6E',
    accentBg: '#E0F2FE',
    shortCode: 'Paytm',
    isPopular: true
  },
  {
    id: 'amazonpay',
    name: 'Amazon Pay',
    packageName: 'in.amazon.mShop.android.shopping',
    brandColor: '#FF9900',
    accentBg: '#FEF3C7',
    shortCode: 'Amzn',
    isPopular: false
  },
  {
    id: 'bhim',
    name: 'BHIM UPI',
    packageName: 'in.org.npci.upiapp',
    brandColor: '#00796B',
    accentBg: '#E0F2F1',
    shortCode: 'BHIM',
    isPopular: false
  },
  {
    id: 'whatsapp',
    name: 'WhatsApp Pay',
    packageName: 'com.whatsapp',
    brandColor: '#25D366',
    accentBg: '#DCFCE7',
    shortCode: 'WA',
    isPopular: false
  },
  {
    id: 'other',
    name: 'Other UPI App',
    packageName: 'android.intent.action.VIEW',
    brandColor: '#475569',
    accentBg: '#F1F5F9',
    shortCode: 'UPI',
    isPopular: false
  }
];

export interface UpiUriBuildOptions {
  vpa?: string | null;
  payeeName?: string | null;
  amountMinorUnits: number;
  note?: string | null;
  transactionRef?: string | null;
}

export interface InFlightPaymentData {
  transactionId: string;
  spaceId: string;
  originalAmountMinorUnits: number;
  title: string;
  payerId: string;
  payeeVpa?: string | null;
  payeeName?: string | null;
  paymentAppId: string;
  paymentAppLabel: string;
  timestamp: string;
}

const IN_FLIGHT_STORAGE_KEY = 'splito_inflight_wallet_tx';

/**
 * Validates whether a given string is a syntactically valid UPI VPA.
 * Standard format: username@bankhandle (e.g. rahul@oksbi, 9876543210@paytm)
 */
export function isValidVpa(vpa?: string | null): boolean {
  if (!vpa || typeof vpa !== 'string') return false;
  const trimmed = vpa.trim();
  // Standard NPCI VPA format: 2-256 characters before @, 2-64 characters after @
  const vpaRegex = /^[a-zA-Z0-9.\-_]{2,256}@[a-zA-Z0-9]{2,64}$/;
  return vpaRegex.test(trimmed);
}

/**
 * Formats integer minor units (paise) into a clean INR rupee string for the UPI am parameter.
 * e.g. 5000 paise -> "50.00", 12550 paise -> "125.50"
 */
export function formatMinorUnitsToRupees(minorUnits: number): string {
  const safeUnits = Math.max(0, Math.round(minorUnits));
  return (safeUnits / 100).toFixed(2);
}

/**
 * Builds an RFC-compliant UPI payment intent URI.
 * Guaranteed format: upi://pay?pa=<VPA>&pn=<NAME>&am=<AMOUNT>&cu=INR&tn=<NOTE>&tr=<REFERENCE>
 * 
 * Rules:
 * - If VPA is missing or invalid, uri is returned as null (never generate a fake VPA).
 * - All query parameters are strictly encoded via URLSearchParams.
 */
export function buildUpiPaymentUri(options: UpiUriBuildOptions): {
  uri: string | null;
  hasValidVpa: boolean;
  message?: string;
} {
  const { vpa, payeeName, amountMinorUnits, note, transactionRef } = options;

  if (amountMinorUnits <= 0) {
    return {
      uri: null,
      hasValidVpa: false,
      message: 'Payment amount must be greater than zero.'
    };
  }

  if (!isValidVpa(vpa)) {
    return {
      uri: null,
      hasValidVpa: false,
      message: 'Payee UPI ID (VPA) is missing or not configured. You can open your UPI app and scan the merchant QR code manually.'
    };
  }

  const cleanVpa = (vpa || '').trim();
  const cleanName = (payeeName || 'SPLITO Payee').trim();
  const amountStr = formatMinorUnitsToRupees(amountMinorUnits);

  const params = new URLSearchParams();
  params.set('pa', cleanVpa);
  params.set('pn', cleanName);
  params.set('am', amountStr);
  params.set('cu', 'INR');

  if (note && note.trim()) {
    params.set('tn', note.trim());
  } else {
    params.set('tn', 'SPLITO Expense');
  }

  if (transactionRef && transactionRef.trim()) {
    params.set('tr', transactionRef.trim());
  }

  const uri = `upi://pay?${params.toString()}`;
  return {
    uri,
    hasValidVpa: true
  };
}

export interface TargetedUpiResult {
  customSchemeUri: string | null;
  intentUri: string | null;
  fallbackUri: string;
}

/**
 * Builds targeted URI schemes and Android Intent URIs for specific UPI applications.
 * This directly routes payments to the chosen application (e.g. PhonePe, Paytm, Google Pay)
 * rather than delegating to Android's generic upi:// resolver or system chooser.
 */
export function buildTargetedUpiUri(app: KnownUpiApp, baseUri: string): TargetedUpiResult {
  const queryParams = baseUri.replace(/^upi:\/\/pay\??/, '');

  let customSchemeUri: string | null = null;
  let intentUri: string | null = null;

  // App-specific direct deep link schemes
  if (app.id === 'phonepe') {
    customSchemeUri = `phonepe://pay?${queryParams}`;
  } else if (app.id === 'paytm') {
    customSchemeUri = `paytmmp://pay?${queryParams}`;
  } else if (app.id === 'gpay') {
    customSchemeUri = `tez://upi/pay?${queryParams}`;
  }

  // Android explicit package Intent URI for WebView and Chrome
  if (app.id !== 'other' && app.packageName && app.packageName !== 'android.intent.action.VIEW') {
    intentUri = `intent://pay?${queryParams}#Intent;scheme=upi;package=${app.packageName};end`;
  }

  return {
    customSchemeUri,
    intentUri,
    fallbackUri: baseUri
  };
}

/**
 * Launches the external UPI payment flow or opens the selected app.
 * Returns an honest status indicating whether the launch was successfully dispatched.
 * Note: Launching an external app does NOT prove that a payment was completed!
 */
export async function launchUpiPayment(
  app: KnownUpiApp,
  uri: string | null
): Promise<{ dispatched: boolean; message: string; targetedUri?: string }> {
  try {
    if (uri) {
      const targeted = buildTargetedUpiUri(app, uri);

      if (Capacitor.isNativePlatform()) {
        // Step 1: If an app-specific custom scheme is available (PhonePe, Paytm, Tez/GPay), try that first
        if (targeted.customSchemeUri) {
          try {
            const canOpen = await AppLauncher.canOpenUrl({ url: targeted.customSchemeUri });
            if (canOpen.value) {
              await AppLauncher.openUrl({ url: targeted.customSchemeUri });
              return {
                dispatched: true,
                message: `Opened direct deep-link with ${app.name}.`,
                targetedUri: targeted.customSchemeUri
              };
            }
          } catch {
            // Fall through to standard check
          }
        }

        // Step 2: Try native AppLauncher with standard UPI URI
        try {
          const canOpen = await AppLauncher.canOpenUrl({ url: uri });
          if (canOpen.value) {
            await AppLauncher.openUrl({ url: uri });
            return {
              dispatched: true,
              message: `Opened UPI payment handoff with ${app.name}.`,
              targetedUri: uri
            };
          }
        } catch {
          // Native app launcher fallback
        }
      }

      // Step 3: Web / WebView intent dispatch
      if (typeof window !== 'undefined') {
        const userAgent = typeof navigator !== 'undefined' ? (navigator.userAgent || '') : '';
        const isAndroid = /android/i.test(userAgent);

        // On Android WebViews/browsers, prioritize the explicit package Intent URI if available,
        // otherwise prefer app-specific custom scheme, or standard upi:// URI
        const dispatchUri = (isAndroid && targeted.intentUri) 
          ? targeted.intentUri 
          : (targeted.customSchemeUri || uri);

        const link = document.createElement('a');
        link.href = dispatchUri;
        link.style.display = 'none';
        document.body.appendChild(link);
        link.click();
        setTimeout(() => {
          if (document.body.contains(link)) {
            document.body.removeChild(link);
          }
        }, 1000);

        return {
          dispatched: true,
          message: `Dispatched payment request to ${app.name}.`,
          targetedUri: dispatchUri
        };
      }
    }

    // When no VPA exists (e.g. manual merchant QR payment), launch the selected app directly
    if (app.packageName && app.packageName !== 'android.intent.action.VIEW') {
      const appLaunchIntent = `intent:#Intent;package=${app.packageName};end`;
      if (Capacitor.isNativePlatform()) {
        try {
          const customScheme = app.id === 'phonepe' ? 'phonepe://' : app.id === 'paytm' ? 'paytmmp://' : app.id === 'gpay' ? 'tez://' : null;
          if (customScheme) {
            const canOpen = await AppLauncher.canOpenUrl({ url: customScheme });
            if (canOpen.value) {
              await AppLauncher.openUrl({ url: customScheme });
              return {
                dispatched: true,
                message: `Opened ${app.name} to scan merchant QR code.`,
                targetedUri: customScheme
              };
            }
          }
        } catch {
          // Fall through
        }
      }

      if (typeof window !== 'undefined') {
        const link = document.createElement('a');
        link.href = appLaunchIntent;
        link.style.display = 'none';
        document.body.appendChild(link);
        link.click();
        setTimeout(() => {
          if (document.body.contains(link)) {
            document.body.removeChild(link);
          }
        }, 1000);

        return {
          dispatched: true,
          message: `Opened ${app.name} for QR scan.`,
          targetedUri: appLaunchIntent
        };
      }
    }

    return {
      dispatched: false,
      message: `No payee UPI ID provided. Please open ${app.name} and scan the QR code manually.`
    };
  } catch (err: any) {
    const errorMsg = err instanceof Error ? err.message : String(err);
    return {
      dispatched: false,
      message: `Could not launch external UPI application: ${errorMsg}`
    };
  }
}

/**
 * Saves in-flight payment metadata to localStorage so that if the Android OS kills
 * the WebView while the external UPI app is open, SPLITO can restore state upon return.
 */
export function saveInFlightPayment(data: InFlightPaymentData): void {
  try {
    localStorage.setItem(IN_FLIGHT_STORAGE_KEY, JSON.stringify(data));
  } catch (e) {
    console.warn('Notice: Unable to save in-flight payment to local storage', e);
  }
}

/**
 * Retrieves the currently in-flight payment from localStorage.
 */
export function getInFlightPayment(): InFlightPaymentData | null {
  try {
    const raw = localStorage.getItem(IN_FLIGHT_STORAGE_KEY);
    if (!raw) return null;
    return JSON.parse(raw) as InFlightPaymentData;
  } catch {
    return null;
  }
}

/**
 * Clears in-flight payment metadata once manual confirmation is complete.
 */
export function clearInFlightPayment(): void {
  try {
    localStorage.removeItem(IN_FLIGHT_STORAGE_KEY);
  } catch (e) {
    console.warn('Notice: Unable to clear in-flight payment', e);
  }
}

/**
 * Registers a foreground-return listener that fires when the user returns to SPLITO.
 * Supports Capacitor App state change and document.visibilitychange fallback.
 */
export function registerForegroundReturnListener(onReturn: () => void): () => void {
  let isCleanedUp = false;

  const handleVisibilityChange = () => {
    if (document.visibilityState === 'visible' && !isCleanedUp) {
      onReturn();
    }
  };

  if (typeof document !== 'undefined') {
    document.addEventListener('visibilitychange', handleVisibilityChange);
  }

  let capacitorListenerHandle: { remove: () => Promise<void> } | null = null;
  if (Capacitor.isNativePlatform()) {
    try {
      App.addListener('appStateChange', (state) => {
        if (state.isActive && !isCleanedUp) {
          onReturn();
        }
      }).then((handle) => {
        capacitorListenerHandle = handle;
      }).catch(() => {
        // App listener fallback
      });
    } catch {
      // Ignore if not supported in current environment
    }
  }

  return () => {
    isCleanedUp = true;
    if (typeof document !== 'undefined') {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    }
    if (capacitorListenerHandle) {
      capacitorListenerHandle.remove().catch(() => {});
    }
  };
}
