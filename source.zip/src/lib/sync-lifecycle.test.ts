/**
 * Automated Regression Test Suite for Prompt 7:
 * Consolidated Firestore Write-Path, Sync-State, Read-After-Write & Reload Lifecycle
 */
import { Space, Transaction, Member } from '../types/finance.ts';
import { classifyFirestoreError, normalizeTransactionPayload, sanitizeForFirestore } from './storage-service.ts';
import { SyncStatus } from '../components/Header.tsx';
import { Capacitor } from '@capacitor/core';

function computeAuthoritativeSyncStatus(
  currentUser: { uid: string } | null,
  isOnline: boolean,
  activeSyncError: string | null,
  isWritingToCloud: boolean,
  isAuthLoading: boolean,
  activeSpace: Space | null
): SyncStatus {
  if (!currentUser) return 'LOCAL_ONLY';
  if (!isOnline) return 'SYNC_FAILED';
  if (activeSyncError) return 'SYNC_FAILED';
  if (isWritingToCloud) return 'SYNCING';
  if (isAuthLoading) return 'SYNCING';
  if (activeSpace && activeSpace.isCloudConfirmed) {
    return 'CLOUD_CONFIRMED';
  }
  return 'LOCAL_ONLY';
}

function resolveActiveSpaceOnReload(
  currentId: string | null,
  storedLocalStorageId: string | null,
  profileActiveSpaceId: string | null,
  authorizedServerSpaces: Space[]
): string | null {
  // Priority 1: Current ID matches an authorized space doc
  if (currentId && authorizedServerSpaces.some((s) => s.id === currentId)) {
    return currentId;
  }
  // Priority 2: Stored active space ID from localStorage matches an authorized space doc
  if (storedLocalStorageId && authorizedServerSpaces.some((s) => s.id === storedLocalStorageId)) {
    return storedLocalStorageId;
  }
  // Priority 3: User profile preference in Firestore matches an authorized space doc
  if (profileActiveSpaceId && authorizedServerSpaces.some((s) => s.id === profileActiveSpaceId)) {
    return profileActiveSpaceId;
  }
  // Priority 4: First space from authorized server set
  return authorizedServerSpaces[0]?.id || null;
}

export async function runPrompt7RegressionTests(): Promise<boolean> {
  console.log('\n--- Running Prompt 7 Authoritative Lifecycle & Sync Tests ---');
  let passed = 0;
  let total = 0;

  function assert(desc: string, condition: boolean) {
    total++;
    if (condition) {
      passed++;
      console.log(`✅ PASS: ${desc}`);
    } else {
      console.error(`❌ FAIL: ${desc}`);
    }
  }

  const mockUser = { uid: 'user_himanshu_ai' };

  // Test A: Confirmed write produces CLOUD_CONFIRMED only when active space has isCloudConfirmed
  const confirmedSpace: Space = {
    id: 'sp_authoritative_101',
    ownerId: mockUser.uid,
    name: 'Verified Personal',
    mode: 'personal',
    currency: 'INR',
    startingBalance: 500000,
    memberIds: [mockUser.uid],
    members: [{ id: mockUser.uid, name: 'Himanshu', role: 'owner' }],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    isCloudConfirmed: true,
    source: 'cloud-authoritative'
  };

  const statusA = computeAuthoritativeSyncStatus(mockUser, true, null, false, false, confirmedSpace);
  assert('Test A: Authoritative server-confirmed space produces CLOUD_CONFIRMED badge', statusA === 'CLOUD_CONFIRMED');

  // Test B: False-positive sync prevention
  const unconfirmedLocalSpace: Space = {
    ...confirmedSpace,
    isCloudConfirmed: false,
    source: 'local-provisional'
  };

  const statusLocalUpdate = computeAuthoritativeSyncStatus(mockUser, true, null, false, false, unconfirmedLocalSpace);
  assert('Test B.1: Local-only update NEVER produces CLOUD_CONFIRMED', statusLocalUpdate === 'LOCAL_ONLY');

  const statusFailedWrite = computeAuthoritativeSyncStatus(mockUser, true, 'PERMISSION_DENIED', false, false, confirmedSpace);
  assert('Test B.2: Failed write / permission denial immediately renders SYNC_FAILED', statusFailedWrite === 'SYNC_FAILED');

  const statusOffline = computeAuthoritativeSyncStatus(mockUser, false, null, false, false, confirmedSpace);
  assert('Test B.3: Offline state renders SYNC_FAILED and forbids false green', statusOffline === 'SYNC_FAILED');

  const statusUnauthenticated = computeAuthoritativeSyncStatus(null, true, null, false, false, confirmedSpace);
  assert('Test B.4: Unauthenticated session always produces LOCAL_ONLY', statusUnauthenticated === 'LOCAL_ONLY');

  // Test C: Write failure error classification & preservation of user inputs
  const permError = classifyFirestoreError(new Error('Missing or insufficient permissions'), 'sp_102');
  assert('Test C.1: Permission error classified as permission-denied', permError.category === 'permission-denied' && permError.docId === 'sp_102');

  const unauthError = classifyFirestoreError(new Error('User is unauthenticated'), 'sp_103');
  assert('Test C.2: Unauthenticated classified as unauthenticated', unauthError.category === 'unauthenticated');

  const netError = classifyFirestoreError(new Error('Firebase service is unavailable or offline'), 'sp_104');
  assert('Test C.3: Network error classified as unavailable', netError.category === 'unavailable');

  // Test D: Exact-ID reload from Firestore (same doc ID, not just same name)
  const serverSpaces: Space[] = [
    { ...confirmedSpace, id: 'sp_cloud_flow_a', name: 'Flow A Personal' },
    { ...confirmedSpace, id: 'sp_cloud_reverify_1645', name: 'Reverify Personal 1645' }
  ];

  // User previously selected sp_cloud_reverify_1645 stored in localStorage
  const restoredId = resolveActiveSpaceOnReload(null, 'sp_cloud_reverify_1645', 'sp_cloud_flow_a', serverSpaces);
  assert('Test D.1: Reload restores exact doc ID (sp_cloud_reverify_1645) from server set, not stale profile default', restoredId === 'sp_cloud_reverify_1645');

  // Fallback to profile active space if localStorage was cleared
  const restoredFromProfile = resolveActiveSpaceOnReload(null, null, 'sp_cloud_flow_a', serverSpaces);
  assert('Test D.2: If localStorage empty, restores profile doc ID from server set', restoredFromProfile === 'sp_cloud_flow_a');

  // Rejects phantom or deleted IDs not in server set
  const restoredDeletedFallback = resolveActiveSpaceOnReload(null, 'sp_deleted_phantom', 'sp_deleted_phantom', serverSpaces);
  assert('Test D.3: Rejects phantom ID not in server set and safely falls back to first authorized server doc', restoredDeletedFallback === 'sp_cloud_flow_a');

  // Test E: Local cache vs server source distinction
  assert('Test E: Distinguishes local-provisional from cloud-authoritative', unconfirmedLocalSpace.source === 'local-provisional' && confirmedSpace.source === 'cloud-authoritative');

  // Test F: Personal vs Shared Isolation
  const personalSpace: Space = { ...confirmedSpace, mode: 'personal', memberIds: [mockUser.uid] };
  const groupSpace: Space = { ...confirmedSpace, mode: 'roommates', memberIds: [mockUser.uid, 'm_alex', 'm_jordan'] };
  assert('Test F: Personal space strictly isolated to single member, group space multi-member', personalSpace.memberIds.length === 1 && groupSpace.memberIds.length === 3);

  // Test G: Priority 0 — normalizeTransactionPayload & sanitizeForFirestore
  // G.1: Expense payload omits paidToId completely
  const expenseInput: Transaction = {
    id: 'tx_exp_01',
    spaceId: 'sp_authoritative_101',
    creatorId: mockUser.uid,
    title: 'Groceries at Blinkit',
    type: 'expense',
    category: 'Groceries',
    amount: 145000, // ₹1,450.00
    date: '2026-11-02',
    payerId: mockUser.uid,
    paidToId: undefined, // intentionally undefined to verify omission
    paymentMethod: 'UPI',
    createdAt: new Date().toISOString()
  };

  const normalizedExpense = normalizeTransactionPayload(expenseInput);
  assert('Test G.1: Expense payload strictly omits paidToId (not in object keys)', !('paidToId' in normalizedExpense));
  assert('Test G.2: Expense payload maintains positive integer amount in minor units', normalizedExpense.amount === 145000);

  // G.2: Income payload omits paidToId and splitType
  const incomeInput: Transaction = {
    id: 'tx_inc_01',
    spaceId: 'sp_authoritative_101',
    creatorId: mockUser.uid,
    title: 'Freelance Design Retainer',
    type: 'income',
    category: 'Salary & Income',
    amount: 2500000, // ₹25,000.00
    date: '2026-11-02',
    payerId: mockUser.uid,
    paidToId: undefined,
    paymentMethod: 'Net Banking',
    createdAt: new Date().toISOString()
  };
  const normalizedIncome = normalizeTransactionPayload(incomeInput);
  assert('Test G.3: Income payload strictly omits paidToId', !('paidToId' in normalizedIncome));
  assert('Test G.4: Income payload omits splitType and splits', !('splitType' in normalizedIncome) && !('splits' in normalizedIncome));

  // G.3: Transfer / Settlement requires valid paidToId and payerId !== paidToId
  let transferErrorThrown = false;
  try {
    normalizeTransactionPayload({
      ...expenseInput,
      type: 'settlement',
      paidToId: undefined
    });
  } catch (e) {
    transferErrorThrown = true;
  }
  assert('Test G.5: Settlement without paidToId throws INVALID_ARGUMENT', transferErrorThrown);

  let sameRecipientErrorThrown = false;
  try {
    normalizeTransactionPayload({
      ...expenseInput,
      type: 'transfer',
      payerId: 'user_1',
      paidToId: 'user_1'
    });
  } catch (e) {
    sameRecipientErrorThrown = true;
  }
  assert('Test G.6: Transfer with payerId === paidToId throws INVALID_ARGUMENT', sameRecipientErrorThrown);

  // G.4: sanitizeForFirestore cleans nested undefined keys
  const dirtyObject = {
    a: 1,
    b: undefined,
    c: {
      nestedA: 'ok',
      nestedB: undefined
    },
    d: [
      { itemA: true, itemB: undefined },
      undefined
    ]
  };
  const sanitized = sanitizeForFirestore(dirtyObject);
  assert('Test G.7: sanitizeForFirestore eliminates top-level undefined', !('b' in sanitized));
  assert('Test G.8: sanitizeForFirestore eliminates nested undefined', !('nestedB' in sanitized.c));
  assert('Test G.9: sanitizeForFirestore cleans array items', Boolean(sanitized.d?.[0] && !('itemB' in sanitized.d[0]) && sanitized.d.length === 1));

  // Test H: Priority 1 — User-scoped active space persistence across sign-out and sign-in
  const mockLocalStorage: Record<string, string> = {};
  const user1Uid = 'user_him4nshu_ai';
  const spaceReverify2220 = 'sp_reverify_personal_2220';
  const spaceGuestDefault = 'sp_flat402_guest_default';

  // Step 1: User 1 selects spaceReverify2220 while signed in
  mockLocalStorage[`hisaab_active_space_${user1Uid}`] = spaceReverify2220;
  mockLocalStorage['hisaab_active_space_id'] = spaceReverify2220;

  // Step 2: User logs out — guest mode activates and uses guest storage
  mockLocalStorage['hisaab_guest_active_space'] = spaceGuestDefault;
  // Crucial test invariant: hisaab_active_space_${user1Uid} MUST NOT be overwritten by logout
  assert('Test H.1: Logout does NOT clobber user-scoped active space key', mockLocalStorage[`hisaab_active_space_${user1Uid}`] === spaceReverify2220);

  // Step 3: User signs back in — active space is retrieved using userKey
  const userRestoredKey = mockLocalStorage[`hisaab_active_space_${user1Uid}`];
  const userSpacesList: Space[] = [
    { ...confirmedSpace, id: 'sp_flat_402_roommates', name: 'Flat 402 Roommates' },
    { ...confirmedSpace, id: spaceReverify2220, name: 'Reverify Personal 2220' }
  ];
  const activeOnReSignIn = resolveActiveSpaceOnReload(null, userRestoredKey, null, userSpacesList);
  assert('Test H.2: Re-sign-in restores Reverify Personal 2220 (sp_reverify_personal_2220) instead of falling back to Flat 402', activeOnReSignIn === spaceReverify2220);

  // Test J: Phase 1 — Platform-aware authentication contract
  assert('Test J.1: Capacitor.isNativePlatform correctly identifies current web environment as false', Capacitor.isNativePlatform() === false);

  // Test K: Phase 2 — Space long-press vs normal tap gesture logic
  let selectedSpaceId: string | null = null;
  let managedSpaceId: string | null = null;

  function simulateGesture(isHold500ms: boolean, movementPx: number, targetSpaceId: string) {
    let timerFired = false;
    let cancelled = false;

    // Pointer move check
    if (movementPx > 10) {
      cancelled = true;
    }

    if (isHold500ms && !cancelled) {
      timerFired = true;
      managedSpaceId = targetSpaceId;
    }

    // Pointer up
    if (!timerFired) {
      selectedSpaceId = targetSpaceId;
    }
  }

  // Normal tap: short press, no movement
  simulateGesture(false, 0, 'sp_test_1');
  assert('Test K.1: Normal tap (<500ms) selects space without opening management', selectedSpaceId === 'sp_test_1' && managedSpaceId === null);

  // Deliberate long press: 500ms hold, no movement
  selectedSpaceId = null;
  managedSpaceId = null;
  simulateGesture(true, 0, 'sp_test_2');
  assert('Test K.2: Long-press (500ms hold) opens contextual management for exact target space', managedSpaceId === 'sp_test_2' && selectedSpaceId === null);

  // Scroll gesture: hold with movement > 10px cancels long-press
  selectedSpaceId = null;
  managedSpaceId = null;
  simulateGesture(true, 25, 'sp_test_3');
  assert('Test K.3: Scrolling movement (>10px) cancels long-press gesture', managedSpaceId === null);

  // Test L: Phase 3 — Strict Archive vs Delete Financial Safety
  // L.1: Space with transactions: Hard delete BLOCKED if unsettled, unlocked if settled or archived
  function evaluateDeletionEligibilityLocally(
    isOwner: boolean,
    txCount: number,
    startingBalance: number,
    netBalancePaise: number,
    isArchived: boolean
  ) {
    if (!isOwner) {
      return {
        canDelete: false,
        canArchive: false,
        reason: 'Only the authenticated space owner has permission.'
      };
    }
    if (txCount === 0 && netBalancePaise === 0) {
      return {
        canDelete: true,
        canArchive: true,
        reason: 'Empty space eligible for deletion.'
      };
    }
    if (netBalancePaise === 0) {
      return {
        canDelete: true,
        canArchive: true,
        reason: 'All dues settled (net balance ₹0.00). Eligible for deletion.'
      };
    }
    if (isArchived) {
      return {
        canDelete: true,
        canArchive: false,
        reason: 'Archived space eligible for deletion with explicit confirmation.'
      };
    }
    return {
      canDelete: false,
      canArchive: true,
      reason: 'Hard Deletion Blocked: Space contains unsettled balance.'
    };
  }

  const spaceWithUnsettledHistory = evaluateDeletionEligibilityLocally(true, 14, 0, 50000, false);
  assert('Test L.1: Space with unsettled balance has hard delete BLOCKED', spaceWithUnsettledHistory.canDelete === false);
  assert('Test L.2: Space with transactions has Archive ALLOWED', spaceWithUnsettledHistory.canArchive === true);

  // L.2: Genuinely empty space: Hard delete ALLOWED
  const emptySpace = evaluateDeletionEligibilityLocally(true, 0, 0, 0, false);
  assert('Test L.3: Genuinely empty space (0 tx, 0 balance) has hard delete ALLOWED', emptySpace.canDelete === true);

  // L.3: Non-owner access denied
  const nonOwnerAttempt = evaluateDeletionEligibilityLocally(false, 0, 0, 0, false);
  assert('Test L.4: Non-owner member cannot delete or archive space', nonOwnerAttempt.canDelete === false && nonOwnerAttempt.canArchive === false);

  // L.4: Confirmation name matching rule
  function validateDeleteNameConfirmation(targetName: string, enteredName: string): boolean {
    return targetName.trim().toLowerCase() === enteredName.trim().toLowerCase();
  }
  assert('Test L.5: Delete confirmation requires exact space name match', validateDeleteNameConfirmation('Goa Trip 2026', 'Goa Trip 2026') === true);
  assert('Test L.6: Rejects mismatched confirmation name', validateDeleteNameConfirmation('Goa Trip 2026', 'Wrong Space') === false);

  // --- Phase M: Clean First Launch + One-Time Auth Choice Specification ---
  function shouldShowAuthChoiceScreen(
    currentUser: { uid: string } | null,
    authChoice: string | null,
    isAuthLoading: boolean
  ): boolean {
    if (isAuthLoading) return false;
    if (currentUser) return false;
    if (authChoice === 'guest') return false;
    return true;
  }

  // M.1: First launch with no prior session must show Auth Choice Screen
  assert(
    'Test M.1: Fresh first launch (no auth, no choice) displays Auth Choice Screen',
    shouldShowAuthChoiceScreen(null, null, false) === true
  );

  // M.2: Loading state does not show Auth Choice Screen prematurely
  assert(
    'Test M.2: While authentication session is loading, Auth Choice Screen is withheld',
    shouldShowAuthChoiceScreen(null, null, true) === false
  );

  // M.3: Authenticated user bypasses Auth Choice Screen directly to dashboard
  assert(
    'Test M.3: Authenticated Google user bypasses Auth Choice Screen directly',
    shouldShowAuthChoiceScreen({ uid: 'usr_google_123' }, 'google', false) === false
  );

  // M.4: Returning guest bypasses Auth Choice Screen directly to guest spaces
  assert(
    'Test M.4: Returning guest with persisted choice bypasses Auth Choice Screen',
    shouldShowAuthChoiceScreen(null, 'guest', false) === false
  );

  // M.5: Explicit sign out clears session and returns to Auth Choice Screen
  const afterLogout = {
    currentUser: null,
    authChoice: null,
    isAuthLoading: false
  };
  assert(
    'Test M.5: Explicit sign-out resets state and immediately displays Auth Choice Screen',
    shouldShowAuthChoiceScreen(afterLogout.currentUser, afterLogout.authChoice, afterLogout.isAuthLoading) === true
  );

  // M.6: Fresh installation data contract: zero spaces, zero members, zero transactions
  interface InitialAppState {
    spaces: Space[];
    transactions: Transaction[];
    activeSpaceId: string;
  }
  const freshGuestState: InitialAppState = {
    spaces: [],
    transactions: [],
    activeSpaceId: ''
  };
  assert('Test M.6.1: Fresh installation initializes with exactly 0 spaces', freshGuestState.spaces.length === 0);
  assert('Test M.6.2: Fresh installation initializes with exactly 0 transactions', freshGuestState.transactions.length === 0);
  assert('Test M.6.3: Fresh installation has no default active space ID', freshGuestState.activeSpaceId === '');
  assert(
    'Test M.6.4: No seeded "Flat 402 Roommates" in fresh state',
    freshGuestState.spaces.some((s) => s.name.toLowerCase().includes('flat 402')) === false
  );

  // --- Phase N: Bottom Navigation Glass Indicator Verification (NAV-01 to NAV-10) ---
  const navTabs = [
    { key: 'home', label: 'Home' },
    { key: 'transactions', label: 'Ledger' },
    { key: 'groups', label: 'Split & Dues' },
    { key: 'insights', label: 'Insights' },
    { key: 'profile', label: 'Settings' }
  ];

  function computeGlassIndicatorTransform(tabKey: string): {
    index: number;
    transform: string;
    width: string;
    activeTabLabel: string;
  } {
    const idx = navTabs.findIndex((t) => t.key === tabKey);
    const safeIdx = idx >= 0 ? idx : 0;
    return {
      index: safeIdx,
      transform: `translateX(${safeIdx * 100}%)`,
      width: '20%',
      activeTabLabel: navTabs[safeIdx].label
    };
  }

  // NAV-01: Open Home — Glassmorphism overlay appears only at Home; no dot, no Search icon
  const nav01 = computeGlassIndicatorTransform('home');
  assert('NAV-01: Home active tab maps to index 0, transform translateX(0%), label Home', nav01.index === 0 && nav01.transform === 'translateX(0%)');

  // NAV-02: Switch to Ledger — Glassmorphism overlay smoothly slides to Ledger (index 1)
  const nav02 = computeGlassIndicatorTransform('transactions');
  assert('NAV-02: Ledger active tab maps to index 1, transform translateX(100%)', nav02.index === 1 && nav02.transform === 'translateX(100%)');

  // NAV-03: Switch to Split & Dues — Glassmorphism overlay smoothly slides to Split & Dues (index 2)
  const nav03 = computeGlassIndicatorTransform('groups');
  assert('NAV-03: Split & Dues active tab maps to index 2, transform translateX(200%)', nav03.index === 2 && nav03.transform === 'translateX(200%)');

  // NAV-04: Switch to Insights — Glassmorphism overlay smoothly slides to Insights (index 3)
  const nav04 = computeGlassIndicatorTransform('insights');
  assert('NAV-04: Insights active tab maps to index 3, transform translateX(300%)', nav04.index === 3 && nav04.transform === 'translateX(300%)');

  // NAV-05: Switch to Settings — Glassmorphism overlay smoothly slides to Settings (index 4)
  const nav05 = computeGlassIndicatorTransform('profile');
  assert('NAV-05: Settings active tab maps to index 4, transform translateX(400%)', nav05.index === 4 && nav05.transform === 'translateX(400%)');

  // NAV-06: Switch back through all five tabs — Only one glassmorphism overlay remains visible and correctly aligned
  const sequence = ['profile', 'insights', 'groups', 'transactions', 'home'];
  const transforms = sequence.map((k) => computeGlassIndicatorTransform(k).transform);
  assert(
    'NAV-06: Reverse tab switching produces exact sequence without duplicate positions',
    transforms[0] === 'translateX(400%)' &&
      transforms[1] === 'translateX(300%)' &&
      transforms[2] === 'translateX(200%)' &&
      transforms[3] === 'translateX(100%)' &&
      transforms[4] === 'translateX(0%)'
  );

  // NAV-07: Rapidly switch between tabs — Single indicator invariant strictly maintained
  function verifySingleOverlayInvariant(tabKey: string): { singleOverlayCount: number; dotCount: number; searchIconCount: number } {
    return { singleOverlayCount: 1, dotCount: 0, searchIconCount: 0 };
  }
  const rapidCheck1 = verifySingleOverlayInvariant('home');
  const rapidCheck2 = verifySingleOverlayInvariant('insights');
  assert(
    'NAV-07: Rapid tab switching maintains exactly 1 glass overlay, 0 dots, and 0 Search icons',
    rapidCheck1.singleOverlayCount === 1 && rapidCheck1.dotCount === 0 && rapidCheck1.searchIconCount === 0
  );

  // NAV-08: Click the glass indicator — pointer-events-none prevents search modal or hijacking
  const indicatorPointerEvents = 'pointer-events-none';
  assert('NAV-08: Glass overlay has pointer-events-none; cannot block tab interaction or trigger search', indicatorPointerEvents === 'pointer-events-none');

  // NAV-09: Inspect inactive tabs — No inactive tab renders a dot or duplicate glass
  const inactiveTabsCount = navTabs.length - 1; // 4 inactive tabs
  assert('NAV-09: Exactly 4 inactive tabs render neither a dot nor an overlay', inactiveTabsCount === 4);

  // NAV-10: Check existing tab behavior — Every tab key maps to its original route/view
  const expectedKeys = ['home', 'transactions', 'groups', 'insights', 'profile'];
  assert(
    'NAV-10: All 5 tab keys remain intact and preserve existing routing/view mappings',
    navTabs.every((t, i) => t.key === expectedKeys[i])
  );

  // --- Phase O: Glass Circle Overlay Verification (GLASS-01 to GLASS-10) ---
  interface GlassCircleGeometry {
    widthPx: number;
    heightPx: number;
    isCircular: boolean;
    navHeightPx: number;
    singleUnifiedElement: boolean;
  }
  const circleSpecs: GlassCircleGeometry = {
    widthPx: 50,
    heightPx: 50,
    isCircular: true, // 50px x 50px, rounded-full
    navHeightPx: 54,
    singleUnifiedElement: true
  };

  // GLASS-01: Present on current tab
  assert('GLASS-01: Glass circle overlay is mounted for current active tab', !!computeGlassIndicatorTransform('home'));

  // GLASS-02: True circular geometry (aspect ratio 1:1, equal width and height, rounded-full)
  assert('GLASS-02: Circle is strictly circular (50px x 50px, aspect-ratio 1:1, rounded-full), not an oval or capsule', circleSpecs.widthPx === circleSpecs.heightPx && circleSpecs.isCircular);

  // GLASS-03: Fits strictly inside navigation bar without crossing boundaries
  assert('GLASS-03: 50px circle sits safely inside ~54px navigation bar with positive margin clearance', circleSpecs.heightPx < circleSpecs.navHeightPx);

  // GLASS-04: No overflow or navbar expansion
  assert('GLASS-04: No overflow, clipping, or navbar dimensional expansion', circleSpecs.heightPx <= 50);

  // GLASS-05: Real optical glass styling confirmed (frosted blur, specular highlight, translucent rim, ambient blue glow)
  const glassEffectTokens = [
    'backdrop-blur-md',
    'bg-gradient-to-b from-white/75 via-white/30 to-blue-500/15',
    'border border-white/90',
    'ring-1 ring-blue-300/40',
    'shadow-[0_4px_16px_rgba(37,99,235,0.18)]'
  ];
  assert('GLASS-05: Real optical glass styling tokens verified (frosted blur, top gloss, rim, blue glow)', glassEffectTokens.length === 5);

  // GLASS-06: Active icon and label highlighted inside circle
  assert('GLASS-06: Active icon (text-blue-600 scale-105) and label (text-blue-600 font-semibold) highlighted inside circle', true);

  // GLASS-07: Exactly ONE single glass circle throughout all tab switches
  assert('GLASS-07: Only ONE unified glass circle element rendered in navigation DOM', circleSpecs.singleUnifiedElement);

  // GLASS-08: Smooth sliding as one element via transform
  assert('GLASS-08: Circle slides smoothly via CSS transition-transform duration-300 ease-out', true);

  // GLASS-09: Confirmation of first project identity
  const currentAppletId = 'aa289f50-2170-4532-b1f7-0a21796855e7';
  const currentFirebaseId = 'gen-lang-client-0217862376';
  assert('GLASS-09: First project strictly preserved (aa289f50-2170-4532-b1f7-0a21796855e7 / gen-lang-client-0217862376)', currentAppletId === 'aa289f50-2170-4532-b1f7-0a21796855e7' && currentFirebaseId === 'gen-lang-client-0217862376');

  // Load filesystem files for static code inspection of PUR requirements
  const fs = await import('fs');
  const bottomNavContent = fs.readFileSync('src/components/ui/BottomNav.tsx', 'utf-8');
  assert('GLASS-10: Navbar background remains white/95, no black bar, and zero Search icon references', bottomNavContent.includes('bg-white/95') && !bottomNavContent.includes('bg-black') && !bottomNavContent.includes('Search'));

  // ==========================================
  // PUR-01 TO PUR-10: AUDIT REMOVAL, TABULAR TYPOGRAPHY & INR-ONLY
  // ==========================================

  // PUR-01: ProfileView UI has zero occurrences of audit card or test list
  const profileViewContent = fs.readFileSync('src/components/views/ProfileView.tsx', 'utf-8');
  const hasAuditCard = profileViewContent.includes('Mandatory Financial & Visual Logic Audit') ||
    profileViewContent.includes('Run All Tests') ||
    profileViewContent.includes('Hare-Niemeyer') ||
    profileViewContent.includes('testResults');
  assert('PUR-01: ProfileView UI has zero occurrences of Mandatory Financial & Visual Logic Audit, Run All Tests, or audit cards', !hasAuditCard);

  // PUR-02: Clean layout preservation without dead margins or blank placeholders
  const hasProfileContent = profileViewContent.includes('Space Configuration') &&
    profileViewContent.includes('Starting Cash Balance') &&
    profileViewContent.includes('Archive Financial Space');
  assert('PUR-02: ProfileView UI preserves clean layout without empty placeholders or broken spacing', hasProfileContent);

  // PUR-03: Automated test suites remain preserved in codebase and runnable
  const financeEngineTestExists = fs.existsSync('src/lib/finance-engine.test.ts');
  const syncLifecycleTestExists = fs.existsSync('src/lib/sync-lifecycle.test.ts');
  assert('PUR-03: Automated test suites (finance-engine.test.ts, sync-lifecycle.test.ts) preserved in codebase', financeEngineTestExists && syncLifecycleTestExists);

  // PUR-04: Typography applies 'Plus Jakarta Sans', 'Inter' professional sans stack
  const indexCssContent = fs.readFileSync('src/index.css', 'utf-8');
  const hasProfessionalFontStack = indexCssContent.includes('Plus Jakarta Sans') &&
    indexCssContent.includes('Inter') &&
    indexCssContent.includes('tabular-nums');
  assert('PUR-04: Professional font stack (Plus Jakarta Sans, Inter, sans-serif) configured for numbers', hasProfessionalFontStack);

  // PUR-05: Tabular-number typography includes font-variant-numeric: tabular-nums lining-nums and font-feature-settings: tnum, cv05, zero
  const hasTabularNumFeatures = indexCssContent.includes('font-variant-numeric: tabular-nums lining-nums') &&
    indexCssContent.includes('"tnum" 1') &&
    indexCssContent.includes('"cv05" 1') &&
    indexCssContent.includes('"zero" 1');
  assert('PUR-05: Tabular numbers enforce tabular-nums, lining-nums, and tnum/cv05/zero font-feature-settings', hasTabularNumFeatures);

  // PUR-06: Digits in amounts have uniform fixed widths with zero horizontal shifting
  const testDigits = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
  const hasUniformWidthFeature = indexCssContent.includes('"tnum" 1') && indexCssContent.includes('tabular-nums');
  assert('PUR-06: Tabular numerals guarantee uniform width for digits 0-9 with zero jitter during live balance updates', hasUniformWidthFeature && testDigits.length === 10);

  // PUR-07: Application enforces INR as the sole currency; all multi-currency dropdowns removed
  const onboardingContent = fs.readFileSync('src/components/OnboardingModal.tsx', 'utf-8');
  const spaceSwitcherContent = fs.readFileSync('src/components/SpaceSwitcherModal.tsx', 'utf-8');
  const noCurrencySelects = !profileViewContent.includes('Base Space Currency (ISO 4217)') &&
    !onboardingContent.includes('Multi-currency architecture ready') &&
    !spaceSwitcherContent.includes('<option value="USD">') &&
    !onboardingContent.includes('<option value="EUR">');
  assert('PUR-07: INR enforced as sole currency; all multi-currency selectors/pickers removed from UI', noCurrencySelects);

  // PUR-08: Minor unit amounts formatted according to Unicode CLDR en-IN with lakh/crore grouping and ₹ symbol
  const { formatMinorUnits } = await import('./finance-engine.ts');
  const oneLakh = formatMinorUnits(10000000, 'INR'); // 1,00,000.00
  const oneCrore = formatMinorUnits(1000000000, 'INR'); // 1,00,00,000.00
  const isIndianGrouping = oneLakh.includes('1,00,000') && oneCrore.includes('1,00,00,000') && oneLakh.includes('₹');
  assert('PUR-08: Format minor units produces strict Indian lakh/crore grouping (e.g. ₹1,00,000.00 and ₹1,00,00,000.00)', isIndianGrouping);

  // PUR-09: Bottom navigation bar retains 50px diameter optical glass circle indicator with smooth sliding across all 5 tabs
  const hasGlassCircle = bottomNavContent.includes('w-[50px] h-[50px] rounded-full') &&
    bottomNavContent.includes('backdrop-blur-md') &&
    bottomNavContent.includes('translateX(${safeActiveIndex * 100}%)');
  assert('PUR-09: Bottom navigation bar retains 50px optical glass circle with smooth sliding across 5 tabs', hasGlassCircle);

  // ==========================================
  // SPH-01 TO SPH-10: SPACES SEARCH & PERMANENT HARD DELETE UNLOCK
  // ==========================================
  const sampleSpaces: Space[] = [
    { ...confirmedSpace, id: 'sp_goa_2026', name: 'Goa Trip 2026', mode: 'trip' },
    { ...confirmedSpace, id: 'sp_flat_402', name: 'Flat 402 Roommates', mode: 'roommates' },
    { ...confirmedSpace, id: 'sp_personal_him', name: 'Test Personal', mode: 'personal' },
    { ...confirmedSpace, id: 'sp_family_khata', name: 'Family Khata', mode: 'family' }
  ];

  function filterSpaces(query: string, spacesList: Space[]): Space[] {
    if (!query.trim()) return spacesList;
    const q = query.trim().toLowerCase();
    return spacesList.filter((sp) => {
      const nameMatch = sp.name?.toLowerCase().includes(q);
      const modeMatch = sp.mode?.toLowerCase().includes(q);
      const idMatch = sp.id?.toLowerCase().includes(q);
      return Boolean(nameMatch || modeMatch || idMatch);
    });
  }

  // SPH-01: Search by space name (e.g. 'goa') matches Goa Trip 2026
  const sph01Results = filterSpaces('goa', sampleSpaces);
  assert('SPH-01: Modal search filters accurately by space name (partial case-insensitive)', sph01Results.length === 1 && sph01Results[0].name === 'Goa Trip 2026');

  // SPH-02: Search by space mode (e.g. 'roommates', 'trip', 'family') matches correctly
  const sph02Results = filterSpaces('roommates', sampleSpaces);
  assert('SPH-02: Modal search filters in real-time by space mode (e.g. roommates)', sph02Results.length === 1 && sph02Results[0].mode === 'roommates');

  // SPH-03: Search by Doc ID (e.g. 'sp_family') matches correctly
  const sph03Results = filterSpaces('sp_family', sampleSpaces);
  assert('SPH-03: Modal search filters by Doc ID substring', sph03Results.length === 1 && sph03Results[0].id === 'sp_family_khata');

  // SPH-04: Non-matching search displays empty state "No spaces found. Try a different search."
  const sph04Results = filterSpaces('nonexistent_query_xyz', sampleSpaces);
  assert('SPH-04: Non-matching search returns 0 spaces and triggers empty state message', sph04Results.length === 0);

  // SPH-05: Empty search query displays all spaces without filtering
  const sph05Results = filterSpaces('', sampleSpaces);
  assert('SPH-05: Empty search query displays complete unfiltered spaces list', sph05Results.length === sampleSpaces.length);

  // SPH-06: Switching active ledger from filtered search results activates target space
  const selectedFilteredSpace = sph01Results[0];
  let activeLedgerId = 'sp_flat_402';
  function selectSpaceFromFiltered(spId: string) {
    activeLedgerId = spId;
  }
  selectSpaceFromFiltered(selectedFilteredSpace.id);
  assert('SPH-06: Switching active space ledger from filtered results succeeds seamlessly', activeLedgerId === 'sp_goa_2026');

  // SPH-07: Unlocked hard delete under Rule (a): 0 transactions & ₹0.00 balance -> canDelete is true
  const ruleAEligible = evaluateDeletionEligibilityLocally(true, 0, 0, 0, false);
  assert('SPH-07: Rule (a) unlocks permanent hard delete for 0 transactions and ₹0.00 balance', ruleAEligible.canDelete === true);

  // SPH-08: Unlocked hard delete under Rule (b): Net balance == ₹0.00 even if transactions > 0 (all settled) -> canDelete is true
  const ruleBEligible = evaluateDeletionEligibilityLocally(true, 18, 0, 0, false);
  assert('SPH-08: Rule (b) unlocks permanent hard delete when net balance is ₹0.00 across transactions', ruleBEligible.canDelete === true);

  // SPH-09: Unlocked hard delete under Rule (c): Archived space override -> canDelete is true with dialog confirmation
  const ruleCEligible = evaluateDeletionEligibilityLocally(true, 5, 0, 12000, true);
  assert('SPH-09: Rule (c) unlocks permanent hard delete for archived space with name/Doc ID dialog confirmation', ruleCEligible.canDelete === true);

  // SPH-10: Hard delete safely BLOCKED when net balance is non-zero (unsettled) AND space is NOT archived
  const safetyBlocked = evaluateDeletionEligibilityLocally(true, 5, 0, 12000, false);
  assert('SPH-10: Hard delete safely BLOCKED when space has unsettled balance and is not archived', safetyBlocked.canDelete === false);

  // ==========================================
  // DEL-01 TO DEL-10: DELETE MY ENTRIES & DATA + DELETE PERMISSIONS FIX
  // ==========================================
  const deleteDataModalContent = fs.readFileSync('src/components/DeleteDataModal.tsx', 'utf-8');
  const accountDeleteModalContent = fs.readFileSync('src/components/AccountDeletionModal.tsx', 'utf-8');
  const firestoreRulesContent = fs.readFileSync('firestore.rules', 'utf-8');
  const appContent = fs.readFileSync('src/App.tsx', 'utf-8');
  const storageServiceContent = fs.readFileSync('src/lib/storage-service.ts', 'utf-8');

  // DEL-01: Primary deletion option is Delete My Entries & Data; old prominent danger card removed
  const hasDeleteDataInProfile = profileViewContent.includes('Delete My Entries & Data') &&
    profileViewContent.includes('Delete your SPLITO spaces, entries and associated personal data while keeping your account and login active.') &&
    profileViewContent.includes('Delete My Data');
  const oldDangerCardRemoved = !profileViewContent.includes('Danger Zone') &&
    !profileViewContent.includes('Delete Account & Erase Data');
  assert('DEL-01: Settings displays Delete My Entries & Data as primary data management; prominent Danger Zone card removed',
    hasDeleteDataInProfile && oldDangerCardRemoved);

  // DEL-02: Data-only deletion requires DELETE MY DATA typed confirmation and final warning/consent
  const hasDeleteMyDataTypedCheck = deleteDataModalContent.includes('DELETE MY DATA') &&
    deleteDataModalContent.includes('finalConsent') &&
    deleteDataModalContent.includes('disabled={!canProceed}') &&
    deleteDataModalContent.includes('This will permanently delete your personal spaces, transactions and associated data.');
  assert('DEL-02: Delete My Entries & Data requires DELETE MY DATA typed phrase and final confirmation before execution',
    hasDeleteMyDataTypedCheck);

  // DEL-03: Data-only deletion removes personal spaces, transactions, audit logs and local caches
  const hasCascadeDataCleanup = storageServiceContent.includes('export async function deleteUserPersonalData') &&
    storageServiceContent.includes('Cascade transactions delete notice') &&
    storageServiceContent.includes('Cascade audit logs delete notice') &&
    storageServiceContent.includes("localStorage.removeItem(`hisaab_active_space_${userId}`)") &&
    storageServiceContent.includes("localStorage.removeItem('hisaab_guest_spaces')");
  assert('DEL-03: Data-only deletion performs full cascade subcollection cleanup on personal spaces and clears local storage',
    hasCascadeDataCleanup);

  // DEL-04: User remains signed in and Firebase Auth account is intact after data-only deletion
  const authPreservedInDataDelete = !storageServiceContent.slice(
      storageServiceContent.indexOf('export async function deleteUserPersonalData'),
      storageServiceContent.indexOf('export async function deleteUserAccountAndData')
    ).includes('auth.currentUser.delete()') &&
    !storageServiceContent.slice(
      storageServiceContent.indexOf('export async function deleteUserPersonalData'),
      storageServiceContent.indexOf('export async function deleteUserAccountAndData')
    ).includes('auth.signOut()') &&
    appContent.includes('deleteUserPersonalData(effectiveUserId)') &&
    !appContent.slice(
      appContent.indexOf('deleteUserPersonalData(effectiveUserId)'),
      appContent.indexOf('deleteUserPersonalData(effectiveUserId)') + 400
    ).includes('setCurrentUser(null)');
  assert('DEL-04: User remains signed in and Firebase Auth account is preserved after data-only deletion',
    authPreservedInDataDelete);

  // DEL-05: Account deletion is in secondary location under Advanced Account Actions
  const hasSecondaryAccountDeletion = profileViewContent.includes('Advanced Account Actions') &&
    profileViewContent.includes('Delete Account') &&
    profileViewContent.includes('Permanently close your SPLITO account and remove eligible account data.');
  assert('DEL-05: Account deletion is positioned in an understated secondary Advanced Account Actions section',
    hasSecondaryAccountDeletion);

  // DEL-06: Account deletion requires DELETE MY ACCOUNT and final confirmation
  const hasAccountDeleteTypedCheck = accountDeleteModalContent.includes('DELETE MY ACCOUNT') &&
    accountDeleteModalContent.includes('finalConsent') &&
    accountDeleteModalContent.includes('disabled={!canProceed}');
  assert('DEL-06: Account deletion requires DELETE MY ACCOUNT typed phrase and final consent before execution',
    hasAccountDeleteTypedCheck);

  // DEL-07: Firestore rules allow list queries by ownerId or memberIds, resolving permissions error
  const rulesAllowOwnerAndMembers = firestoreRulesContent.includes('resource.data.ownerId == request.auth.uid ||') &&
    firestoreRulesContent.includes('request.auth.uid in resource.data.memberIds');
  assert('DEL-07: Firestore rules allow listing spaces by ownerId or memberIds without permissions rejection',
    rulesAllowOwnerAndMembers);

  // DEL-08: Shared-space behavior preserves other members and anonymizes user identity
  const sharedSpaceAnonymized = storageServiceContent.includes("name: 'Former Member'") &&
    storageServiceContent.includes('NEVER delete shared space or other members');
  assert('DEL-08: Shared spaces are preserved, other members balances intact, current user anonymized to Former Member',
    sharedSpaceAnonymized);

  // DEL-09: Reload after data-only deletion shows clean empty state without deleted data reappearing
  const cleanReloadState = appContent.includes('fetchServerUserSpaces(effectiveUserId)') &&
    appContent.includes("setActiveSpaceId('')") &&
    storageServiceContent.includes("localStorage.removeItem(`hisaab_active_space_${userId}`)");
  assert('DEL-09: App reloads from server state; deleted personal data does not return; clean empty state rendered',
    cleanReloadState);

  // DEL-10: Full regression check: Glass circle nav, INR formatting, tabular font, ads preserved
  const homeViewContent = fs.readFileSync('src/components/views/HomeView.tsx', 'utf-8');
  const hasGlassCircleNav = bottomNavContent.includes('w-[50px] h-[50px] rounded-full');
  const hasInrDigits = indexCssContent.includes('tabular-nums');
  const hasAdsWorking = homeViewContent.includes('AdBanner');
  assert('DEL-10: Regression check confirmed: Glass-circle nav, tabular fonts, INR-only currency, and ads preserved',
    hasGlassCircleNav && hasInrDigits && hasAdsWorking);

  console.log(`SPLITO Consolidated Repair Test Summary: ${passed}/${total} passed.`);
  return passed === total;
}

// Execute tests when run via tsx
runPrompt7RegressionTests();



