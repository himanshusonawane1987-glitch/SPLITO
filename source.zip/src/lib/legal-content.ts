/**
 * SPLITO Legal Documents & User Agreements
 * Master Specification v1.5
 * 
 * IMPORTANT NOTICE:
 * These documents are provided for transparency and user guidance.
 */

export type LegalDocKey =
  | 'user_agreement'
  | 'terms_conditions'
  | 'privacy_policy'
  | 'subscription_terms'
  | 'cancellation_refund'
  | 'data_permissions'
  | 'account_deletion';

export interface LegalDocument {
  id: LegalDocKey;
  titleEn: string;
  titleHi: string;
  summaryEn: string;
  summaryHi: string;
  sectionsEn: Array<{ heading: string; body: string }>;
  sectionsHi: Array<{ heading: string; body: string }>;
}

export const LEGAL_DOCUMENTS: Record<LegalDocKey, LegalDocument> = {
  user_agreement: {
    id: 'user_agreement',
    titleEn: 'User Agreement',
    titleHi: 'उपयोगकर्ता अनुबंध (User Agreement)',
    summaryEn: 'Core agreement governing use of the SPLITO expense ledger.',
    summaryHi: 'स्प्लिटो (SPLITO) लेजर के उपयोग के मुख्य नियम।',
    sectionsEn: [
      {
        heading: '1. What SPLITO Is and Is Not',
        body: 'SPLITO is a digital ledger and expense-sharing calculation tool designed to help individuals, roommates, families, and travel groups track shared expenses. CRITICAL NOTICE: SPLITO is NOT a bank, NOT a non-banking financial company (NBFC), NOT a digital wallet, NOT an authorized payment gateway, NOT an investment platform, and NOT a certified financial planner. SPLITO does not hold, transmit, custody, or process actual bank funds or fiat currency.'
      },
      {
        heading: '2. User Responsibility & Data Entry',
        body: 'All balances, splits, and calculations depend entirely on the transaction descriptions, dates, payers, and amounts entered by users. SPLITO does not verify whether expenses reflect real-world transactions. Users are solely responsible for ensuring the factual accuracy of their entries.'
      },
      {
        heading: '3. Strictest Security Warning: Banking Credentials',
        body: 'NEVER enter net banking passwords, UPI PINs, ATM PINs, card CVVs, or One-Time Passwords (OTPs) anywhere inside SPLITO. SPLITO will never ask for your banking passwords. If any member or space asks you to enter banking credentials, refuse immediately.'
      },
      {
        heading: '4. Shared Spaces & Member Visibility',
        body: 'When you invite or accept invitations to a shared space (such as a Flat Roommates, Family, or Trip space), all members of that space can view all transactions, expenses, receipts, settlements, and member balances recorded in that space.'
      }
    ],
    sectionsHi: [
      {
        heading: '1. स्प्लिटो (SPLITO) क्या है और क्या नहीं',
        body: 'स्प्लिटो केवल एक डिजिटल लेजर और खर्च हिसाब-किताब का टूल है। महत्वपूर्ण सूचना: स्प्लिटो कोई बैंक नहीं है, कोई डिजिटल वॉलेट नहीं है, कोई यूपीआई पेमेंट गेटवे नहीं है, और न ही कोई निवेश सलाहकार है। स्प्लिटो आपके असली बैंक के पैसे अपने पास नहीं रखता।'
      },
      {
        heading: '2. उपयोगकर्ता की जिम्मेदारी',
        body: 'सभी हिसाब-किताब आपके द्वारा दर्ज किए गए खर्चों पर निर्भर करते हैं। अपने दर्ज किए गए खर्चों की सत्यता की जिम्मेदारी उपयोगकर्ता की होती है।'
      },
      {
        heading: '3. सुरक्षा चेतावनी: बैंक पासवर्ड व यूपीआई पिन',
        body: 'स्प्लिटो में कभी भी अपना बैंक पासवर्ड, यूपीआई पिन (UPI PIN), एटीएम पिन या ओटीपी (OTP) दर्ज न करें। स्प्लिटो आपसे कभी भी गोपनीय बैंकिंग जानकारी नहीं मांगता।'
      },
      {
        heading: '4. साझा ग्रुप में जानकारी दिखना',
        body: 'जब आप किसी रूममेट्स, परिवार या ट्रिप के ग्रुप में जुड़ते हैं, तो उस ग्रुप के सभी सदस्य उस ग्रुप में दर्ज किए गए सभी खर्च व हिसाब देख सकते हैं।'
      }
    ]
  },

  terms_conditions: {
    id: 'terms_conditions',
    titleEn: 'Terms and Conditions',
    titleHi: 'नियम और शर्तें (Terms & Conditions)',
    summaryEn: 'Terms of service for web and mobile usage.',
    summaryHi: 'वेब और मोबाइल ऐप के उपयोग की शर्तें।',
    sectionsEn: [
      {
        heading: '1. Acceptance of Terms',
        body: 'By downloading, accessing, or using SPLITO, you agree to be bound by these Terms and Conditions. If you do not agree, do not use the application.'
      },
      {
        heading: '2. Eligibility & Account Security',
        body: 'You must be at least 13 years old (or the legal age of consent in your jurisdiction) to use SPLITO. You are responsible for safeguarding your Google account credentials used to sign in.'
      },
      {
        heading: '3. Acceptable Use',
        body: 'You agree not to use SPLITO for fraudulent purposes, money laundering record-keeping, extortion, harassment, or distributing illegal or harmful content.'
      },
      {
        heading: '4. Intellectual Property & Brand',
        body: 'All trademarks, logos, UI designs, code, and algorithms related to SPLITO belong to SPLITO. You may not reverse-engineer, decompile, or re-license the application.'
      },
      {
        heading: '5. Limitation of Liability',
        body: 'To the fullest extent permitted by applicable law, SPLITO shall not be liable for any indirect, incidental, or consequential damages resulting from lost financial data, user miscalculations, interpersonal dispute regarding debts, or service downtime.'
      }
    ],
    sectionsHi: [
      {
        heading: '1. शर्तों की स्वीकृति',
        body: 'स्प्लिटो का उपयोग करके आप इन नियमों और शर्तों से बंधने की सहमति देते हैं।'
      },
      {
        heading: '2. खाता सुरक्षा',
        body: 'अपने गूगल खाते की सुरक्षा की जिम्मेदारी आपकी है जिसके जरिए आप ऐप में लॉग इन करते हैं।'
      },
      {
        heading: '3. उचित उपयोग',
        body: 'स्प्लिटो का उपयोग किसी भी अवैध, धोखाधड़ी या गैर-कानूनी काम के लिए नहीं किया जाना चाहिए।'
      },
      {
        heading: '4. बौद्धिक संपदा अधिकार',
        body: 'स्प्लिटो के सभी ट्रेडमार्क, लोगो, डिजाइन और कोड SPLITO के हैं।'
      },
      {
        heading: '5. जिम्मेदारी की सीमा',
        body: 'हिसाब-किताब में उपयोगकर्ता द्वारा की गई किसी भी मानवीय गलती या रूममेट्स के आपसी विवाद के लिए स्प्लिटो जिम्मेदार नहीं होगा।'
      }
    ]
  },

  privacy_policy: {
    id: 'privacy_policy',
    titleEn: 'Privacy Policy',
    titleHi: 'गोपनीयता नीति (Privacy Policy)',
    summaryEn: 'How SPLITO collects, stores, and protects your information.',
    summaryHi: 'स्प्लिटो आपकी जानकारी कैसे सुरक्षित रखता है।',
    sectionsEn: [
      {
        heading: '1. Information We Collect',
        body: 'When you use SPLITO with Google Sign-In, we receive your email address, display name, and avatar URL via Firebase Authentication. If you continue as a Guest, data is tied only to a random local identifier on your device. When you record transactions, we store transaction titles, amounts (in minor units), categories, timestamps, and space member IDs.'
      },
      {
        heading: '2. Cloud Storage and Synchronization',
        body: 'SPLITO utilizes Google Cloud Firebase (Firestore database) located in secure enterprise cloud facilities to store and synchronize your spaces and ledgers across your authorized devices.'
      },
      {
        heading: '3. Strict Financial Data Advertising Firewall',
        body: 'We adhere to a strict financial privacy firewall: SPLITO NEVER transmits your expense notes, transaction amounts, balances, settlement debts, or member names to advertising networks or external data brokers. Ad networks only receive standard anonymized device identifiers for non-financial ads.'
      },
      {
        heading: '4. Third-Party Service Providers',
        body: 'We utilize reputable third-party infrastructure providers including Google Firebase (for authentication & cloud database) and Unity Ads (for ads on free tiers). Unity Ads may use your device\'s advertising ID to show you ads.'
      }
    ],
    sectionsHi: [
      {
        heading: '1. हम कौन सी जानकारी एकत्र करते हैं',
        body: 'जब आप गूगल से लॉग इन करते हैं, तो हमें आपका नाम और ईमेल मिलता है। जब आप खर्च दर्ज करते हैं, तो हम केवल खर्च का नाम, राशि, श्रेणी और तारीख सुरक्षित रखते हैं।'
      },
      {
        heading: '2. क्लाउड स्टोरेज और सुरक्षा',
        body: 'आपका डेटा गूगल फायरबेस (Firebase Firestore) के सुरक्षित सर्वर पर स्टोर होता है ताकि आपका हिसाब सुरक्षित रहे।'
      },
      {
        heading: '3. विज्ञापन और वित्तीय डेटा की गोपनीयता',
        body: 'स्प्लिटो आपके किसी भी खर्च, राशि, रूममेट के नाम या बैलेंस की जानकारी किसी विज्ञापन कंपनी को कभी नहीं भेजता है।'
      },
      {
        heading: '4. थर्ड-पार्टी सेवाएं और विज्ञापन',
        body: 'हम बुनियादी ढांचे के लिए गूगल फायरबेस (Google Firebase) और विज्ञापनों के लिए यूनिटी ऐड्स (Unity Ads) का उपयोग करते हैं। Unity Ads आपको विज्ञापन दिखाने के लिए आपके डिवाइस की विज्ञापन आईडी का इस्तेमाल कर सकता है।'
      }
    ]
  },

  subscription_terms: {
    id: 'subscription_terms',
    titleEn: 'Subscription Terms & Pricing',
    titleHi: 'सब्सक्रिप्शन नियम व शुल्क (Subscription Terms)',
    summaryEn: 'Details on Free tier and upcoming SPLITO Pro subscription.',
    summaryHi: 'फ्री और आने वाले स्प्लिटो प्रो (SPLITO Pro) प्लान की जानकारी।',
    sectionsEn: [
      {
        heading: '1. SPLITO Subscription Status',
        body: 'Premium subscription is coming soon. Currently the app is free with rewarded ads. Pricing and terms will be shared before launch.'
      }
    ],
    sectionsHi: [
      {
        heading: '1. स्प्लिटो सब्सक्रिप्शन स्थिति',
        body: 'प्रीमियम सब्सक्रिप्शन जल्द आ रहा है। फिलहाल ऐप रिवॉर्डेड विज्ञापनों के साथ मुफ्त है। कीमत और शर्तें लॉन्च से पहले बताई जाएंगी।'
      }
    ]
  },

  cancellation_refund: {
    id: 'cancellation_refund',
    titleEn: 'Cancellation and Refund Policy',
    titleHi: 'रद्दीकरण और रिफंड नीति (Cancellation & Refund)',
    summaryEn: 'How subscription cancellation and refund policies apply.',
    summaryHi: 'सब्सक्रिप्शन रद्दीकरण और रिफंड नीतियां।',
    sectionsEn: [
      {
        heading: '1. Subscription Cancellation & Refunds',
        body: 'Premium subscription is coming soon. Currently the app is free with rewarded ads. Pricing and terms will be shared before launch.'
      }
    ],
    sectionsHi: [
      {
        heading: '1. रद्दीकरण और रिफंड नीति',
        body: 'प्रीमियम सब्सक्रिप्शन जल्द आ रहा है। फिलहाल ऐप रिवॉर्डेड विज्ञापनों के साथ मुफ्त है। कीमत और शर्तें लॉन्च से पहले बताई जाएंगी।'
      }
    ]
  },

  data_permissions: {
    id: 'data_permissions',
    titleEn: 'Data Collection and Permissions',
    titleHi: 'डेटा संग्रह व अनुमतियां (Data & Permissions)',
    summaryEn: 'Device permissions requested and why they are needed.',
    summaryHi: 'ऐप द्वारा मांगी जाने वाली अनुमतियों की स्पष्ट जानकारी।',
    sectionsEn: [
      {
        heading: '1. Camera & Storage Permission (Optional)',
        body: 'Requested only when you choose to take a photo of an expense bill/receipt to attach to a transaction. We never access your camera without your explicit in-app action, and we do not scan your private photo gallery.'
      },
      {
        heading: '2. Network Access (Internet)',
        body: 'Required to synchronize your expenses with cloud storage and keep shared roommate calculations updated in real time.'
      },
      {
        heading: '3. Data We Do NOT Collect',
        body: 'We do not collect phone contacts (unless you explicitly share an invite), GPS live location, SMS messages, bank account numbers, or biometric fingerprints.'
      }
    ],
    sectionsHi: [
      {
        heading: '1. कैमरा अनुमति (वैकल्पिक)',
        body: 'केवल तब मांगी जाती है जब आप किसी खर्च का बिल या रसीद फोटो खींचकर जोड़ना चाहें। आपके निजी फोटो नहीं देखे जाते।'
      },
      {
        heading: '2. इंटरनेट अनुमति',
        body: 'क्लाउड सिंक और रूममेट्स के बीच तुरंत हिसाब अपडेट रखने के लिए आवश्यक है।'
      },
      {
        heading: '3. हम कौन सी जानकारी नहीं लेते',
        body: 'हम आपकी फोन कॉन्टैक्ट लिस्ट, लाइव लोकेशन, बैंक पासवर्ड या एसएमएस नहीं पढ़ते।'
      }
    ]
  },

  account_deletion: {
    id: 'account_deletion',
    titleEn: 'Account Deletion Policy',
    titleHi: 'खाता हटाने की नीति (Account Deletion Policy)',
    summaryEn: 'How to delete your account and associated data permanently.',
    summaryHi: 'अपना खाता और डेटा पूरी तरह कैसे हटाएं।',
    sectionsEn: [
      {
        heading: '1. Right to Erasure',
        body: 'You have the absolute right to delete your SPLITO account and request complete removal of your personal profile at any time.'
      },
      {
        heading: '2. How to Request Deletion',
        body: 'Open SPLITO > Settings (Profile tab) > Danger Zone > "Delete Account". You will be asked to type "DELETE MY ACCOUNT" to confirm.'
      },
      {
        heading: '3. What Happens Upon Deletion',
        body: 'Upon confirmation: (a) Your user profile and authentication credentials in Firebase are deleted immediately. (b) All private Personal spaces owned exclusively by you are purged. (c) In multi-member shared spaces (like Flat Roommates or Trip), your personal identifiable details are anonymized while preserving the shared ledger math so remaining roommates do not suffer broken arithmetic.'
      },
      {
        heading: '4. Contact for Manual Deletion Requests',
        body: 'If you are unable to access the app, you may email your deletion request to Splito.supports@gmail.com from your registered email address.'
      }
    ],
    sectionsHi: [
      {
        heading: '1. खाता हटाने का अधिकार',
        body: 'आपको किसी भी समय अपना खाता और डेटा हटाने का पूरा अधिकार है।'
      },
      {
        heading: '2. खाता कैसे हटाएं',
        body: 'सेटिंग्स में जाएं > "Delete Account" पर क्लिक करें और पुष्टि के लिए "DELETE MY ACCOUNT" लिखें।'
      },
      {
        heading: '3. खाता हटाने पर क्या होगा',
        body: 'आपका प्रोफाइल तुरंत हटा दिया जाएगा। आपके निजी स्पेस मिटा दिए जाएंगे। साझा ग्रुप में आपका नाम हटा दिया जाएगा ताकि अन्य रूममेट्स का हिसाब न बिगड़े।'
      },
      {
        heading: '4. ईमेल द्वारा खाता हटाने का अनुरोध',
        body: 'यदि आप ऐप में लॉग इन नहीं कर पा रहे हैं, तो अपने पंजीकृत ईमेल पते से Splito.supports@gmail.com पर खाता हटाने का अनुरोध भेज सकते हैं।'
      }
    ]
  }
};
