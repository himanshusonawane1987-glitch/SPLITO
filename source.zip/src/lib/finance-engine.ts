/**
 * HISAAB Pure Finance Module — Definitive Spec Version 1.2
 * 
 * Invariants & Guarantees:
 * 1. ALL money is stored and computed as integer minor units (paise, cents, fils, yen).
 *    Never use floating-point arithmetic for monetary math.
 * 2. ISO 4217 Currency Support: Minor units exponents (INR: 2, USD: 2, JPY: 0, KWD: 3, etc.)
 * 3. Actual Balance = Starting Balance + Received Income − Paid Expenses + Incoming Transfers − Outgoing Transfers.
 * 4. Largest Remainder Method (Hare-Niemeyer):
 *    Split shares ALWAYS sum strictly to the expense total. Rounding differences are assigned by highest remainder.
 * 5. Settlement Sign Convention:
 *    - Positive (> 0): Member is owed money (Credit / Receivable)
 *    - Negative (< 0): Member owes money (Debit / Payable)
 *    - Sum of all net balances across a closed space strictly equals 0.
 * 6. Smart Settlement: Bounded backtracking with greedy fallback for optimal minimal cashflow reconciliation.
 * 7. Immutable Reversals: Financial entries are never silently destroyed; they are reversed.
 */

import {
  ActualBalanceBreakdown,
  AdvancePaymentRef,
  CategoryBreakdown,
  CurrencyCode,
  CurrencyMetadata,
  DebtSettlement,
  Member,
  MemberBalance,
  PersonalItemAllocation,
  Space,
  SplitShare,
  SplitType,
  TemporaryParticipant,
  Transaction,
  TransactionType
} from '../types/finance.ts';

/**
 * ISO 4217 Currency Registry with Unicode CLDR locales and minor unit exponents
 */
export const CURRENCY_REGISTRY: Record<CurrencyCode, CurrencyMetadata> = {
  INR: {
    code: 'INR',
    name: 'Indian Rupee',
    symbol: '₹',
    minorUnits: 2,
    locale: 'en-IN',
    sampleFormatted: '₹1,24,500.50'
  },
  USD: {
    code: 'USD',
    name: 'US Dollar',
    symbol: '$',
    minorUnits: 2,
    locale: 'en-US',
    sampleFormatted: '$1,250.00'
  },
  EUR: {
    code: 'EUR',
    name: 'Euro',
    symbol: '€',
    minorUnits: 2,
    locale: 'de-DE',
    sampleFormatted: '1.250,00 €'
  },
  GBP: {
    code: 'GBP',
    name: 'British Pound',
    symbol: '£',
    minorUnits: 2,
    locale: 'en-GB',
    sampleFormatted: '£1,250.00'
  },
  JPY: {
    code: 'JPY',
    name: 'Japanese Yen',
    symbol: '¥',
    minorUnits: 0, // Zero decimals
    locale: 'ja-JP',
    sampleFormatted: '¥12,500'
  },
  KWD: {
    code: 'KWD',
    name: 'Kuwaiti Dinar',
    symbol: 'KD',
    minorUnits: 3, // 3 decimals (1000 fils)
    locale: 'ar-KW',
    sampleFormatted: 'KD 125.750'
  },
  AED: {
    code: 'AED',
    name: 'UAE Dirham',
    symbol: 'د.إ',
    minorUnits: 2,
    locale: 'ar-AE',
    sampleFormatted: '1,250.00 د.إ'
  },
  SGD: {
    code: 'SGD',
    name: 'Singapore Dollar',
    symbol: 'S$',
    minorUnits: 2,
    locale: 'en-SG',
    sampleFormatted: 'S$1,250.00'
  },
  CAD: {
    code: 'CAD',
    name: 'Canadian Dollar',
    symbol: 'CA$',
    minorUnits: 2,
    locale: 'en-CA',
    sampleFormatted: 'CA$1,250.00'
  },
  AUD: {
    code: 'AUD',
    name: 'Australian Dollar',
    symbol: 'A$',
    minorUnits: 2,
    locale: 'en-AU',
    sampleFormatted: 'A$1,250.00'
  },
  CHF: {
    code: 'CHF',
    name: 'Swiss Franc',
    symbol: 'CHF',
    minorUnits: 2,
    locale: 'de-CH',
    sampleFormatted: 'CHF 1,250.00'
  }
};

/**
 * Gets currency metadata safely with fallback to INR
 */
export function getCurrencyMeta(code: CurrencyCode = 'INR'): CurrencyMetadata {
  return CURRENCY_REGISTRY[code] || CURRENCY_REGISTRY.INR;
}

/**
 * Returns symbol for currency
 */
export function getCurrencySymbol(code: CurrencyCode = 'INR'): string {
  return getCurrencyMeta(code).symbol;
}

/**
 * Precision parser that converts user input (string or number) into integer minor units.
 * Respects ISO 4217 minor unit exponents (e.g. 2 for INR/USD, 0 for JPY, 3 for KWD).
 */
export function parseInputToMinorUnits(input: string | number, currency: CurrencyCode = 'INR'): number {
  const meta = getCurrencyMeta(currency);
  const exponent = meta.minorUnits;
  const factor = Math.pow(10, exponent);

  if (typeof input === 'number') {
    if (isNaN(input)) return 0;
    return Math.round(input * factor);
  }

  if (!input || typeof input !== 'string') return 0;

  // Clean string: remove symbols, spaces, commas
  const cleaned = input.replace(/[^\d.-]/g, '').trim();
  if (!cleaned || cleaned === '-' || cleaned === '.') return 0;

  const isNegative = cleaned.startsWith('-');
  const unsigned = isNegative ? cleaned.slice(1) : cleaned;

  const parts = unsigned.split('.');
  const wholePart = parts[0] ? parseInt(parts[0], 10) : 0;
  if (isNaN(wholePart)) return 0;

  let fractionUnits = 0;
  if (exponent > 0 && parts.length > 1) {
    const fractionStr = parts[1].padEnd(exponent, '0').slice(0, exponent);
    fractionUnits = parseInt(fractionStr, 10) || 0;
  }

  const totalMinorUnits = wholePart * factor + fractionUnits;
  return isNegative ? -totalMinorUnits : totalMinorUnits;
}

/**
 * Backward compatibility alias for parseInputToPaise (defaults to INR)
 */
export function parseInputToPaise(input: string | number): number {
  return parseInputToMinorUnits(input, 'INR');
}

/**
 * Converts integer minor units to formatted decimal string without currency symbol.
 * Example: 125000 (INR, 2 decimals) -> "1250.00"
 * Example: 1250 (JPY, 0 decimals) -> "1250"
 * Example: 1250750 (KWD, 3 decimals) -> "1250.750"
 */
export function minorUnitsToDecimalString(minorUnits: number, currency: CurrencyCode = 'INR'): string {
  if (isNaN(minorUnits)) return '0';
  const meta = getCurrencyMeta(currency);
  const exponent = meta.minorUnits;
  const isNegative = minorUnits < 0;
  const abs = Math.abs(Math.round(minorUnits));

  if (exponent === 0) {
    return `${isNegative ? '-' : ''}${abs}`;
  }

  const factor = Math.pow(10, exponent);
  const whole = Math.floor(abs / factor);
  const fraction = abs % factor;
  const fractionStr = fraction.toString().padStart(exponent, '0');
  return `${isNegative ? '-' : ''}${whole}.${fractionStr}`;
}

export function paiseToDecimalString(paise: number): string {
  return minorUnitsToDecimalString(paise, 'INR');
}

/**
 * Formats integer minor units into locale-aware currency strings via Intl.NumberFormat and Unicode CLDR.
 */
export function formatMinorUnits(
  minorUnits: number,
  currency: CurrencyCode = 'INR',
  options: { showSign?: boolean; compact?: boolean } = {}
): string {
  if (isNaN(minorUnits)) return '0';

  const meta = getCurrencyMeta(currency);
  const exponent = meta.minorUnits;
  const factor = Math.pow(10, exponent);

  const isNegative = minorUnits < 0;
  const absUnits = Math.abs(Math.round(minorUnits));
  const decimalVal = exponent > 0 ? absUnits / factor : absUnits;

  const formatter = new Intl.NumberFormat(meta.locale, {
    style: 'currency',
    currency: meta.code,
    minimumFractionDigits: exponent,
    maximumFractionDigits: exponent
  });

  const formatted = formatter.format(decimalVal);

  if (isNegative) {
    return `-${formatted}`;
  } else if (options.showSign && minorUnits > 0) {
    return `+${formatted}`;
  }

  return formatted;
}

/**
 * Backward compatibility alias for formatPaise
 */
export function formatPaise(
  paise: number,
  currency: CurrencyCode = 'INR',
  options?: { showSign?: boolean; compact?: boolean }
): string {
  return formatMinorUnits(paise, currency, options);
}

/**
 * Pure function to calculate actual available balance:
 * Actual Balance = Starting Balance + Received Income − Paid Expenses + Incoming Transfers − Outgoing Transfers
 */
export function calculateActualBalance(params: {
  startingBalance: number;
  receivedIncome: number;
  paidExpenses: number;
  incomingTransfers: number;
  outgoingTransfers: number;
}): ActualBalanceBreakdown {
  const starting = Math.round(params.startingBalance || 0);
  const income = Math.round(params.receivedIncome || 0);
  const expense = Math.round(params.paidExpenses || 0);
  const incoming = Math.round(params.incomingTransfers || 0);
  const outgoing = Math.round(params.outgoingTransfers || 0);

  const actual = starting + income - expense + incoming - outgoing;

  return {
    startingBalance: starting,
    receivedIncome: income,
    paidExpenses: expense,
    incomingTransfers: incoming,
    outgoingTransfers: outgoing,
    actualBalance: actual
  };
}

/**
 * Filters out reversed entries and their reversals so ledger calculations remain mathematically pure.
 */
export function getActiveLedgerTransactions(transactions: Transaction[]): Transaction[] {
  const reversedIds = new Set<string>();

  for (const tx of transactions) {
    if (tx.isReversal && tx.reversesTransactionId) {
      reversedIds.add(tx.reversesTransactionId);
      reversedIds.add(tx.id);
    }
    if (tx.isReversed) {
      reversedIds.add(tx.id);
    }
  }

  return transactions.filter((tx) => {
    if (reversedIds.has(tx.id)) return false;
    // Status-aware filtering (SPLITO Wallet Pay):
    // Existing transactions without paymentStatus default to 'paid'.
    // Only 'paid' transactions affect balances, dues, and category breakdowns.
    if (tx.paymentStatus && tx.paymentStatus !== 'paid') {
      return false;
    }
    return true;
  });
}

/**
 * Calculates actual balance for a specific Space considering active transactions
 * and the perspective of the current user.
 */
export function calculateSpaceLedgerBalance(
  space: Space,
  transactions: Transaction[],
  currentUserId?: string
): ActualBalanceBreakdown {
  const activeTx = getActiveLedgerTransactions(transactions);
  const startingBalance = space.startingBalance || 0;
  let receivedIncome = 0;
  let paidExpenses = 0;
  let incomingTransfers = 0;
  let outgoingTransfers = 0;

  const effectiveUserId = currentUserId || space.ownerId;
  const isPersonal = space.mode === 'personal';

  for (const tx of activeTx) {
    if (tx.type === 'income') {
      if (isPersonal || tx.payerId === effectiveUserId || tx.paidToId === effectiveUserId) {
        receivedIncome += tx.amount;
      }
    } else if (tx.type === 'expense') {
      if (isPersonal) {
        paidExpenses += tx.amount;
      } else {
        if (tx.payerId === effectiveUserId) {
          paidExpenses += tx.amount;
        }
      }
    } else if (tx.type === 'transfer' || tx.type === 'settlement') {
      if (tx.payerId === effectiveUserId) {
        outgoingTransfers += tx.amount;
      }
      if (tx.paidToId === effectiveUserId) {
        incomingTransfers += tx.amount;
      }
    }
  }

  return calculateActualBalance({
    startingBalance,
    receivedIncome,
    paidExpenses,
    incomingTransfers,
    outgoingTransfers
  });
}

/**
 * Largest Remainder Method (Hare-Niemeyer) for Equal Splits:
 * Divides total minor units equally across member IDs.
 * GUARANTEE: Shares always sum strictly to totalMinorUnits.
 * Remainder is assigned by highest fractional remainder (or first in order).
 */
export function calculateEqualSplits(totalMinorUnits: number, memberIds: string[]): SplitShare[] {
  const total = Math.max(0, Math.round(totalMinorUnits));
  if (!memberIds || memberIds.length === 0) return [];
  const n = memberIds.length;

  const baseShare = Math.floor(total / n);
  const remainder = total % n;

  return memberIds.map((memberId, idx) => {
    const extra = idx < remainder ? 1 : 0;
    const shareMinorUnits = baseShare + extra;
    return {
      memberId,
      shareMinorUnits,
      percentage: total > 0 ? Number(((shareMinorUnits / total) * 100).toFixed(1)) : 0
    };
  });
}

/**
 * Largest Remainder Method (Hare-Niemeyer) for Percentage Splits:
 * Calculates integer shares and allocates fractional shortfall strictly in descending order of remainders.
 * GUARANTEE: Shares always sum strictly to totalMinorUnits.
 */
export function calculatePercentageSplits(
  totalMinorUnits: number,
  splits: { memberId: string; percentage: number }[]
): SplitShare[] {
  const total = Math.max(0, Math.round(totalMinorUnits));
  if (!splits || splits.length === 0) return [];

  // Compute exact float quotient, floor to integer base share, record fractional remainder
  const intermediate = splits.map((s, index) => {
    const exact = (total * Math.max(0, s.percentage)) / 100;
    const base = Math.floor(exact);
    const remainder = exact - base;
    return {
      index,
      memberId: s.memberId,
      percentage: s.percentage,
      base,
      remainder
    };
  });

  const sumBase = intermediate.reduce((acc, curr) => acc + curr.base, 0);
  const shortfall = total - sumBase;

  // Sort by remainder descending (Largest Remainder Method)
  const sortedIndices = [...intermediate].sort((a, b) => b.remainder - a.remainder);

  const bonusAllocations = new Set<number>();
  for (let i = 0; i < shortfall && i < sortedIndices.length; i++) {
    bonusAllocations.add(sortedIndices[i].index);
  }

  return intermediate.map((item) => {
    const shareMinorUnits = item.base + (bonusAllocations.has(item.index) ? 1 : 0);
    return {
      memberId: item.memberId,
      shareMinorUnits,
      percentage: item.percentage
    };
  });
}

/**
 * Custom Split:
 * Directly accepts custom amounts in minor units.
 * GUARANTEE: Adjusts any delta onto the largest share so the sum strictly equals totalMinorUnits.
 */
export function calculateCustomSplits(
  totalMinorUnits: number,
  splits: { memberId: string; customMinorUnits: number }[]
): SplitShare[] {
  const total = Math.max(0, Math.round(totalMinorUnits));
  if (!splits || splits.length === 0) return [];

  const result: SplitShare[] = splits.map((s) => ({
    memberId: s.memberId,
    shareMinorUnits: Math.max(0, Math.round(s.customMinorUnits || 0)),
    percentage: total > 0 ? Number(((s.customMinorUnits / total) * 100).toFixed(1)) : 0
  }));

  const sumShares = result.reduce((acc, curr) => acc + curr.shareMinorUnits, 0);
  const difference = total - sumShares;

  if (difference !== 0 && result.length > 0) {
    let largestIdx = 0;
    let maxShare = -1;
    for (let i = 0; i < result.length; i++) {
      if (result[i].shareMinorUnits > maxShare) {
        maxShare = result[i].shareMinorUnits;
        largestIdx = i;
      }
    }
    result[largestIdx].shareMinorUnits += difference;
  }

  return result;
}

/**
 * Single Person Split:
 * Exactly one selected member bears 100% of the expense amount,
 * even if another member originally paid for the expense.
 */
export function calculateSinglePersonSplit(
  totalMinorUnits: number,
  memberId: string
): SplitShare[] {
  const total = Math.max(0, Math.round(totalMinorUnits));
  if (!memberId) return [];
  return [
    {
      memberId,
      shareMinorUnits: total,
      percentage: 100
    }
  ];
}

/**
 * Calculates member balances in a group space:
 * For each member:
 *   totalPaidMinorUnits: how much they paid upfront for expenses or paid in settlements/transfers
 *   totalOwedMinorUnits: their consumption share of expenses or amount received in settlements/transfers
 *   netBalanceMinorUnits = totalPaidMinorUnits - totalOwedMinorUnits
 * 
 * SIGN CONVENTION:
 *   Positive (+): Member is owed money (Receivable / Credit from others)
 *   Negative (-): Member owes money (Payable / Debit to others)
 *   Zero: Settled up.
 * 
 * Sum across all members in a closed group is guaranteed to be 0!
 */
export const MAX_TEMP_PARTICIPANT_NAME_LENGTH = 60;
export const UNKNOWN_TEMP_PARTICIPANT_LABEL = 'Unknown (Temp)';

/**
 * Checks whether a memberId belongs to an expense-scoped temporary participant.
 */
export function isTemporaryParticipantId(id?: string): boolean {
  return Boolean(id && id.startsWith('tmp_'));
}

/**
 * Generates an expense-scoped temporary participant ID that cannot collide across expenses
 * or with permanent space member IDs.
 */
export function buildTemporaryParticipantId(expenseId: string, suffix?: string): string {
  const safeExpenseId = (expenseId || 'exp').replace(/[^a-zA-Z0-9_-]/g, '');
  const uniqueSuffix = suffix || Math.random().toString(36).substring(2, 8);
  return `tmp_${safeExpenseId}_${uniqueSuffix}`;
}

/**
 * Validates and trims a temporary participant display name.
 */
export function validateTemporaryParticipantName(rawName: string): {
  isValid: boolean;
  trimmed: string;
  error?: string;
} {
  const trimmed = (rawName || '').trim();
  if (!trimmed) {
    return { isValid: false, trimmed: '', error: 'Please enter a name.' };
  }
  if (trimmed.length > MAX_TEMP_PARTICIPANT_NAME_LENGTH) {
    return {
      isValid: false,
      trimmed: trimmed.slice(0, MAX_TEMP_PARTICIPANT_NAME_LENGTH),
      error: `Name cannot exceed ${MAX_TEMP_PARTICIPANT_NAME_LENGTH} characters.`
    };
  }
  return { isValid: true, trimmed };
}

/**
 * Disambiguates duplicate temporary participant names within the same expense
 * (e.g., "Rohan" -> "Rohan (2)", "Rohan (3)"). Case-insensitive comparison.
 */
export function disambiguateTemporaryParticipantName(
  trimmedName: string,
  existingTempParticipants: TemporaryParticipant[]
): string {
  const lowerExisting = new Set(
    (existingTempParticipants || []).map((tp) => (tp.name || '').trim().toLowerCase())
  );
  if (!lowerExisting.has(trimmedName.toLowerCase())) {
    return trimmedName;
  }
  let counter = 2;
  let candidate = `${trimmedName} (${counter})`;
  while (lowerExisting.has(candidate.toLowerCase())) {
    counter++;
    candidate = `${trimmedName} (${counter})`;
  }
  return candidate;
}

/**
 * Scans all transactions (active and historical) to build a read-only metadata index
 * for expense-scoped temporary participants so names resolve everywhere without leaking raw IDs.
 */
export function buildTempParticipantMetaMap(
  transactions: Transaction[]
): Map<string, { name: string; linkedExpenseId?: string }> {
  const metaMap = new Map<string, { name: string; linkedExpenseId?: string }>();

  const upsert = (id: string, rawName?: string, linkedExpenseId?: string) => {
    if (!id) return;
    const trimmed = typeof rawName === 'string' ? rawName.trim() : '';
    const existing = metaMap.get(id);
    if (!existing) {
      metaMap.set(id, {
        name: trimmed || UNKNOWN_TEMP_PARTICIPANT_LABEL,
        ...(linkedExpenseId ? { linkedExpenseId } : {})
      });
    } else {
      const nextName =
        trimmed && (existing.name === UNKNOWN_TEMP_PARTICIPANT_LABEL || !existing.name)
          ? trimmed
          : existing.name;
      metaMap.set(id, {
        name: nextName || UNKNOWN_TEMP_PARTICIPANT_LABEL,
        ...(existing.linkedExpenseId || linkedExpenseId
          ? { linkedExpenseId: existing.linkedExpenseId || linkedExpenseId }
          : {})
      });
    }
  };

  for (const tx of transactions || []) {
    if (Array.isArray(tx.temporaryParticipants)) {
      for (const tp of tx.temporaryParticipants) {
        if (tp && tp.id) {
          upsert(tp.id, tp.name, tx.id);
        }
      }
    }
    if (Array.isArray(tx.splits)) {
      for (const s of tx.splits) {
        if (s && s.memberId && (s.isTemporary || isTemporaryParticipantId(s.memberId))) {
          upsert(s.memberId, s.memberName, tx.id);
        }
      }
    }
    if (tx.payerId && isTemporaryParticipantId(tx.payerId) && tx.payerNameSnapshot?.trim()) {
      upsert(tx.payerId, tx.payerNameSnapshot, tx.linkedExpenseId);
    }
    if (tx.paidToId && isTemporaryParticipantId(tx.paidToId) && tx.paidToNameSnapshot?.trim()) {
      upsert(tx.paidToId, tx.paidToNameSnapshot, tx.linkedExpenseId);
    }
  }

  return metaMap;
}

/**
 * Resolves any participant's display name (permanent member or expense-scoped temporary participant).
 * Never leaks raw `tmp_...` IDs for malformed records; falls back to "Unknown (Temp)".
 */
export function getParticipantDisplayName(
  memberId: string,
  permanentMembers: Member[],
  txOrTransactions?: Transaction | Transaction[],
  split?: SplitShare
): string {
  const permanent = (permanentMembers || []).find((m) => m.id === memberId);
  if (permanent?.name) return permanent.name;

  if (split?.memberName && split.memberName.trim()) {
    return split.memberName.trim();
  }

  if (Array.isArray(txOrTransactions)) {
    const meta = buildTempParticipantMetaMap(txOrTransactions).get(memberId);
    if (meta?.name) return meta.name;
  } else if (txOrTransactions) {
    const tx = txOrTransactions;
    const tp = tx.temporaryParticipants?.find((p) => p.id === memberId);
    if (tp?.name && tp.name.trim()) return tp.name.trim();

    const matchingSplit = tx.splits?.find((s) => s.memberId === memberId);
    if (matchingSplit?.memberName && matchingSplit.memberName.trim()) {
      return matchingSplit.memberName.trim();
    }

    if (tx.payerId === memberId && tx.payerNameSnapshot?.trim()) {
      return tx.payerNameSnapshot.trim();
    }
    if (tx.paidToId === memberId && tx.paidToNameSnapshot?.trim()) {
      return tx.paidToNameSnapshot.trim();
    }
  }

  if (split?.isTemporary || isTemporaryParticipantId(memberId)) {
    return UNKNOWN_TEMP_PARTICIPANT_LABEL;
  }

  return memberId;
}

/**
 * Q4 Guard: Finds active (non-reversed, non-reversal, non-advance) manual settlements
 * referencing a specific temporary participant ID.
 */
export function findActiveManualSettlementsForTempParticipant(
  tempId: string,
  transactions: Transaction[]
): Transaction[] {
  if (!tempId) return [];
  const activeTx = getActiveLedgerTransactions(transactions);
  return activeTx.filter(
    (tx) =>
      tx.type === 'settlement' &&
      !tx.isAdvancePayment &&
      (tx.payerId === tempId || tx.paidToId === tempId)
  );
}

/**
 * Q4 Guard: Finds active manual settlements referencing any temporary participant
 * attached to a given expense transaction (used to warn before expense reversal).
 */
export function findActiveManualSettlementsForExpenseTemps(
  expense: Transaction,
  transactions: Transaction[]
): Transaction[] {
  const tempIds = new Set<string>();
  for (const tp of expense.temporaryParticipants || []) {
    if (tp?.id) tempIds.add(tp.id);
  }
  for (const s of expense.splits || []) {
    if (s?.memberId && (s.isTemporary || isTemporaryParticipantId(s.memberId))) {
      tempIds.add(s.memberId);
    }
  }
  if (tempIds.size === 0) return [];

  const activeTx = getActiveLedgerTransactions(transactions);
  return activeTx.filter(
    (tx) =>
      tx.type === 'settlement' &&
      !tx.isAdvancePayment &&
      (tempIds.has(tx.payerId) || (tx.paidToId ? tempIds.has(tx.paidToId) : false))
  );
}

/**
 * Q1 Filter: Hides fully-settled temporary participants (netBalance === 0) from active
 * balance views by default unless the user opts in via Settings.
 */
export function filterVisibleMemberBalances(
  balances: MemberBalance[],
  keepSettledTempParticipants: boolean
): MemberBalance[] {
  if (keepSettledTempParticipants) return balances;
  return balances.filter((b) => !(b.isTemporary && b.netBalanceMinorUnits === 0));
}

export function calculateGroupBalances(members: Member[], transactions: Transaction[]): MemberBalance[] {
  const activeTx = getActiveLedgerTransactions(transactions);
  const permanentIdSet = new Set(members.map((m) => m.id));
  const tempMetaMap = buildTempParticipantMetaMap(transactions);

  const balanceMap = new Map<
    string,
    {
      name: string;
      isTemporary: boolean;
      linkedExpenseId?: string;
      totalExpensePaid: number;
      totalExpenseShare: number;
      totalSettlementPaid: number;
      totalSettlementReceived: number;
    }
  >();

  for (const m of members) {
    balanceMap.set(m.id, {
      name: m.name,
      isTemporary: false,
      totalExpensePaid: 0,
      totalExpenseShare: 0,
      totalSettlementPaid: 0,
      totalSettlementReceived: 0
    });
  }

  const getOrCreateEntry = (id: string, fallbackName?: string, explicitTemp?: boolean, linkedExpenseId?: string) => {
    const existing = balanceMap.get(id);
    if (existing) return existing;

    const meta = tempMetaMap.get(id);
    const isTemp = !permanentIdSet.has(id) && (Boolean(explicitTemp) || Boolean(meta) || isTemporaryParticipantId(id));
    const resolvedName = isTemp
      ? (fallbackName?.trim() || meta?.name || UNKNOWN_TEMP_PARTICIPANT_LABEL)
      : (fallbackName?.trim() || id);

    const entry = {
      name: resolvedName,
      isTemporary: isTemp,
      linkedExpenseId: meta?.linkedExpenseId || linkedExpenseId,
      totalExpensePaid: 0,
      totalExpenseShare: 0,
      totalSettlementPaid: 0,
      totalSettlementReceived: 0
    };
    balanceMap.set(id, entry);
    return entry;
  };

  for (const tx of activeTx) {
    if (tx.type === 'expense') {
      const payerEntry = getOrCreateEntry(tx.payerId, tx.payerNameSnapshot, undefined, tx.id);
      payerEntry.totalExpensePaid += tx.amount;

      if (tx.splits && tx.splits.length > 0) {
        for (const split of tx.splits) {
          const splitEntry = getOrCreateEntry(
            split.memberId,
            split.memberName,
            split.isTemporary,
            tx.id
          );
          splitEntry.totalExpenseShare += split.shareMinorUnits;
        }
      } else {
        payerEntry.totalExpenseShare += tx.amount;
      }
    } else if (tx.type === 'settlement' || tx.type === 'transfer') {
      if (tx.payerId && tx.paidToId) {
        const payerEntry = getOrCreateEntry(tx.payerId, tx.payerNameSnapshot, undefined, tx.linkedExpenseId);
        payerEntry.totalSettlementPaid += tx.amount;

        const recipientEntry = getOrCreateEntry(tx.paidToId, tx.paidToNameSnapshot, undefined, tx.linkedExpenseId);
        recipientEntry.totalSettlementReceived += tx.amount;
      }
    }
  }

  const result: MemberBalance[] = [];
  balanceMap.forEach((val, id) => {
    const totalPaid = val.totalExpensePaid + val.totalSettlementPaid;
    const totalOwed = val.totalExpenseShare + val.totalSettlementReceived;
    result.push({
      memberId: id,
      memberName: val.name,
      ...(val.isTemporary ? { isTemporary: true } : {}),
      ...(val.isTemporary && val.linkedExpenseId ? { linkedExpenseId: val.linkedExpenseId } : {}),
      totalExpenseShareMinorUnits: val.totalExpenseShare,
      totalExpensePaidMinorUnits: val.totalExpensePaid,
      totalSettlementPaidMinorUnits: val.totalSettlementPaid,
      totalSettlementReceivedMinorUnits: val.totalSettlementReceived,
      totalPaidMinorUnits: totalPaid,
      totalOwedMinorUnits: totalOwed,
      netBalanceMinorUnits: totalPaid - totalOwed
    });
  });

  return result;
}

/**
 * SMART SETTLEMENT — SIGNATURE FEATURE
 * Bounded backtracking with greedy fallback algorithm:
 * 1. Phase 1 (Exact 2-person zero-sum pairings):
 *    If debtor D owes exactly what creditor C is owed (D.owes == C.isOwed),
 *    settling D -> C in 1 transaction eliminates BOTH from the balance sheet.
 * 2. Phase 2 (Exact 3-person zero-sum combinations):
 *    If 1 debtor balances 2 creditors or 2 debtors balance 1 creditor,
 *    settle with 2 transactions instead of cascading through multiple intermediaries.
 * 3. Phase 3 (Greedy reconciliation fallback):
 *    For remaining un-paired balances, match the largest debtor with the largest creditor.
 * 
 * Outcome: Absolute minimal number of transactions, eliminates circular & transitive debt,
 * and maintains 100% precision in integer minor units.
 */
export function calculateDebtSettlements(memberBalances: MemberBalance[]): DebtSettlement[] {
  interface Participant {
    id: string;
    name: string;
    amount: number; // Positive magnitude
    isTemporary?: boolean;
  }

  const debtors: Participant[] = [];
  const creditors: Participant[] = [];

  for (const b of memberBalances) {
    if (b.netBalanceMinorUnits < 0) {
      debtors.push({
        id: b.memberId,
        name: b.memberName,
        amount: Math.abs(b.netBalanceMinorUnits),
        ...(b.isTemporary ? { isTemporary: true } : {})
      });
    } else if (b.netBalanceMinorUnits > 0) {
      creditors.push({
        id: b.memberId,
        name: b.memberName,
        amount: b.netBalanceMinorUnits,
        ...(b.isTemporary ? { isTemporary: true } : {})
      });
    }
  }

  const settlements: DebtSettlement[] = [];

  // Phase 1: Direct 1-to-1 exact matches (Subset Sum k=1)
  for (let i = 0; i < debtors.length; i++) {
    const d = debtors[i];
    if (d.amount === 0) continue;

    for (let j = 0; j < creditors.length; j++) {
      const c = creditors[j];
      if (c.amount === 0) continue;

      if (d.amount === c.amount) {
        settlements.push({
          fromMemberId: d.id,
          fromMemberName: d.name,
          toMemberId: c.id,
          toMemberName: c.name,
          amountMinorUnits: d.amount,
          ...(d.isTemporary ? { fromIsTemporary: true } : {}),
          ...(c.isTemporary ? { toIsTemporary: true } : {})
        });
        d.amount = 0;
        c.amount = 0;
        break;
      }
    }
  }

  // Phase 2: 1-debtor to 2-creditors exact sum match
  for (let i = 0; i < debtors.length; i++) {
    const d = debtors[i];
    if (d.amount === 0) continue;

    let matched = false;
    for (let j = 0; j < creditors.length - 1; j++) {
      const c1 = creditors[j];
      if (c1.amount === 0) continue;

      for (let k = j + 1; k < creditors.length; k++) {
        const c2 = creditors[k];
        if (c2.amount === 0) continue;

        if (d.amount === c1.amount + c2.amount) {
          settlements.push({
            fromMemberId: d.id,
            fromMemberName: d.name,
            toMemberId: c1.id,
            toMemberName: c1.name,
            amountMinorUnits: c1.amount,
            ...(d.isTemporary ? { fromIsTemporary: true } : {}),
            ...(c1.isTemporary ? { toIsTemporary: true } : {})
          });
          settlements.push({
            fromMemberId: d.id,
            fromMemberName: d.name,
            toMemberId: c2.id,
            toMemberName: c2.name,
            amountMinorUnits: c2.amount,
            ...(d.isTemporary ? { fromIsTemporary: true } : {}),
            ...(c2.isTemporary ? { toIsTemporary: true } : {})
          });
          d.amount = 0;
          c1.amount = 0;
          c2.amount = 0;
          matched = true;
          break;
        }
      }
      if (matched) break;
    }
  }

  // Phase 3: Greedy reconciliation fallback for remaining balances
  const remainingDebtors = debtors.filter((d) => d.amount > 0).sort((a, b) => b.amount - a.amount);
  const remainingCreditors = creditors.filter((c) => c.amount > 0).sort((a, b) => b.amount - a.amount);

  let dIdx = 0;
  let cIdx = 0;

  while (dIdx < remainingDebtors.length && cIdx < remainingCreditors.length) {
    const debtor = remainingDebtors[dIdx];
    const creditor = remainingCreditors[cIdx];

    const settleAmount = Math.min(debtor.amount, creditor.amount);

    if (settleAmount > 0) {
      settlements.push({
        fromMemberId: debtor.id,
        fromMemberName: debtor.name,
        toMemberId: creditor.id,
        toMemberName: creditor.name,
        amountMinorUnits: settleAmount,
        ...(debtor.isTemporary ? { fromIsTemporary: true } : {}),
        ...(creditor.isTemporary ? { toIsTemporary: true } : {})
      });
    }

    debtor.amount -= settleAmount;
    creditor.amount -= settleAmount;

    if (debtor.amount === 0) dIdx++;
    if (creditor.amount === 0) cIdx++;
  }

  return settlements;
}

/**
 * Calculates category-wise breakdown for charts and analytics
 */
export function calculateCategoryBreakdowns(
  transactions: Transaction[],
  type: TransactionType = 'expense'
): CategoryBreakdown[] {
  const activeTx = getActiveLedgerTransactions(transactions);
  const filtered = activeTx.filter((t) => t.type === type);
  const total = filtered.reduce((acc, curr) => acc + curr.amount, 0);

  const map = new Map<string, { amount: number; count: number }>();
  for (const tx of filtered) {
    const cat = tx.category || 'General';
    const curr = map.get(cat) || { amount: 0, count: 0 };
    curr.amount += tx.amount;
    curr.count += 1;
    map.set(cat, curr);
  }

  const result: CategoryBreakdown[] = [];
  map.forEach((val, category) => {
    result.push({
      category,
      amountMinorUnits: val.amount,
      percentage: total > 0 ? Number(((val.amount / total) * 100).toFixed(1)) : 0,
      count: val.count,
      type
    });
  });

  return result.sort((a, b) => b.amountMinorUnits - a.amountMinorUnits);
}

/**
 * Creates an immutable reversal transaction that negates a prior transaction.
 * Follows the "never delete financial facts — reverse them" ledger invariant.
 */
export function createReversalTransaction(
  originalTx: Transaction,
  actorId: string,
  reason: string = 'User requested entry reversal'
): { originalUpdated: Transaction; reversalTx: Transaction } {
  const now = new Date().toISOString();

  const originalUpdated: Transaction = {
    ...originalTx,
    isReversed: true,
    reversedAt: now,
    reversedBy: actorId,
    version: (originalTx.version || 1) + 1
  };

  const reversalTx: Transaction = {
    id: `rev_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    spaceId: originalTx.spaceId,
    creatorId: actorId,
    title: `[Reversal] ${originalTx.title}`,
    type: originalTx.type,
    category: originalTx.category,
    amount: originalTx.amount,
    date: now.split('T')[0],
    payerId: originalTx.paidToId || originalTx.payerId, // Inverse direction
    paidToId: originalTx.paidToId ? originalTx.payerId : undefined,
    notes: `Reversal of #${originalTx.id.slice(-6)}: ${reason}`,
    isReversal: true,
    reversesTransactionId: originalTx.id,
    version: 1,
    createdAt: now
  };

  return { originalUpdated, reversalTx };
}

/**
 * Deterministic ID for a linked advance payment settlement transaction.
 * Ensures idempotency across edits, re-saves, and offline queue retries.
 */
export function buildAdvanceTransactionId(expenseId: string, memberId: string): string {
  return `adv_${expenseId}_${memberId}`;
}

export interface EnhancedSplitInput {
  totalMinorUnits: number;
  splitType: SplitType;
  payerId: string;
  selectedMemberIds: string[];
  percentageMap?: Record<string, number>;
  customSharedMinorUnitsMap?: Record<string, number>;
  personalItems?: PersonalItemAllocation[];
  advancePaidMinorUnitsMap?: Record<string, number>;
  temporaryParticipants?: TemporaryParticipant[];
  expenseId?: string;
  currency?: CurrencyCode;
  memberNamesById?: Record<string, string>;
}

export interface EnhancedSplitResult {
  splits: SplitShare[];
  personalItems: PersonalItemAllocation[];
  advancePayments: AdvancePaymentRef[];
  temporaryParticipants: TemporaryParticipant[];
  totalPersonalMinorUnits: number;
  sharedPoolMinorUnits: number;
  allocatedMinorUnits: number;
  customSharedSumMinorUnits: number;
  customSharedDeltaMinorUnits: number;
  percentageSum: number;
  totalAdvanceMinorUnits: number;
}

export interface EnhancedSplitValidationResult {
  isValid: boolean;
  errors: string[];
  memberErrors: Record<string, string>;
  result: EnhancedSplitResult;
}

/**
 * Pure enhanced split calculator supporting:
 * 1. Personal Item (Individual Share): excluded from shared pool and assigned exclusively to its member.
 * 2. Shared Pool Distribution: remaining amount (total - personalItemsTotal) split via Equal, %, Custom, or Single.
 * 3. Advance Payment (Already Paid): tracked as informational breakdown on SplitShare and AdvancePaymentRef,
 *    with actual balance deduction performed ONLY by the separate linked settlement transaction (zero double deduction).
 *
 * All calculations strictly use integer minor units.
 */
export function calculateEnhancedExpenseSplits(input: EnhancedSplitInput): EnhancedSplitResult {
  const total = Math.max(0, Math.round(input.totalMinorUnits || 0));
  const splitType = input.splitType;

  if (splitType === 'none') {
    return {
      splits: [],
      personalItems: [],
      advancePayments: [],
      temporaryParticipants: [],
      totalPersonalMinorUnits: 0,
      sharedPoolMinorUnits: total,
      allocatedMinorUnits: 0,
      customSharedSumMinorUnits: 0,
      customSharedDeltaMinorUnits: 0,
      percentageSum: 0,
      totalAdvanceMinorUnits: 0
    };
  }

  const sanitizedPersonalItems: PersonalItemAllocation[] = (input.personalItems || [])
    .filter((item) => Boolean(item.memberId) && Math.round(item.amountMinorUnits || 0) > 0)
    .map((item) => ({
      id: item.id,
      memberId: item.memberId,
      ...(item.label && item.label.trim() ? { label: item.label.trim() } : {}),
      amountMinorUnits: Math.round(item.amountMinorUnits)
    }));

  const personalByMember = new Map<string, number>();
  let totalPersonalMinorUnits = 0;
  for (const item of sanitizedPersonalItems) {
    const prev = personalByMember.get(item.memberId) || 0;
    personalByMember.set(item.memberId, prev + item.amountMinorUnits);
    totalPersonalMinorUnits += item.amountMinorUnits;
  }

  const sharedPoolMinorUnits = Math.max(0, total - totalPersonalMinorUnits);
  const selectedIds = Array.from(new Set(input.selectedMemberIds || []));
  const percentageMap = input.percentageMap || {};
  const customMap = input.customSharedMinorUnitsMap || {};
  const advanceMap = input.advancePaidMinorUnitsMap || {};

  const sharedByMember = new Map<string, number>();
  let customSharedSumMinorUnits = 0;
  let percentageSum = 0;

  if (splitType === 'equal') {
    if (sharedPoolMinorUnits > 0 && selectedIds.length > 0) {
      const equalShares = calculateEqualSplits(sharedPoolMinorUnits, selectedIds);
      for (const s of equalShares) {
        sharedByMember.set(s.memberId, s.shareMinorUnits);
      }
    }
  } else if (splitType === 'percentage') {
    for (const id of selectedIds) {
      percentageSum += percentageMap[id] || 0;
    }
    if (sharedPoolMinorUnits > 0 && selectedIds.length > 0) {
      const pctInput = selectedIds.map((id) => ({
        memberId: id,
        percentage: Math.max(0, percentageMap[id] || 0)
      }));
      const pctShares = calculatePercentageSplits(sharedPoolMinorUnits, pctInput);
      for (const s of pctShares) {
        sharedByMember.set(s.memberId, s.shareMinorUnits);
      }
    }
  } else if (splitType === 'custom') {
    for (const id of selectedIds) {
      const val = Math.max(0, Math.round(customMap[id] || 0));
      sharedByMember.set(id, val);
      customSharedSumMinorUnits += val;
    }
  } else if (splitType === 'single') {
    if (sharedPoolMinorUnits > 0 && selectedIds.length > 0) {
      const singleShares = calculateSinglePersonSplit(sharedPoolMinorUnits, selectedIds[0]);
      for (const s of singleShares) {
        sharedByMember.set(s.memberId, s.shareMinorUnits);
      }
    }
  }

  const customSharedDeltaMinorUnits =
    splitType === 'custom' ? sharedPoolMinorUnits - customSharedSumMinorUnits : 0;

  // Include all selected shared members PLUS any member who has a personal item assigned
  const orderedMemberIds: string[] = [...selectedIds];
  for (const memberId of personalByMember.keys()) {
    if (!orderedMemberIds.includes(memberId)) {
      orderedMemberIds.push(memberId);
    }
  }

  // Determine whether any advance payments exist on participating members
  let hasAnyAdvance = false;
  for (const memberId of orderedMemberIds) {
    if (memberId !== input.payerId && Math.round(advanceMap[memberId] || 0) > 0) {
      hasAnyAdvance = true;
      break;
    }
  }
  const hasEnhancedMetadata = totalPersonalMinorUnits > 0 || hasAnyAdvance;

  const tempById = new Map<string, TemporaryParticipant>();
  for (const tp of input.temporaryParticipants || []) {
    if (tp && tp.id) {
      tempById.set(tp.id, {
        id: tp.id,
        name: (tp.name || '').trim() || UNKNOWN_TEMP_PARTICIPANT_LABEL,
        isTemporary: true
      });
    }
  }

  const splits: SplitShare[] = [];
  const advancePayments: AdvancePaymentRef[] = [];
  const activeTemporaryParticipants: TemporaryParticipant[] = [];
  const seenTempIds = new Set<string>();
  let allocatedMinorUnits = 0;
  let totalAdvanceMinorUnits = 0;

  for (const memberId of orderedMemberIds) {
    const sharedMinorUnits = sharedByMember.get(memberId) || 0;
    const personalMinorUnits = personalByMember.get(memberId) || 0;
    const shareMinorUnits = sharedMinorUnits + personalMinorUnits;
    const advancePaidMinorUnits =
      memberId === input.payerId ? 0 : Math.max(0, Math.round(advanceMap[memberId] || 0));
    const remainingMinorUnits = Math.max(0, shareMinorUnits - advancePaidMinorUnits);

    const percentage =
      splitType === 'percentage' && totalPersonalMinorUnits === 0 && selectedIds.includes(memberId)
        ? percentageMap[memberId] || 0
        : total > 0
        ? Number(((shareMinorUnits / total) * 100).toFixed(1))
        : 0;

    const splitObj: SplitShare = {
      memberId,
      shareMinorUnits,
      percentage
    };

    const tempMeta = tempById.get(memberId);
    if (tempMeta || isTemporaryParticipantId(memberId)) {
      const resolvedTempName =
        tempMeta?.name || input.memberNamesById?.[memberId]?.trim() || UNKNOWN_TEMP_PARTICIPANT_LABEL;
      splitObj.memberName = resolvedTempName;
      splitObj.isTemporary = true;
      if (!seenTempIds.has(memberId)) {
        seenTempIds.add(memberId);
        activeTemporaryParticipants.push({
          id: memberId,
          name: resolvedTempName,
          isTemporary: true
        });
      }
    }

    if (hasEnhancedMetadata) {
      splitObj.sharedMinorUnits = sharedMinorUnits;
      splitObj.personalMinorUnits = personalMinorUnits;
      splitObj.advancePaidMinorUnits = advancePaidMinorUnits;
      splitObj.remainingMinorUnits = remainingMinorUnits;
    }

    splits.push(splitObj);
    allocatedMinorUnits += shareMinorUnits;

    if (advancePaidMinorUnits > 0) {
      totalAdvanceMinorUnits += advancePaidMinorUnits;
      advancePayments.push({
        memberId,
        amountMinorUnits: advancePaidMinorUnits,
        advanceTransactionId: buildAdvanceTransactionId(input.expenseId || 'pending', memberId)
      });
    }
  }

  return {
    splits,
    personalItems: sanitizedPersonalItems,
    advancePayments,
    temporaryParticipants: activeTemporaryParticipants,
    totalPersonalMinorUnits,
    sharedPoolMinorUnits,
    allocatedMinorUnits,
    customSharedSumMinorUnits,
    customSharedDeltaMinorUnits,
    percentageSum,
    totalAdvanceMinorUnits
  };
}

/**
 * Validates an enhanced expense split configuration before save.
 * Enforces:
 * - Positive expense total
 * - Non-negative personal items and totalPersonal <= totalMinorUnits
 * - Percentage sum === 100% (when sharedPool > 0)
 * - Exact custom shared pool match (when sharedPool > 0)
 * - Non-negative advance payments, zero advance on bill payer
 * - DYNAMIC CAP: A member's Already Paid cannot exceed their calculated shareMinorUnits for that expense.
 *   Overpayment beyond share is disallowed; Remaining Balance can never go negative.
 */
export function validateEnhancedExpenseSplits(input: EnhancedSplitInput): EnhancedSplitValidationResult {
  const result = calculateEnhancedExpenseSplits(input);
  const errors: string[] = [];
  const memberErrors: Record<string, string> = {};
  const currency = input.currency || 'INR';
  const total = Math.round(input.totalMinorUnits || 0);

  if (total <= 0) {
    errors.push('Total expense amount must be greater than zero.');
  }

  if (input.splitType === 'none') {
    return {
      isValid: errors.length === 0,
      errors,
      memberErrors,
      result
    };
  }

  // Raw personal item checks
  for (const item of input.personalItems || []) {
    if (item.amountMinorUnits < 0) {
      errors.push('Personal item amounts cannot be negative.');
      break;
    }
    if (item.amountMinorUnits > 0 && !item.memberId) {
      errors.push('Each personal item must be assigned to a member.');
      break;
    }
  }

  if (result.totalPersonalMinorUnits > total) {
    errors.push(
      `Personal items total (${formatMinorUnits(result.totalPersonalMinorUnits, currency)}) cannot exceed expense total (${formatMinorUnits(total, currency)}).`
    );
  }

  const selectedIds = Array.from(new Set(input.selectedMemberIds || []));

  if (result.sharedPoolMinorUnits > 0) {
    if (selectedIds.length === 0) {
      errors.push('Select at least one member to split the remaining shared amount.');
    } else if (input.splitType === 'percentage') {
      const pctMap = input.percentageMap || {};
      const hasNegativePct = selectedIds.some((id) => (pctMap[id] || 0) < 0);
      if (hasNegativePct) {
        errors.push('Split percentages cannot be negative.');
      } else if (Math.abs(result.percentageSum - 100) > 0.01) {
        errors.push(`Split percentages must total 100% (currently ${result.percentageSum.toFixed(1)}%).`);
      }
    } else if (input.splitType === 'custom') {
      const customMap = input.customSharedMinorUnitsMap || {};
      const hasNegativeCustom = selectedIds.some((id) => (customMap[id] || 0) < 0);
      if (hasNegativeCustom) {
        errors.push('Custom split amounts cannot be negative.');
      } else if (result.customSharedDeltaMinorUnits > 0) {
        errors.push(
          `Custom split is short by ${formatMinorUnits(result.customSharedDeltaMinorUnits, currency)} of the shared pool.`
        );
      } else if (result.customSharedDeltaMinorUnits < 0) {
        errors.push(
          `Custom split exceeds the shared pool by ${formatMinorUnits(Math.abs(result.customSharedDeltaMinorUnits), currency)}.`
        );
      }
    }
  } else if (input.splitType === 'custom') {
    const customMap = input.customSharedMinorUnitsMap || {};
    const hasNegativeCustom = selectedIds.some((id) => (customMap[id] || 0) < 0);
    if (hasNegativeCustom) {
      errors.push('Custom split amounts cannot be negative.');
    } else if (result.customSharedSumMinorUnits > 0) {
      errors.push('Shared pool is 0 because personal items cover the entire expense; custom shared amounts must be 0.');
    }
  }

  // Advance payment checks including DYNAMIC CAP (advance <= shareMinorUnits)
  const shareByMember = new Map<string, number>();
  for (const s of result.splits) {
    shareByMember.set(s.memberId, s.shareMinorUnits);
  }

  const advanceMap = input.advancePaidMinorUnitsMap || {};
  for (const [memberId, rawAdv] of Object.entries(advanceMap)) {
    if (rawAdv < 0) {
      const msg = 'Already Paid amount cannot be negative.';
      errors.push(msg);
      memberErrors[memberId] = msg;
      continue;
    }

    const adv = Math.round(rawAdv || 0);
    if (adv === 0) continue;

    const memberLabel = input.memberNamesById?.[memberId] || 'this member';

    if (memberId === input.payerId) {
      const msg = `${memberLabel} is the bill payer and cannot have an Already Paid advance on this expense.`;
      errors.push(msg);
      memberErrors[memberId] = msg;
      continue;
    }

    const memberShare = shareByMember.get(memberId) ?? 0;
    if (adv > memberShare) {
      const msg = `Maximum Already Paid for ${memberLabel} is ${formatMinorUnits(memberShare, currency)} — their share`;
      errors.push(msg);
      memberErrors[memberId] = msg;
    }
  }

  // Strict sum invariant check when no prior allocation mismatch
  if (errors.length === 0 && result.splits.length > 0 && result.allocatedMinorUnits !== total) {
    errors.push(
      `Allocated shares (${formatMinorUnits(result.allocatedMinorUnits, currency)}) must equal the expense total (${formatMinorUnits(total, currency)}).`
    );
  }

  return {
    isValid: errors.length === 0,
    errors,
    memberErrors,
    result
  };
}

/**
 * Returns active (non-reversed, non-reversal) linked advance payments for an expense
 * by reading live ledger transactions. Respects direct advance reversals in the ledger.
 */
export function buildActiveLinkedAdvancesMap(
  expenseId: string,
  transactions: Transaction[]
): Record<string, number> {
  const reversedIds = new Set<string>();
  for (const tx of transactions) {
    if (tx.isReversal && tx.reversesTransactionId) {
      reversedIds.add(tx.reversesTransactionId);
      reversedIds.add(tx.id);
    }
    if (tx.isReversed) {
      reversedIds.add(tx.id);
    }
  }

  const map: Record<string, number> = {};
  for (const tx of transactions) {
    if (
      tx.isAdvancePayment &&
      tx.linkedExpenseId === expenseId &&
      !tx.isReversal &&
      !reversedIds.has(tx.id)
    ) {
      const memberId = tx.advanceMemberId || tx.payerId;
      if (memberId) {
        map[memberId] = (map[memberId] || 0) + tx.amount;
      }
    }
  }
  return map;
}

export interface AdvanceReconciliationPlan {
  toCreate: Transaction[];
  toUpdate: { id: string; updates: Partial<Transaction>; nextTx: Transaction }[];
  toReverse: { originalUpdated: Transaction; reversalTx: Transaction }[];
  resolvedAdvanceRefs: AdvancePaymentRef[];
}

/**
 * Reconciles linked advance payment settlement transactions for an expense create/edit.
 * Guarantees zero duplicate deductions across edits, re-saves, and offline queue retries:
 * - Unchanged advance -> no-op
 * - Changed amount/payer/title/date/method/status -> single in-place update
 * - Removed/zeroed/no-split/payer-changed -> immutable reversal of the old advance entry
 * - New advance -> deterministic ID adv_${expenseId}_${memberId} (unless previously reversed)
 */
export function reconcileLinkedAdvanceTransactions(
  expense: Transaction,
  existingTransactions: Transaction[],
  members: Member[],
  actorId?: string
): AdvanceReconciliationPlan {
  const effectiveActorId = actorId || expense.creatorId;
  const reversedIds = new Set<string>();
  const existingById = new Map<string, Transaction>();

  for (const tx of existingTransactions) {
    existingById.set(tx.id, tx);
    if (tx.isReversal && tx.reversesTransactionId) {
      reversedIds.add(tx.reversesTransactionId);
      reversedIds.add(tx.id);
    }
    if (tx.isReversed) {
      reversedIds.add(tx.id);
    }
  }

  const activeExistingByMember = new Map<string, Transaction>();
  for (const tx of existingTransactions) {
    if (
      tx.isAdvancePayment &&
      tx.linkedExpenseId === expense.id &&
      !tx.isReversal &&
      !reversedIds.has(tx.id)
    ) {
      const memberId = tx.advanceMemberId || tx.payerId;
      if (memberId) {
        activeExistingByMember.set(memberId, tx);
      }
    }
  }

  const shareByMember = new Map<string, number>();
  for (const s of expense.splits || []) {
    shareByMember.set(s.memberId, s.shareMinorUnits);
  }

  const desiredByMember = new Map<string, number>();
  if (expense.type === 'expense' && expense.splitType !== 'none' && Array.isArray(expense.advancePayments)) {
    for (const ref of expense.advancePayments) {
      const amount = Math.round(ref.amountMinorUnits || 0);
      if (!ref.memberId || ref.memberId === expense.payerId || amount <= 0) continue;
      // Dynamic cap enforcement during reconciliation as defense-in-depth
      const cap = shareByMember.has(ref.memberId) ? shareByMember.get(ref.memberId)! : amount;
      const cappedAmount = Math.min(amount, cap);
      if (cappedAmount > 0) {
        desiredByMember.set(ref.memberId, cappedAmount);
      }
    }
  }

  const getMemberName = (id: string) =>
    getParticipantDisplayName(id, members, [expense, ...existingTransactions]);
  const payerName = getMemberName(expense.payerId);

  const toCreate: Transaction[] = [];
  const toUpdate: { id: string; updates: Partial<Transaction>; nextTx: Transaction }[] = [];
  const toReverse: { originalUpdated: Transaction; reversalTx: Transaction }[] = [];
  const resolvedAdvanceRefs: AdvancePaymentRef[] = [];

  for (const [memberId, desiredAmount] of desiredByMember.entries()) {
    const memberName = getMemberName(memberId);
    const isTempAdvMember = isTemporaryParticipantId(memberId);
    const expectedTitle = `Advance: ${expense.title} (${memberName} → ${payerName})`;
    const expectedNotes = `Advance payment for "${expense.title}"`;
    const existing = activeExistingByMember.get(memberId);

    if (existing) {
      resolvedAdvanceRefs.push({
        memberId,
        amountMinorUnits: desiredAmount,
        advanceTransactionId: existing.id
      });

      const needsUpdate =
        existing.amount !== desiredAmount ||
        existing.paidToId !== expense.payerId ||
        existing.title !== expectedTitle ||
        existing.date !== expense.date ||
        (existing.paymentMethod || 'UPI') !== (expense.paymentMethod || 'UPI') ||
        existing.paymentStatus !== expense.paymentStatus;

      if (needsUpdate) {
        const nextVersion = (existing.version || 1) + 1;
        const updates: Partial<Transaction> = {
          amount: desiredAmount,
          paidToId: expense.payerId,
          title: expectedTitle,
          date: expense.date,
          paymentMethod: expense.paymentMethod || 'UPI',
          notes: expectedNotes,
          version: nextVersion,
          ...(isTempAdvMember ? { payerNameSnapshot: memberName } : {}),
          ...(expense.paymentStatus ? { paymentStatus: expense.paymentStatus } : {})
        };
        const nextTx: Transaction = {
          ...existing,
          ...updates
        };
        toUpdate.push({ id: existing.id, updates, nextTx });
      }
    } else {
      const baseId = buildAdvanceTransactionId(expense.id, memberId);
      let advId = baseId;
      if (existingById.has(advId) && reversedIds.has(advId)) {
        let suffix = 1;
        while (existingById.has(`${baseId}_r${suffix}`)) {
          suffix++;
        }
        advId = `${baseId}_r${suffix}`;
      }

      const newAdvTx: Transaction = {
        id: advId,
        spaceId: expense.spaceId,
        creatorId: effectiveActorId,
        title: expectedTitle,
        type: 'settlement',
        category: 'Advance Payment',
        amount: desiredAmount,
        date: expense.date,
        payerId: memberId,
        paidToId: expense.payerId,
        ...(isTempAdvMember ? { payerNameSnapshot: memberName } : {}),
        paymentMethod: expense.paymentMethod || 'UPI',
        ...(expense.paymentStatus ? { paymentStatus: expense.paymentStatus } : {}),
        isAdvancePayment: true,
        linkedExpenseId: expense.id,
        advanceMemberId: memberId,
        notes: expectedNotes,
        version: 1,
        createdAt: new Date().toISOString()
      };

      toCreate.push(newAdvTx);
      resolvedAdvanceRefs.push({
        memberId,
        amountMinorUnits: desiredAmount,
        advanceTransactionId: advId
      });
    }
  }

  for (const [memberId, existing] of activeExistingByMember.entries()) {
    if (!desiredByMember.has(memberId)) {
      const reversal = createReversalTransaction(
        existing,
        effectiveActorId,
        `Linked advance payment removed on "${expense.title}"`
      );
      toReverse.push(reversal);
    }
  }

  return {
    toCreate,
    toUpdate,
    toReverse,
    resolvedAdvanceRefs
  };
}

export interface CascadeReversalPlan {
  primary: { originalUpdated: Transaction; reversalTx: Transaction };
  linkedReversals: { originalUpdated: Transaction; reversalTx: Transaction }[];
}

/**
 * Reverses a transaction and, if it is a parent expense with active linked advance payments,
 * automatically cascade-reverses all active linked advance entries so net balances return to ₹0.
 */
export function createCascadeReversalPlan(
  originalTx: Transaction,
  allTransactions: Transaction[],
  actorId: string,
  reason: string = 'User requested entry reversal'
): CascadeReversalPlan {
  const primary = createReversalTransaction(originalTx, actorId, reason);
  const linkedReversals: { originalUpdated: Transaction; reversalTx: Transaction }[] = [];

  if (originalTx.type === 'expense') {
    const reversedIds = new Set<string>();
    for (const tx of allTransactions) {
      if (tx.isReversal && tx.reversesTransactionId) {
        reversedIds.add(tx.reversesTransactionId);
        reversedIds.add(tx.id);
      }
      if (tx.isReversed) {
        reversedIds.add(tx.id);
      }
    }

    const activeLinkedAdvances = allTransactions.filter(
      (tx) =>
        tx.isAdvancePayment &&
        tx.linkedExpenseId === originalTx.id &&
        !tx.isReversal &&
        !reversedIds.has(tx.id)
    );

    for (const advTx of activeLinkedAdvances) {
      linkedReversals.push(
        createReversalTransaction(
          advTx,
          actorId,
          `Cascaded reversal of parent expense "${originalTx.title}"`
        )
      );
    }
  }

  return { primary, linkedReversals };
}

