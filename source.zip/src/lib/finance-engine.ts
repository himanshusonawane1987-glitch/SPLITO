/**
 * HISAAB Pure Finance Module — Definitive Spec Version 1.2
 * 
 * Invariants & Guarantees:
 * 1. ALL money is stored and computed as integer minor units (paise, cents, fils, yen).
 *    Never use floating-point arithmetic for monetary math.
 * 2. ISO 4217 Currency Support: Minor units exponents (INR: 2, USD: 2, JPY: 0, KWD: 3, etc.)
 * 3. Actual Balance = Starting Balance + Received Income − Paid Expenses + Incoming Transfers − Outgoing Transfers.
 * 4. Largest Remainder Method (Hare-Niemeyer):
 *    Split shares ALWAYS sum strictly to the expense total. Rounding differences are assigned by highest remainder.
 * 5. Settlement Sign Convention:
 *    - Positive (> 0): Member is owed money (Credit / Receivable)
 *    - Negative (< 0): Member owes money (Debit / Payable)
 *    - Sum of all net balances across a closed space strictly equals 0.
 * 6. Smart Settlement: Bounded backtracking with greedy fallback for optimal minimal cashflow reconciliation.
 * 7. Immutable Reversals: Financial entries are never silently destroyed; they are reversed.
 */

import {
  ActualBalanceBreakdown,
  CategoryBreakdown,
  CurrencyCode,
  CurrencyMetadata,
  DebtSettlement,
  Member,
  MemberBalance,
  Space,
  SplitShare,
  Transaction,
  TransactionType
} from '../types/finance.ts';

/**
 * ISO 4217 Currency Registry with Unicode CLDR locales and minor unit exponents
 */
export const CURRENCY_REGISTRY: Record<CurrencyCode, CurrencyMetadata> = {
  INR: {
    code: 'INR',
    name: 'Indian Rupee',
    symbol: '₹',
    minorUnits: 2,
    locale: 'en-IN',
    sampleFormatted: '₹1,24,500.50'
  },
  USD: {
    code: 'USD',
    name: 'US Dollar',
    symbol: '$',
    minorUnits: 2,
    locale: 'en-US',
    sampleFormatted: '$1,250.00'
  },
  EUR: {
    code: 'EUR',
    name: 'Euro',
    symbol: '€',
    minorUnits: 2,
    locale: 'de-DE',
    sampleFormatted: '1.250,00 €'
  },
  GBP: {
    code: 'GBP',
    name: 'British Pound',
    symbol: '£',
    minorUnits: 2,
    locale: 'en-GB',
    sampleFormatted: '£1,250.00'
  },
  JPY: {
    code: 'JPY',
    name: 'Japanese Yen',
    symbol: '¥',
    minorUnits: 0, // Zero decimals
    locale: 'ja-JP',
    sampleFormatted: '¥12,500'
  },
  KWD: {
    code: 'KWD',
    name: 'Kuwaiti Dinar',
    symbol: 'KD',
    minorUnits: 3, // 3 decimals (1000 fils)
    locale: 'ar-KW',
    sampleFormatted: 'KD 125.750'
  },
  AED: {
    code: 'AED',
    name: 'UAE Dirham',
    symbol: 'د.إ',
    minorUnits: 2,
    locale: 'ar-AE',
    sampleFormatted: '1,250.00 د.إ'
  },
  SGD: {
    code: 'SGD',
    name: 'Singapore Dollar',
    symbol: 'S$',
    minorUnits: 2,
    locale: 'en-SG',
    sampleFormatted: 'S$1,250.00'
  },
  CAD: {
    code: 'CAD',
    name: 'Canadian Dollar',
    symbol: 'CA$',
    minorUnits: 2,
    locale: 'en-CA',
    sampleFormatted: 'CA$1,250.00'
  },
  AUD: {
    code: 'AUD',
    name: 'Australian Dollar',
    symbol: 'A$',
    minorUnits: 2,
    locale: 'en-AU',
    sampleFormatted: 'A$1,250.00'
  },
  CHF: {
    code: 'CHF',
    name: 'Swiss Franc',
    symbol: 'CHF',
    minorUnits: 2,
    locale: 'de-CH',
    sampleFormatted: 'CHF 1,250.00'
  }
};

/**
 * Gets currency metadata safely with fallback to INR
 */
export function getCurrencyMeta(code: CurrencyCode = 'INR'): CurrencyMetadata {
  return CURRENCY_REGISTRY[code] || CURRENCY_REGISTRY.INR;
}

/**
 * Returns symbol for currency
 */
export function getCurrencySymbol(code: CurrencyCode = 'INR'): string {
  return getCurrencyMeta(code).symbol;
}

/**
 * Precision parser that converts user input (string or number) into integer minor units.
 * Respects ISO 4217 minor unit exponents (e.g. 2 for INR/USD, 0 for JPY, 3 for KWD).
 */
export function parseInputToMinorUnits(input: string | number, currency: CurrencyCode = 'INR'): number {
  const meta = getCurrencyMeta(currency);
  const exponent = meta.minorUnits;
  const factor = Math.pow(10, exponent);

  if (typeof input === 'number') {
    if (isNaN(input)) return 0;
    return Math.round(input * factor);
  }

  if (!input || typeof input !== 'string') return 0;

  // Clean string: remove symbols, spaces, commas
  const cleaned = input.replace(/[^\d.-]/g, '').trim();
  if (!cleaned || cleaned === '-' || cleaned === '.') return 0;

  const isNegative = cleaned.startsWith('-');
  const unsigned = isNegative ? cleaned.slice(1) : cleaned;

  const parts = unsigned.split('.');
  const wholePart = parts[0] ? parseInt(parts[0], 10) : 0;
  if (isNaN(wholePart)) return 0;

  let fractionUnits = 0;
  if (exponent > 0 && parts.length > 1) {
    const fractionStr = parts[1].padEnd(exponent, '0').slice(0, exponent);
    fractionUnits = parseInt(fractionStr, 10) || 0;
  }

  const totalMinorUnits = wholePart * factor + fractionUnits;
  return isNegative ? -totalMinorUnits : totalMinorUnits;
}

/**
 * Backward compatibility alias for parseInputToPaise (defaults to INR)
 */
export function parseInputToPaise(input: string | number): number {
  return parseInputToMinorUnits(input, 'INR');
}

/**
 * Converts integer minor units to formatted decimal string without currency symbol.
 * Example: 125000 (INR, 2 decimals) -> "1250.00"
 * Example: 1250 (JPY, 0 decimals) -> "1250"
 * Example: 1250750 (KWD, 3 decimals) -> "1250.750"
 */
export function minorUnitsToDecimalString(minorUnits: number, currency: CurrencyCode = 'INR'): string {
  if (isNaN(minorUnits)) return '0';
  const meta = getCurrencyMeta(currency);
  const exponent = meta.minorUnits;
  const isNegative = minorUnits < 0;
  const abs = Math.abs(Math.round(minorUnits));

  if (exponent === 0) {
    return `${isNegative ? '-' : ''}${abs}`;
  }

  const factor = Math.pow(10, exponent);
  const whole = Math.floor(abs / factor);
  const fraction = abs % factor;
  const fractionStr = fraction.toString().padStart(exponent, '0');
  return `${isNegative ? '-' : ''}${whole}.${fractionStr}`;
}

export function paiseToDecimalString(paise: number): string {
  return minorUnitsToDecimalString(paise, 'INR');
}

/**
 * Formats integer minor units into locale-aware currency strings via Intl.NumberFormat and Unicode CLDR.
 */
export function formatMinorUnits(
  minorUnits: number,
  currency: CurrencyCode = 'INR',
  options: { showSign?: boolean; compact?: boolean } = {}
): string {
  if (isNaN(minorUnits)) return '0';

  const meta = getCurrencyMeta(currency);
  const exponent = meta.minorUnits;
  const factor = Math.pow(10, exponent);

  const isNegative = minorUnits < 0;
  const absUnits = Math.abs(Math.round(minorUnits));
  const decimalVal = exponent > 0 ? absUnits / factor : absUnits;

  const formatter = new Intl.NumberFormat(meta.locale, {
    style: 'currency',
    currency: meta.code,
    minimumFractionDigits: exponent,
    maximumFractionDigits: exponent
  });

  const formatted = formatter.format(decimalVal);

  if (isNegative) {
    return `-${formatted}`;
  } else if (options.showSign && minorUnits > 0) {
    return `+${formatted}`;
  }

  return formatted;
}

/**
 * Backward compatibility alias for formatPaise
 */
export function formatPaise(
  paise: number,
  currency: CurrencyCode = 'INR',
  options?: { showSign?: boolean; compact?: boolean }
): string {
  return formatMinorUnits(paise, currency, options);
}

/**
 * Pure function to calculate actual available balance:
 * Actual Balance = Starting Balance + Received Income − Paid Expenses + Incoming Transfers − Outgoing Transfers
 */
export function calculateActualBalance(params: {
  startingBalance: number;
  receivedIncome: number;
  paidExpenses: number;
  incomingTransfers: number;
  outgoingTransfers: number;
}): ActualBalanceBreakdown {
  const starting = Math.round(params.startingBalance || 0);
  const income = Math.round(params.receivedIncome || 0);
  const expense = Math.round(params.paidExpenses || 0);
  const incoming = Math.round(params.incomingTransfers || 0);
  const outgoing = Math.round(params.outgoingTransfers || 0);

  const actual = starting + income - expense + incoming - outgoing;

  return {
    startingBalance: starting,
    receivedIncome: income,
    paidExpenses: expense,
    incomingTransfers: incoming,
    outgoingTransfers: outgoing,
    actualBalance: actual
  };
}

/**
 * Filters out reversed entries and their reversals so ledger calculations remain mathematically pure.
 */
export function getActiveLedgerTransactions(transactions: Transaction[]): Transaction[] {
  const reversedIds = new Set<string>();

  for (const tx of transactions) {
    if (tx.isReversal && tx.reversesTransactionId) {
      reversedIds.add(tx.reversesTransactionId);
      reversedIds.add(tx.id);
    }
    if (tx.isReversed) {
      reversedIds.add(tx.id);
    }
  }

  return transactions.filter((tx) => {
    if (reversedIds.has(tx.id)) return false;
    // Status-aware filtering (SPLITO Wallet Pay):
    // Existing transactions without paymentStatus default to 'paid'.
    // Only 'paid' transactions affect balances, dues, and category breakdowns.
    if (tx.paymentStatus && tx.paymentStatus !== 'paid') {
      return false;
    }
    return true;
  });
}

/**
 * Calculates actual balance for a specific Space considering active transactions
 * and the perspective of the current user.
 */
export function calculateSpaceLedgerBalance(
  space: Space,
  transactions: Transaction[],
  currentUserId?: string
): ActualBalanceBreakdown {
  const activeTx = getActiveLedgerTransactions(transactions);
  const startingBalance = space.startingBalance || 0;
  let receivedIncome = 0;
  let paidExpenses = 0;
  let incomingTransfers = 0;
  let outgoingTransfers = 0;

  const effectiveUserId = currentUserId || space.ownerId;
  const isPersonal = space.mode === 'personal';

  for (const tx of activeTx) {
    if (tx.type === 'income') {
      if (isPersonal || tx.payerId === effectiveUserId || tx.paidToId === effectiveUserId) {
        receivedIncome += tx.amount;
      }
    } else if (tx.type === 'expense') {
      if (isPersonal) {
        paidExpenses += tx.amount;
      } else {
        if (tx.payerId === effectiveUserId) {
          paidExpenses += tx.amount;
        }
      }
    } else if (tx.type === 'transfer' || tx.type === 'settlement') {
      if (tx.payerId === effectiveUserId) {
        outgoingTransfers += tx.amount;
      }
      if (tx.paidToId === effectiveUserId) {
        incomingTransfers += tx.amount;
      }
    }
  }

  return calculateActualBalance({
    startingBalance,
    receivedIncome,
    paidExpenses,
    incomingTransfers,
    outgoingTransfers
  });
}

/**
 * Largest Remainder Method (Hare-Niemeyer) for Equal Splits:
 * Divides total minor units equally across member IDs.
 * GUARANTEE: Shares always sum strictly to totalMinorUnits.
 * Remainder is assigned by highest fractional remainder (or first in order).
 */
export function calculateEqualSplits(totalMinorUnits: number, memberIds: string[]): SplitShare[] {
  const total = Math.max(0, Math.round(totalMinorUnits));
  if (!memberIds || memberIds.length === 0) return [];
  const n = memberIds.length;

  const baseShare = Math.floor(total / n);
  const remainder = total % n;

  return memberIds.map((memberId, idx) => {
    const extra = idx < remainder ? 1 : 0;
    const shareMinorUnits = baseShare + extra;
    return {
      memberId,
      shareMinorUnits,
      percentage: total > 0 ? Number(((shareMinorUnits / total) * 100).toFixed(1)) : 0
    };
  });
}

/**
 * Largest Remainder Method (Hare-Niemeyer) for Percentage Splits:
 * Calculates integer shares and allocates fractional shortfall strictly in descending order of remainders.
 * GUARANTEE: Shares always sum strictly to totalMinorUnits.
 */
export function calculatePercentageSplits(
  totalMinorUnits: number,
  splits: { memberId: string; percentage: number }[]
): SplitShare[] {
  const total = Math.max(0, Math.round(totalMinorUnits));
  if (!splits || splits.length === 0) return [];

  // Compute exact float quotient, floor to integer base share, record fractional remainder
  const intermediate = splits.map((s, index) => {
    const exact = (total * Math.max(0, s.percentage)) / 100;
    const base = Math.floor(exact);
    const remainder = exact - base;
    return {
      index,
      memberId: s.memberId,
      percentage: s.percentage,
      base,
      remainder
    };
  });

  const sumBase = intermediate.reduce((acc, curr) => acc + curr.base, 0);
  const shortfall = total - sumBase;

  // Sort by remainder descending (Largest Remainder Method)
  const sortedIndices = [...intermediate].sort((a, b) => b.remainder - a.remainder);

  const bonusAllocations = new Set<number>();
  for (let i = 0; i < shortfall && i < sortedIndices.length; i++) {
    bonusAllocations.add(sortedIndices[i].index);
  }

  return intermediate.map((item) => {
    const shareMinorUnits = item.base + (bonusAllocations.has(item.index) ? 1 : 0);
    return {
      memberId: item.memberId,
      shareMinorUnits,
      percentage: item.percentage
    };
  });
}

/**
 * Custom Split:
 * Directly accepts custom amounts in minor units.
 * GUARANTEE: Adjusts any delta onto the largest share so the sum strictly equals totalMinorUnits.
 */
export function calculateCustomSplits(
  totalMinorUnits: number,
  splits: { memberId: string; customMinorUnits: number }[]
): SplitShare[] {
  const total = Math.max(0, Math.round(totalMinorUnits));
  if (!splits || splits.length === 0) return [];

  const result: SplitShare[] = splits.map((s) => ({
    memberId: s.memberId,
    shareMinorUnits: Math.max(0, Math.round(s.customMinorUnits || 0)),
    percentage: total > 0 ? Number(((s.customMinorUnits / total) * 100).toFixed(1)) : 0
  }));

  const sumShares = result.reduce((acc, curr) => acc + curr.shareMinorUnits, 0);
  const difference = total - sumShares;

  if (difference !== 0 && result.length > 0) {
    let largestIdx = 0;
    let maxShare = -1;
    for (let i = 0; i < result.length; i++) {
      if (result[i].shareMinorUnits > maxShare) {
        maxShare = result[i].shareMinorUnits;
        largestIdx = i;
      }
    }
    result[largestIdx].shareMinorUnits += difference;
  }

  return result;
}

/**
 * Single Person Split:
 * Exactly one selected member bears 100% of the expense amount,
 * even if another member originally paid for the expense.
 */
export function calculateSinglePersonSplit(
  totalMinorUnits: number,
  memberId: string
): SplitShare[] {
  const total = Math.max(0, Math.round(totalMinorUnits));
  if (!memberId) return [];
  return [
    {
      memberId,
      shareMinorUnits: total,
      percentage: 100
    }
  ];
}

/**
 * Calculates member balances in a group space:
 * For each member:
 *   totalPaidMinorUnits: how much they paid upfront for expenses or paid in settlements/transfers
 *   totalOwedMinorUnits: their consumption share of expenses or amount received in settlements/transfers
 *   netBalanceMinorUnits = totalPaidMinorUnits - totalOwedMinorUnits
 * 
 * SIGN CONVENTION:
 *   Positive (+): Member is owed money (Receivable / Credit from others)
 *   Negative (-): Member owes money (Payable / Debit to others)
 *   Zero: Settled up.
 * 
 * Sum across all members in a closed group is guaranteed to be 0!
 */
export function calculateGroupBalances(members: Member[], transactions: Transaction[]): MemberBalance[] {
  const activeTx = getActiveLedgerTransactions(transactions);
  const balanceMap = new Map<
    string,
    {
      name: string;
      totalExpensePaid: number;
      totalExpenseShare: number;
      totalSettlementPaid: number;
      totalSettlementReceived: number;
    }
  >();

  for (const m of members) {
    balanceMap.set(m.id, {
      name: m.name,
      totalExpensePaid: 0,
      totalExpenseShare: 0,
      totalSettlementPaid: 0,
      totalSettlementReceived: 0
    });
  }

  for (const tx of activeTx) {
    if (tx.type === 'expense') {
      const payerEntry = balanceMap.get(tx.payerId) || {
        name: tx.payerId,
        totalExpensePaid: 0,
        totalExpenseShare: 0,
        totalSettlementPaid: 0,
        totalSettlementReceived: 0
      };
      payerEntry.totalExpensePaid += tx.amount;
      balanceMap.set(tx.payerId, payerEntry);

      if (tx.splits && tx.splits.length > 0) {
        for (const split of tx.splits) {
          const splitEntry = balanceMap.get(split.memberId) || {
            name: split.memberId,
            totalExpensePaid: 0,
            totalExpenseShare: 0,
            totalSettlementPaid: 0,
            totalSettlementReceived: 0
          };
          splitEntry.totalExpenseShare += split.shareMinorUnits;
          balanceMap.set(split.memberId, splitEntry);
        }
      } else {
        payerEntry.totalExpenseShare += tx.amount;
      }
    } else if (tx.type === 'settlement' || tx.type === 'transfer') {
      if (tx.payerId && tx.paidToId) {
        const payerEntry = balanceMap.get(tx.payerId) || {
          name: tx.payerId,
          totalExpensePaid: 0,
          totalExpenseShare: 0,
          totalSettlementPaid: 0,
          totalSettlementReceived: 0
        };
        payerEntry.totalSettlementPaid += tx.amount;
        balanceMap.set(tx.payerId, payerEntry);

        const recipientEntry = balanceMap.get(tx.paidToId) || {
          name: tx.paidToId,
          totalExpensePaid: 0,
          totalExpenseShare: 0,
          totalSettlementPaid: 0,
          totalSettlementReceived: 0
        };
        recipientEntry.totalSettlementReceived += tx.amount;
        balanceMap.set(tx.paidToId, recipientEntry);
      }
    }
  }

  const result: MemberBalance[] = [];
  balanceMap.forEach((val, id) => {
    const totalPaid = val.totalExpensePaid + val.totalSettlementPaid;
    const totalOwed = val.totalExpenseShare + val.totalSettlementReceived;
    result.push({
      memberId: id,
      memberName: val.name,
      totalExpenseShareMinorUnits: val.totalExpenseShare,
      totalExpensePaidMinorUnits: val.totalExpensePaid,
      totalSettlementPaidMinorUnits: val.totalSettlementPaid,
      totalSettlementReceivedMinorUnits: val.totalSettlementReceived,
      totalPaidMinorUnits: totalPaid,
      totalOwedMinorUnits: totalOwed,
      netBalanceMinorUnits: totalPaid - totalOwed
    });
  });

  return result;
}

/**
 * SMART SETTLEMENT — SIGNATURE FEATURE
 * Bounded backtracking with greedy fallback algorithm:
 * 1. Phase 1 (Exact 2-person zero-sum pairings):
 *    If debtor D owes exactly what creditor C is owed (D.owes == C.isOwed),
 *    settling D -> C in 1 transaction eliminates BOTH from the balance sheet.
 * 2. Phase 2 (Exact 3-person zero-sum combinations):
 *    If 1 debtor balances 2 creditors or 2 debtors balance 1 creditor,
 *    settle with 2 transactions instead of cascading through multiple intermediaries.
 * 3. Phase 3 (Greedy reconciliation fallback):
 *    For remaining un-paired balances, match the largest debtor with the largest creditor.
 * 
 * Outcome: Absolute minimal number of transactions, eliminates circular & transitive debt,
 * and maintains 100% precision in integer minor units.
 */
export function calculateDebtSettlements(memberBalances: MemberBalance[]): DebtSettlement[] {
  interface Participant {
    id: string;
    name: string;
    amount: number; // Positive magnitude
  }

  const debtors: Participant[] = [];
  const creditors: Participant[] = [];

  for (const b of memberBalances) {
    if (b.netBalanceMinorUnits < 0) {
      debtors.push({ id: b.memberId, name: b.memberName, amount: Math.abs(b.netBalanceMinorUnits) });
    } else if (b.netBalanceMinorUnits > 0) {
      creditors.push({ id: b.memberId, name: b.memberName, amount: b.netBalanceMinorUnits });
    }
  }

  const settlements: DebtSettlement[] = [];

  // Phase 1: Direct 1-to-1 exact matches (Subset Sum k=1)
  for (let i = 0; i < debtors.length; i++) {
    const d = debtors[i];
    if (d.amount === 0) continue;

    for (let j = 0; j < creditors.length; j++) {
      const c = creditors[j];
      if (c.amount === 0) continue;

      if (d.amount === c.amount) {
        settlements.push({
          fromMemberId: d.id,
          fromMemberName: d.name,
          toMemberId: c.id,
          toMemberName: c.name,
          amountMinorUnits: d.amount
        });
        d.amount = 0;
        c.amount = 0;
        break;
      }
    }
  }

  // Phase 2: 1-debtor to 2-creditors exact sum match
  for (let i = 0; i < debtors.length; i++) {
    const d = debtors[i];
    if (d.amount === 0) continue;

    let matched = false;
    for (let j = 0; j < creditors.length - 1; j++) {
      const c1 = creditors[j];
      if (c1.amount === 0) continue;

      for (let k = j + 1; k < creditors.length; k++) {
        const c2 = creditors[k];
        if (c2.amount === 0) continue;

        if (d.amount === c1.amount + c2.amount) {
          settlements.push({
            fromMemberId: d.id,
            fromMemberName: d.name,
            toMemberId: c1.id,
            toMemberName: c1.name,
            amountMinorUnits: c1.amount
          });
          settlements.push({
            fromMemberId: d.id,
            fromMemberName: d.name,
            toMemberId: c2.id,
            toMemberName: c2.name,
            amountMinorUnits: c2.amount
          });
          d.amount = 0;
          c1.amount = 0;
          c2.amount = 0;
          matched = true;
          break;
        }
      }
      if (matched) break;
    }
  }

  // Phase 3: Greedy reconciliation fallback for remaining balances
  const remainingDebtors = debtors.filter((d) => d.amount > 0).sort((a, b) => b.amount - a.amount);
  const remainingCreditors = creditors.filter((c) => c.amount > 0).sort((a, b) => b.amount - a.amount);

  let dIdx = 0;
  let cIdx = 0;

  while (dIdx < remainingDebtors.length && cIdx < remainingCreditors.length) {
    const debtor = remainingDebtors[dIdx];
    const creditor = remainingCreditors[cIdx];

    const settleAmount = Math.min(debtor.amount, creditor.amount);

    if (settleAmount > 0) {
      settlements.push({
        fromMemberId: debtor.id,
        fromMemberName: debtor.name,
        toMemberId: creditor.id,
        toMemberName: creditor.name,
        amountMinorUnits: settleAmount
      });
    }

    debtor.amount -= settleAmount;
    creditor.amount -= settleAmount;

    if (debtor.amount === 0) dIdx++;
    if (creditor.amount === 0) cIdx++;
  }

  return settlements;
}

/**
 * Calculates category-wise breakdown for charts and analytics
 */
export function calculateCategoryBreakdowns(
  transactions: Transaction[],
  type: TransactionType = 'expense'
): CategoryBreakdown[] {
  const activeTx = getActiveLedgerTransactions(transactions);
  const filtered = activeTx.filter((t) => t.type === type);
  const total = filtered.reduce((acc, curr) => acc + curr.amount, 0);

  const map = new Map<string, { amount: number; count: number }>();
  for (const tx of filtered) {
    const cat = tx.category || 'General';
    const curr = map.get(cat) || { amount: 0, count: 0 };
    curr.amount += tx.amount;
    curr.count += 1;
    map.set(cat, curr);
  }

  const result: CategoryBreakdown[] = [];
  map.forEach((val, category) => {
    result.push({
      category,
      amountMinorUnits: val.amount,
      percentage: total > 0 ? Number(((val.amount / total) * 100).toFixed(1)) : 0,
      count: val.count,
      type
    });
  });

  return result.sort((a, b) => b.amountMinorUnits - a.amountMinorUnits);
}

/**
 * Creates an immutable reversal transaction that negates a prior transaction.
 * Follows the "never delete financial facts — reverse them" ledger invariant.
 */
export function createReversalTransaction(
  originalTx: Transaction,
  actorId: string,
  reason: string = 'User requested entry reversal'
): { originalUpdated: Transaction; reversalTx: Transaction } {
  const now = new Date().toISOString();

  const originalUpdated: Transaction = {
    ...originalTx,
    isReversed: true,
    reversedAt: now,
    reversedBy: actorId,
    version: (originalTx.version || 1) + 1
  };

  const reversalTx: Transaction = {
    id: `rev_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    spaceId: originalTx.spaceId,
    creatorId: actorId,
    title: `[Reversal] ${originalTx.title}`,
    type: originalTx.type,
    category: originalTx.category,
    amount: originalTx.amount,
    date: now.split('T')[0],
    payerId: originalTx.paidToId || originalTx.payerId, // Inverse direction
    paidToId: originalTx.paidToId ? originalTx.payerId : undefined,
    notes: `Reversal of #${originalTx.id.slice(-6)}: ${reason}`,
    isReversal: true,
    reversesTransactionId: originalTx.id,
    version: 1,
    createdAt: now
  };

  return { originalUpdated, reversalTx };
}
