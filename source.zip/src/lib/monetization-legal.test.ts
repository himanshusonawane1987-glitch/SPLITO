/**
 * Automated Test Suite for SPLITO Monetization, Subscriptions, Ads & Legal Disclosures
 * Master Specification v1.5
 */

import {
  calculateEntitlement,
  startProTrial,
  cancelProSubscription,
  restorePurchases,
  DEFAULT_FREE_SUBSCRIPTION
} from './billing-service.ts';
import {
  SUBSCRIPTION_PRICING,
  UserSubscription
} from '../types/subscription.ts';
import {
  ADMOB_TEST_CONFIG,
  shouldShowAds,
  getSafeAdTargetingContext
} from './ad-service.ts';
import {
  LEGAL_DOCUMENTS,
  LegalDocKey
} from './legal-content.ts';

export async function runMonetizationTests(): Promise<boolean> {
  console.log('\n--- Running SPLITO Monetization, Billing, Ad Firewall & Legal Tests ---');
  let passed = 0;
  let total = 0;

  function assert(desc: string, condition: boolean) {
    total++;
    if (condition) {
      passed++;
      console.log(`✅ PASS: ${desc}`);
    } else {
      console.error(`❌ FAIL: ${desc}`);
    }
  }

  // MON-01: Free plan defaults and ₹0 pricing
  const freeEntitlement = calculateEntitlement(DEFAULT_FREE_SUBSCRIPTION);
  assert('MON-01: Free plan entitlement provides basic features and indicates ads on free tier',
    freeEntitlement.plan === 'free' &&
    freeEntitlement.isPro === false &&
    freeEntitlement.canExportPdfWithoutAds === false &&
    freeEntitlement.isAdFree === false
  );

  // MON-02: Pro plan pricing structure (₹59/mo, ₹599/yr)
  assert('MON-02.1: Monthly plan is ₹59 (5900 minor units) with 30-day trial',
    SUBSCRIPTION_PRICING.monthly.pricePaise === 5900 &&
    SUBSCRIPTION_PRICING.monthly.formattedPrice === '₹59' &&
    SUBSCRIPTION_PRICING.monthly.trialDays === 30
  );
  assert('MON-02.2: Yearly plan is ₹599 (59900 minor units) with 30-day trial and 15% savings note',
    SUBSCRIPTION_PRICING.yearly.pricePaise === 59900 &&
    SUBSCRIPTION_PRICING.yearly.formattedPrice === '₹599' &&
    SUBSCRIPTION_PRICING.yearly.trialDays === 30 &&
    SUBSCRIPTION_PRICING.yearly.savingsNote?.includes('15%') === true
  );

  // MON-03: 1-Month Free Trial activation and entitlement computation
  const now = new Date();
  const futureTrialEnd = new Date(now.getTime() + 25 * 24 * 60 * 60 * 1000).toISOString(); // 25 days left
  const trialSub: UserSubscription = {
    plan: 'pro',
    status: 'trial',
    billingCycle: 'monthly',
    trialStartDate: now.toISOString(),
    trialEndDate: futureTrialEnd,
    currentPeriodStart: now.toISOString(),
    currentPeriodEnd: futureTrialEnd,
    autoRenew: true,
    updatedAt: now.toISOString()
  };
  const trialEntitlement = calculateEntitlement(trialSub);
  assert('MON-03: Active 30-day trial grants full Pro benefits without ads',
    trialEntitlement.isPro === true &&
    trialEntitlement.status === 'trial' &&
    trialEntitlement.canExportPdfWithoutAds === true &&
    trialEntitlement.isAdFree === true &&
    (trialEntitlement.daysRemainingInTrial ?? 0) > 0
  );

  // MON-04: Trial expiration reverts cleanly to Free plan without locking basic ledger
  const expiredTrialEnd = new Date(now.getTime() - 2 * 24 * 60 * 60 * 1000).toISOString(); // 2 days ago
  const expiredSub: UserSubscription = {
    ...trialSub,
    trialEndDate: expiredTrialEnd,
    currentPeriodEnd: expiredTrialEnd
  };
  const expiredEntitlement = calculateEntitlement(expiredSub);
  assert('MON-04: Expired trial reverts user to Free plan without loss of basic functionality',
    expiredEntitlement.isPro === false &&
    expiredEntitlement.plan === 'free' &&
    expiredEntitlement.isAdFree === false
  );

  // MON-05: Cancellation preserves active period until expiration
  const activePeriodEnd = new Date(now.getTime() + 15 * 24 * 60 * 60 * 1000).toISOString();
  const cancelledSub: UserSubscription = {
    plan: 'pro',
    status: 'cancelled',
    billingCycle: 'monthly',
    currentPeriodEnd: activePeriodEnd,
    autoRenew: false,
    cancelledAt: now.toISOString(),
    updatedAt: now.toISOString()
  };
  const cancelledEntitlement = calculateEntitlement(cancelledSub);
  assert('MON-05: Cancelled subscription preserves Pro features until current period ends',
    cancelledEntitlement.isPro === true &&
    cancelledEntitlement.status === 'cancelled' &&
    cancelledEntitlement.statusLabel.includes('Cancels on')
  );

  // MON-06: AdMob test units and privacy ad suppression
  assert('MON-06.1: shouldShowAds is false for Pro users and true for Free users',
    shouldShowAds(true) === false && shouldShowAds(false) === true
  );
  assert('MON-06.2: AdMob test units configured for non-production development',
    ADMOB_TEST_CONFIG.isTestMode === true &&
    ADMOB_TEST_CONFIG.bannerAdUnitId.startsWith('ca-app-pub-3940256099942544')
  );

  // MON-07: Financial Privacy Firewall strictly prevents data leaks
  const adContext = getSafeAdTargetingContext();
  const contextKeys = Object.keys(adContext);
  assert('MON-07: Ad targeting context strictly omits financial balances, transaction notes, and member names',
    !contextKeys.includes('amount') &&
    !contextKeys.includes('balance') &&
    !contextKeys.includes('transaction') &&
    !contextKeys.includes('notes') &&
    !contextKeys.includes('members')
  );

  // MON-08: Complete Legal Library of 7 documents
  const expectedDocKeys: LegalDocKey[] = [
    'user_agreement',
    'terms_conditions',
    'privacy_policy',
    'subscription_terms',
    'cancellation_refund',
    'data_permissions',
    'account_deletion'
  ];
  const allDocsExist = expectedDocKeys.every((key) => !!LEGAL_DOCUMENTS[key]);
  assert('MON-08: All 7 required legal documents exist in the legal registry', allDocsExist);

  // MON-09: Non-banking and credential safety disclosures in both English & Hindi
  const userAgreement = LEGAL_DOCUMENTS.user_agreement;
  const fullUserAgreementEn = userAgreement.sectionsEn.map((s) => s.body).join(' ');
  const fullUserAgreementHi = userAgreement.sectionsHi.map((s) => s.body).join(' ');
  const hasBankWarningEn = fullUserAgreementEn.includes('NOT a bank') && fullUserAgreementEn.includes('UPI PIN');
  const hasBankWarningHi = fullUserAgreementHi.includes('कोई बैंक नहीं है') && fullUserAgreementHi.includes('यूपीआई पिन');
  assert('MON-09: User Agreement contains mandatory non-banking and UPI PIN/OTP warnings in English & Hindi',
    hasBankWarningEn && hasBankWarningHi
  );

  // MON-10: Subscription terms disclosure states Coming Soon (no prices, trial, or cancel-steps) in English & Hindi
  const subTerms = LEGAL_DOCUMENTS.subscription_terms;
  const cancelTerms = LEGAL_DOCUMENTS.cancellation_refund;
  const fullSubTermsEn = subTerms.sectionsEn.map((s) => s.body).join(' ');
  const fullSubTermsHi = subTerms.sectionsHi.map((s) => s.body).join(' ');
  const fullCancelEn = cancelTerms.sectionsEn.map((s) => s.body).join(' ');
  const fullCancelHi = cancelTerms.sectionsHi.map((s) => s.body).join(' ');

  const exactComingSoonEn = 'Premium subscription is coming soon. Currently the app is free with rewarded ads. Pricing and terms will be shared before launch.';
  const exactComingSoonHi = 'प्रीमियम सब्सक्रिप्शन जल्द आ रहा है। फिलहाल ऐप रिवॉर्डेड विज्ञापनों के साथ मुफ्त है। कीमत और शर्तें लॉन्च से पहले बताई जाएंगी।';

  const hasComingSoonEn = fullSubTermsEn.includes(exactComingSoonEn) && fullCancelEn.includes(exactComingSoonEn);
  const hasComingSoonHi = fullSubTermsHi.includes(exactComingSoonHi) && fullCancelHi.includes(exactComingSoonHi);
  const noOldPricing = !fullSubTermsEn.includes('₹59') && !fullSubTermsEn.includes('₹599') && !fullCancelEn.includes('₹59') && !fullCancelEn.includes('Play Store');

  assert('MON-10: Subscription Terms explicitly document ₹59/mo, ₹599/yr pricing and free trial in English & Hindi',
    hasComingSoonEn && hasComingSoonHi && noOldPricing
  );

  // ==========================================
  // AD-01 TO AD-10: HOME FEED ADS, END-OF-LIST AD, SETTLEMENT REPOSITIONING & PERMANENT AD
  // ==========================================
  const fs = await import('fs');
  const homeViewContent = fs.readFileSync('src/components/views/HomeView.tsx', 'utf-8');
  const bottomNavContent = fs.readFileSync('src/components/ui/BottomNav.tsx', 'utf-8');

  // AD-01: Inline ads appear continuously inside the Home screen scrollable feed at regular intervals (after every 3rd item)
  const hasInlineAdInterval = homeViewContent.includes('(idx + 1) % 3 === 0') &&
    homeViewContent.includes('placement="inline"');
  assert('AD-01: Inline ads appear continuously inside the Home screen feed after every 3rd item', hasInlineAdInterval);

  // AD-02: End-of-list ad appears only at the bottom of the Home feed and not at the top
  const hasEndOfListAd = homeViewContent.includes('placement="end-of-list"') &&
    homeViewContent.lastIndexOf('placement="end-of-list"') > homeViewContent.indexOf('placement="inline"');
  assert('AD-02: End-of-list ad appears only at the scroll end of the Home feed', hasEndOfListAd);

  // AD-03: Settlement Overview & Roommate Balances section is positioned below the balance card and below the action buttons
  const balanceCardIndex = homeViewContent.indexOf('Actual Available Balance');
  const actionButtonsIndex = homeViewContent.indexOf('Add Expense');
  const settlementSectionIndex = homeViewContent.indexOf('Settlement Overview & Roommate Balances');
  const isSettlementMovedDown = settlementSectionIndex > actionButtonsIndex && actionButtonsIndex > balanceCardIndex;
  assert('AD-03: Settlement Overview section is in a lower position, below the balance card and below the action buttons', isSettlementMovedDown);

  // AD-04: Permanent ad slot is always in the same fixed position near Settlement Overview
  const permanentAdIndex = homeViewContent.indexOf('placement="permanent"');
  const isPermanentNearSettlement = permanentAdIndex > settlementSectionIndex && permanentAdIndex < homeViewContent.indexOf('Recent Diary Entries');
  assert('AD-04: Permanent ad slot is in fixed position immediately adjacent to Settlement Overview', isPermanentNearSettlement);

  // AD-05: Permanent ad does NOT overlap section title, 'MY' label, roommate names, or balances
  const adBannerContent = fs.readFileSync('src/components/ui/AdBanner.tsx', 'utf-8');
  const hasNoAdOverlap = !homeViewContent.includes('absolute inset-0') &&
    homeViewContent.includes('space-y-3') &&
    homeViewContent.includes('placement="permanent"') &&
    adBannerContent.includes('data-ad-placement');
  assert('AD-05: Permanent ad is an independent flow container with zero overlap over titles or roommate balances', hasNoAdOverlap);

  // AD-06: FREE users see ads in all placements, Pro users see NO ads in any placement
  const freeShowsAds = shouldShowAds(false);
  const proSuppressesAds = !shouldShowAds(true);
  assert('AD-06: FREE users see ads in all placements; Pro users see NO ads in any placement', freeShowsAds && proSuppressesAds);

  // AD-07: No financial data, transaction data, balances, or user data is sent to ad network
  const safeContext = getSafeAdTargetingContext();
  const hasZeroFinancialLeak = !('amount' in safeContext) &&
    !('balance' in safeContext) &&
    !('transactions' in safeContext) &&
    !('notes' in safeContext) &&
    !('userId' in safeContext);
  assert('AD-07: Strict privacy firewall guarantees zero financial or personal data is sent to ad network', hasZeroFinancialLeak);

  // AD-08: Glass-circle bottom navigation bar is unchanged and works exactly as before
  const hasGlassNav = bottomNavContent.includes('w-[50px] h-[50px] rounded-full') &&
    bottomNavContent.includes('backdrop-blur-md') &&
    !bottomNavContent.includes('Search');
  assert('AD-08: Glass-circle bottom navigation bar is unchanged, optical glass styling preserved, zero Search icons', hasGlassNav);

  // AD-09: INR-only formatting and Indian digit grouping (en-IN) are unchanged on Home screen
  const { formatMinorUnits } = await import('./finance-engine.ts');
  const formattedTest = formatMinorUnits(15000000, 'INR'); // ₹1,50,000.00
  const isIndianFormat = formattedTest.includes('₹') && formattedTest.includes('1,50,000');
  assert('AD-09: INR-only currency formatting with Indian digit grouping (en-IN) strictly preserved', isIndianFormat);

  // AD-10: Balance card, action buttons, and Settlement Overview content remain completely intact
  const hasAllCoreHomeSections = homeViewContent.includes('Actual Available Balance') &&
    homeViewContent.includes('Add Expense') &&
    homeViewContent.includes('Scan Receipt') &&
    homeViewContent.includes('Add Income') &&
    homeViewContent.includes('Settle Up') &&
    homeViewContent.includes('Settlement Overview & Roommate Balances') &&
    homeViewContent.includes('View Dues Matrix');
  assert('AD-10: Balance card, action buttons, and Settlement Overview content are fully preserved', hasAllCoreHomeSections);

  // ==========================================
  // CS-01 TO CS-08: SPLITO PRO FEATURES TEMPORARILY COMING SOON
  // ==========================================
  const profileViewContent = fs.readFileSync('src/components/views/ProfileView.tsx', 'utf-8');
  const subModalContent = fs.readFileSync('src/components/SubscriptionModal.tsx', 'utf-8');
  const insightsViewContent = fs.readFileSync('src/components/views/InsightsView.tsx', 'utf-8');
  const pdfModalContent = fs.readFileSync('src/components/PdfExportModal.tsx', 'utf-8');
  const rewardedModalContent = fs.readFileSync('src/components/RewardedAdModal.tsx', 'utf-8');
  const billingServiceContent = fs.readFileSync('src/lib/billing-service.ts', 'utf-8');

  // CS-01: Pro upgrade card displays "COMING SOON" badge / label
  const hasComingSoonBadge = profileViewContent.includes('COMING SOON') &&
    subModalContent.includes('COMING SOON');
  assert('CS-01: Pro upgrade card displays COMING SOON badge/label in Profile and Modal', hasComingSoonBadge);

  // CS-02: Supporting message states "Premium features are on their way. Subscription will be available soon."
  const hasSupportingMessage = profileViewContent.includes('Premium features are on their way. Subscription will be available soon.') &&
    subModalContent.includes('Premium features are on their way. Subscription will be available soon.');
  assert('CS-02: Supporting message explicitly communicates premium features are on their way', hasSupportingMessage);

  // CS-03: Monthly & yearly plan prices and 1-month free trial info are displayed for informational purposes
  const hasPricingDisplayed = subModalContent.includes('₹59 / month') &&
    subModalContent.includes('₹599 / year') &&
    subModalContent.includes('Includes 1-month free trial') &&
    profileViewContent.includes('₹59/month') &&
    profileViewContent.includes('₹599/year');
  assert('CS-03: Monthly & yearly plan prices and 1-month free trial info are preserved for informational display', hasPricingDisplayed);

  // CS-04: All subscribe/purchase actions are disabled (Monthly, Yearly, Start Free Trial, Upgrade to Pro, Continue to Payment)
  const isPurchaseBlockedInService = billingServiceContent.includes('export const IS_PRO_AVAILABLE_FOR_PURCHASE = false;');
  const isButtonDisabledInModal = subModalContent.includes('disabled={true}') &&
    subModalContent.includes('Coming Soon (Purchases Disabled)');
  
  let purchaseAttemptBlocked = false;
  try {
    await startProTrial('test_user', 'monthly', true);
  } catch (err: any) {
    if (err?.message?.includes('temporarily coming soon')) {
      purchaseAttemptBlocked = true;
    }
  }
  assert('CS-04: All subscribe/purchase actions are disabled and protected by service-level gate',
    isPurchaseBlockedInService && isButtonDisabledInModal && purchaseAttemptBlocked);

  // CS-05: Tapping any Pro upgrade entry point displays a Coming Soon explanation with simple Close/OK action
  const hasComingSoonExplanationAndClose = subModalContent.includes('SPLITO Pro is Coming Soon') &&
    subModalContent.includes('variant="primary"') &&
    subModalContent.includes('Close') &&
    profileViewContent.includes('Coming Soon');
  assert('CS-05: Pro upgrade entry points route to informational Coming Soon modal with clean Close action', hasComingSoonExplanationAndClose);

  // CS-06: Pro-only features show a "COMING SOON" badge / indicator
  const hasProFeaturesComingSoonBadges = insightsViewContent.includes('SPLITO Pro Features') &&
    insightsViewContent.includes('Advanced Reports & Insights') &&
    insightsViewContent.includes('Money Timeline') &&
    insightsViewContent.includes('Spending Guard') &&
    insightsViewContent.includes('Advanced Exports') &&
    pdfModalContent.includes('Ad-Free Export Coming Soon') &&
    rewardedModalContent.includes('SPLITO Pro (Coming Soon)');
  assert('CS-06: Pro-only features (Reports, Timeline, Guard, Exports, Ad-Free) show visible COMING SOON badges', hasProFeaturesComingSoonBadges);

  // CS-07: Free features (spaces, expenses, settlements, smart settlement, balances, reports, search, delete) work normally
  const { calculateDebtSettlements, calculateActualBalance } = await import('./finance-engine.ts');
  const dummyBalances = [
    {
      memberId: 'm1',
      memberName: 'User A',
      totalPaidMinorUnits: 10000,
      totalOwedMinorUnits: 5000,
      netBalanceMinorUnits: 5000,
      totalExpenseShareMinorUnits: 5000,
      totalExpensePaidMinorUnits: 10000,
      totalSettlementPaidMinorUnits: 0,
      totalSettlementReceivedMinorUnits: 0
    },
    {
      memberId: 'm2',
      memberName: 'User B',
      totalPaidMinorUnits: 0,
      totalOwedMinorUnits: 5000,
      netBalanceMinorUnits: -5000,
      totalExpenseShareMinorUnits: 5000,
      totalExpensePaidMinorUnits: 0,
      totalSettlementPaidMinorUnits: 0,
      totalSettlementReceivedMinorUnits: 0
    }
  ];
  const settlements = calculateDebtSettlements(dummyBalances);
  const actualBal = calculateActualBalance({
    startingBalance: 50000,
    paidExpenses: 0,
    receivedIncome: 0,
    incomingTransfers: 0,
    outgoingTransfers: 0
  });
  assert('CS-07: All Free core ledger features (settlements, balances, calculation engines) continue working 100%',
    settlements.length === 1 && settlements[0].amountMinorUnits === 5000 && actualBal.actualBalance === 50000);

  // CS-08: Free user advertising (Home feed inline ads, end-of-list ad, permanent ad near settlement, PDF export rewarded ad) continues working normally
  const freeAdsActive = shouldShowAds(false);
  const hasAllAdPlacements = homeViewContent.includes('placement="inline"') &&
    homeViewContent.includes('placement="permanent"') &&
    homeViewContent.includes('placement="end-of-list"') &&
    rewardedModalContent.includes('AdMob Test Unit');
  assert('CS-08: Free user advertising (inline feed ads, end-of-list, permanent, rewarded) continues working normally',
    freeAdsActive && hasAllAdPlacements);

  // ==========================================
  // SC-01 TO SC-08: SCAN RECEIPT → COMING SOON
  // ==========================================
  const receiptCaptureModalContent = fs.readFileSync('src/components/ReceiptCaptureModal.tsx', 'utf-8');
  const transactionsViewContent = fs.readFileSync('src/components/views/TransactionsView.tsx', 'utf-8');
  const txModalContent = fs.readFileSync('src/components/TransactionModal.tsx', 'utf-8');
  const indexCssContent = fs.readFileSync('src/index.css', 'utf-8');
  const { IS_SCAN_RECEIPT_AVAILABLE } = await import('./scan-service.ts');

  // SC-01: Scan Receipt button shows a visible COMING SOON badge
  const hasHomeScanBadge = homeViewContent.includes('Scan Receipt') &&
    homeViewContent.includes('bg-amber-100 text-amber-800 border border-amber-300') &&
    homeViewContent.includes('COMING SOON');
  assert('SC-01: Scan Receipt button on Home screen displays a visible COMING SOON badge', hasHomeScanBadge);

  // SC-02: Tapping Scan Receipt opens the informational Coming Soon modal with a Close button only; no camera, no OCR, no API call
  const isComingSoonModalOnly = receiptCaptureModalContent.includes('Receipt Scanning is Coming Soon') &&
    receiptCaptureModalContent.includes('Close') &&
    !receiptCaptureModalContent.includes('type="file"') &&
    !receiptCaptureModalContent.includes('<input');
  assert('SC-02: Modal is purely informational with a Close button only; zero camera or file input elements', isComingSoonModalOnly);

  // SC-03: No API key prompt, no error, and no simulated scan result appears
  const hasZeroSimulatedReceipts = !receiptCaptureModalContent.includes('sampleReceipts') &&
    !receiptCaptureModalContent.includes('simulateScan') &&
    !receiptCaptureModalContent.includes('D-Mart Supermarket') &&
    !receiptCaptureModalContent.includes('Apollo Pharmacy');
  assert('SC-03: Hardcoded/simulated receipt scans, sample slips, and API key prompts are completely removed', hasZeroSimulatedReceipts);

  // SC-04: Every Scan Receipt entry point (Home, Ledger, and TransactionModal) shows Coming Soon and never initiates a scan
  const allEntryPointsGated = IS_SCAN_RECEIPT_AVAILABLE === false &&
    transactionsViewContent.includes('SOON') &&
    txModalContent.includes('COMING SOON');
  assert('SC-04: Every Scan Receipt entry point displays Coming Soon and IS_SCAN_RECEIPT_AVAILABLE is false', allEntryPointsGated);

  // SC-05: Add Expense, Add Income and Settle Up still work normally
  const otherActionButtonsPreserved = homeViewContent.includes('Add Expense') &&
    homeViewContent.includes('Add Income') &&
    homeViewContent.includes('Settle Up');
  assert('SC-05: Add Expense, Add Income and Settle Up actions on Home screen remain 100% active and preserved', otherActionButtonsPreserved);

  // SC-06: Home feed ads, end-of-feed ad, Settlement Overview ad and rewarded PDF ad still work
  const adsPreserved = freeAdsActive &&
    homeViewContent.includes('placement="inline"') &&
    homeViewContent.includes('placement="end-of-list"') &&
    homeViewContent.includes('placement="permanent"') &&
    rewardedModalContent.includes('AdMob Test Unit');
  assert('SC-06: Home feed inline ads, end-of-list ad, permanent ad and rewarded PDF export ads remain active', adsPreserved);

  // SC-07: Pro Coming Soon, seven legal pages, consent, Delete My Entries & Data and account deletion are unchanged
  const featuresPreserved = profileViewContent.includes('SPLITO Subscription') &&
    profileViewContent.includes('Delete My Entries & Data') &&
    profileViewContent.includes('Delete Account') &&
    profileViewContent.includes('Legal, Terms & Consumer Disclosures') &&
    subModalContent.includes('COMING SOON');
  assert('SC-07: Pro Coming Soon status, 7 legal pages, Delete My Entries & Data and Account Deletion are unchanged', featuresPreserved);

  // SC-08: Glass-circle navigation, INR-only formatting and tabular-number typography are intact on all amounts
  const typographyPreserved = bottomNavContent.includes('w-[50px] h-[50px] rounded-full') &&
    indexCssContent.includes('tabular-nums') &&
    indexCssContent.includes('"tnum" 1');
  assert('SC-08: Glass-circle 50px navigation, INR-only currency (₹) and tabular font stack remain intact', typographyPreserved);

  console.log(`\nSPLITO Monetization, Legal, Coming Soon & Scan Receipt Test Summary: ${passed}/${total} passed.`);
  return passed === total;
}

runMonetizationTests();


