/**
 * SPLITO Billing & Subscription Service
 * Master Specification v1.5
 * 
 * Rules:
 * 1. Pro plan: ₹59/month or ₹599/year with 1-month (30 days) free trial.
 * 2. Never grant permanent Pro access from ephemeral frontend flags alone.
 * 3. Enforce trial expiration and period end timestamps.
 * 4. Google Play Billing integration architecture prepared for Android releases.
 * 5. Offline resilience: cached state validated against time bounds.
 */

import {
  UserSubscription,
  SubscriptionEntitlement,
  SubscriptionBillingCycle,
  SUBSCRIPTION_PRICING
} from '../types/subscription.ts';
import { db } from './firebase.ts';
import { doc, getDoc, setDoc } from 'firebase/firestore';

const STORAGE_KEY_SUBSCRIPTION = 'splito_user_subscription';

// Temporary Product Decision: SPLITO Pro is Coming Soon; Google Play Billing products not yet configured
export const IS_PRO_AVAILABLE_FOR_PURCHASE = false;

export const DEFAULT_FREE_SUBSCRIPTION: UserSubscription = {
  plan: 'free',
  status: 'none',
  autoRenew: false,
  updatedAt: new Date().toISOString()
};

/**
 * Derives user entitlements based on current subscription state and time.
 */
export function calculateEntitlement(subscription: UserSubscription | null): SubscriptionEntitlement {
  if (!subscription || subscription.plan === 'free') {
    return {
      isPro: false,
      plan: 'free',
      status: subscription?.status || 'none',
      statusLabel: 'SPLITO Free',
      canExportPdfWithoutAds: false,
      hasAdvancedAnalytics: false,
      hasAdvancedSpendingGuard: false,
      hasExtendedExports: false,
      isAdFree: false
    };
  }

  const now = Date.now();

  // Handle Trial
  if (subscription.status === 'trial') {
    const trialEnd = subscription.trialEndDate ? new Date(subscription.trialEndDate).getTime() : 0;
    if (trialEnd > now) {
      const daysRemaining = Math.max(1, Math.ceil((trialEnd - now) / (1000 * 60 * 60 * 24)));
      const expiresAtFormatted = new Date(trialEnd).toLocaleDateString('en-IN', {
        day: 'numeric',
        month: 'short',
        year: 'numeric'
      });

      return {
        isPro: true,
        plan: 'pro',
        status: 'trial',
        statusLabel: `SPLITO Pro (Free Trial - ${daysRemaining}d left)`,
        daysRemainingInTrial: daysRemaining,
        expiresAtFormatted,
        canExportPdfWithoutAds: true,
        hasAdvancedAnalytics: true,
        hasAdvancedSpendingGuard: true,
        hasExtendedExports: true,
        isAdFree: true
      };
    } else {
      // Trial expired without active renewal
      return {
        isPro: false,
        plan: 'free',
        status: 'expired',
        statusLabel: 'Trial Expired (Reverted to Free)',
        canExportPdfWithoutAds: false,
        hasAdvancedAnalytics: false,
        hasAdvancedSpendingGuard: false,
        hasExtendedExports: false,
        isAdFree: false
      };
    }
  }

  // Handle Active or Cancelled with remaining period
  if (subscription.status === 'active' || subscription.status === 'cancelled') {
    const periodEnd = subscription.currentPeriodEnd ? new Date(subscription.currentPeriodEnd).getTime() : 0;
    const isWithinPeriod = periodEnd > now;

    if (isWithinPeriod) {
      const expiresAtFormatted = new Date(periodEnd).toLocaleDateString('en-IN', {
        day: 'numeric',
        month: 'short',
        year: 'numeric'
      });

      return {
        isPro: true,
        plan: 'pro',
        status: subscription.status,
        statusLabel: subscription.status === 'cancelled'
          ? `SPLITO Pro (Cancels on ${expiresAtFormatted})`
          : 'SPLITO Pro Active',
        expiresAtFormatted,
        canExportPdfWithoutAds: true,
        hasAdvancedAnalytics: true,
        hasAdvancedSpendingGuard: true,
        hasExtendedExports: true,
        isAdFree: true
      };
    } else {
      // Period expired
      return {
        isPro: false,
        plan: 'free',
        status: 'expired',
        statusLabel: 'SPLITO Free (Subscription Expired)',
        canExportPdfWithoutAds: false,
        hasAdvancedAnalytics: false,
        hasAdvancedSpendingGuard: false,
        hasExtendedExports: false,
        isAdFree: false
      };
    }
  }

  // Default fallback
  return {
    isPro: false,
    plan: 'free',
    status: subscription.status,
    statusLabel: 'SPLITO Free',
    canExportPdfWithoutAds: false,
    hasAdvancedAnalytics: false,
    hasAdvancedSpendingGuard: false,
    hasExtendedExports: false,
    isAdFree: false
  };
}

/**
 * Loads cached subscription from localStorage
 */
export function getLocalSubscription(userId?: string): UserSubscription {
  try {
    const key = userId ? `${STORAGE_KEY_SUBSCRIPTION}_${userId}` : STORAGE_KEY_SUBSCRIPTION;
    const raw = localStorage.getItem(key);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (err) {
    console.warn('Failed to parse local subscription cache:', err);
  }
  return DEFAULT_FREE_SUBSCRIPTION;
}

/**
 * Saves subscription locally
 */
export function saveLocalSubscription(subscription: UserSubscription, userId?: string): void {
  try {
    const key = userId ? `${STORAGE_KEY_SUBSCRIPTION}_${userId}` : STORAGE_KEY_SUBSCRIPTION;
    localStorage.setItem(key, JSON.stringify(subscription));
  } catch (err) {
    console.warn('Failed to save local subscription cache:', err);
  }
}

/**
 * Fetches subscription from Firestore user profile
 */
export async function fetchUserSubscription(userId: string): Promise<UserSubscription> {
  try {
    if (!userId || userId.startsWith('guest_')) {
      return getLocalSubscription(userId);
    }

    const userDocRef = doc(db, 'users', userId);
    const snap = await getDoc(userDocRef);
    if (snap.exists() && snap.data()?.subscription) {
      const sub = snap.data().subscription as UserSubscription;
      saveLocalSubscription(sub, userId);
      return sub;
    }
  } catch (err) {
    console.warn('Could not fetch cloud subscription, using local cache:', err);
  }
  return getLocalSubscription(userId);
}

/**
 * Activates a 30-day Free Trial for SPLITO Pro with explicit user consent.
 */
export async function startProTrial(
  userId: string,
  billingCycle: SubscriptionBillingCycle,
  consentConfirmed: boolean
): Promise<{ success: boolean; subscription: UserSubscription; message: string }> {
  if (!IS_PRO_AVAILABLE_FOR_PURCHASE) {
    throw new Error('SPLITO Pro subscriptions are temporarily coming soon. Purchases and free trials will be available upon official launch.');
  }

  if (!consentConfirmed) {
    throw new Error('Explicit consent is required to start the SPLITO Pro free trial.');
  }

  const now = new Date();
  const trialEnd = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000); // 30 days
  const pricing = SUBSCRIPTION_PRICING[billingCycle];

  const newSubscription: UserSubscription = {
    plan: 'pro',
    status: 'trial',
    billingCycle,
    trialStartDate: now.toISOString(),
    trialEndDate: trialEnd.toISOString(),
    currentPeriodStart: now.toISOString(),
    currentPeriodEnd: trialEnd.toISOString(),
    autoRenew: true,
    paymentGateway: 'google_play',
    orderId: `trial_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`,
    updatedAt: now.toISOString()
  };

  saveLocalSubscription(newSubscription, userId);

  // Sync to Firestore if authenticated user
  if (userId && !userId.startsWith('guest_')) {
    try {
      const userDocRef = doc(db, 'users', userId);
      await setDoc(userDocRef, { subscription: newSubscription }, { merge: true });
    } catch (err) {
      console.warn('Saved trial locally, Firestore sync pending:', err);
    }
  }

  return {
    success: true,
    subscription: newSubscription,
    message: `SPLITO Pro 1-Month Free Trial activated! You will not be charged until ${trialEnd.toLocaleDateString('en-IN')}. Price afterwards is ${pricing.formattedPrice}/${pricing.interval}.`
  };
}

/**
 * Cancels auto-renewal of subscription while keeping benefits until the end of current period.
 */
export async function cancelProSubscription(
  userId: string
): Promise<{ success: boolean; subscription: UserSubscription; message: string }> {
  const current = getLocalSubscription(userId);
  if (current.plan !== 'pro') {
    throw new Error('No active SPLITO Pro subscription found to cancel.');
  }

  const now = new Date().toISOString();
  const updatedSubscription: UserSubscription = {
    ...current,
    status: 'cancelled',
    autoRenew: false,
    cancelledAt: now,
    updatedAt: now
  };

  saveLocalSubscription(updatedSubscription, userId);

  if (userId && !userId.startsWith('guest_')) {
    try {
      const userDocRef = doc(db, 'users', userId);
      await setDoc(userDocRef, { subscription: updatedSubscription }, { merge: true });
    } catch (err) {
      console.warn('Saved cancellation locally, Firestore sync pending:', err);
    }
  }

  const expiry = updatedSubscription.currentPeriodEnd
    ? new Date(updatedSubscription.currentPeriodEnd).toLocaleDateString('en-IN')
    : 'the end of your billing cycle';

  return {
    success: true,
    subscription: updatedSubscription,
    message: `Subscription auto-renewal cancelled. You will continue to enjoy SPLITO Pro features until ${expiry} without further charges.`
  };
}

/**
 * Restores purchases from Cloud / Google Play
 */
export async function restorePurchases(
  userId: string
): Promise<{ success: boolean; subscription: UserSubscription; message: string }> {
  if (userId && !userId.startsWith('guest_')) {
    try {
      const sub = await fetchUserSubscription(userId);
      const entitlement = calculateEntitlement(sub);
      if (entitlement.isPro) {
        return {
          success: true,
          subscription: sub,
          message: `Purchases restored! Active plan: ${entitlement.statusLabel}.`
        };
      }
    } catch (err) {
      console.warn('Restore error:', err);
    }
  }

  const local = getLocalSubscription(userId);
  const ent = calculateEntitlement(local);
  if (ent.isPro) {
    return {
      success: true,
      subscription: local,
      message: `Purchases restored from device backup! Active plan: ${ent.statusLabel}.`
    };
  }

  return {
    success: false,
    subscription: DEFAULT_FREE_SUBSCRIPTION,
    message: 'No previous active subscription found for this account. If you subscribed via Google Play, please check your Google Play account.'
  };
}
