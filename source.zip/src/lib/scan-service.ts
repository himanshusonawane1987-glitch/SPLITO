/**
 * SPLITO Scan Receipt Service
 * Feature Availability Flag & Configuration
 */

// Temporary Product Decision: Scan Receipt OCR service is Coming Soon.
// External OCR / Vision API credentials are not configured.
// All receipt scanning entry points are gated behind an informational Coming Soon state.
export const IS_SCAN_RECEIPT_AVAILABLE = false;
