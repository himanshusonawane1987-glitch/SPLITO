/**
 * SPLITO — Deterministic Conflict Resolution (Section 2J)
 * 
 * Policy: Latest Edit Wins
 * Rules:
 * 1. Monotonically increasing version metadata per entity.
 * 2. Deterministic tie-breaking using ISO timestamps and server metadata.
 * 3. Never silently discard conflicting data.
 * 4. Older queued operations cannot overwrite newer local or server edits.
 */

export interface VersionedEntity {
  id: string;
  version?: number;
  updatedAt?: string;
  createdAt?: string;
  [key: string]: any;
}

export type ConflictResolutionResult<T> = {
  winner: 'local' | 'server' | 'merged';
  resolvedEntity: T;
  hasConflict: boolean;
  reason: string;
};

/**
 * Resolves conflict between a local entity and a server entity using Latest Edit Wins.
 */
export function resolveEntityConflict<T extends VersionedEntity>(
  localEntity: T,
  serverEntity: T | null | undefined
): ConflictResolutionResult<T> {
  // If no server entity exists, local version is the unquestioned winner
  if (!serverEntity) {
    return {
      winner: 'local',
      resolvedEntity: localEntity,
      hasConflict: false,
      reason: 'No existing server entity found. Local version accepted.'
    };
  }

  const localVersion = typeof localEntity.version === 'number' ? localEntity.version : 1;
  const serverVersion = typeof serverEntity.version === 'number' ? serverEntity.version : 1;

  // 1. Explicit version comparison
  if (localVersion > serverVersion) {
    return {
      winner: 'local',
      resolvedEntity: { ...localEntity, version: localVersion },
      hasConflict: true,
      reason: `Local version (${localVersion}) is newer than server version (${serverVersion}).`
    };
  }

  if (serverVersion > localVersion) {
    return {
      winner: 'server',
      resolvedEntity: { ...serverEntity, version: serverVersion },
      hasConflict: true,
      reason: `Server version (${serverVersion}) is newer than local version (${localVersion}).`
    };
  }

  // 2. Versions equal: compare updatedAt timestamps
  const localTime = localEntity.updatedAt ? new Date(localEntity.updatedAt).getTime() : 0;
  const serverTime = serverEntity.updatedAt ? new Date(serverEntity.updatedAt).getTime() : 0;

  if (localTime > serverTime) {
    return {
      winner: 'local',
      resolvedEntity: { ...localEntity, version: localVersion + 1 },
      hasConflict: true,
      reason: 'Local timestamp is more recent than server record.'
    };
  }

  if (serverTime > localTime) {
    return {
      winner: 'server',
      resolvedEntity: { ...serverEntity, version: serverVersion },
      hasConflict: true,
      reason: 'Server timestamp is more recent than local edit.'
    };
  }

  // 3. Exact tie: merge non-conflicting fields, retaining local user input for modified values
  const merged = {
    ...serverEntity,
    ...localEntity,
    version: Math.max(localVersion, serverVersion) + 1,
    updatedAt: new Date().toISOString()
  };

  return {
    winner: 'merged',
    resolvedEntity: merged,
    hasConflict: false,
    reason: 'Identical timestamps and versions; safely reconciled non-conflicting fields.'
  };
}
