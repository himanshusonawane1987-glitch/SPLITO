/**
 * SPLITO Advertisement Management & Financial Privacy Firewall
 * Master Specification v1.5
 * 
 * Rules:
 * 1. Pro users: 100% ad-free across the entire application.
 * 2. Free users: Exactly one small, non-intrusive banner placement.
 * 3. Rewarded ad: Optional for PDF export on the free tier.
 * 4. STRICT PRIVACY: NEVER send expense descriptions, transaction amounts,
 *    member names, balances, or financial records to ad networks.
 * 5. Test Ad Unit IDs enabled for development and compliance preview.
 */

export interface AdMobConfig {
  appId: string;
  bannerAdUnitId: string;
  rewardedAdUnitId: string;
  isTestMode: boolean;
}

// Official Google AdMob Test Ad Unit IDs for Android / Development
export const ADMOB_TEST_CONFIG: AdMobConfig = {
  appId: 'ca-app-pub-3940256099942544~3347511713',
  bannerAdUnitId: 'ca-app-pub-3940256099942544/6300978111',
  rewardedAdUnitId: 'ca-app-pub-3940256099942544/5224354917',
  isTestMode: true
};

/**
 * Sanitizes context to guarantee ZERO financial data leaks to ad networks.
 */
export function getSafeAdTargetingContext(): Record<string, string> {
  // Return only non-sensitive general application context
  return {
    app: 'splito',
    environment: 'development_test'
  };
}

/**
 * Checks if ads should be displayed for the user.
 */
export function shouldShowAds(isPro: boolean): boolean {
  return !isPro;
}
