import { initializeApp } from 'firebase/app';
import {
  getAuth,
  initializeAuth,
  indexedDBLocalPersistence,
  browserLocalPersistence,
  GoogleAuthProvider,
  signInWithPopup,
  signInWithCredential,
  signOut as firebaseSignOut,
  onAuthStateChanged,
  User as FirebaseUser
} from 'firebase/auth';
import {
  initializeFirestore,
  getFirestore,
  persistentLocalCache,
  persistentMultipleTabManager,
  doc,
  getDocFromServer
} from 'firebase/firestore';
import { Capacitor } from '@capacitor/core';
import { FirebaseAuthentication } from '@capacitor-firebase/authentication';
import firebaseConfig from '../../firebase-applet-config.json';

const app = initializeApp(firebaseConfig);

let firestoreInstance: ReturnType<typeof getFirestore>;
try {
  firestoreInstance = initializeFirestore(
    app,
    {
      localCache: persistentLocalCache({
        tabManager: persistentMultipleTabManager()
      })
    },
    firebaseConfig.firestoreDatabaseId
  );
} catch {
  // Safe fallback if Firestore was already initialized
  firestoreInstance = getFirestore(app, firebaseConfig.firestoreDatabaseId);
}

export const db = firestoreInstance;

let authInstance: ReturnType<typeof getAuth>;
try {
  if (Capacitor.isNativePlatform()) {
    authInstance = initializeAuth(app, {
      persistence: [indexedDBLocalPersistence, browserLocalPersistence]
    });
  } else {
    authInstance = getAuth(app);
  }
} catch {
  authInstance = getAuth(app);
}

export const auth = authInstance;
export const googleProvider = new GoogleAuthProvider();

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map((provider) => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export async function testConnection(): Promise<boolean> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    return true;
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn('Firebase client is offline or starting up.');
    }
    return false;
  }
}

/**
 * Platform-aware Google Sign-In:
 * - Native Capacitor Android: Invokes native Google sign-in via @capacitor-firebase/authentication,
 *   retrieves the Google ID token, converts it into a Firebase credential, and signs into the
 *   Firebase JS SDK with signInWithCredential.
 * - Browser: Uses standard compatible signInWithPopup.
 */
export async function loginWithGoogle(): Promise<FirebaseUser | null> {
  try {
    if (Capacitor.isNativePlatform()) {
      // 1. Invoke native Capacitor Google Sign-in flow
      const result = await FirebaseAuthentication.signInWithGoogle();

      // 2. Retrieve returned Google ID token
      const idToken = result.credential?.idToken;
      if (!idToken) {
        throw new Error('Native Google sign-in failed: No ID token returned from Google Play Services.');
      }

      // 3. Construct GoogleAuthProvider credential
      const credential = GoogleAuthProvider.credential(idToken);

      // 4. Authenticate Firebase JavaScript SDK using signInWithCredential
      const userCredential = await signInWithCredential(auth, credential);

      // 5. Confirm resulting Firebase JS auth.currentUser
      return userCredential.user;
    } else {
      // Browser preview: compatible web popup authentication
      const cred = await signInWithPopup(auth, googleProvider);
      return cred.user;
    }
  } catch (error) {
    console.error('Google Sign-in Error:', error);
    throw error;
  }
}

/**
 * Platform-aware Sign-Out:
 * Clears both the native authentication session (when on native) and the Firebase JS session.
 */
export async function logoutUser(): Promise<void> {
  try {
    if (Capacitor.isNativePlatform()) {
      try {
        await FirebaseAuthentication.signOut();
      } catch (nativeErr) {
        console.warn('Native FirebaseAuthentication sign-out notice:', nativeErr);
      }
    }
    await firebaseSignOut(auth);
  } catch (error) {
    console.error('Sign-out error:', error);
    throw error;
  }
}

export { onAuthStateChanged };
export type { FirebaseUser };
