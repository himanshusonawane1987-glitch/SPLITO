/**
 * SPLITO Wallet Pay — Unit and Integration Test Suite
 * Master Specification V1.0 (PART 17 & PART 18)
 * 
 * Verifies:
 * 1. Finance Engine status-aware filtering (Paid included, Pending & Failed excluded).
 * 2. Group dues and balance reconciliation with payment statuses.
 * 3. Category breakdowns exclusion of pending and failed entries.
 * 4. Split Engine: single-person split (100% to one), none, equal, percentage, custom.
 * 5. Storage Service normalizer preserves all new Wallet Pay fields.
 * 6. UPI URI Builder: RFC query parameter encoding, INR currency, note, transaction reference.
 * 7. VPA validation: blocks invalid or missing VPAs, prevents fake merchant VPA generation.
 * 8. Status transitions: Pending -> Paid, Failed -> Retry -> Paid without transaction duplication.
 * 9. Actual paid amount correction & split recalculation.
 * 10. In-flight transaction persistence in localStorage and crash-recovery restoration.
 * 11. Ledger filteredStats consistency with Home balances.
 * 12. Non-duplicate submission protections.
 */

import { describe, it } from 'node:test';
import assert from 'node:assert';
import {
  Space,
  Transaction,
  Member,
  SplitShare
} from '../types/finance.ts';
import {
  calculateSpaceLedgerBalance,
  calculateGroupBalances,
  calculateCategoryBreakdowns,
  getActiveLedgerTransactions,
  calculateSinglePersonSplit,
  calculateEqualSplits,
  calculatePercentageSplits,
  calculateCustomSplits
} from './finance-engine.ts';
import { normalizeTransactionPayload } from './storage-service.ts';
import {
  buildUpiPaymentUri,
  buildTargetedUpiUri,
  isValidVpa,
  formatMinorUnitsToRupees,
  saveInFlightPayment,
  getInFlightPayment,
  clearInFlightPayment,
  KNOWN_UPI_APPS
} from './upi-service.ts';

// Mock localStorage if in pure Node environment
const mockStorage: Record<string, string> = {};
if (typeof globalThis.localStorage === 'undefined') {
  (globalThis as any).localStorage = {
    getItem: (k: string) => mockStorage[k] ?? null,
    setItem: (k: string, v: string) => { mockStorage[k] = String(v); },
    removeItem: (k: string) => { delete mockStorage[k]; },
    clear: () => {
      for (const key of Object.keys(mockStorage)) {
        delete mockStorage[key];
      }
    }
  };
}

describe('SPLITO Wallet Pay — Finance Engine Status-Aware Filtering', () => {
  const sampleSpace: Space = {
    id: 'space_hal',
    ownerId: 'user_1',
    name: 'HAL Roommates',
    mode: 'roommates',
    currency: 'INR',
    startingBalance: 0,
    memberIds: ['user_1', 'user_2', 'user_3'],
    members: [
      { id: 'user_1', name: 'Aman', role: 'owner' },
      { id: 'user_2', name: 'Rohan', role: 'member' },
      { id: 'user_3', name: 'Sameer', role: 'member' }
    ],
    createdAt: '2026-01-01T00:00:00.000Z',
    updatedAt: '2026-01-01T00:00:00.000Z'
  };

  const sampleMembers: Member[] = sampleSpace.members;

  it('1. Existing historic transactions without paymentStatus default to Paid and affect balances', () => {
    const historicTx: Transaction = {
      id: 'tx_hist_1',
      spaceId: 'space_hal',
      creatorId: 'user_1',
      title: 'Monthly Rent',
      type: 'expense',
      category: 'Rent',
      amount: 1500000, // ₹15,000.00
      date: '2026-03-01',
      payerId: 'user_1',
      splits: [
        { memberId: 'user_1', shareMinorUnits: 500000 },
        { memberId: 'user_2', shareMinorUnits: 500000 },
        { memberId: 'user_3', shareMinorUnits: 500000 }
      ],
      createdAt: '2026-03-01T10:00:00.000Z'
    };

    const activeList = getActiveLedgerTransactions([historicTx]);
    assert.strictEqual(activeList.length, 1, 'Historic transaction without paymentStatus must be included as active');

    const balance = calculateSpaceLedgerBalance(sampleSpace, [historicTx], 'user_1');
    assert.strictEqual(balance.paidExpenses, 1500000, 'Expense amount must be counted in balance');
  });

  it('2. Explicit Paid entries are included in balances and group dues', () => {
    const paidTx: Transaction = {
      id: 'tx_paid_1',
      spaceId: 'space_hal',
      creatorId: 'user_1',
      title: 'WiFi Bill',
      type: 'expense',
      category: 'WiFi & Cable',
      amount: 99900, // ₹999.00
      date: '2026-03-02',
      payerId: 'user_1',
      paymentStatus: 'paid',
      splits: [
        { memberId: 'user_1', shareMinorUnits: 33300 },
        { memberId: 'user_2', shareMinorUnits: 33300 },
        { memberId: 'user_3', shareMinorUnits: 33300 }
      ],
      createdAt: '2026-03-02T10:00:00.000Z'
    };

    const balance = calculateSpaceLedgerBalance(sampleSpace, [paidTx], 'user_1');
    assert.strictEqual(balance.paidExpenses, 99900, 'Explicit Paid entry must be included in balance');

    const groupDues = calculateGroupBalances(sampleMembers, [paidTx]);
    const payerDue = groupDues.find((m) => m.memberId === 'user_1');
    assert.strictEqual(payerDue?.netBalanceMinorUnits, 66600, 'Payer is owed ₹666.00 by roommates');
  });

  it('3. Pending entries are strictly excluded from balances and group dues', () => {
    const pendingTx: Transaction = {
      id: 'tx_pend_1',
      spaceId: 'space_hal',
      creatorId: 'user_1',
      title: 'Pending Grocery via GPay',
      type: 'expense',
      category: 'Groceries',
      amount: 45000, // ₹450.00
      date: '2026-03-03',
      payerId: 'user_1',
      paymentStatus: 'pending',
      splits: [
        { memberId: 'user_1', shareMinorUnits: 15000 },
        { memberId: 'user_2', shareMinorUnits: 15000 },
        { memberId: 'user_3', shareMinorUnits: 15000 }
      ],
      createdAt: '2026-03-03T10:00:00.000Z'
    };

    const activeList = getActiveLedgerTransactions([pendingTx]);
    assert.strictEqual(activeList.length, 0, 'Pending entry must be excluded from active ledger calculations');

    const balance = calculateSpaceLedgerBalance(sampleSpace, [pendingTx], 'user_1');
    assert.strictEqual(balance.paidExpenses, 0, 'Pending entry must not increment paid expenses');

    const groupDues = calculateGroupBalances(sampleMembers, [pendingTx]);
    const payerDue = groupDues.find((m) => m.memberId === 'user_1');
    assert.strictEqual(payerDue?.netBalanceMinorUnits, 0, 'Pending entry must not create group debt or dues');
  });

  it('4. Failed entries are strictly excluded from balances and group dues', () => {
    const failedTx: Transaction = {
      id: 'tx_fail_1',
      spaceId: 'space_hal',
      creatorId: 'user_1',
      title: 'Failed Payment for Snacks',
      type: 'expense',
      category: 'Snacks & Drinks',
      amount: 25000,
      date: '2026-03-03',
      payerId: 'user_1',
      paymentStatus: 'failed',
      splits: [
        { memberId: 'user_1', shareMinorUnits: 25000 }
      ],
      createdAt: '2026-03-03T11:00:00.000Z'
    };

    const activeList = getActiveLedgerTransactions([failedTx]);
    assert.strictEqual(activeList.length, 0, 'Failed entry must be excluded from active ledger');

    const balance = calculateSpaceLedgerBalance(sampleSpace, [failedTx], 'user_1');
    assert.strictEqual(balance.paidExpenses, 0, 'Failed entry must not affect balance');
  });

  it('5. Category breakdowns strictly exclude Pending and Failed transactions', () => {
    const txList: Transaction[] = [
      {
        id: 'tx_1',
        spaceId: 'space_hal',
        creatorId: 'user_1',
        title: 'Paid Groceries',
        type: 'expense',
        category: 'Groceries',
        amount: 100000, // ₹1,000
        date: '2026-03-04',
        payerId: 'user_1',
        paymentStatus: 'paid',
        createdAt: '2026-03-04T10:00:00.000Z'
      },
      {
        id: 'tx_2',
        spaceId: 'space_hal',
        creatorId: 'user_1',
        title: 'Pending Groceries',
        type: 'expense',
        category: 'Groceries',
        amount: 80000, // ₹800
        date: '2026-03-04',
        payerId: 'user_1',
        paymentStatus: 'pending',
        createdAt: '2026-03-04T10:05:00.000Z'
      },
      {
        id: 'tx_3',
        spaceId: 'space_hal',
        creatorId: 'user_1',
        title: 'Failed Groceries',
        type: 'expense',
        category: 'Groceries',
        amount: 50000, // ₹500
        date: '2026-03-04',
        payerId: 'user_1',
        paymentStatus: 'failed',
        createdAt: '2026-03-04T10:10:00.000Z'
      }
    ];

    const breakdowns = calculateCategoryBreakdowns(txList, 'expense');
    const groceryCat = breakdowns.find((c) => c.category === 'Groceries');
    assert.strictEqual(groceryCat?.amountMinorUnits, 100000, 'Category breakdown must only include ₹1,000 from Paid transaction');
    assert.strictEqual(groceryCat?.count, 1, 'Only 1 transaction counted');
  });
});

describe('SPLITO Wallet Pay — Split Configurations (Single Person, None, Equal, Pct, Custom)', () => {
  it('6. Single-person split assigns 100% of expense to exactly one selected member', () => {
    const total = 75000; // ₹750.00
    const targetMemberId = 'user_2'; // Rohan bears 100%

    const splits = calculateSinglePersonSplit(total, targetMemberId);
    assert.strictEqual(splits.length, 1, 'Single split produces exactly 1 share');
    assert.strictEqual(splits[0].memberId, 'user_2', 'Assigned to chosen member');
    assert.strictEqual(splits[0].shareMinorUnits, 75000, 'Share equals 100% of amount');
    assert.strictEqual(splits[0].percentage, 100, 'Percentage is 100%');
  });

  it('7. No Split (none) produces empty splits array and payer bears 100%', () => {
    // In SPLITO architecture, splitType: 'none' produces splits: [] and payer bears entire cost
    const noneSplits: SplitShare[] = [];
    assert.strictEqual(noneSplits.length, 0, 'None split has 0 split shares');
  });

  it('8. Equal splits always sum strictly to total using Largest Remainder (paise accurate)', () => {
    const total = 10000; // ₹100.00 across 3 roommates -> 3333, 3333, 3334
    const members = ['m1', 'm2', 'm3'];
    const splits = calculateEqualSplits(total, members);

    const sum = splits.reduce((acc, s) => acc + s.shareMinorUnits, 0);
    assert.strictEqual(sum, total, 'Sum must strictly equal 10000 paise');
    assert.strictEqual(splits[0].shareMinorUnits, 3334, 'First member gets remainder penny');
    assert.strictEqual(splits[1].shareMinorUnits, 3333);
    assert.strictEqual(splits[2].shareMinorUnits, 3333);
  });

  it('9. Percentage splits always sum strictly to total', () => {
    const total = 50000; // ₹500.00
    const input = [
      { memberId: 'm1', percentage: 50 },
      { memberId: 'm2', percentage: 25 },
      { memberId: 'm3', percentage: 25 }
    ];
    const splits = calculatePercentageSplits(total, input);
    const sum = splits.reduce((acc, s) => acc + s.shareMinorUnits, 0);
    assert.strictEqual(sum, total, 'Percentage split sum equals total');
    assert.strictEqual(splits[0].shareMinorUnits, 25000);
    assert.strictEqual(splits[1].shareMinorUnits, 12500);
    assert.strictEqual(splits[2].shareMinorUnits, 12500);
  });

  it('10. Custom splits adjust difference onto largest share', () => {
    const total = 10000;
    const input = [
      { memberId: 'm1', customMinorUnits: 6000 },
      { memberId: 'm2', customMinorUnits: 4000 }
    ];
    const splits = calculateCustomSplits(total, input);
    const sum = splits.reduce((acc, s) => acc + s.shareMinorUnits, 0);
    assert.strictEqual(sum, total, 'Custom split sum strictly equals total');
  });
});

describe('SPLITO Wallet Pay — Storage Normalizer & Payload Preservation', () => {
  it('11. normalizeTransactionPayload preserves paymentStatus, paymentApp, upiPayeeVpa and timing metadata', () => {
    const rawTx: Transaction = {
      id: 'tx_wallet_test_1',
      spaceId: 'sp_1',
      creatorId: 'usr_1',
      title: 'Electricity Bill via PhonePe',
      type: 'expense',
      category: 'Electricity',
      amount: 184000, // ₹1,840.00
      date: '2026-03-05',
      payerId: 'usr_1',
      paymentMethod: 'UPI',
      paymentStatus: 'pending',
      paymentApp: 'com.phonepe.app',
      paymentAppLabel: 'PhonePe',
      upiPayeeVpa: 'bescom@sbi',
      upiPayeeName: 'BESCOM Bangalore',
      paymentAttemptedAt: '2026-03-05T14:30:00.000Z',
      createdAt: '2026-03-05T14:30:00.000Z'
    };

    const normalized = normalizeTransactionPayload(rawTx);

    assert.strictEqual(normalized.paymentStatus, 'pending');
    assert.strictEqual(normalized.paymentApp, 'com.phonepe.app');
    assert.strictEqual(normalized.paymentAppLabel, 'PhonePe');
    assert.strictEqual(normalized.upiPayeeVpa, 'bescom@sbi');
    assert.strictEqual(normalized.upiPayeeName, 'BESCOM Bangalore');
    assert.strictEqual(normalized.paymentAttemptedAt, '2026-03-05T14:30:00.000Z');
  });
});

describe('SPLITO Wallet Pay — UPI Service & URI Builder', () => {
  it('12. Valid UPI URI builder produces RFC-compliant parameters with INR and encoded values', () => {
    const result = buildUpiPaymentUri({
      vpa: 'rahul.sharma@okaxis',
      payeeName: 'Rahul Sharma',
      amountMinorUnits: 25050, // ₹250.50
      note: 'Dinner & Sweets',
      transactionRef: 'ref_12345'
    });

    assert.strictEqual(result.hasValidVpa, true);
    assert.notStrictEqual(result.uri, null);

    const uri = result.uri!;
    assert(uri.startsWith('upi://pay?'), 'Must start with upi://pay?');
    assert(uri.includes('pa=rahul.sharma%40okaxis') || uri.includes('pa=rahul.sharma@okaxis'), 'Contains encoded VPA');
    assert(uri.includes('am=250.50'), 'Amount must be formatted in rupees 250.50');
    assert(uri.includes('cu=INR'), 'Currency must be INR');
    assert(uri.includes('tr=ref_12345'), 'Transaction reference present');
  });

  it('13. Invalid or missing VPA returns null URI with clear guidance and never hardcodes fake VPA', () => {
    const resultMissing = buildUpiPaymentUri({
      vpa: '',
      payeeName: 'Merchant Shop',
      amountMinorUnits: 5000
    });

    assert.strictEqual(resultMissing.hasValidVpa, false);
    assert.strictEqual(resultMissing.uri, null, 'Must return null URI when VPA is missing');
    assert(resultMissing.message?.includes('scan the merchant QR code manually'), 'Guides user to manual QR scan');

    // Invalid format
    assert.strictEqual(isValidVpa('invalid_vpa_without_bank'), false);
    assert.strictEqual(isValidVpa('user@'), false);
    assert.strictEqual(isValidVpa('@sbi'), false);
    assert.strictEqual(isValidVpa('valid.user@okaxis'), true);
  });

  it('14. Format minor units to rupees correctly handles paise', () => {
    assert.strictEqual(formatMinorUnitsToRupees(100), '1.00');
    assert.strictEqual(formatMinorUnitsToRupees(5050), '50.50');
    assert.strictEqual(formatMinorUnitsToRupees(99), '0.99');
    assert.strictEqual(formatMinorUnitsToRupees(0), '0.00');
  });

  it('15. Known UPI apps registry contains all 6 required apps plus generic fallback', () => {
    const appIds = KNOWN_UPI_APPS.map((a) => a.id);
    assert(appIds.includes('gpay'), 'Google Pay included');
    assert(appIds.includes('phonepe'), 'PhonePe included');
    assert(appIds.includes('paytm'), 'Paytm included');
    assert(appIds.includes('amazonpay'), 'Amazon Pay included');
    assert(appIds.includes('bhim'), 'BHIM included');
    assert(appIds.includes('whatsapp'), 'WhatsApp Pay included');
    assert(appIds.includes('other'), 'Other fallback included');

    // Test targeted deep-link and intent URIs for direct app routing
    const baseUri = 'upi://pay?pa=test%40upi&pn=Test&am=100.00&cu=INR';

    const phonepeApp = KNOWN_UPI_APPS.find((a) => a.id === 'phonepe')!;
    const phonepeTargeted = buildTargetedUpiUri(phonepeApp, baseUri);
    assert(phonepeTargeted.customSchemeUri?.startsWith('phonepe://pay?'), 'PhonePe custom scheme');
    assert(phonepeTargeted.intentUri?.includes('package=com.phonepe.app'), 'PhonePe explicit package intent');

    const paytmApp = KNOWN_UPI_APPS.find((a) => a.id === 'paytm')!;
    const paytmTargeted = buildTargetedUpiUri(paytmApp, baseUri);
    assert(paytmTargeted.customSchemeUri?.startsWith('paytmmp://pay?'), 'Paytm custom scheme');
    assert(paytmTargeted.intentUri?.includes('package=net.one97.paytm'), 'Paytm explicit package intent');

    const gpayApp = KNOWN_UPI_APPS.find((a) => a.id === 'gpay')!;
    const gpayTargeted = buildTargetedUpiUri(gpayApp, baseUri);
    assert(gpayTargeted.customSchemeUri?.startsWith('tez://upi/pay?'), 'GPay custom scheme (Tez)');
    assert(gpayTargeted.intentUri?.includes('package=com.google.android.apps.nbu.paisa.user'), 'GPay explicit package intent');

    const bhimApp = KNOWN_UPI_APPS.find((a) => a.id === 'bhim')!;
    const bhimTargeted = buildTargetedUpiUri(bhimApp, baseUri);
    assert(bhimTargeted.intentUri?.includes('package=in.org.npci.upiapp'), 'BHIM explicit package intent');

    const otherApp = KNOWN_UPI_APPS.find((a) => a.id === 'other')!;
    const otherTargeted = buildTargetedUpiUri(otherApp, baseUri);
    assert.strictEqual(otherTargeted.customSchemeUri, null, 'Other app has no custom scheme');
    assert.strictEqual(otherTargeted.intentUri, null, 'Other app has no explicit package');
    assert.strictEqual(otherTargeted.fallbackUri, baseUri, 'Other app falls back to standard upi:// URI');
  });
});

describe('SPLITO Wallet Pay — Lifecycle & State Transitions', () => {
  it('16. Pending -> Paid updates original transaction without duplication', () => {
    const originalTx: Transaction = {
      id: 'tx_flow_1',
      spaceId: 'sp_flow',
      creatorId: 'u1',
      title: 'Cafe Coffee Day',
      type: 'expense',
      category: 'Snacks & Drinks',
      amount: 32000,
      date: '2026-03-05',
      payerId: 'u1',
      paymentStatus: 'pending',
      createdAt: '2026-03-05T15:00:00.000Z'
    };

    // User confirms Paid
    const updatedTx: Transaction = {
      ...originalTx,
      paymentStatus: 'paid',
      paymentConfirmedAt: '2026-03-05T15:02:00.000Z'
    };

    assert.strictEqual(updatedTx.id, originalTx.id, 'Transaction ID must remain identical');
    assert.strictEqual(updatedTx.paymentStatus, 'paid');
    assert.strictEqual(updatedTx.amount, 32000);
  });

  it('17. Failed -> Retry -> Paid retains original transaction identity', () => {
    const failedTx: Transaction = {
      id: 'tx_retry_1',
      spaceId: 'sp_flow',
      creatorId: 'u1',
      title: 'Auto Fare',
      type: 'expense',
      category: 'General',
      amount: 15000,
      date: '2026-03-05',
      payerId: 'u1',
      paymentStatus: 'failed',
      createdAt: '2026-03-05T16:00:00.000Z'
    };

    // User taps Pay Again -> Retrying sets to pending
    const retryTx: Transaction = {
      ...failedTx,
      paymentStatus: 'pending',
      paymentAttemptedAt: '2026-03-05T16:05:00.000Z'
    };

    // User confirms Paid
    const confirmedTx: Transaction = {
      ...retryTx,
      paymentStatus: 'paid',
      paymentConfirmedAt: '2026-03-05T16:06:00.000Z'
    };

    assert.strictEqual(confirmedTx.id, failedTx.id, 'Original ID strictly preserved throughout retry flow');
    assert.strictEqual(confirmedTx.paymentStatus, 'paid');
  });

  it('18. Actual paid amount correction updates transaction and recalculates splits', () => {
    const originalAmount = 2000; // ₹20.00
    const actualPaidAmount = 1800; // ₹18.00 (discount or rounding)
    const members = ['m1', 'm2'];

    // Original splits: 1000 each
    const originalSplits = calculateEqualSplits(originalAmount, members);
    assert.strictEqual(originalSplits[0].shareMinorUnits, 1000);

    // Recalculated splits: 900 each
    const correctedSplits = calculateEqualSplits(actualPaidAmount, members);
    assert.strictEqual(correctedSplits[0].shareMinorUnits, 900);
    assert.strictEqual(correctedSplits[1].shareMinorUnits, 900);
    assert.strictEqual(correctedSplits[0].shareMinorUnits + correctedSplits[1].shareMinorUnits, actualPaidAmount);
  });

  it('19. In-flight payment persistence in localStorage recovers safely across WebView restart', () => {
    clearInFlightPayment();
    assert.strictEqual(getInFlightPayment(), null);

    saveInFlightPayment({
      transactionId: 'tx_inflight_1',
      spaceId: 'sp_1',
      originalAmountMinorUnits: 5000,
      title: 'Test Fruit',
      payerId: 'u1',
      payeeVpa: 'fruit@upi',
      payeeName: 'Fruit Stall',
      paymentAppId: 'gpay',
      paymentAppLabel: 'Google Pay',
      timestamp: '2026-03-05T17:00:00.000Z'
    });

    const recovered = getInFlightPayment();
    assert.notStrictEqual(recovered, null);
    assert.strictEqual(recovered?.transactionId, 'tx_inflight_1');
    assert.strictEqual(recovered?.title, 'Test Fruit');
    assert.strictEqual(recovered?.paymentAppLabel, 'Google Pay');

    clearInFlightPayment();
    assert.strictEqual(getInFlightPayment(), null);
  });

  it('20. Ledger filteredStats consistency: pending and failed entries are excluded from totals', () => {
    const transactions: Transaction[] = [
      {
        id: 't1',
        spaceId: 'sp',
        creatorId: 'u',
        title: 'Paid Milk',
        type: 'expense',
        category: 'Groceries',
        amount: 6000, // ₹60
        date: '2026-03-05',
        payerId: 'u',
        paymentStatus: 'paid',
        createdAt: '2026-03-05T00:00:00.000Z'
      },
      {
        id: 't2',
        spaceId: 'sp',
        creatorId: 'u',
        title: 'Pending Bread',
        type: 'expense',
        category: 'Groceries',
        amount: 4000, // ₹40
        date: '2026-03-05',
        payerId: 'u',
        paymentStatus: 'pending',
        createdAt: '2026-03-05T00:00:00.000Z'
      },
      {
        id: 't3',
        spaceId: 'sp',
        creatorId: 'u',
        title: 'Failed Butter',
        type: 'expense',
        category: 'Groceries',
        amount: 5000, // ₹50
        date: '2026-03-05',
        payerId: 'u',
        paymentStatus: 'failed',
        createdAt: '2026-03-05T00:00:00.000Z'
      }
    ];

    // Compute stats using filteredStats formula
    let expenseTotal = 0;
    for (const tx of transactions) {
      if (!tx.isReversed && (!tx.paymentStatus || tx.paymentStatus === 'paid')) {
        if (tx.type === 'expense') expenseTotal += tx.amount;
      }
    }

    assert.strictEqual(expenseTotal, 6000, 'Ledger total must be exactly ₹60 (only Paid entry)');
  });
});
