import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildActiveLinkedAdvancesMap,
  buildAdvanceTransactionId,
  calculateCategoryBreakdowns,
  calculateDebtSettlements,
  calculateEnhancedExpenseSplits,
  calculateGroupBalances,
  calculateSpaceLedgerBalance,
  createCascadeReversalPlan,
  reconcileLinkedAdvanceTransactions,
  validateEnhancedExpenseSplits
} from './finance-engine.ts';
import { normalizeTransactionPayload } from './storage-service.ts';
import { buildPdfDocument } from './export-service.ts';
import { Member, Space, Transaction } from '../types/finance.ts';

const MEMBERS: Member[] = [
  { id: 'u_payer', name: 'Aarav', role: 'owner' },
  { id: 'u_purvesh', name: 'Purvesh', role: 'member' },
  { id: 'u_rahul', name: 'Rahul', role: 'member' },
  { id: 'u_neha', name: 'Neha', role: 'member' }
];

const MEMBER_NAMES: Record<string, string> = {
  u_payer: 'Aarav',
  u_purvesh: 'Purvesh',
  u_rahul: 'Rahul',
  u_neha: 'Neha'
};

const SPACE: Space = {
  id: 'space_trip',
  ownerId: 'u_payer',
  name: 'Goa Trip',
  mode: 'trip',
  currency: 'INR',
  startingBalance: 0,
  memberIds: MEMBERS.map((m) => m.id),
  members: MEMBERS,
  createdAt: '2026-01-01T00:00:00.000Z',
  updatedAt: '2026-01-01T00:00:00.000Z'
};

function hasUndefinedDeep(obj: unknown): boolean {
  if (obj === undefined) return true;
  if (obj === null || typeof obj !== 'object') return false;
  if (Array.isArray(obj)) {
    return obj.some((item) => hasUndefinedDeep(item));
  }
  return Object.values(obj as Record<string, unknown>).some((v) => hasUndefinedDeep(v));
}

function makeExpense(overrides: Partial<Transaction> = {}): Transaction {
  return {
    id: 'exp_100',
    spaceId: SPACE.id,
    creatorId: 'u_payer',
    title: 'Dinner at Beach Shack',
    type: 'expense',
    category: 'Food & Dining',
    amount: 12000, // ₹120.00
    date: '2026-04-10',
    payerId: 'u_payer',
    paymentMethod: 'UPI',
    splitType: 'equal',
    version: 1,
    createdAt: '2026-04-10T12:00:00.000Z',
    ...overrides
  };
}

// ============================================================================
// GROUP 1: Personal Item (Individual Share) Math
// ============================================================================
test('Group 1.1: Personal Item + Equal Split (₹120 total, ₹40 personal for Purvesh -> Purvesh ₹60, others ₹20)', () => {
  const validation = validateEnhancedExpenseSplits({
    totalMinorUnits: 12000,
    splitType: 'equal',
    payerId: 'u_payer',
    selectedMemberIds: ['u_payer', 'u_purvesh', 'u_rahul', 'u_neha'],
    personalItems: [{ id: 'pi_1', memberId: 'u_purvesh', label: 'Dessert', amountMinorUnits: 4000 }],
    currency: 'INR',
    memberNamesById: MEMBER_NAMES
  });

  assert.equal(validation.isValid, true);
  assert.equal(validation.result.totalPersonalMinorUnits, 4000);
  assert.equal(validation.result.sharedPoolMinorUnits, 8000);
  assert.equal(validation.result.allocatedMinorUnits, 12000);

  const byId = new Map(validation.result.splits.map((s) => [s.memberId, s]));
  assert.equal(byId.get('u_purvesh')?.shareMinorUnits, 6000);
  assert.equal(byId.get('u_purvesh')?.sharedMinorUnits, 2000);
  assert.equal(byId.get('u_purvesh')?.personalMinorUnits, 4000);
  assert.equal(byId.get('u_payer')?.shareMinorUnits, 2000);
  assert.equal(byId.get('u_rahul')?.shareMinorUnits, 2000);
  assert.equal(byId.get('u_neha')?.shareMinorUnits, 2000);
});

test('Group 1.2: Personal Item + Percentage Split distributes shared pool by % and adds personal exclusively', () => {
  // ₹200 total, ₹50 personal for Purvesh -> ₹150 shared pool split 50%/30%/20%
  const validation = validateEnhancedExpenseSplits({
    totalMinorUnits: 20000,
    splitType: 'percentage',
    payerId: 'u_payer',
    selectedMemberIds: ['u_payer', 'u_purvesh', 'u_rahul'],
    percentageMap: { u_payer: 50, u_purvesh: 30, u_rahul: 20 },
    personalItems: [{ id: 'pi_1', memberId: 'u_purvesh', amountMinorUnits: 5000 }],
    currency: 'INR',
    memberNamesById: MEMBER_NAMES
  });

  assert.equal(validation.isValid, true);
  const byId = new Map(validation.result.splits.map((s) => [s.memberId, s]));
  assert.equal(byId.get('u_payer')?.shareMinorUnits, 7500); // 50% of 150
  assert.equal(byId.get('u_purvesh')?.shareMinorUnits, 9500); // 30% of 150 (45) + 50 personal
  assert.equal(byId.get('u_rahul')?.shareMinorUnits, 3000); // 20% of 150
  assert.equal(validation.result.allocatedMinorUnits, 20000);
});

test('Group 1.3: Personal Item + Custom Split assigns custom shares over remaining shared pool', () => {
  // ₹200 total, ₹40 personal for Purvesh -> ₹160 shared pool split custom ₹60/₹60/₹40
  const validation = validateEnhancedExpenseSplits({
    totalMinorUnits: 20000,
    splitType: 'custom',
    payerId: 'u_payer',
    selectedMemberIds: ['u_payer', 'u_purvesh', 'u_rahul'],
    customSharedMinorUnitsMap: { u_payer: 6000, u_purvesh: 6000, u_rahul: 4000 },
    personalItems: [{ id: 'pi_1', memberId: 'u_purvesh', amountMinorUnits: 4000 }],
    currency: 'INR',
    memberNamesById: MEMBER_NAMES
  });

  assert.equal(validation.isValid, true);
  const byId = new Map(validation.result.splits.map((s) => [s.memberId, s]));
  assert.equal(byId.get('u_payer')?.shareMinorUnits, 6000);
  assert.equal(byId.get('u_purvesh')?.shareMinorUnits, 10000); // 60 shared + 40 personal
  assert.equal(byId.get('u_rahul')?.shareMinorUnits, 4000);
  assert.equal(validation.result.allocatedMinorUnits, 20000);
});

test('Group 1.4: Multiple personal items, odd-paisa Hare-Niemeyer rounding, unchecked member, and 100% personal items', () => {
  // Multiple items + odd-paisa shared pool: ₹100.00 total, ₹10.00 + ₹5.00 personal for Purvesh, ₹5.00 personal for Neha (unchecked from shared)
  // Shared pool = ₹80.00 split among 3 (Aarav, Purvesh, Rahul) -> 2667, 2667, 2666
  const multi = validateEnhancedExpenseSplits({
    totalMinorUnits: 10000,
    splitType: 'equal',
    payerId: 'u_payer',
    selectedMemberIds: ['u_payer', 'u_purvesh', 'u_rahul'],
    personalItems: [
      { id: 'pi_1', memberId: 'u_purvesh', label: 'Coffee', amountMinorUnits: 1000 },
      { id: 'pi_2', memberId: 'u_purvesh', label: 'Cake', amountMinorUnits: 500 },
      { id: 'pi_3', memberId: 'u_neha', label: 'Juice', amountMinorUnits: 500 }
    ],
    currency: 'INR',
    memberNamesById: MEMBER_NAMES
  });

  assert.equal(multi.isValid, true);
  assert.equal(multi.result.allocatedMinorUnits, 10000);
  const multiById = new Map(multi.result.splits.map((s) => [s.memberId, s]));
  assert.equal(multiById.get('u_neha')?.sharedMinorUnits, 0);
  assert.equal(multiById.get('u_neha')?.personalMinorUnits, 500);
  assert.equal(multiById.get('u_neha')?.shareMinorUnits, 500);
  assert.equal(multiById.get('u_purvesh')?.personalMinorUnits, 1500);
  assert.equal(multiById.get('u_purvesh')?.shareMinorUnits, 2667 + 1500);

  // 100% personal items (shared pool === 0)
  const allPersonal = validateEnhancedExpenseSplits({
    totalMinorUnits: 10000,
    splitType: 'equal',
    payerId: 'u_payer',
    selectedMemberIds: [],
    personalItems: [
      { id: 'pi_a', memberId: 'u_purvesh', amountMinorUnits: 7000 },
      { id: 'pi_b', memberId: 'u_rahul', amountMinorUnits: 3000 }
    ],
    currency: 'INR',
    memberNamesById: MEMBER_NAMES
  });
  assert.equal(allPersonal.isValid, true);
  assert.equal(allPersonal.result.sharedPoolMinorUnits, 0);
  assert.equal(allPersonal.result.allocatedMinorUnits, 10000);
});

// ============================================================================
// GROUP 2: Advance Payment (Already Paid) Math + Ledger + Exports
// ============================================================================
test('Group 2.1: Advance Payment (₹120 equal 4 ways -> ₹30 each; Purvesh Already Paid ₹10 -> Remaining ₹20, zero-sum, preserved ₹120 total)', () => {
  const calc = calculateEnhancedExpenseSplits({
    totalMinorUnits: 12000,
    splitType: 'equal',
    payerId: 'u_payer',
    selectedMemberIds: ['u_payer', 'u_purvesh', 'u_rahul', 'u_neha'],
    advancePaidMinorUnitsMap: { u_purvesh: 1000 },
    expenseId: 'exp_120',
    currency: 'INR',
    memberNamesById: MEMBER_NAMES
  });

  const expense = makeExpense({
    id: 'exp_120',
    amount: 12000,
    splits: calc.splits,
    advancePayments: calc.advancePayments
  });

  // Original expense total MUST stay ₹120.00
  assert.equal(expense.amount, 12000);

  const plan = reconcileLinkedAdvanceTransactions(expense, [], MEMBERS, 'u_payer');
  assert.equal(plan.toCreate.length, 1);
  assert.equal(plan.toUpdate.length, 0);
  assert.equal(plan.toReverse.length, 0);

  const advTx = plan.toCreate[0];
  assert.equal(advTx.id, buildAdvanceTransactionId('exp_120', 'u_purvesh'));
  assert.equal(advTx.type, 'settlement');
  assert.equal(advTx.category, 'Advance Payment');
  assert.equal(advTx.amount, 1000);
  assert.equal(advTx.payerId, 'u_purvesh');
  assert.equal(advTx.paidToId, 'u_payer');
  assert.equal(advTx.isAdvancePayment, true);
  assert.equal(advTx.linkedExpenseId, 'exp_120');

  const ledger = [expense, advTx];
  const balances = calculateGroupBalances(MEMBERS, ledger);
  const byMember = new Map(balances.map((b) => [b.memberId, b.netBalanceMinorUnits]));

  // Aarav paid ₹120, share ₹30, received ₹10 advance -> net +₹80
  assert.equal(byMember.get('u_payer'), 8000);
  // Purvesh share ₹30, paid ₹10 advance -> remaining -₹20
  assert.equal(byMember.get('u_purvesh'), -2000);
  // Rahul & Neha share ₹30 -> -₹30 each
  assert.equal(byMember.get('u_rahul'), -3000);
  assert.equal(byMember.get('u_neha'), -3000);

  // Strict zero-sum invariant
  const sumBalances = balances.reduce((acc, b) => acc + b.netBalanceMinorUnits, 0);
  assert.equal(sumBalances, 0);

  // Smart Settlement should ask Purvesh for ₹20 -> Aarav
  const settlements = calculateDebtSettlements(balances);
  const purveshSettlement = settlements.find((s) => s.fromMemberId === 'u_purvesh');
  assert.ok(purveshSettlement);
  assert.equal(purveshSettlement.toMemberId, 'u_payer');
  assert.equal(purveshSettlement.amountMinorUnits, 2000);

  // Category total preserves original ₹120 expense (settlement is excluded from expense categories)
  const categories = calculateCategoryBreakdowns(ledger, 'expense');
  assert.equal(categories.length, 1);
  assert.equal(categories[0].category, 'Food & Dining');
  assert.equal(categories[0].amountMinorUnits, 12000);

  // PDF statement generation succeeds with both original expense and separate advance entry
  const actualBalance = calculateSpaceLedgerBalance(SPACE, ledger, 'u_payer');
  const pdfDoc = buildPdfDocument(SPACE, ledger, balances, actualBalance);
  assert.ok(pdfDoc.getNumberOfPages() >= 1);
});

// ============================================================================
// GROUP 3: Combined Personal Item + Advance Payment
// ============================================================================
test('Group 3.1: Combined Personal Item (₹40) + Advance Payment (₹10) on ₹120 Equal 4-way -> Purvesh Share ₹60, Paid ₹10, Remaining ₹50', () => {
  const validation = validateEnhancedExpenseSplits({
    totalMinorUnits: 12000,
    splitType: 'equal',
    payerId: 'u_payer',
    selectedMemberIds: ['u_payer', 'u_purvesh', 'u_rahul', 'u_neha'],
    personalItems: [{ id: 'pi_1', memberId: 'u_purvesh', label: 'Special Dish', amountMinorUnits: 4000 }],
    advancePaidMinorUnitsMap: { u_purvesh: 1000 },
    expenseId: 'exp_combo',
    currency: 'INR',
    memberNamesById: MEMBER_NAMES
  });

  assert.equal(validation.isValid, true);
  const purveshSplit = validation.result.splits.find((s) => s.memberId === 'u_purvesh');
  assert.ok(purveshSplit);
  assert.equal(purveshSplit.sharedMinorUnits, 2000);
  assert.equal(purveshSplit.personalMinorUnits, 4000);
  assert.equal(purveshSplit.shareMinorUnits, 6000);
  assert.equal(purveshSplit.advancePaidMinorUnits, 1000);
  assert.equal(purveshSplit.remainingMinorUnits, 5000);

  const expense = makeExpense({
    id: 'exp_combo',
    amount: 12000,
    splits: validation.result.splits,
    personalItems: validation.result.personalItems,
    advancePayments: validation.result.advancePayments
  });

  const plan = reconcileLinkedAdvanceTransactions(expense, [], MEMBERS, 'u_payer');
  const ledger = [expense, ...plan.toCreate];
  const balances = calculateGroupBalances(MEMBERS, ledger);
  const byMember = new Map(balances.map((b) => [b.memberId, b.netBalanceMinorUnits]));

  assert.equal(byMember.get('u_purvesh'), -5000); // ₹60 share - ₹10 advance = owes ₹50
  assert.equal(byMember.get('u_rahul'), -2000);
  assert.equal(byMember.get('u_neha'), -2000);
  assert.equal(byMember.get('u_payer'), 9000); // paid ₹120 - ₹20 own share - ₹10 advance received = +₹90
  assert.equal(
    balances.reduce((acc, b) => acc + b.netBalanceMinorUnits, 0),
    0
  );
});

// ============================================================================
// GROUP 4: Duplicate-Deduction Prevention & Full Edit / Reversal Lifecycle
// ============================================================================
test('Group 4.1: Re-saving unchanged expense is a no-op; editing advance ₹10->₹15 updates in-place (delta ₹5 only); ₹15->₹0 reverses cleanly', () => {
  const calc1 = calculateEnhancedExpenseSplits({
    totalMinorUnits: 12000,
    splitType: 'equal',
    payerId: 'u_payer',
    selectedMemberIds: ['u_payer', 'u_purvesh', 'u_rahul', 'u_neha'],
    advancePaidMinorUnitsMap: { u_purvesh: 1000 },
    expenseId: 'exp_life',
    currency: 'INR'
  });

  const exp1 = makeExpense({
    id: 'exp_life',
    splits: calc1.splits,
    advancePayments: calc1.advancePayments
  });

  // Initial create
  const plan1 = reconcileLinkedAdvanceTransactions(exp1, [], MEMBERS, 'u_payer');
  assert.equal(plan1.toCreate.length, 1);
  let ledger: Transaction[] = [exp1, ...plan1.toCreate];

  // Re-save unchanged -> strict NO-OP
  const planNoop = reconcileLinkedAdvanceTransactions(exp1, ledger, MEMBERS, 'u_payer');
  assert.equal(planNoop.toCreate.length, 0);
  assert.equal(planNoop.toUpdate.length, 0);
  assert.equal(planNoop.toReverse.length, 0);

  // Edit advance ₹10 -> ₹15
  const calc2 = calculateEnhancedExpenseSplits({
    totalMinorUnits: 12000,
    splitType: 'equal',
    payerId: 'u_payer',
    selectedMemberIds: ['u_payer', 'u_purvesh', 'u_rahul', 'u_neha'],
    advancePaidMinorUnitsMap: { u_purvesh: 1500 },
    expenseId: 'exp_life',
    currency: 'INR'
  });
  const exp2 = { ...exp1, splits: calc2.splits, advancePayments: calc2.advancePayments, version: 2 };
  const plan2 = reconcileLinkedAdvanceTransactions(exp2, ledger, MEMBERS, 'u_payer');
  assert.equal(plan2.toCreate.length, 0);
  assert.equal(plan2.toUpdate.length, 1);
  assert.equal(plan2.toUpdate[0].nextTx.amount, 1500);
  assert.equal(plan2.toReverse.length, 0);

  ledger = [exp2, plan2.toUpdate[0].nextTx];
  const balAfterEdit = calculateGroupBalances(MEMBERS, ledger);
  const purveshAfterEdit = balAfterEdit.find((b) => b.memberId === 'u_purvesh')?.netBalanceMinorUnits;
  assert.equal(purveshAfterEdit, -1500); // ₹30 - ₹15 = -₹15 (changed by ₹5 only, zero double deduction)

  // Edit advance ₹15 -> ₹0 -> reverses old advance immutably
  const calc3 = calculateEnhancedExpenseSplits({
    totalMinorUnits: 12000,
    splitType: 'equal',
    payerId: 'u_payer',
    selectedMemberIds: ['u_payer', 'u_purvesh', 'u_rahul', 'u_neha'],
    advancePaidMinorUnitsMap: { u_purvesh: 0 },
    expenseId: 'exp_life',
    currency: 'INR'
  });
  const exp3 = { ...exp2, splits: calc3.splits, advancePayments: [], version: 3 };
  const plan3 = reconcileLinkedAdvanceTransactions(exp3, ledger, MEMBERS, 'u_payer');
  assert.equal(plan3.toCreate.length, 0);
  assert.equal(plan3.toUpdate.length, 0);
  assert.equal(plan3.toReverse.length, 1);

  ledger = [exp3, plan3.toReverse[0].originalUpdated, plan3.toReverse[0].reversalTx];
  const balAfterZero = calculateGroupBalances(MEMBERS, ledger);
  assert.equal(balAfterZero.find((b) => b.memberId === 'u_purvesh')?.netBalanceMinorUnits, -3000);
});

test('Group 4.2: Payer change updates paidToId; parent reversal cascades to linked advance and returns all balances to ₹0', () => {
  const calc = calculateEnhancedExpenseSplits({
    totalMinorUnits: 12000,
    splitType: 'equal',
    payerId: 'u_payer',
    selectedMemberIds: ['u_payer', 'u_purvesh', 'u_rahul', 'u_neha'],
    advancePaidMinorUnitsMap: { u_purvesh: 1000 },
    expenseId: 'exp_rev',
    currency: 'INR'
  });
  const exp = makeExpense({ id: 'exp_rev', splits: calc.splits, advancePayments: calc.advancePayments });
  const planCreate = reconcileLinkedAdvanceTransactions(exp, [], MEMBERS, 'u_payer');
  let ledger: Transaction[] = [exp, ...planCreate.toCreate];

  // Change payer from u_payer -> u_rahul: linked advance paidToId should update to u_rahul
  const expNewPayer: Transaction = { ...exp, payerId: 'u_rahul', version: 2 };
  const planPayer = reconcileLinkedAdvanceTransactions(expNewPayer, ledger, MEMBERS, 'u_payer');
  assert.equal(planPayer.toUpdate.length, 1);
  assert.equal(planPayer.toUpdate[0].nextTx.paidToId, 'u_rahul');
  ledger = [expNewPayer, planPayer.toUpdate[0].nextTx];

  // Cascade reverse parent expense -> linked advance also reversed -> all balances strictly 0
  const cascade = createCascadeReversalPlan(expNewPayer, ledger, 'u_payer', 'Entered by mistake');
  assert.equal(cascade.linkedReversals.length, 1);

  const reversedLedger: Transaction[] = [
    cascade.primary.originalUpdated,
    cascade.primary.reversalTx,
    cascade.linkedReversals[0].originalUpdated,
    cascade.linkedReversals[0].reversalTx
  ];
  const balancesAfterCascade = calculateGroupBalances(MEMBERS, reversedLedger);
  for (const b of balancesAfterCascade) {
    assert.equal(b.netBalanceMinorUnits, 0, `Expected 0 balance for ${b.memberName}`);
  }
});

test('Group 4.3: Direct advance reversal respected by buildActiveLinkedAdvancesMap; re-adding advance uses _r1 ID without overwriting reversed history', () => {
  const calc = calculateEnhancedExpenseSplits({
    totalMinorUnits: 12000,
    splitType: 'equal',
    payerId: 'u_payer',
    selectedMemberIds: ['u_payer', 'u_purvesh', 'u_rahul', 'u_neha'],
    advancePaidMinorUnitsMap: { u_purvesh: 1000 },
    expenseId: 'exp_direct_rev',
    currency: 'INR'
  });
  const exp = makeExpense({
    id: 'exp_direct_rev',
    splits: calc.splits,
    advancePayments: calc.advancePayments
  });
  const created = reconcileLinkedAdvanceTransactions(exp, [], MEMBERS, 'u_payer');
  const adv = created.toCreate[0];

  // Directly reverse ONLY the advance entry in ledger
  const directRev = createCascadeReversalPlan(adv, [exp, adv], 'u_payer', 'Direct advance reversal');
  const ledgerAfterDirectRev = [exp, directRev.primary.originalUpdated, directRev.primary.reversalTx];

  // Live map must report NO active advance for Purvesh
  const liveMap = buildActiveLinkedAdvancesMap('exp_direct_rev', ledgerAfterDirectRev);
  assert.equal(liveMap['u_purvesh'], undefined);

  // If user edits expense and adds ₹12 advance again, must create adv_exp_direct_rev_u_purvesh_r1
  const expReAdd: Transaction = {
    ...exp,
    advancePayments: [
      {
        memberId: 'u_purvesh',
        amountMinorUnits: 1200,
        advanceTransactionId: buildAdvanceTransactionId('exp_direct_rev', 'u_purvesh')
      }
    ]
  };
  const planReAdd = reconcileLinkedAdvanceTransactions(expReAdd, ledgerAfterDirectRev, MEMBERS, 'u_payer');
  assert.equal(planReAdd.toCreate.length, 1);
  assert.equal(planReAdd.toCreate[0].id, 'adv_exp_direct_rev_u_purvesh_r1');
  assert.equal(planReAdd.toCreate[0].amount, 1200);
});

test('Group 4.4: Wallet Pay pending/failed paymentStatus excludes both parent expense and linked advance until paid', () => {
  const calc = calculateEnhancedExpenseSplits({
    totalMinorUnits: 12000,
    splitType: 'equal',
    payerId: 'u_payer',
    selectedMemberIds: ['u_payer', 'u_purvesh', 'u_rahul', 'u_neha'],
    advancePaidMinorUnitsMap: { u_purvesh: 1000 },
    expenseId: 'exp_wp',
    currency: 'INR'
  });
  const pendingExpense = makeExpense({
    id: 'exp_wp',
    paymentStatus: 'pending',
    splits: calc.splits,
    advancePayments: calc.advancePayments
  });
  const plan = reconcileLinkedAdvanceTransactions(pendingExpense, [], MEMBERS, 'u_payer');
  assert.equal(plan.toCreate[0].paymentStatus, 'pending');

  const pendingBalances = calculateGroupBalances(MEMBERS, [pendingExpense, plan.toCreate[0]]);
  for (const b of pendingBalances) {
    assert.equal(b.netBalanceMinorUnits, 0);
  }
});

// ============================================================================
// GROUP 5: Validation & Edge Cases — INCLUDING DYNAMIC CAP ENFORCEMENT
// ============================================================================
test('Group 5.1: DYNAMIC CAP varies per member & per expense (₹60 share caps at ₹60, ₹20 share caps at ₹20, ₹100 share caps at ₹100 — never fixed ₹30)', () => {
  // Case A: Member share is ₹60 (₹120 total, ₹40 personal for Purvesh + ₹20 shared)
  const share60Ok = validateEnhancedExpenseSplits({
    totalMinorUnits: 12000,
    splitType: 'equal',
    payerId: 'u_payer',
    selectedMemberIds: ['u_payer', 'u_purvesh', 'u_rahul', 'u_neha'],
    personalItems: [{ id: 'pi_1', memberId: 'u_purvesh', amountMinorUnits: 4000 }],
    advancePaidMinorUnitsMap: { u_purvesh: 6000 }, // Exact share ₹60 -> allowed
    currency: 'INR',
    memberNamesById: MEMBER_NAMES
  });
  assert.equal(share60Ok.isValid, true);
  assert.equal(
    share60Ok.result.splits.find((s) => s.memberId === 'u_purvesh')?.remainingMinorUnits,
    0
  );

  const share60Over = validateEnhancedExpenseSplits({
    totalMinorUnits: 12000,
    splitType: 'equal',
    payerId: 'u_payer',
    selectedMemberIds: ['u_payer', 'u_purvesh', 'u_rahul', 'u_neha'],
    personalItems: [{ id: 'pi_1', memberId: 'u_purvesh', amountMinorUnits: 4000 }],
    advancePaidMinorUnitsMap: { u_purvesh: 6001 }, // ₹60.01 > ₹60.00 -> rejected
    currency: 'INR',
    memberNamesById: MEMBER_NAMES
  });
  assert.equal(share60Over.isValid, false);
  assert.match(share60Over.memberErrors['u_purvesh'], /Maximum Already Paid for Purvesh.*60\.00/);

  // Case B: Rahul's share on the SAME expense is ₹20 -> ₹20 allowed, ₹21 rejected (proves cap is NOT fixed ₹30)
  const share20Ok = validateEnhancedExpenseSplits({
    totalMinorUnits: 12000,
    splitType: 'equal',
    payerId: 'u_payer',
    selectedMemberIds: ['u_payer', 'u_purvesh', 'u_rahul', 'u_neha'],
    personalItems: [{ id: 'pi_1', memberId: 'u_purvesh', amountMinorUnits: 4000 }],
    advancePaidMinorUnitsMap: { u_rahul: 2000 },
    currency: 'INR',
    memberNamesById: MEMBER_NAMES
  });
  assert.equal(share20Ok.isValid, true);

  const share20Over = validateEnhancedExpenseSplits({
    totalMinorUnits: 12000,
    splitType: 'equal',
    payerId: 'u_payer',
    selectedMemberIds: ['u_payer', 'u_purvesh', 'u_rahul', 'u_neha'],
    personalItems: [{ id: 'pi_1', memberId: 'u_purvesh', amountMinorUnits: 4000 }],
    advancePaidMinorUnitsMap: { u_rahul: 2100 }, // ₹21 < ₹30, yet > Rahul's ₹20 share -> MUST reject!
    currency: 'INR',
    memberNamesById: MEMBER_NAMES
  });
  assert.equal(share20Over.isValid, false);
  assert.match(share20Over.memberErrors['u_rahul'], /Maximum Already Paid for Rahul.*20\.00/);

  // Case C: Larger expense ₹400 equal 4 ways -> ₹100 share each -> ₹80 and ₹100 allowed, ₹101 rejected
  const share100Ok = validateEnhancedExpenseSplits({
    totalMinorUnits: 40000,
    splitType: 'equal',
    payerId: 'u_payer',
    selectedMemberIds: ['u_payer', 'u_purvesh', 'u_rahul', 'u_neha'],
    advancePaidMinorUnitsMap: { u_purvesh: 8000, u_rahul: 10000 }, // > ₹30, valid because <= ₹100 share!
    currency: 'INR',
    memberNamesById: MEMBER_NAMES
  });
  assert.equal(share100Ok.isValid, true);

  const share100Over = validateEnhancedExpenseSplits({
    totalMinorUnits: 40000,
    splitType: 'equal',
    payerId: 'u_payer',
    selectedMemberIds: ['u_payer', 'u_purvesh', 'u_rahul', 'u_neha'],
    advancePaidMinorUnitsMap: { u_purvesh: 10100 },
    currency: 'INR',
    memberNamesById: MEMBER_NAMES
  });
  assert.equal(share100Over.isValid, false);
  assert.match(share100Over.memberErrors['u_purvesh'], /Maximum Already Paid for Purvesh.*100\.00/);
});

test('Group 5.2: Save-time normalization rejects advance exceeding member share (dynamic cap defense-in-depth)', () => {
  const invalidTx = makeExpense({
    id: 'exp_over_cap',
    amount: 12000,
    splits: [
      { memberId: 'u_payer', shareMinorUnits: 3000 },
      { memberId: 'u_purvesh', shareMinorUnits: 3000, advancePaidMinorUnits: 3500 },
      { memberId: 'u_rahul', shareMinorUnits: 3000 },
      { memberId: 'u_neha', shareMinorUnits: 3000 }
    ],
    advancePayments: [
      { memberId: 'u_purvesh', amountMinorUnits: 3500, advanceTransactionId: 'adv_exp_over_cap_u_purvesh' }
    ]
  });

  assert.throws(() => normalizeTransactionPayload(invalidTx), /exceeds member share/i);
});

test('Group 5.3: Rejects negative values, personal > total, custom sum mismatch, percentage != 100%, and advance on payer', () => {
  // Negative personal item
  assert.equal(
    validateEnhancedExpenseSplits({
      totalMinorUnits: 12000,
      splitType: 'equal',
      payerId: 'u_payer',
      selectedMemberIds: ['u_payer', 'u_purvesh'],
      personalItems: [{ id: 'pi_neg', memberId: 'u_purvesh', amountMinorUnits: -500 }]
    }).isValid,
    false
  );

  // Personal items exceed total
  assert.equal(
    validateEnhancedExpenseSplits({
      totalMinorUnits: 10000,
      splitType: 'equal',
      payerId: 'u_payer',
      selectedMemberIds: ['u_payer', 'u_purvesh'],
      personalItems: [{ id: 'pi_big', memberId: 'u_purvesh', amountMinorUnits: 12000 }]
    }).isValid,
    false
  );

  // Custom sum mismatch
  assert.equal(
    validateEnhancedExpenseSplits({
      totalMinorUnits: 10000,
      splitType: 'custom',
      payerId: 'u_payer',
      selectedMemberIds: ['u_payer', 'u_purvesh'],
      customSharedMinorUnitsMap: { u_payer: 4000, u_purvesh: 5000 }
    }).isValid,
    false
  );

  // Percentage != 100%
  assert.equal(
    validateEnhancedExpenseSplits({
      totalMinorUnits: 10000,
      splitType: 'percentage',
      payerId: 'u_payer',
      selectedMemberIds: ['u_payer', 'u_purvesh'],
      percentageMap: { u_payer: 50, u_purvesh: 40 }
    }).isValid,
    false
  );

  // Advance on bill payer
  const payerAdv = validateEnhancedExpenseSplits({
    totalMinorUnits: 10000,
    splitType: 'equal',
    payerId: 'u_payer',
    selectedMemberIds: ['u_payer', 'u_purvesh'],
    advancePaidMinorUnitsMap: { u_payer: 1000 },
    memberNamesById: MEMBER_NAMES
  });
  assert.equal(payerAdv.isValid, false);
  assert.ok(payerAdv.memberErrors['u_payer']);
});

test('Group 5.4: Multi-currency integer minor units (INR 2 decimals, JPY 0 decimals, KWD 3 decimals)', () => {
  // JPY: 0 decimals (¥1200 total, ¥400 personal, ¥800 split 4 ways = ¥200 each; Purvesh ¥600, advance ¥100 -> rem ¥500)
  const jpy = validateEnhancedExpenseSplits({
    totalMinorUnits: 1200,
    splitType: 'equal',
    payerId: 'u_payer',
    selectedMemberIds: ['u_payer', 'u_purvesh', 'u_rahul', 'u_neha'],
    personalItems: [{ id: 'pi_jpy', memberId: 'u_purvesh', amountMinorUnits: 400 }],
    advancePaidMinorUnitsMap: { u_purvesh: 100 },
    currency: 'JPY',
    memberNamesById: MEMBER_NAMES
  });
  assert.equal(jpy.isValid, true);
  assert.equal(jpy.result.splits.find((s) => s.memberId === 'u_purvesh')?.shareMinorUnits, 600);
  assert.equal(jpy.result.splits.find((s) => s.memberId === 'u_purvesh')?.remainingMinorUnits, 500);

  // KWD: 3 decimals (KD 12.000 = 12000 fils; KD 4.000 personal; KD 8.000 / 4 = 2000 fils; Purvesh 6000 fils; advance 1500 -> rem 4500)
  const kwd = validateEnhancedExpenseSplits({
    totalMinorUnits: 12000,
    splitType: 'equal',
    payerId: 'u_payer',
    selectedMemberIds: ['u_payer', 'u_purvesh', 'u_rahul', 'u_neha'],
    personalItems: [{ id: 'pi_kwd', memberId: 'u_purvesh', amountMinorUnits: 4000 }],
    advancePaidMinorUnitsMap: { u_purvesh: 1500 },
    currency: 'KWD',
    memberNamesById: MEMBER_NAMES
  });
  assert.equal(kwd.isValid, true);
  assert.equal(kwd.result.splits.find((s) => s.memberId === 'u_purvesh')?.shareMinorUnits, 6000);
  assert.equal(kwd.result.splits.find((s) => s.memberId === 'u_purvesh')?.remainingMinorUnits, 4500);
});

// ============================================================================
// GROUP 6: Backward Compatibility & Firestore Payload Hygiene
// ============================================================================
test('Group 6.1: Legacy transactions without enhanced fields compute identically; normalizeTransactionPayload preserves new fields with zero undefined values', () => {
  const legacyExpense: Transaction = makeExpense({
    id: 'exp_legacy',
    amount: 12000,
    splits: [
      { memberId: 'u_payer', shareMinorUnits: 3000, percentage: 25 },
      { memberId: 'u_purvesh', shareMinorUnits: 3000, percentage: 25 },
      { memberId: 'u_rahul', shareMinorUnits: 3000, percentage: 25 },
      { memberId: 'u_neha', shareMinorUnits: 3000, percentage: 25 }
    ]
  });

  const legacyBalances = calculateGroupBalances(MEMBERS, [legacyExpense]);
  assert.equal(legacyBalances.find((b) => b.memberId === 'u_payer')?.netBalanceMinorUnits, 9000);
  assert.equal(legacyBalances.find((b) => b.memberId === 'u_purvesh')?.netBalanceMinorUnits, -3000);

  // Enhanced expense + linked advance normalization must preserve all new fields with ZERO undefined values
  const calc = calculateEnhancedExpenseSplits({
    totalMinorUnits: 12000,
    splitType: 'equal',
    payerId: 'u_payer',
    selectedMemberIds: ['u_payer', 'u_purvesh', 'u_rahul', 'u_neha'],
    personalItems: [{ id: 'pi_1', memberId: 'u_purvesh', label: undefined, amountMinorUnits: 4000 }],
    advancePaidMinorUnitsMap: { u_purvesh: 1000 },
    expenseId: 'exp_hygiene',
    currency: 'INR'
  });

  const enhancedExpense = makeExpense({
    id: 'exp_hygiene',
    splits: calc.splits,
    personalItems: calc.personalItems,
    advancePayments: calc.advancePayments
  });

  const normalizedParent = normalizeTransactionPayload(enhancedExpense);
  assert.equal(hasUndefinedDeep(normalizedParent), false);
  assert.equal(normalizedParent.personalItems.length, 1);
  assert.equal(normalizedParent.personalItems[0].amountMinorUnits, 4000);
  assert.equal(normalizedParent.advancePayments.length, 1);
  assert.equal(normalizedParent.advancePayments[0].amountMinorUnits, 1000);
  assert.equal(normalizedParent.splits.find((s: any) => s.memberId === 'u_purvesh').personalMinorUnits, 4000);
  assert.equal(normalizedParent.splits.find((s: any) => s.memberId === 'u_purvesh').remainingMinorUnits, 5000);

  const plan = reconcileLinkedAdvanceTransactions(enhancedExpense, [], MEMBERS, 'u_payer');
  const normalizedAdv = normalizeTransactionPayload(plan.toCreate[0]);
  assert.equal(hasUndefinedDeep(normalizedAdv), false);
  assert.equal(normalizedAdv.isAdvancePayment, true);
  assert.equal(normalizedAdv.linkedExpenseId, 'exp_hygiene');
  assert.equal(normalizedAdv.advanceMemberId, 'u_purvesh');
});
