/**
 * SPLITO — Reliable Network Detection Service
 * Spec V1.0 (Section 2A)
 * 
 * Responsibilities:
 * 1. Single shared source of truth for network status across web and native Android.
 * 2. Official @capacitor/network plugin integration with Network.getStatus() and Network.addListener().
 * 3. Graceful fallback to navigator.onLine and window online/offline events when native plugin is unavailable.
 * 4. Automatic status refresh on Android app resume/foreground via @capacitor/app.
 * 5. Clean subscription and unsubscription API without competing listeners.
 * 6. Node.js test environment resilience.
 */

import { Network, ConnectionStatus } from '@capacitor/network';
import { Capacitor } from '@capacitor/core';
import { App } from '@capacitor/app';

export interface NetworkState {
  connected: boolean;
  connectionType: string;
  lastCheckedAt: string;
}

type NetworkListener = (status: NetworkState) => void;

let currentNetworkState: NetworkState = {
  connected: typeof navigator !== 'undefined' ? (navigator.onLine ?? true) : true,
  connectionType: 'unknown',
  lastCheckedAt: new Date().toISOString()
};

const listeners = new Set<NetworkListener>();
let isInitialized = false;
let initPromise: Promise<NetworkState> | null = null;
let capacitorPluginHandle: { remove: () => Promise<void> } | null = null;
let appStateHandle: { remove: () => Promise<void> } | null = null;
let windowOnlineHandler: (() => void) | null = null;
let windowOfflineHandler: (() => void) | null = null;
let windowFocusHandler: (() => void) | null = null;

function notifyListeners() {
  for (const listener of listeners) {
    try {
      listener(currentNetworkState);
    } catch (err) {
      console.warn('Network listener error:', err);
    }
  }
}

/**
 * Updates the internal network state and notifies subscribers if changed.
 */
export function updateNetworkState(connected: boolean, connectionType: string = 'unknown'): NetworkState {
  const previous = currentNetworkState.connected;
  currentNetworkState = {
    connected,
    connectionType,
    lastCheckedAt: new Date().toISOString()
  };

  if (previous !== connected) {
    notifyListeners();
  }

  return currentNetworkState;
}

/**
 * Performs a fast lightweight internet reachability probe in browser/WebView contexts.
 * Prevents false-offline states when Capacitor Network or navigator.onLine transiently report false
 * even though WiFi/cellular internet is working.
 * Immediately fails (<10ms) when device is truly offline / in Airplane Mode.
 */
export async function verifyInternetReachability(timeoutMs: number = 1500): Promise<boolean> {
  if (typeof window === 'undefined' || typeof fetch !== 'function') {
    return currentNetworkState.connected;
  }

  const controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
  const timer = controller ? setTimeout(() => controller.abort(), timeoutMs) : null;

  try {
    await fetch('https://www.gstatic.com/generate_204', {
      method: 'HEAD',
      mode: 'no-cors',
      cache: 'no-store',
      ...(controller ? { signal: controller.signal } : {})
    });
    return true;
  } catch {
    return false;
  } finally {
    if (timer) clearTimeout(timer);
  }
}

/**
 * Reads the latest network status from Capacitor Network or browser fallback,
 * verifying actual internet reachability before declaring offline in browser/WebView.
 */
export async function refreshNetworkStatus(): Promise<NetworkState> {
  let pluginConnected: boolean | null = null;
  let pluginType: string = 'unknown';

  try {
    if (Capacitor.isPluginAvailable('Network')) {
      const status: ConnectionStatus = await Network.getStatus();
      pluginConnected = status.connected;
      pluginType = status.connectionType || 'unknown';
    }
  } catch {
    // Plugin unavailable or call failed; fall back to browser navigator
  }

  const navigatorOnline = typeof navigator !== 'undefined' ? navigator.onLine : true;

  // If Capacitor plugin reports connected (or plugin unavailable and navigator.onLine is true)
  if (pluginConnected === true) {
    return updateNetworkState(true, pluginType);
  }
  if (pluginConnected === null && navigatorOnline === true) {
    return updateNetworkState(true, 'web-online');
  }

  // If plugin or navigator reports offline in a browser/WebView environment,
  // verify with a fast reachability probe so a false-offline report never traps the user.
  if (typeof window !== 'undefined' && typeof fetch === 'function') {
    const reachable = await verifyInternetReachability(1500);
    if (reachable) {
      return updateNetworkState(true, pluginType !== 'none' && pluginType !== 'unknown' ? pluginType : 'wifi');
    }
  }

  return updateNetworkState(false, 'none');
}

/**
 * Initializes network detection listeners once.
 */
export async function initializeNetworkDetection(): Promise<NetworkState> {
  if (isInitialized && initPromise) {
    return initPromise;
  }
  if (isInitialized) {
    return currentNetworkState;
  }
  isInitialized = true;

  initPromise = (async () => {
    // 1. Initial status fetch
    await refreshNetworkStatus();

    // 2. Capacitor native Network plugin listener
    try {
      if (Capacitor.isPluginAvailable('Network')) {
        capacitorPluginHandle = await Network.addListener('networkStatusChange', (status: ConnectionStatus) => {
          if (status.connected) {
            updateNetworkState(true, status.connectionType);
          } else {
            refreshNetworkStatus();
          }
        });
      }
    } catch (err) {
      console.warn('Notice: Capacitor Network listener setup failed, using browser events', err);
    }

    // 3. Browser fallback listeners for web / iframe / hybrid
    if (typeof window !== 'undefined') {
      windowOnlineHandler = () => {
        updateNetworkState(true, 'web-online');
        refreshNetworkStatus();
      };
      windowOfflineHandler = () => {
        updateNetworkState(false, 'none');
      };
      windowFocusHandler = () => {
        refreshNetworkStatus();
      };

      window.addEventListener('online', windowOnlineHandler);
      window.addEventListener('offline', windowOfflineHandler);
      window.addEventListener('focus', windowFocusHandler);
    }

    // 4. Android app resume/foreground listener to re-verify connectivity immediately
    try {
      if (Capacitor.isNativePlatform()) {
        appStateHandle = await App.addListener('appStateChange', (state) => {
          if (state.isActive) {
            refreshNetworkStatus();
          }
        });
      }
    } catch {
      // App listener fallback
    }

    return currentNetworkState;
  })();

  return initPromise;
}

/**
 * Returns current snapshot of network status synchronously.
 */
export function getNetworkStatus(): NetworkState {
  return currentNetworkState;
}

/**
 * Returns true if network is currently connected.
 */
export function isOnline(): boolean {
  return currentNetworkState.connected;
}

/**
 * Subscribes a callback to network state changes. Returns an unregister function.
 */
export function subscribeNetworkStatus(listener: NetworkListener): () => void {
  listeners.add(listener);
  // Emit current state immediately to the new listener
  try {
    listener(currentNetworkState);
  } catch (err) {
    console.warn('Initial network listener error:', err);
  }

  return () => {
    listeners.delete(listener);
  };
}

/**
 * Cleans up all network listeners (used for testing or teardown).
 */
export async function cleanupNetworkDetection(): Promise<void> {
  listeners.clear();

  if (capacitorPluginHandle) {
    try {
      await capacitorPluginHandle.remove();
    } catch {
      // Ignore
    }
    capacitorPluginHandle = null;
  }

  if (appStateHandle) {
    try {
      await appStateHandle.remove();
    } catch {
      // Ignore
    }
    appStateHandle = null;
  }

  if (typeof window !== 'undefined') {
    if (windowOnlineHandler) {
      window.removeEventListener('online', windowOnlineHandler);
      windowOnlineHandler = null;
    }
    if (windowOfflineHandler) {
      window.removeEventListener('offline', windowOfflineHandler);
      windowOfflineHandler = null;
    }
    if (windowFocusHandler) {
      window.removeEventListener('focus', windowFocusHandler);
      windowFocusHandler = null;
    }
  }

  isInitialized = false;
  initPromise = null;
}
