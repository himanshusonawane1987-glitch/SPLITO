/**
 * SPLITO — Reliable Network Detection Service
 * Spec V1.0 (Section 2A)
 * 
 * Responsibilities:
 * 1. Single shared source of truth for network status across web and native Android.
 * 2. Official @capacitor/network plugin integration with Network.getStatus() and Network.addListener().
 * 3. Graceful fallback to navigator.onLine and window online/offline events when native plugin is unavailable.
 * 4. Automatic status refresh on Android app resume/foreground via @capacitor/app.
 * 5. Clean subscription and unsubscription API without competing listeners.
 * 6. Node.js test environment resilience.
 */

import { Network, ConnectionStatus } from '@capacitor/network';
import { Capacitor } from '@capacitor/core';
import { App } from '@capacitor/app';

export interface NetworkState {
  connected: boolean;
  connectionType: string;
  lastCheckedAt: string;
}

type NetworkListener = (status: NetworkState) => void;

let currentNetworkState: NetworkState = {
  connected: typeof navigator !== 'undefined' ? (navigator.onLine ?? true) : true,
  connectionType: 'unknown',
  lastCheckedAt: new Date().toISOString()
};

const listeners = new Set<NetworkListener>();
let isInitialized = false;
let capacitorPluginHandle: { remove: () => Promise<void> } | null = null;
let appStateHandle: { remove: () => Promise<void> } | null = null;
let windowOnlineHandler: (() => void) | null = null;
let windowOfflineHandler: (() => void) | null = null;

function notifyListeners() {
  for (const listener of listeners) {
    try {
      listener(currentNetworkState);
    } catch (err) {
      console.warn('Network listener error:', err);
    }
  }
}

/**
 * Updates the internal network state and notifies subscribers if changed.
 */
export function updateNetworkState(connected: boolean, connectionType: string = 'unknown'): NetworkState {
  const previous = currentNetworkState.connected;
  currentNetworkState = {
    connected,
    connectionType,
    lastCheckedAt: new Date().toISOString()
  };

  if (previous !== connected) {
    notifyListeners();
  }

  return currentNetworkState;
}

/**
 * Reads the latest network status from Capacitor Network or browser fallback.
 */
export async function refreshNetworkStatus(): Promise<NetworkState> {
  try {
    if (Capacitor.isPluginAvailable('Network')) {
      const status: ConnectionStatus = await Network.getStatus();
      return updateNetworkState(status.connected, status.connectionType);
    }
  } catch (err) {
    // Plugin unavailable or call failed; fall back to browser navigator
  }

  const browserConnected = typeof navigator !== 'undefined' ? (navigator.onLine ?? true) : true;
  return updateNetworkState(browserConnected, browserConnected ? 'web-online' : 'none');
}

/**
 * Initializes network detection listeners once.
 */
export async function initializeNetworkDetection(): Promise<NetworkState> {
  if (isInitialized) {
    return currentNetworkState;
  }
  isInitialized = true;

  // 1. Initial status fetch
  await refreshNetworkStatus();

  // 2. Capacitor native Network plugin listener
  try {
    if (Capacitor.isPluginAvailable('Network')) {
      capacitorPluginHandle = await Network.addListener('networkStatusChange', (status: ConnectionStatus) => {
        updateNetworkState(status.connected, status.connectionType);
      });
    }
  } catch (err) {
    console.warn('Notice: Capacitor Network listener setup failed, using browser events', err);
  }

  // 3. Browser fallback listeners for web / iframe / hybrid
  if (typeof window !== 'undefined') {
    windowOnlineHandler = () => {
      refreshNetworkStatus();
    };
    windowOfflineHandler = () => {
      updateNetworkState(false, 'none');
    };

    window.addEventListener('online', windowOnlineHandler);
    window.addEventListener('offline', windowOfflineHandler);
  }

  // 4. Android app resume/foreground listener to re-verify connectivity immediately
  try {
    if (Capacitor.isNativePlatform()) {
      appStateHandle = await App.addListener('appStateChange', (state) => {
        if (state.isActive) {
          refreshNetworkStatus();
        }
      });
    }
  } catch {
    // App listener fallback
  }

  return currentNetworkState;
}

/**
 * Returns current snapshot of network status synchronously.
 */
export function getNetworkStatus(): NetworkState {
  return currentNetworkState;
}

/**
 * Returns true if network is currently connected.
 */
export function isOnline(): boolean {
  return currentNetworkState.connected;
}

/**
 * Subscribes a callback to network state changes. Returns an unregister function.
 */
export function subscribeNetworkStatus(listener: NetworkListener): () => void {
  listeners.add(listener);
  // Emit current state immediately to the new listener
  try {
    listener(currentNetworkState);
  } catch (err) {
    console.warn('Initial network listener error:', err);
  }

  return () => {
    listeners.delete(listener);
  };
}

/**
 * Cleans up all network listeners (used for testing or teardown).
 */
export async function cleanupNetworkDetection(): Promise<void> {
  listeners.clear();

  if (capacitorPluginHandle) {
    try {
      await capacitorPluginHandle.remove();
    } catch {
      // Ignore
    }
    capacitorPluginHandle = null;
  }

  if (appStateHandle) {
    try {
      await appStateHandle.remove();
    } catch {
      // Ignore
    }
    appStateHandle = null;
  }

  if (typeof window !== 'undefined') {
    if (windowOnlineHandler) {
      window.removeEventListener('online', windowOnlineHandler);
      windowOnlineHandler = null;
    }
    if (windowOfflineHandler) {
      window.removeEventListener('offline', windowOfflineHandler);
      windowOfflineHandler = null;
    }
  }

  isInitialized = false;
}
