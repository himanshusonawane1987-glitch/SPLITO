import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import {
  Space,
  Transaction,
  UserProfile,
  SpaceMode,
  CurrencyCode,
  DebtSettlement,
  TransactionType,
  Member,
  PaymentMethod,
  PaymentStatus,
  SplitShare
} from './types/finance.ts';
import {
  auth,
  onAuthStateChanged,
  loginWithGoogle,
  logoutUser,
  testConnection,
  FirebaseUser
} from './lib/firebase.ts';
import {
  syncUserProfile,
  createSpace,
  updateSpaceDetails,
  subscribeToUserSpaces,
  subscribeToTransactions,
  addTransaction,
  updateTransaction,
  deleteTransaction,
  reverseLedgerTransaction,
  recordAuditLog,
  getModeDefaultSpaceName,
  updateUserActiveSpace,
  archiveSpace,
  unarchiveSpace,
  deleteEmptySpace,
  getProvisionalSpaces,
  getLocalUserSpaces,
  getLocalUserProfile,
  getLocalTransactions,
  filterOutDeletedSpaces,
  pushTransactionToCloud
} from './lib/storage-service.ts';
import {
  isOnline as getIsOnline,
  initializeNetworkDetection,
  refreshNetworkStatus,
  subscribeNetworkStatus
} from './lib/network-service.ts';
import { initializeOfflineQueue, drainQueue } from './lib/offline-queue.ts';
import { doc, getDocFromServer, setDoc } from 'firebase/firestore';
import { db } from './lib/firebase.ts';
import {
  calculateSpaceLedgerBalance,
  calculateGroupBalances,
  calculateDebtSettlements,
  createReversalTransaction
} from './lib/finance-engine.ts';

import { Header, SyncStatus } from './components/Header.tsx';
import { BottomNav, TabKey } from './components/ui/BottomNav.tsx';
import { FloatingAddButton } from './components/ui/FloatingAddButton.tsx';
import { OnboardingModal } from './components/OnboardingModal.tsx';
import { SpaceSwitcherModal } from './components/SpaceSwitcherModal.tsx';
import { TransactionModal } from './components/TransactionModal.tsx';
import { SettlementModal } from './components/SettlementModal.tsx';
import { ReceiptCaptureModal } from './components/ReceiptCaptureModal.tsx';
import { PdfExportModal } from './components/PdfExportModal.tsx';
import { AuthChoiceScreen } from './components/AuthChoiceScreen.tsx';
import { WalletPayModal } from './components/WalletPayModal.tsx';
import { StartupOfflineAlertModal, createOfflineDialogController } from './components/StartupOfflineAlertModal.tsx';
import { GuestMigrationModal } from './components/GuestMigrationModal.tsx';

import { HomeView } from './components/views/HomeView.tsx';
import { TransactionsView } from './components/views/TransactionsView.tsx';
import { GroupsView } from './components/views/GroupsView.tsx';
import { InsightsView } from './components/views/InsightsView.tsx';
import { ProfileView } from './components/views/ProfileView.tsx';

import {
  UserSubscription,
  SubscriptionEntitlement,
  ConsentPreferences
} from './types/subscription.ts';
import {
  calculateEntitlement,
  fetchUserSubscription,
  getLocalSubscription,
  saveLocalSubscription,
  DEFAULT_FREE_SUBSCRIPTION
} from './lib/billing-service.ts';
import { deleteUserAccountAndData, deleteUserPersonalData, fetchServerUserSpaces } from './lib/storage-service.ts';
import { LegalDocKey } from './lib/legal-content.ts';
import { SubscriptionModal } from './components/SubscriptionModal.tsx';
import { LegalModal } from './components/legal/LegalModal.tsx';
import { ConsentModal } from './components/ConsentModal.tsx';
import { AccountDeletionModal } from './components/AccountDeletionModal.tsx';
import { DeleteDataModal } from './components/DeleteDataModal.tsx';
import { RewardedAdModal } from './components/RewardedAdModal.tsx';
import { exportPdfStatement, exportCsvStatement } from './lib/export-service.ts';
import { scheduleDailyTrollNotifications } from './lib/reminder-service.ts';
import { LocalNotifications } from '@capacitor/local-notifications';

import { Archive, AlertTriangle, RefreshCw, Loader2, Plus, Wallet } from 'lucide-react';

export default function App() {
  const [cachedLastUserId, setCachedLastUserId] = useState<string | null>(() => {
    return localStorage.getItem('splito_last_user_id');
  });
  const [authChoice, setAuthChoice] = useState<string | null>(() => {
    return localStorage.getItem('splito_auth_choice') || localStorage.getItem('hisaab_auth_choice');
  });

  // Compute instant synchronous initial spaces from local storage before Firebase/Firestore resolves
  const initialLocalSpaces = useMemo<Space[]>(() => {
    const choice = localStorage.getItem('splito_auth_choice') || localStorage.getItem('hisaab_auth_choice');
    const lastUid = localStorage.getItem('splito_last_user_id');
    if (choice === 'guest') {
      try {
        const raw = localStorage.getItem('hisaab_guest_spaces');
        const guestId = localStorage.getItem('hisaab_guest_id') || 'guest_local';
        const parsed = raw ? (JSON.parse(raw) as Space[]) : [];
        return filterOutDeletedSpaces(guestId, Array.isArray(parsed) ? parsed : []);
      } catch {
        return [];
      }
    }
    if (choice === 'google' && lastUid) {
      return getLocalUserSpaces(lastUid);
    }
    return [];
  }, []);

  const [currentUser, setCurrentUser] = useState<FirebaseUser | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(() => {
    const lastUid = localStorage.getItem('splito_last_user_id');
    return lastUid ? getLocalUserProfile(lastUid) : null;
  });
  const [isAuthLoading, setIsAuthLoading] = useState<boolean>(() => {
    const choice = localStorage.getItem('splito_auth_choice') || localStorage.getItem('hisaab_auth_choice');
    const lastUid = localStorage.getItem('splito_last_user_id');
    if (choice === 'guest') return false;
    if (choice === 'google' && lastUid) return false;
    return true;
  });
  const [isSigningIn, setIsSigningIn] = useState<boolean>(false);
  const [signInError, setSignInError] = useState<string | null>(null);
  const [isOnline, setIsOnline] = useState<boolean>(() => getIsOnline());

  // Spaces & active selection — hydrated synchronously from local storage
  const [spaces, setSpaces] = useState<Space[]>(initialLocalSpaces);
  const [activeSpaceId, setActiveSpaceId] = useState<string>(() => {
    const choice = localStorage.getItem('splito_auth_choice') || localStorage.getItem('hisaab_auth_choice');
    const lastUid = localStorage.getItem('splito_last_user_id');
    const candidateId =
      (choice === 'google' && lastUid ? localStorage.getItem(`hisaab_active_space_${lastUid}`) : null) ||
      (choice === 'guest' ? localStorage.getItem('hisaab_guest_active_space') : null) ||
      localStorage.getItem('hisaab_active_space_id') ||
      '';
    if (candidateId && initialLocalSpaces.some((s) => s.id === candidateId)) {
      return candidateId;
    }
    return initialLocalSpaces[0]?.id || '';
  });
  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    const choice = localStorage.getItem('splito_auth_choice') || localStorage.getItem('hisaab_auth_choice');
    const lastUid = localStorage.getItem('splito_last_user_id');
    const candidateId =
      (choice === 'google' && lastUid ? localStorage.getItem(`hisaab_active_space_${lastUid}`) : null) ||
      (choice === 'guest' ? localStorage.getItem('hisaab_guest_active_space') : null) ||
      localStorage.getItem('hisaab_active_space_id') ||
      initialLocalSpaces[0]?.id ||
      '';
    return candidateId ? getLocalTransactions(candidateId) : [];
  });

  const activeSpace = useMemo<Space | null>(() => {
    return spaces.find((s) => s.id === activeSpaceId) || spaces[0] || null;
  }, [spaces, activeSpaceId]);

  const [isWritingToCloud, setIsWritingToCloud] = useState<boolean>(false);
  const [activeSyncError, setActiveSyncError] = useState<string | null>(null);

  // Ensure auth loading state never traps startup when offline
  useEffect(() => {
    if (!isAuthLoading) return;
    const timer = setTimeout(() => {
      setIsAuthLoading(false);
    }, 800);
    return () => clearTimeout(timer);
  }, [isAuthLoading]);

  const syncStatus = useMemo<SyncStatus>(() => {
    if (!currentUser) return 'LOCAL_ONLY';
    if (!isOnline) return 'SYNC_FAILED';
    if (activeSyncError) return 'SYNC_FAILED';
    if (isWritingToCloud) return 'SYNCING';
    if (isAuthLoading) return 'SYNCING';
    // Authoritative rule: CLOUD_CONFIRMED ONLY when the active space is verified from Firestore
    if (activeSpace && activeSpace.isCloudConfirmed) {
      return 'CLOUD_CONFIRMED';
    }
    return 'LOCAL_ONLY';
  }, [currentUser, isOnline, activeSyncError, isWritingToCloud, isAuthLoading, activeSpace]);

  // Navigation tab
  const [activeTab, setActiveTab] = useState<TabKey>('home');

  // Modals state
  const [isOnboardingOpen, setIsOnboardingOpen] = useState<boolean>(false);
  const [isSpaceSwitcherOpen, setIsSpaceSwitcherOpen] = useState<boolean>(false);
  const [isAddModalOpen, setIsAddModalOpen] = useState<boolean>(false);
  const [addModalInitialType, setAddModalInitialType] = useState<TransactionType>('expense');
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null);
  const [isSettlementModalOpen, setIsSettlementModalOpen] = useState<boolean>(false);
  const [activeSettlementDebt, setActiveSettlementDebt] = useState<DebtSettlement | null>(null);
  const [initialSettlementSlipView, setInitialSettlementSlipView] = useState<boolean>(false);
  const [isReceiptCaptureOpen, setIsReceiptCaptureOpen] = useState<boolean>(false);
  const [isPdfExportOpen, setIsPdfExportOpen] = useState<boolean>(false);
  const [isWalletPayOpen, setIsWalletPayOpen] = useState<boolean>(false);
  const [walletPayInitialTransaction, setWalletPayInitialTransaction] = useState<Transaction | null>(null);

  // Subscription & Entitlement State
  const [subscription, setSubscription] = useState<UserSubscription>(() => {
    return getLocalSubscription();
  });
  const entitlement = useMemo<SubscriptionEntitlement>(() => {
    return calculateEntitlement(subscription);
  }, [subscription]);

  // Monetization & Legal Modals
  const [isSubscriptionModalOpen, setIsSubscriptionModalOpen] = useState<boolean>(false);
  const [isLegalModalOpen, setIsLegalModalOpen] = useState<boolean>(false);
  const [activeLegalDocKey, setActiveLegalDocKey] = useState<LegalDocKey>('user_agreement');
  const [isConsentModalOpen, setIsConsentModalOpen] = useState<boolean>(false);
  const [isDeleteDataModalOpen, setIsDeleteDataModalOpen] = useState<boolean>(false);
  const [isAccountDeletionModalOpen, setIsAccountDeletionModalOpen] = useState<boolean>(false);
  const [isRewardedAdModalOpen, setIsRewardedAdModalOpen] = useState<boolean>(false);
  const [pendingExportType, setPendingExportType] = useState<'pdf' | 'csv'>('pdf');
  const [rewardedAdsCompleted, setRewardedAdsCompleted] = useState<number>(() => {
    const saved = localStorage.getItem('splito_rewarded_ads_completed');
    return saved ? parseInt(saved, 10) : 0;
  });

  const handleUpdateRewardedAdsCompleted = (newCount: number) => {
    setRewardedAdsCompleted(newCount);
    localStorage.setItem('splito_rewarded_ads_completed', String(newCount));
  };

  const handleTriggerRewardedAd = (type: 'pdf' | 'csv' = 'pdf') => {
    setPendingExportType(type);
    setIsRewardedAdModalOpen(true);
  };

  // Prefill states for transaction review from receipt capture
  const [prefillData, setPrefillData] = useState<{
    title?: string;
    amountMinorUnits?: number;
    category?: string;
    date?: string;
    paymentMethod?: PaymentMethod;
    receiptPreviewUrl?: string;
  } | null>(null);

  // Fallback guest identifier
  const [localGuestId] = useState<string>(() => {
    let id = localStorage.getItem('hisaab_guest_id');
    if (!id) {
      id = `guest_${Date.now()}`;
      localStorage.setItem('hisaab_guest_id', id);
    }
    return id;
  });

  const cloudUserId =
    (typeof auth !== 'undefined' && auth.currentUser?.uid) ||
    currentUser?.uid ||
    (authChoice === 'google' ? cachedLastUserId : null);
  const effectiveUserId = cloudUserId || localGuestId;
  const effectiveUserName =
    currentUser?.displayName ||
    userProfile?.displayName ||
    (currentUser?.email ? currentUser.email.split('@')[0] : 'Guest User');

  // Profile Photo (DP) stored locally across restarts (PF-06)
  const [profilePhoto, setProfilePhoto] = useState<string | null>(() => {
    return localStorage.getItem('splito_profile_photo') || null;
  });

  const handleUpdateProfilePhoto = (newPhoto: string | null) => {
    setProfilePhoto(newPhoto);
    if (newPhoto) {
      localStorage.setItem('splito_profile_photo', newPhoto);
    } else {
      localStorage.removeItem('splito_profile_photo');
    }
  };

  // Offline-First network & migration states
  const [isStartupOfflineAlertOpen, setIsStartupOfflineAlertOpen] = useState<boolean>(false);
  const isStartupOfflineAlertOpenRef = useRef<boolean>(false);
  const startupOfflineAlertDismissedRef = useRef<boolean>(false);
  const isSubmittingOnboardingRef = useRef<boolean>(false);
  const [guestMigrationSpaces, setGuestMigrationSpaces] = useState<Space[]>([]);
  const [isGuestMigrationOpen, setIsGuestMigrationOpen] = useState<boolean>(false);

  const offlineDialogControllerRef = useRef<ReturnType<typeof createOfflineDialogController> | null>(null);
  if (!offlineDialogControllerRef.current) {
    offlineDialogControllerRef.current = createOfflineDialogController({
      refreshStatus: refreshNetworkStatus,
      isDialogOpen: () => isStartupOfflineAlertOpenRef.current && !startupOfflineAlertDismissedRef.current,
      onDismissDialog: () => {
        startupOfflineAlertDismissedRef.current = true;
        isStartupOfflineAlertOpenRef.current = false;
        setIsStartupOfflineAlertOpen(false);
        try {
          sessionStorage.setItem('splito_startup_offline_alert_dismissed', 'true');
        } catch {}
      },
      onSetOnline: (connected) => {
        setIsOnline(connected);
      },
      onDrainQueue: () => drainQueue(),
      debounceMs: 250
    });
  }

  // Reliable Network Detection & Offline Outbox Startup
  useEffect(() => {
    let cancelled = false;

    initializeNetworkDetection().then((status) => {
      if (cancelled) return;
      setIsOnline(status.connected);
      if (!status.connected && !startupOfflineAlertDismissedRef.current) {
        let dismissed = false;
        try {
          dismissed = sessionStorage.getItem('splito_startup_offline_alert_dismissed') === 'true';
        } catch {}
        if (!dismissed) {
          offlineDialogControllerRef.current?.reset();
          isStartupOfflineAlertOpenRef.current = true;
          setIsStartupOfflineAlertOpen(true);
        }
      } else if (status.connected) {
        offlineDialogControllerRef.current?.handleNetworkChange(true);
      }
    });

    const unsubNetwork = subscribeNetworkStatus((status) => {
      setIsOnline(status.connected);
      offlineDialogControllerRef.current?.handleNetworkChange(status.connected);
    });

    initializeOfflineQueue().then(() => {
      if (getIsOnline()) {
        drainQueue().catch(() => {});
      }
    });

    return () => {
      cancelled = true;
      unsubNetwork();
      offlineDialogControllerRef.current?.cleanup();
    };
  }, []);

  // 1. Initial connection test and Auth listener (local-first, never blocks UI on network)
  useEffect(() => {
    if (getIsOnline()) {
      testConnection().catch(() => {});
    }

    const unsubscribeAuth = onAuthStateChanged(auth, (firebaseUser) => {
      setCurrentUser(firebaseUser);
      setIsAuthLoading(false);

      if (firebaseUser) {
        setAuthChoice('google');
        setCachedLastUserId(firebaseUser.uid);
        localStorage.setItem('splito_auth_choice', 'google');
        localStorage.setItem('splito_last_user_id', firebaseUser.uid);

        const userKey = `hisaab_active_space_${firebaseUser.uid}`;
        const rememberedId = localStorage.getItem(userKey);
        if (rememberedId) {
          setActiveSpaceId(rememberedId);
        }

        // Hydrate cached profile and spaces immediately before any cloud calls
        const cachedProfile = getLocalUserProfile(firebaseUser.uid);
        if (cachedProfile) {
          setUserProfile(cachedProfile);
        }

        const localSpaces = getLocalUserSpaces(firebaseUser.uid);
        if (localSpaces.length > 0) {
          setSpaces(localSpaces);
          setIsOnboardingOpen(false);
          if (rememberedId && localSpaces.some((s) => s.id === rememberedId)) {
            setActiveSpaceId(rememberedId);
          } else {
            setActiveSpaceId((prev) =>
              prev && localSpaces.some((s) => s.id === prev) ? prev : localSpaces[0].id
            );
          }
        }

        // Check for existing local guest spaces to offer migration
        const savedGuestSpaces = localStorage.getItem('hisaab_guest_spaces');
        const migrationDismissed = sessionStorage.getItem('splito_guest_migration_dismissed');
        if (savedGuestSpaces && !migrationDismissed) {
          try {
            const parsed = JSON.parse(savedGuestSpaces) as Space[];
            if (parsed.length > 0) {
              setGuestMigrationSpaces(parsed);
              setIsGuestMigrationOpen(true);
            }
          } catch {}
        }

        // Non-blocking background profile & subscription sync
        const googleName =
          firebaseUser.displayName || (firebaseUser.email ? firebaseUser.email.split('@')[0] : 'User');
        syncUserProfile(firebaseUser.uid, firebaseUser.email, googleName, 'roommates')
          .then((profile) => {
            if (profile) {
              setUserProfile(profile);
              if (!rememberedId && profile.activeSpaceId) {
                setActiveSpaceId((prev) => prev || profile.activeSpaceId);
                localStorage.setItem(userKey, profile.activeSpaceId);
              }
            }
          })
          .catch((err) => console.warn('Profile sync notice:', err));

        if (getIsOnline()) {
          fetchUserSubscription(firebaseUser.uid)
            .then((sub) => setSubscription(sub))
            .catch(() => {});
          drainQueue().catch(() => {});
        }
      } else {
        setActiveSyncError(null);
        setSubscription(getLocalSubscription());
        localStorage.removeItem('splito_last_user_id');
        setCachedLastUserId(null);

        // Guest mode fallback: check guest storage
        const savedGuestSpaces = localStorage.getItem('hisaab_guest_spaces');
        const savedGuestActiveId =
          localStorage.getItem('hisaab_guest_active_space') || localStorage.getItem('hisaab_active_space_id');
        if (savedGuestSpaces) {
          try {
            const parsed = JSON.parse(savedGuestSpaces) as Space[];
            const guestSpaces = filterOutDeletedSpaces(
              localGuestId,
              parsed.map((s) => ({
                ...s,
                isCloudConfirmed: false,
                source: 'local-provisional' as const
              }))
            );
            setSpaces(guestSpaces);
            if (guestSpaces.length > 0) {
              if (savedGuestActiveId && guestSpaces.some((s) => s.id === savedGuestActiveId)) {
                setActiveSpaceId(savedGuestActiveId);
              } else {
                setActiveSpaceId(guestSpaces[0].id);
                localStorage.setItem('hisaab_guest_active_space', guestSpaces[0].id);
              }
            } else {
              setActiveSpaceId('');
              setTransactions([]);
            }
          } catch (e) {
            console.error('Error loading guest spaces:', e);
            setSpaces([]);
            setActiveSpaceId('');
            setTransactions([]);
          }
        } else {
          // Clean first launch: start with 0 spaces and zero demo data
          setSpaces([]);
          setActiveSpaceId('');
          setTransactions([]);
        }
      }
    });

    return () => unsubscribeAuth();
  }, []);

  // 2. Real-time Spaces subscription for authenticated users (local-first hydration + safe background sync)
  useEffect(() => {
    const activeUid = currentUser?.uid || (authChoice === 'google' ? cachedLastUserId : null);
    if (!activeUid) return;

    // Immediately ensure local spaces are rendered synchronously
    const immediateLocal = getLocalUserSpaces(activeUid);
    if (immediateLocal.length > 0) {
      setSpaces(immediateLocal);
      setIsOnboardingOpen(false);
    }

    if (!currentUser) return;

    const unsubscribeSpaces = subscribeToUserSpaces(
      currentUser.uid,
      (fetchedSpaces, meta) => {
        setSpaces(fetchedSpaces);
        if (fetchedSpaces.length === 0) {
          const isConfirmedServerEmpty = meta?.fromCache === false && getIsOnline();
          const localSpaces = getLocalUserSpaces(currentUser.uid);
          // Only open onboarding when confirmed online by server with zero cloud spaces AND zero local spaces
          if (isConfirmedServerEmpty && localSpaces.length === 0) {
            setIsOnboardingOpen(true);
          }
        } else {
          setIsOnboardingOpen(false);
          setActiveSpaceId((currentId) => {
            // Priority 1: Current ID matches an authorized space doc
            if (currentId && fetchedSpaces.some((s) => s.id === currentId)) {
              return currentId;
            }
            // Priority 2: Stored active space ID for this authenticated user
            const userKey = `hisaab_active_space_${currentUser.uid}`;
            const userStoredId = localStorage.getItem(userKey);
            if (userStoredId && fetchedSpaces.some((s) => s.id === userStoredId)) {
              return userStoredId;
            }
            // Priority 3: User profile preference in Firestore matches an authorized space doc
            if (userProfile?.activeSpaceId && fetchedSpaces.some((s) => s.id === userProfile.activeSpaceId)) {
              return userProfile.activeSpaceId;
            }
            // Priority 4: Stored legacy active space ID matches
            const storedLegacyId = localStorage.getItem('hisaab_active_space_id');
            if (storedLegacyId && fetchedSpaces.some((s) => s.id === storedLegacyId)) {
              return storedLegacyId;
            }
            // Priority 5: First space from authorized server set
            const fallbackId = fetchedSpaces[0].id;
            localStorage.setItem(userKey, fallbackId);
            localStorage.setItem('hisaab_active_space_id', fallbackId);
            return fallbackId;
          });
        }
      },
      (error) => {
        const localSpaces = getLocalUserSpaces(currentUser.uid);
        if (localSpaces.length > 0) {
          setSpaces(localSpaces);
        } else {
          setActiveSyncError(error.message);
          console.warn('Spaces subscription notice:', error.message);
        }
      }
    );

    return () => {
      if (unsubscribeSpaces) unsubscribeSpaces();
    };
  }, [currentUser, authChoice, cachedLastUserId, userProfile?.activeSpaceId]);

  // 3. Real-time Transactions subscription for active space (local cache first, background sync)
  useEffect(() => {
    if (!activeSpaceId) {
      setTransactions([]);
      return;
    }

    const cachedTx = getLocalTransactions(activeSpaceId);
    if (cachedTx.length > 0) {
      setTransactions(cachedTx);
    }

    if (currentUser) {
      const unsubscribeTx = subscribeToTransactions(
        activeSpaceId,
        (fetched) => {
          setTransactions(fetched);
          setActiveSyncError(null);
        },
        (error) => {
          const localTx = getLocalTransactions(activeSpaceId);
          if (localTx.length > 0) {
            setTransactions(localTx);
          } else {
            setActiveSyncError(error.message);
            console.warn('Transactions subscription notice:', error.message);
          }
        }
      );
      return () => {
        if (unsubscribeTx) unsubscribeTx();
      };
    } else {
      const key = `hisaab_local_tx_${activeSpaceId}`;
      const saved = localStorage.getItem(key);
      if (saved) {
        try {
          setTransactions(JSON.parse(saved));
        } catch (e) {
          setTransactions([]);
        }
      } else {
        setTransactions([]);
      }
    }
  }, [currentUser, activeSpaceId]);

  const saveGuestTransactions = (newTxList: Transaction[]) => {
    if (!currentUser && activeSpaceId) {
      localStorage.setItem(`hisaab_local_tx_${activeSpaceId}`, JSON.stringify(newTxList));
    }
  };

  // Pure finance calculations:
  const actualBalanceBreakdown = useMemo(() => {
    if (!activeSpace) {
      return {
        startingBalance: 0,
        receivedIncome: 0,
        paidExpenses: 0,
        incomingTransfers: 0,
        outgoingTransfers: 0,
        actualBalance: 0
      };
    }
    return calculateSpaceLedgerBalance(activeSpace, transactions, effectiveUserId);
  }, [activeSpace, transactions, effectiveUserId]);

  const memberBalances = useMemo(() => {
    if (!activeSpace) return [];
    return calculateGroupBalances(activeSpace.members || [], transactions);
  }, [activeSpace, transactions]);

  const debtSettlements = useMemo(() => {
    return calculateDebtSettlements(memberBalances);
  }, [memberBalances]);

  // Persistently select active space across storage and user profile
  const handleSelectActiveSpace = useCallback(
    (spaceId: string) => {
      setActiveSpaceId(spaceId);
      localStorage.setItem('hisaab_active_space_id', spaceId);
      if (currentUser) {
        localStorage.setItem(`hisaab_active_space_${currentUser.uid}`, spaceId);
        updateUserActiveSpace(currentUser.uid, spaceId).catch(() => {});
        setUserProfile((prev) => (prev ? { ...prev, activeSpaceId: spaceId } : null));
      } else {
        localStorage.setItem('hisaab_guest_active_space', spaceId);
      }
    },
    [currentUser]
  );

  const spacesRef = useRef<Space[]>(spaces);
  spacesRef.current = spaces;
  const handleSelectActiveSpaceRef = useRef(handleSelectActiveSpace);
  handleSelectActiveSpaceRef.current = handleSelectActiveSpace;

  const hasSpaces = spaces.length > 0;

  // Schedule 10/day funny reminders once spaces are ready and verify on foreground resume
  useEffect(() => {
    if (!hasSpaces) return;

    scheduleDailyTrollNotifications({ fromUserAction: false }).catch((err) => {
      console.warn('Expense reminders scheduling notice:', err);
    });

    const handleVisibility = () => {
      if (typeof document !== 'undefined' && document.visibilityState === 'visible') {
        scheduleDailyTrollNotifications({ fromUserAction: false }).catch(() => {});
      }
    };
    if (typeof document !== 'undefined') {
      document.addEventListener('visibilitychange', handleVisibility);
    }
    return () => {
      if (typeof document !== 'undefined') {
        document.removeEventListener('visibilitychange', handleVisibility);
      }
    };
  }, [hasSpaces]);

  // Handle tapping on a local notification cleanly without listener teardown races
  useEffect(() => {
    let isMounted = true;
    let removeListener: (() => void) | null = null;
    try {
      LocalNotifications.addListener('localNotificationActionPerformed', (action) => {
        if (!isMounted) return;
        const extra = action?.notification?.extra;
        if (extra?.mode) {
          const matchingSpace = spacesRef.current.find((s) => s.mode === extra.mode);
          if (matchingSpace) {
            handleSelectActiveSpaceRef.current(matchingSpace.id);
          }
        }
        setActiveTab('home');
      }).then((handle) => {
        if (handle && handle.remove) {
          if (!isMounted) {
            handle.remove();
          } else {
            removeListener = () => handle.remove();
          }
        }
      }).catch(() => {});
    } catch {
      // In web preview without plugin, proceed silently
    }

    return () => {
      isMounted = false;
      if (removeListener) removeListener();
    };
  }, []);

  // Handlers for Onboarding completion (strictly local-first, instant navigation, duplicate-proof)
  const handleOnboardingComplete = async (data: {
    mode: SpaceMode;
    spaceName: string;
    startingBalancePaise: number;
    currency: CurrencyCode;
    initialMembers: string[];
  }) => {
    if (isSubmittingOnboardingRef.current) return;
    isSubmittingOnboardingRef.current = true;

    try {
      const spaceId = `sp_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
      const effectiveUid = (typeof auth !== 'undefined' && auth.currentUser?.uid) || currentUser?.uid || localGuestId;

      const memberObjects: Member[] = [
        {
          id: effectiveUid,
          name: effectiveUserName,
          email: currentUser?.email || '',
          avatarColor: '#2563eb',
          isCurrentUser: true,
          role: 'owner'
        }
      ];

      data.initialMembers.forEach((name, i) => {
        memberObjects.push({
          id: `m_${Date.now()}_${i}`,
          name,
          avatarColor: ['#10b981', '#f59e0b', '#8b5cf6', '#ec4899'][i % 4],
          role: 'member'
        });
      });

      const now = new Date().toISOString();
      const newSpace: Space = {
        id: spaceId,
        ownerId: effectiveUid,
        name: data.spaceName,
        mode: data.mode,
        currency: data.currency,
        startingBalance: data.startingBalancePaise,
        memberIds: memberObjects.map((m) => m.id),
        members: memberObjects,
        version: 1,
        isArchived: false,
        createdAt: now,
        updatedAt: now
      };

      if (cloudUserId) {
        setActiveSyncError(null);
        const localSpace = await createSpace(newSpace);
        setSpaces((prev) => [localSpace, ...prev.filter((s) => s.id !== localSpace.id)]);
        setActiveSpaceId(localSpace.id);
        localStorage.setItem(`hisaab_active_space_${cloudUserId}`, localSpace.id);
        localStorage.setItem('hisaab_active_space_id', localSpace.id);
        setUserProfile((prev) => (prev ? { ...prev, activeSpaceId: localSpace.id } : null));
        setIsOnboardingOpen(false);
        // Non-blocking background profile preference update
        updateUserActiveSpace(cloudUserId, localSpace.id).catch(() => {});
      } else {
        const guestSpace: Space = {
          ...newSpace,
          isCloudConfirmed: false,
          source: 'local-provisional'
        };
        const updated = [guestSpace, ...spaces.filter((s) => s.id !== guestSpace.id)];
        localStorage.setItem('hisaab_guest_spaces', JSON.stringify(updated));
        setSpaces(updated);
        handleSelectActiveSpace(spaceId);
        setIsOnboardingOpen(false);
      }
    } finally {
      isSubmittingOnboardingRef.current = false;
    }
  };

  // Create new Space from Space Switcher (local-first, instant)
  const handleCreateNewSpace = async (data: {
    name: string;
    mode: SpaceMode;
    currency: CurrencyCode;
    startingBalancePaise: number;
    members: string[];
  }) => {
    const spaceId = `sp_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const effectiveUid = (typeof auth !== 'undefined' && auth.currentUser?.uid) || currentUser?.uid || localGuestId;

    const memberObjects: Member[] = [
      {
        id: effectiveUid,
        name: effectiveUserName,
        email: currentUser?.email || '',
        avatarColor: '#2563eb',
        isCurrentUser: true,
        role: 'owner'
      }
    ];

    data.members.forEach((name, i) => {
      memberObjects.push({
        id: `m_${Date.now()}_${i}`,
        name,
        avatarColor: ['#10b981', '#f59e0b', '#8b5cf6', '#ec4899'][i % 4],
        role: 'member'
      });
    });

    const now = new Date().toISOString();
    const newSpace: Space = {
      id: spaceId,
      ownerId: effectiveUid,
      name: data.name,
      mode: data.mode,
      currency: data.currency,
      startingBalance: data.startingBalancePaise,
      memberIds: memberObjects.map((m) => m.id),
      members: memberObjects,
      version: 1,
      isArchived: false,
      createdAt: now,
      updatedAt: now
    };

    if (cloudUserId) {
      setActiveSyncError(null);
      const localSpace = await createSpace(newSpace);
      setSpaces((prev) => [localSpace, ...prev.filter((s) => s.id !== localSpace.id)]);
      setActiveSpaceId(localSpace.id);
      localStorage.setItem(`hisaab_active_space_${cloudUserId}`, localSpace.id);
      localStorage.setItem('hisaab_active_space_id', localSpace.id);
      setUserProfile((prev) => (prev ? { ...prev, activeSpaceId: localSpace.id } : null));
      updateUserActiveSpace(cloudUserId, localSpace.id).catch(() => {});
    } else {
      const guestSpace: Space = {
        ...newSpace,
        isCloudConfirmed: false,
        source: 'local-provisional'
      };
      const updated = [guestSpace, ...spaces.filter((s) => s.id !== guestSpace.id)];
      localStorage.setItem('hisaab_guest_spaces', JSON.stringify(updated));
      setSpaces(updated);
      handleSelectActiveSpace(spaceId);
    }
  };

  // Add / Save transaction (local-first, instant UI update, background outbox sync)
  const handleSaveTransaction = async (tx: Transaction) => {
    if (!activeSpace) return;

    if (cloudUserId) {
      try {
        if (editingTransaction) {
          await updateTransaction(activeSpace.id, tx.id, tx);
          setTransactions((prev) => prev.map((t) => (t.id === tx.id ? tx : t)));
        } else {
          const savedTx = await addTransaction(activeSpace.id, tx);
          setTransactions((prev) => [savedTx, ...prev.filter((t) => t.id !== savedTx.id)]);
        }
        setActiveSyncError(null);
      } catch (err) {
        const errorMsg = err instanceof Error ? err.message : String(err);
        setActiveSyncError(errorMsg);
        throw err;
      }
    } else {
      let updated: Transaction[];
      if (editingTransaction) {
        updated = transactions.map((t) => (t.id === tx.id ? tx : t));
      } else {
        updated = [tx, ...transactions];
      }
      setTransactions(updated);
      saveGuestTransactions(updated);
    }
    setEditingTransaction(null);
    setPrefillData(null);
  };

  // Immutable Reversal of transaction (local-first, instant UI update)
  const handleReverseTransaction = async (tx: Transaction) => {
    if (!activeSpace) return;

    if (cloudUserId) {
      try {
        const { originalUpdated, reversalTx } = await reverseLedgerTransaction(
          activeSpace.id,
          tx,
          effectiveUserId,
          effectiveUserName
        );
        setTransactions((prev) => [
          reversalTx,
          ...prev.map((t) => (t.id === tx.id ? originalUpdated : t))
        ]);
        setActiveSyncError(null);
      } catch (err) {
        const errorMsg = err instanceof Error ? err.message : String(err);
        setActiveSyncError(errorMsg);
        throw err;
      }
    } else {
      const { originalUpdated, reversalTx } = createReversalTransaction(tx, effectiveUserId);
      const updated = transactions.map((t) => (t.id === tx.id ? originalUpdated : t));
      const withReversal = [reversalTx, ...updated];
      setTransactions(withReversal);
      saveGuestTransactions(withReversal);
    }
  };

  // Hard deletion fallback (local-first, instant UI update)
  const handleDeleteTransaction = async (txId: string) => {
    if (!activeSpace) return;

    if (cloudUserId) {
      try {
        await deleteTransaction(activeSpace.id, txId);
        setTransactions((prev) => prev.filter((t) => t.id !== txId));
        setActiveSyncError(null);
      } catch (err) {
        const errorMsg = err instanceof Error ? err.message : String(err);
        setActiveSyncError(errorMsg);
        throw err;
      }
    } else {
      const updated = transactions.filter((t) => t.id !== txId);
      setTransactions(updated);
      saveGuestTransactions(updated);
    }
  };

  // Update space details (local-first, instant UI update)
  const handleUpdateSpaceDetails = async (updates: Partial<Space>) => {
    if (!activeSpace) return;

    if (cloudUserId) {
      await updateSpaceDetails(activeSpace.id, updates, cloudUserId);
      setSpaces((prev) =>
        prev.map((s) =>
          s.id === activeSpace.id
            ? { ...s, ...updates, version: (s.version || 1) + 1, updatedAt: new Date().toISOString() }
            : s
        )
      );
    } else {
      const updatedSpaces = spaces.map((s) => (s.id === activeSpace.id ? { ...s, ...updates } : s));
      setSpaces(updatedSpaces);
      localStorage.setItem('hisaab_guest_spaces', JSON.stringify(updatedSpaces));
      localStorage.setItem('hisaab_local_spaces', JSON.stringify(updatedSpaces));
    }
  };

  // Add member to space
  const handleAddMemberToSpace = async (memberName: string, memberEmail?: string) => {
    if (!activeSpace) return;
    const newMember: Member = {
      id: `m_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`,
      name: memberName,
      email: memberEmail,
      avatarColor: '#10b981',
      role: 'member'
    };

    const updatedMembers = [...(activeSpace.members || []), newMember];
    const updatedMemberIds = updatedMembers.map((m) => m.id);

    await handleUpdateSpaceDetails({
      members: updatedMembers,
      memberIds: updatedMemberIds
    });
  };

  // Guest to Signed-In Cloud Migration (Section 2G)
  const handleMigrateGuestData = async () => {
    if (!currentUser || guestMigrationSpaces.length === 0) {
      return { success: false, migratedSpaces: 0, migratedTx: 0, error: 'No user or guest data.' };
    }

    let migratedSpaces = 0;
    let migratedTx = 0;
    const remainingGuestSpaces: Space[] = [];

    for (const guestSpace of guestMigrationSpaces) {
      try {
        const spacePayload: Space = {
          ...guestSpace,
          ownerId: currentUser.uid,
          memberIds: Array.from(new Set([currentUser.uid, ...(guestSpace.memberIds || [])])),
          isCloudConfirmed: true,
          source: 'cloud-authoritative'
        };

        const spaceRef = doc(db, 'spaces', guestSpace.id);
        await setDoc(spaceRef, spacePayload);
        const sSnap = await getDocFromServer(spaceRef);
        if (!sSnap.exists()) {
          throw new Error(`Server confirmation failed for space ${guestSpace.id}`);
        }
        migratedSpaces++;

        const txKey = `hisaab_local_tx_${guestSpace.id}`;
        const txRaw = localStorage.getItem(txKey);
        const spaceTransactions: Transaction[] = txRaw ? JSON.parse(txRaw) : [];

        for (const tx of spaceTransactions) {
          try {
            await pushTransactionToCloud(guestSpace.id, {
              ...tx,
              creatorId: currentUser.uid,
              spaceId: guestSpace.id
            });
            migratedTx++;
          } catch (txErr) {
            console.warn('Migration tx upload notice:', txErr);
          }
        }

        // Only clear local copies after successful server confirmation
        localStorage.removeItem(txKey);
      } catch (spErr) {
        console.warn('Migration space upload failed, retaining local copy:', spErr);
        remainingGuestSpaces.push(guestSpace);
      }
    }

    localStorage.setItem('hisaab_guest_spaces', JSON.stringify(remainingGuestSpaces));
    setGuestMigrationSpaces(remainingGuestSpaces);

    if (remainingGuestSpaces.length > 0) {
      return {
        success: false,
        migratedSpaces,
        migratedTx,
        error: `Partially completed. ${remainingGuestSpaces.length} space(s) preserved locally.`
      };
    }

    return { success: true, migratedSpaces, migratedTx };
  };

  // Auth actions
  const handleLogin = async () => {
    setIsSigningIn(true);
    setSignInError(null);
    try {
      await loginWithGoogle();
      setAuthChoice('google');
      localStorage.setItem('splito_auth_choice', 'google');
    } catch (err) {
      console.error('Login failed:', err);
      const msg = err instanceof Error ? err.message : String(err);
      setSignInError(msg || 'Google Sign-In failed. Please try again.');
    } finally {
      setIsSigningIn(false);
    }
  };

  const handleContinueAsGuest = () => {
    setAuthChoice('guest');
    localStorage.setItem('splito_auth_choice', 'guest');
    const savedGuestSpaces = localStorage.getItem('hisaab_guest_spaces');
    if (savedGuestSpaces) {
      try {
        const parsed = JSON.parse(savedGuestSpaces) as Space[];
        setSpaces(parsed);
        const guestActive = localStorage.getItem('hisaab_guest_active_space');
        if (guestActive && parsed.some((s) => s.id === guestActive)) {
          setActiveSpaceId(guestActive);
        } else if (parsed.length > 0) {
          setActiveSpaceId(parsed[0].id);
        } else {
          setActiveSpaceId('');
        }
      } catch (e) {
        setSpaces([]);
        setActiveSpaceId('');
      }
    } else {
      localStorage.setItem('hisaab_guest_spaces', JSON.stringify([]));
      setSpaces([]);
      setActiveSpaceId('');
      setTransactions([]);
    }
  };

  const handleLogout = async () => {
    try {
      await logoutUser();
      setUserProfile(null);
      setCurrentUser(null);
      setCachedLastUserId(null);
      localStorage.removeItem('splito_last_user_id');
      localStorage.removeItem('splito_auth_choice');
      localStorage.removeItem('hisaab_auth_choice');
      localStorage.removeItem('hisaab_guest_active_space');
      localStorage.removeItem('hisaab_active_space_id');
      setAuthChoice(null);
      setSpaces([]);
      setActiveSpaceId('');
      setTransactions([]);
    } catch (err) {
      console.error('Logout failed:', err);
    }
  };

  // Safe Space Management Handlers (local-first, instant UI update, background outbox sync)
  const handleArchiveSpace = async (spaceId: string) => {
    if (cloudUserId) {
      await archiveSpace(spaceId, cloudUserId);
      setSpaces((prev) => prev.map((s) => (s.id === spaceId ? { ...s, isArchived: true } : s)));
      setActiveSyncError(null);
    } else {
      const updated = spaces.map((s) => (s.id === spaceId ? { ...s, isArchived: true } : s));
      setSpaces(updated);
      localStorage.setItem('hisaab_guest_spaces', JSON.stringify(updated));
    }
  };

  const handleUnarchiveSpace = async (spaceId: string) => {
    if (cloudUserId) {
      await unarchiveSpace(spaceId, cloudUserId);
      setSpaces((prev) => prev.map((s) => (s.id === spaceId ? { ...s, isArchived: false } : s)));
      setActiveSyncError(null);
    } else {
      const updated = spaces.map((s) => (s.id === spaceId ? { ...s, isArchived: false } : s));
      setSpaces(updated);
      localStorage.setItem('hisaab_guest_spaces', JSON.stringify(updated));
    }
  };

  const handleDeleteSpace = async (spaceId: string, spaceName: string) => {
    if (cloudUserId) {
      await deleteEmptySpace(spaceId, cloudUserId, spaceName);
      const remaining = spaces.filter((s) => s.id !== spaceId);
      setSpaces(remaining);
      if (activeSpaceId === spaceId) {
        const fallbackId = remaining[0]?.id || '';
        handleSelectActiveSpace(fallbackId);
      }
      setActiveSyncError(null);
    } else {
      const remaining = spaces.filter((s) => s.id !== spaceId);
      setSpaces(remaining);
      localStorage.setItem('hisaab_guest_spaces', JSON.stringify(remaining));
      if (activeSpaceId === spaceId) {
        const fallbackId = remaining[0]?.id || '';
        handleSelectActiveSpace(fallbackId);
      }
    }
  };

  const handleOpenAddModal = (type: TransactionType) => {
    if (activeSpace?.isArchived && type !== 'settlement') {
      alert('This space is archived and in read-only audit mode. New expenses or transfers cannot be added to an archived space. You can settle outstanding balances or restore the space.');
      return;
    }
    setEditingTransaction(null);
    setPrefillData(null);
    setAddModalInitialType(type);
    setIsAddModalOpen(true);
  };

  const handleOpenWalletPay = (tx?: Transaction | null) => {
    if (activeSpace?.isArchived) {
      alert('This space is archived and in read-only audit mode. New expenses or transfers cannot be added to an archived space. You can settle outstanding balances or restore the space.');
      return;
    }
    setWalletPayInitialTransaction(tx || null);
    setIsWalletPayOpen(true);
  };

  const handleUpdateTransactionPaymentStatus = async (
    txId: string,
    status: PaymentStatus,
    updatedAmountMinorUnits?: number,
    recalculatedSplits?: SplitShare[]
  ) => {
    if (!activeSpace) return;

    const existingTx = transactions.find((t) => t.id === txId);
    if (!existingTx) return;

    const previousStatus = existingTx.paymentStatus || 'paid';
    const amountChanged = typeof updatedAmountMinorUnits === 'number' && updatedAmountMinorUnits > 0 && updatedAmountMinorUnits !== existingTx.amount;
    const finalAmount = amountChanged ? updatedAmountMinorUnits : existingTx.amount;
    const finalSplits = amountChanged && recalculatedSplits ? recalculatedSplits : existingTx.splits;

    const updates: Partial<Transaction> = {
      paymentStatus: status,
      ...(amountChanged ? { amount: finalAmount, splits: finalSplits } : {}),
      ...(status === 'paid' ? { paymentConfirmedAt: new Date().toISOString() } : {})
    };

    if (currentUser) {
      setIsWritingToCloud(true);
      try {
        await updateTransaction(activeSpace.id, txId, updates);

        await recordAuditLog(activeSpace.id, {
          id: `audit_${Date.now()}_status`,
          spaceId: activeSpace.id,
          action: 'PAYMENT_STATUS_CHANGED',
          actorId: currentUser.uid,
          actorName: effectiveUserName,
          targetType: 'transaction',
          targetId: txId,
          details: `Transaction "${existingTx.title}" payment status changed from ${previousStatus} to ${status}${amountChanged ? ` (Amount updated to ${finalAmount} minor units)` : ''}`,
          timestamp: new Date().toISOString()
        });
      } catch (err: any) {
        console.warn('Error updating payment status:', err);
      } finally {
        setIsWritingToCloud(false);
      }
    }

    setTransactions((prev) =>
      prev.map((t) => (t.id === txId ? { ...t, ...updates } : t))
    );
  };

  const handleOpenEditModal = (tx: Transaction) => {
    setEditingTransaction(tx);
    setPrefillData(null);
    setIsAddModalOpen(true);
  };

  const handleOpenSettleModal = (debt: DebtSettlement | null) => {
    setActiveSettlementDebt(debt);
    setInitialSettlementSlipView(false);
    setIsSettlementModalOpen(true);
  };

  const handleOpenGenericSettlementModal = () => {
    setActiveSettlementDebt(null);
    setInitialSettlementSlipView(false);
    setIsSettlementModalOpen(true);
  };

  const handleViewSlipForDebt = (debt: DebtSettlement) => {
    setActiveSettlementDebt(debt);
    setInitialSettlementSlipView(true);
    setIsSettlementModalOpen(true);
  };

  // Receipt capture completion -> prefill Transaction review modal
  const handleProceedFromReceipt = (data: {
    title: string;
    amountMinorUnits: number;
    category: string;
    date: string;
    paymentMethod: PaymentMethod;
    receiptPreviewUrl?: string;
  }) => {
    setEditingTransaction(null);
    setPrefillData(data);
    setAddModalInitialType('expense');
    setIsAddModalOpen(true);
  };

  // Loading screen while checking initial Firebase session (skipped whenever local session/spaces already exist)
  const hasCachedUserDashboard = authChoice === 'google' && Boolean(cachedLastUserId);
  if (isAuthLoading && authChoice !== 'guest' && !hasCachedUserDashboard) {
    return (
      <div className="min-h-screen bg-[#f8fafc] text-slate-900 flex flex-col items-center justify-center p-4">
        <Loader2 className="w-8 h-8 text-blue-600 animate-spin mb-3" />
        <h2 className="text-base font-semibold text-slate-800">Connecting to SPLITO Cloud...</h2>
        <p className="text-xs text-slate-500 mt-1">Verifying your session</p>
      </div>
    );
  }

  // First-Launch Authentication Choice Screen: exactly two options (Sign in with Google, Continue as Guest)
  if (!currentUser && authChoice !== 'guest' && !hasCachedUserDashboard) {
    return (
      <AuthChoiceScreen
        onSignInWithGoogle={handleLogin}
        onContinueAsGuest={handleContinueAsGuest}
        isSigningIn={isSigningIn}
        signInError={signInError}
      />
    );
  }

  return (
    <div className="min-h-screen bg-[#f8fafc] text-slate-900 flex flex-col antialiased">
      {/* Header */}
      <Header
        currentSpace={activeSpace}
        spaces={spaces}
        userProfile={userProfile}
        currentUserEmail={currentUser?.email}
        currentUserDisplayName={currentUser?.displayName}
        profilePhotoUrl={profilePhoto}
        isAuthenticated={!!currentUser}
        isOnline={isOnline}
        syncStatus={syncStatus}
        syncErrorMessage={activeSyncError}
        onOpenSpaceSwitcher={() => setIsSpaceSwitcherOpen(true)}
        onOpenProfile={() => setActiveTab('profile')}
        onLogin={handleLogin}
        onLogout={handleLogout}
      />

      {/* Cloud Sync Diagnostic Banner */}
      {activeSyncError && (
        <div className="bg-rose-50 border-b border-rose-200/80 px-4 py-2.5 text-xs text-rose-800 flex items-center justify-between gap-3 shadow-xs">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
            <span className="font-medium">
              Firestore Cloud Notice: {activeSyncError}
            </span>
          </div>
          <button
            onClick={() => setActiveSyncError(null)}
            className="px-2.5 py-1 text-[11px] font-semibold bg-white border border-rose-200 text-rose-700 rounded-lg hover:bg-rose-50 transition-colors shrink-0 cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Archived Space Notice Banner */}
      {activeSpace?.isArchived && (
        <div className="bg-amber-500/10 border-b border-amber-300/60 px-4 py-2 text-xs font-semibold text-amber-900 flex items-center justify-center gap-2">
          <Archive className="w-4 h-4 text-amber-700" />
          <span>This space is currently archived and in read-only audit mode.</span>
        </div>
      )}

      {/* Main Content Area */}
      <main className="flex-1 max-w-4xl w-full mx-auto px-4 pt-4 sm:pt-6">
        {activeSpace ? (
          <>
            {activeTab === 'home' && (
              <HomeView
                space={activeSpace}
                transactions={transactions}
                actualBalanceBreakdown={actualBalanceBreakdown}
                memberBalances={memberBalances}
                debtSettlements={debtSettlements}
                currentUserId={effectiveUserId}
                isPro={entitlement.isPro}
                onOpenUpgradeModal={() => setIsSubscriptionModalOpen(true)}
                onOpenAddModal={handleOpenAddModal}
                onOpenReceiptCapture={() => setIsReceiptCaptureOpen(true)}
                onOpenSettleModal={handleOpenSettleModal}
                onViewAllTransactions={() => setActiveTab('transactions')}
                onViewGroups={() => setActiveTab('groups')}
                onEditTransaction={handleOpenEditModal}
              />
            )}

            {activeTab === 'transactions' && (
              <TransactionsView
                space={activeSpace}
                transactions={transactions}
                currentUserId={effectiveUserId}
                isPro={entitlement.isPro}
                onOpenUpgradeModal={() => setIsSubscriptionModalOpen(true)}
                onTriggerRewardedAd={(type) => handleTriggerRewardedAd(type)}
                onEditTransaction={handleOpenEditModal}
                onReverseTransaction={handleReverseTransaction}
                onDeleteTransaction={handleDeleteTransaction}
                onOpenAddModal={handleOpenAddModal}
                onOpenReceiptCapture={() => setIsReceiptCaptureOpen(true)}
                onOpenPdfExport={() => setIsPdfExportOpen(true)}
                onPayAgain={(tx) => handleOpenWalletPay(tx)}
              />
            )}

            {activeTab === 'groups' && (
              <GroupsView
                space={activeSpace}
                memberBalances={memberBalances}
                debtSettlements={debtSettlements}
                currentUserId={effectiveUserId}
                onOpenSettleModal={handleOpenSettleModal}
                onOpenGenericSettlementModal={handleOpenGenericSettlementModal}
                onViewSlipForDebt={handleViewSlipForDebt}
                onAddMember={handleAddMemberToSpace}
                onOpenAddModal={handleOpenAddModal}
              />
            )}

            {activeTab === 'insights' && (
              <InsightsView
                space={activeSpace}
                transactions={transactions}
                currentUserId={effectiveUserId}
                isPro={entitlement.isPro}
                onOpenUpgradeModal={() => setIsSubscriptionModalOpen(true)}
              />
            )}

            {activeTab === 'profile' && (
              <ProfileView
                space={activeSpace}
                userProfile={userProfile}
                currentUserEmail={currentUser?.email}
                currentUserDisplayName={currentUser?.displayName}
                profilePhotoUrl={profilePhoto}
                onUpdateProfilePhoto={handleUpdateProfilePhoto}
                isAuthenticated={!!currentUser}
                syncStatus={syncStatus}
                subscription={subscription}
                entitlement={entitlement}
                spaces={spaces}
                transactions={transactions}
                onLogin={handleLogin}
                onLogout={handleLogout}
                onUpdateSpaceDetails={handleUpdateSpaceDetails}
                onOpenSpaceSwitcher={() => setIsSpaceSwitcherOpen(true)}
                onOpenSubscriptionModal={() => setIsSubscriptionModalOpen(true)}
                onOpenLegalModal={(docKey) => {
                  if (docKey) setActiveLegalDocKey(docKey);
                  setIsLegalModalOpen(true);
                }}
                onOpenConsentModal={() => setIsConsentModalOpen(true)}
                onOpenDeleteDataModal={() => setIsDeleteDataModalOpen(true)}
                onOpenAccountDeletionModal={() => setIsAccountDeletionModalOpen(true)}
              />
            )}
          </>
        ) : (
          <div className="py-20 text-center max-w-sm mx-auto px-4">
            <div className="w-14 h-14 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto mb-4 border border-blue-100 shadow-xs">
              <Wallet className="w-7 h-7" />
            </div>
            <h2 className="text-lg font-bold text-slate-800">No Space Selected</h2>
            <p className="text-xs text-slate-500 mt-1.5 mb-5 leading-relaxed">
              Create your first ledger space or personal khata to start recording expenses and splitting bills.
            </p>
            <button
              onClick={() => setIsOnboardingOpen(true)}
              className="px-5 py-2.5 bg-blue-600 text-white rounded-xl text-xs font-semibold cursor-pointer shadow-sm hover:bg-blue-700 transition-colors inline-flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              <span>Create First Space</span>
            </button>
          </div>
        )}
      </main>

      {/* Floating Add Action Button */}
      {activeSpace && !activeSpace.isArchived && (
        <FloatingAddButton
          onSelectAction={handleOpenAddModal}
          onOpenWalletPay={() => handleOpenWalletPay(null)}
          spaceMode={activeSpace.mode}
          isArchived={Boolean(activeSpace.isArchived)}
        />
      )}

      {/* Mobile-first Bottom Navigation */}
      <BottomNav
        activeTab={activeTab}
        onChangeTab={setActiveTab}
        spaceMode={activeSpace?.mode}
      />

      {/* Onboarding Modal */}
      <OnboardingModal
        isOpen={isOnboardingOpen}
        onComplete={handleOnboardingComplete}
        defaultDisplayName={effectiveUserName}
      />

      {/* Space Switcher & Creation Modal */}
      <SpaceSwitcherModal
        isOpen={isSpaceSwitcherOpen}
        onClose={() => setIsSpaceSwitcherOpen(false)}
        spaces={spaces}
        activeSpaceId={activeSpaceId}
        currentUserId={effectiveUserId}
        onSelectSpace={handleSelectActiveSpace}
        onCreateSpace={handleCreateNewSpace}
        onArchiveSpace={handleArchiveSpace}
        onUnarchiveSpace={handleUnarchiveSpace}
        onDeleteSpace={handleDeleteSpace}
        currentUserName={effectiveUserName}
      />

      {/* Add / Edit Transaction Modal */}
      {activeSpace && (
        <TransactionModal
          isOpen={isAddModalOpen}
          onClose={() => {
            setIsAddModalOpen(false);
            setEditingTransaction(null);
            setPrefillData(null);
          }}
          space={activeSpace}
          currentUserId={effectiveUserId}
          initialType={addModalInitialType}
          editingTransaction={editingTransaction}
          prefillTitle={prefillData?.title}
          prefillAmountMinorUnits={prefillData?.amountMinorUnits}
          prefillCategory={prefillData?.category}
          prefillDate={prefillData?.date}
          prefillPaymentMethod={prefillData?.paymentMethod}
          prefillReceiptUrl={prefillData?.receiptPreviewUrl}
          onOpenReceiptCapture={() => {
            setIsAddModalOpen(false);
            setIsReceiptCaptureOpen(true);
          }}
          onSave={handleSaveTransaction}
        />
      )}

      {/* SPLITO Wallet Pay Modal (PART 4 & PART 7) */}
      {activeSpace && (
        <WalletPayModal
          isOpen={isWalletPayOpen}
          onClose={() => {
            setIsWalletPayOpen(false);
            setWalletPayInitialTransaction(null);
          }}
          space={activeSpace}
          currentUserId={effectiveUserId}
          initialTransaction={walletPayInitialTransaction}
          onSaveTransaction={handleSaveTransaction}
          onUpdateTransactionStatus={handleUpdateTransactionPaymentStatus}
        />
      )}

      {/* Settlement Modal */}
      {activeSpace && (
        <SettlementModal
          isOpen={isSettlementModalOpen}
          onClose={() => {
            setIsSettlementModalOpen(false);
            setActiveSettlementDebt(null);
            setInitialSettlementSlipView(false);
          }}
          debt={activeSettlementDebt}
          space={activeSpace}
          currentUserId={effectiveUserId}
          onRecordSettlement={handleSaveTransaction}
          initialViewSlip={initialSettlementSlipView}
        />
      )}

      {/* Receipt Capture Modal (Coming Soon) */}
      <ReceiptCaptureModal
        isOpen={isReceiptCaptureOpen}
        onClose={() => setIsReceiptCaptureOpen(false)}
        currency={activeSpace?.currency || 'INR'}
        onProceedToReview={handleProceedFromReceipt}
      />

      {/* Printable Statement & PDF Export Modal */}
      {activeSpace && (
        <PdfExportModal
          isOpen={isPdfExportOpen}
          onClose={() => setIsPdfExportOpen(false)}
          space={activeSpace}
          transactions={transactions}
          memberBalances={memberBalances}
          actualBalanceBreakdown={actualBalanceBreakdown}
          isPro={entitlement.isPro}
          onTriggerRewardedAd={(type) => handleTriggerRewardedAd(type)}
        />
      )}

      {/* Subscription & Plans Modal (₹59/mo, ₹599/yr, 30-day trial) */}
      <SubscriptionModal
        isOpen={isSubscriptionModalOpen}
        onClose={() => setIsSubscriptionModalOpen(false)}
        userId={effectiveUserId}
        subscription={subscription}
        entitlement={entitlement}
        onSubscriptionUpdated={(updated) => setSubscription(updated)}
        onOpenLegalDoc={(docKey) => {
          setActiveLegalDocKey(docKey);
          setIsLegalModalOpen(true);
        }}
      />

      {/* Legal & Agreements Modal (7 Documents in English & Hindi) */}
      <LegalModal
        isOpen={isLegalModalOpen}
        onClose={() => setIsLegalModalOpen(false)}
        initialDocKey={activeLegalDocKey}
      />

      {/* Consent & Privacy Preferences Modal */}
      <ConsentModal
        isOpen={isConsentModalOpen}
        onClose={() => setIsConsentModalOpen(false)}
        onAccept={(prefs) => {
          setIsConsentModalOpen(false);
        }}
        onOpenLegalDoc={(docKey) => {
          setActiveLegalDocKey(docKey);
          setIsLegalModalOpen(true);
        }}
      />

      {/* Delete My Entries & Data Modal (Data-Only Deletion) */}
      <DeleteDataModal
        isOpen={isDeleteDataModalOpen}
        onClose={() => setIsDeleteDataModalOpen(false)}
        userEmail={currentUser?.email}
        onConfirmDeleteData={async () => {
          await deleteUserPersonalData(effectiveUserId);
          // Reload remaining authorized spaces from server
          const remainingSpaces = await fetchServerUserSpaces(effectiveUserId);
          setSpaces(remainingSpaces);
          if (remainingSpaces.length > 0) {
            setActiveSpaceId(remainingSpaces[0].id);
          } else {
            setActiveSpaceId('');
            setTransactions([]);
          }
        }}
      />

      {/* Account Deletion Modal (Secondary Location) */}
      <AccountDeletionModal
        isOpen={isAccountDeletionModalOpen}
        onClose={() => setIsAccountDeletionModalOpen(false)}
        userEmail={currentUser?.email}
        onConfirmDelete={async () => {
          await deleteUserAccountAndData(effectiveUserId);
          setSpaces([]);
          setTransactions([]);
          setUserProfile(null);
          setCurrentUser(null);
          setAuthChoice(null);
          setActiveSpaceId('');
          setSubscription(DEFAULT_FREE_SUBSCRIPTION);
        }}
      />

      {/* Optional Rewarded Ad Modal for Free Tier PDF & CSV Exports (3-Ad Gate) */}
      <RewardedAdModal
        isOpen={isRewardedAdModalOpen}
        onClose={() => setIsRewardedAdModalOpen(false)}
        exportType={pendingExportType}
        completedAds={rewardedAdsCompleted}
        totalAdsRequired={3}
        onAdCompleted={handleUpdateRewardedAdsCompleted}
        onRewardGranted={async () => {
          setIsRewardedAdModalOpen(false);
          handleUpdateRewardedAdsCompleted(0);
          if (activeSpace) {
            if (pendingExportType === 'csv') {
              await exportCsvStatement(activeSpace, transactions);
            } else {
              await exportPdfStatement(activeSpace, transactions, memberBalances, actualBalanceBreakdown);
            }
          }
        }}
        onOpenUpgradeModal={() => setIsSubscriptionModalOpen(true)}
      />

      {/* Startup Offline Alert Modal (Section 2I & Offline Dialog Behavior Fix) */}
      <StartupOfflineAlertModal
        isOpen={isStartupOfflineAlertOpen}
        isOnline={isOnline}
        onClose={() => {
          offlineDialogControllerRef.current?.handleManualDismiss();
        }}
        onUseOffline={() => {
          offlineDialogControllerRef.current?.handleUseOffline();
        }}
        onUseOnline={() => {
          return offlineDialogControllerRef.current
            ? offlineDialogControllerRef.current.handleUseOnline()
            : false;
        }}
      />

      {/* Guest to Signed-In Account Migration Modal (Section 2G) */}
      <GuestMigrationModal
        isOpen={isGuestMigrationOpen}
        guestSpaces={guestMigrationSpaces}
        onClose={() => {
          setIsGuestMigrationOpen(false);
          sessionStorage.setItem('splito_guest_migration_dismissed', 'true');
        }}
        onNotNow={() => {
          setIsGuestMigrationOpen(false);
          sessionStorage.setItem('splito_guest_migration_dismissed', 'true');
        }}
        onMigrate={handleMigrateGuestData}
      />
    </div>
  );
}
