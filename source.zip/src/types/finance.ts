/**
 * Domain types for HISAAB Financial Ledger
 * Definitive Spec Version 1.2
 * 
 * Rules:
 * 1. ALL money is stored and computed as integer minor units (e.g., paise for INR, cents for USD, yen for JPY, fils for KWD).
 * 2. Never use floating-point arithmetic for monetary calculations.
 * 3. Taglines: "Every Rupee. Accounted For." / "Every currency. Every transaction. Accounted for."
 */

export type CurrencyCode =
  | 'INR'
  | 'USD'
  | 'EUR'
  | 'GBP'
  | 'JPY'
  | 'KWD'
  | 'AED'
  | 'SGD'
  | 'CAD'
  | 'AUD'
  | 'CHF';

export type SpaceMode = 'personal' | 'roommates' | 'family' | 'trip';

export type TransactionType = 'expense' | 'income' | 'transfer' | 'settlement';

export type SplitType = 'none' | 'equal' | 'percentage' | 'custom' | 'single';

export type MemberRole = 'owner' | 'admin' | 'member';

export type PaymentMethod = 'UPI' | 'Cash' | 'Card' | 'Net Banking' | 'Other';

export type PaymentStatus = 'paid' | 'pending' | 'failed';

export interface CurrencyMetadata {
  code: CurrencyCode;
  name: string;
  symbol: string;
  minorUnits: number; // Exponent: e.g. 2 for INR (100 paise), 0 for JPY (1 yen), 3 for KWD (1000 fils)
  locale: string;
  sampleFormatted: string;
}

export interface Member {
  id: string;
  name: string;
  email?: string;
  avatarColor?: string;
  isCurrentUser?: boolean;
  role?: MemberRole;
  upiId?: string;
}

export interface SplitShare {
  memberId: string;
  shareMinorUnits: number; // Integer minor units in space base currency
  percentage?: number; // Visual indicator e.g. 33.3%
}

export interface Transaction {
  id: string;
  spaceId: string;
  creatorId: string;
  title: string; // Merchant or item description
  type: TransactionType;
  category: string;
  amount: number; // Strictly integer minor units (paise for INR, cents for USD, etc.)
  date: string; // YYYY-MM-DD
  payerId: string; // Member who disbursed the money
  paidToId?: string; // Recipient member for transfer or settlement
  paymentMethod?: PaymentMethod;
  paymentStatus?: PaymentStatus;
  paymentApp?: string; // Package name or known app identifier
  paymentAppLabel?: string; // User-facing app label e.g. "Google Pay"
  upiPayeeVpa?: string; // Recipient VPA
  upiPayeeName?: string; // Recipient Name
  paymentAttemptedAt?: string;
  paymentConfirmedAt?: string;
  receiptUrl?: string; // Receipt capture image / thumbnail preview
  splitType?: SplitType;
  splits?: SplitShare[];
  notes?: string;
  // Immutable ledger reversals
  isReversal?: boolean;
  reversesTransactionId?: string;
  isReversed?: boolean;
  reversedAt?: string;
  reversedBy?: string;
  // Converted currency metadata (if entered in a different currency)
  originalCurrency?: CurrencyCode;
  originalAmountMinorUnits?: number;
  exchangeRateBasisPoints?: number; // e.g. 10000 = 1.0000
  // Optimistic concurrency sequence
  version?: number;
  isCloudConfirmed?: boolean;
  createdAt: string;
}

export interface Space {
  id: string;
  ownerId: string;
  name: string;
  mode: SpaceMode;
  currency: CurrencyCode; // Space base currency
  startingBalance: number; // Integer minor units
  memberIds: string[];
  members: Member[];
  version?: number;
  isArchived?: boolean;
  createdAt: string;
  updatedAt: string;
  // Authoritative cloud verification tracking
  isCloudConfirmed?: boolean;
  isProvisional?: boolean;
  source?: 'cloud-authoritative' | 'local-provisional';
}

export interface UserProfile {
  userId: string;
  email?: string;
  displayName: string;
  primaryMode: SpaceMode;
  activeSpaceId: string;
  currency: CurrencyCode;
  createdAt: string;
}

export interface ActualBalanceBreakdown {
  startingBalance: number;
  receivedIncome: number;
  paidExpenses: number;
  incomingTransfers: number;
  outgoingTransfers: number;
  actualBalance: number;
}

export interface MemberBalance {
  memberId: string;
  memberName: string;
  // Expense consumption (Share) — strictly consumption of group expenses
  totalExpenseShareMinorUnits: number;
  totalExpensePaidMinorUnits: number;
  // Settlement transfers
  totalSettlementPaidMinorUnits: number;
  totalSettlementReceivedMinorUnits: number;
  // Total aggregations
  totalPaidMinorUnits: number;
  totalOwedMinorUnits: number;
  netBalanceMinorUnits: number; // Positive: is owed money. Negative: owes money.
}

export interface DebtSettlement {
  fromMemberId: string;
  fromMemberName: string;
  toMemberId: string;
  toMemberName: string;
  amountMinorUnits: number;
}

export interface CategoryBreakdown {
  category: string;
  amountMinorUnits: number;
  percentage: number;
  count: number;
  type: TransactionType;
}

export interface AuditLog {
  id: string;
  spaceId: string;
  action:
    | 'TRANSACTION_CREATED'
    | 'TRANSACTION_REVERSED'
    | 'SETTLEMENT_RECORDED'
    | 'SPACE_ARCHIVED'
    | 'SPACE_UNARCHIVED'
    | 'MEMBER_ADDED'
    | 'SPACE_UPDATED'
    | 'PAYMENT_STATUS_CHANGED';
  actorId: string;
  actorName: string;
  targetType: 'transaction' | 'space' | 'member' | 'settlement';
  targetId: string;
  details: string;
  timestamp: string;
}
