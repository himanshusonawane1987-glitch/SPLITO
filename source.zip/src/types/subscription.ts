/**
 * SPLITO Subscription & Monetization Types
 * Master Specification v1.5
 */

export type SubscriptionPlan = 'free' | 'pro';

export type SubscriptionBillingCycle = 'monthly' | 'yearly';

export type SubscriptionStatus =
  | 'none'
  | 'trial'
  | 'active'
  | 'grace_period'
  | 'cancelled'
  | 'expired';

export interface PlanPricing {
  cycle: SubscriptionBillingCycle;
  pricePaise: number; // Integer minor units (e.g. 5900 = ₹59, 59900 = ₹599)
  formattedPrice: string;
  interval: string;
  trialDays: number;
  savingsNote?: string;
}

export const SUBSCRIPTION_PRICING: Record<SubscriptionBillingCycle, PlanPricing> = {
  monthly: {
    cycle: 'monthly',
    pricePaise: 5900,
    formattedPrice: '₹59',
    interval: 'month',
    trialDays: 30
  },
  yearly: {
    cycle: 'yearly',
    pricePaise: 59900,
    formattedPrice: '₹599',
    interval: 'year',
    trialDays: 30,
    savingsNote: 'Save 15% compared to monthly'
  }
};

export interface UserSubscription {
  plan: SubscriptionPlan;
  status: SubscriptionStatus;
  billingCycle?: SubscriptionBillingCycle;
  trialStartDate?: string;
  trialEndDate?: string;
  currentPeriodStart?: string;
  currentPeriodEnd?: string;
  autoRenew: boolean;
  cancelledAt?: string;
  paymentGateway?: 'google_play' | 'direct' | 'manual';
  orderId?: string;
  purchaseToken?: string;
  updatedAt: string;
}

export interface SubscriptionEntitlement {
  isPro: boolean;
  plan: SubscriptionPlan;
  status: SubscriptionStatus;
  statusLabel: string;
  daysRemainingInTrial?: number;
  expiresAtFormatted?: string;
  canExportPdfWithoutAds: boolean;
  hasAdvancedAnalytics: boolean;
  hasAdvancedSpendingGuard: boolean;
  hasExtendedExports: boolean;
  isAdFree: boolean;
}

export interface ConsentPreferences {
  termsAndPrivacyAccepted: boolean;
  termsAcceptedDate?: string;
  termsVersion: string;
  analyticsConsent: boolean;
  marketingConsent: boolean;
  adPersonalizationConsent: boolean; // Note: Even if true, SPLITO never shares financial records
  updatedAt: string;
}
