export interface CapacitorConfig {
  appId: string;
  appName: string;
  webDir: string;
  server?: {
    androidScheme?: string;
  };
  plugins?: {
    [pluginName: string]: Record<string, any>;
  };
}

const config: CapacitorConfig = {
  appId: 'ai.hisaab.app',
  appName: 'HISAAB - Smart Financial Ledger & Expense Manager',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  },
  plugins: {
    FirebaseAuthentication: {
      skipNativeAuth: false,
      providers: ['google.com']
    }
  }
};

export default config;
